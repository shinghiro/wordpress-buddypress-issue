<?php 
// **********************************
// Header (main-wrap > container > content)
// **********************************
get_header();
include_once(TEMPLATEPATH .'/not-found.php');?>
</main><?php // end of .content
// **********************************
// Footer
// **********************************
get_footer();