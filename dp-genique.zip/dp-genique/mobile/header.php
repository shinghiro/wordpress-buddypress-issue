<?php
/**
 * Original codes for head section
 * @return [type] [description]
 */
function dp_action_custom_head(){
	global $options;
	$code = isset($options['custom_head_content_mobile']) && !empty($options['custom_head_content_mobile']) ? $options['custom_head_content_mobile'] : '';
	$code = str_replace(array("\r\n","\r","\n","\t"), '', $code);
	echo $code;
}
add_action('dp_custom_head', 'dp_action_custom_head');
/**
 * Insert meta tags
 * @return [type] [description]
 */
function dp_action_insert_meta(){
	dp_meta_kw_desc();
	dp_show_ogp();
	dp_show_canonical();
}
add_action('dp_insert_meta', 'dp_action_insert_meta');

// Start header
global $options, $def_options, $ARCHIVE_STYLE, $CURRENT_POST_TYPE, $ELEMENTS_SHOW, $CONTAINER_EDGE, $IS_WOOCOMMERCE;
?>
<!DOCTYPE html><html <?php language_attributes(); ?>><?php
if ( is_singular() ) : ?>
<head prefix="og: http://ogp.me/ns# fb: http://ogp.me/ns/fb# article: http://ogp.me/ns/article#"><?php
else: ?>
<head prefix="og: http://ogp.me/ns# fb: http://ogp.me/ns/fb# blog: http://ogp.me/ns/website#"><?php
endif; ?>
<meta charset="utf-8" /><meta name="viewport" content="width=device-width,initial-scale=1,minimum-scale=1,user-scalable=yes,viewport-fit=cover" /><?php
if ( (is_front_page() || is_archive()) && is_paged()) : ?>
<meta name="robots" content="noindex,follow" /><?php
elseif ( is_singular() ) :
	if (get_post_meta(get_the_ID(), 'dp_noindex', true) &&
		get_post_meta(get_the_ID(), 'dp_nofollow', true) &&
		get_post_meta(get_the_ID(), 'dp_noarchive', true)) :?>
<meta name="robots" content="noindex,nofollow,noarchive" /><?php
	elseif (get_post_meta(get_the_ID(), 'dp_noindex', true) &&
		get_post_meta(get_the_ID(), 'dp_nofollow', true) &&
		!get_post_meta(get_the_ID(), 'dp_noarchive', true)) : ?>
<meta name="robots" content="noindex,nofollow" /><?php
	elseif (get_post_meta(get_the_ID(), 'dp_noindex', true) &&
		!get_post_meta(get_the_ID(), 'dp_nofollow', true) &&
		!get_post_meta(get_the_ID(), 'dp_noarchive', true)) :?>
<meta name="robots" content="noindex" /><?php
	elseif (!get_post_meta(get_the_ID(), 'dp_noindex', true) &&
		get_post_meta(get_the_ID(), 'dp_nofollow', true) &&
		get_post_meta(get_the_ID(), 'dp_noarchive', true)) :?>
<meta name="robots" content="nofollow,noarchive" /><?php
	elseif (!get_post_meta(get_the_ID(), 'dp_noindex', true) &&
		!get_post_meta(get_the_ID(), 'dp_nofollow', true) &&
		get_post_meta(get_the_ID(), 'dp_noarchive', true)) :?>
<meta name="robots" content="noarchive" /><?php
	elseif (!get_post_meta(get_the_ID(), 'dp_noindex', true) &&
		get_post_meta(get_the_ID(), 'dp_nofollow', true) &&
		!get_post_meta(get_the_ID(), 'dp_noarchive', true)) :?>
<meta name="robots" content="nofollow" /><?php
	elseif (get_post_meta(get_the_ID(), 'dp_noindex', true) &&
		!get_post_meta(get_the_ID(), 'dp_nofollow', true) &&
		get_post_meta(get_the_ID(), 'dp_noarchive', true)) :?>
<meta name="robots" content="noindex,noarchive" /><?php
	endif;
endif;

/**
 * Add meta tags
 */
do_action('dp_insert_meta');

/**
 * WordPress header
 */
wp_head();

/**
 * Custom header
 */
do_action('dp_custom_head');?>
</head><?php

/**
 * Main Body
 */
// class for body tag
$body_class = 'mb-theme';
$header_bar_class = 'header_bar mb';
$pjax_container_class = 'dp-pjax-container';

$arr_http = array('http:','https:');

/**
 * wow effect
 */
$wow_title_css = '';
$wow_desc_css = '';
$attr_delay = '';
$attr_delay_1 = '';
$attr_delay_2 = '';
$data_attr_wow = '';
$hd_title_data	= '';
$hd_subt_data = '';
$hd_desc_data	= '';
$hd_title_plx_class	= '';
$hd_subt_plx_class = '';
$hd_desc_plx_class = '';
$wow_footer_item = '';

if ( !( isset($options['disable_wow_js_mobile']) && !empty($options['disable_wow_js_mobile']) ) ) {
	$data_attr_wow = ' data-use-wow="true"';

	$wow_title_css = ' wow fadeInDown';
	$wow_desc_css = ' wow fadeInUp';
	$attr_delay_1 = ' data-wow-delay="0.1s"';
	$attr_delay_2 = ' data-wow-delay="0.3s"';

	$hd_title_data = ' data-wow-delay="0.4s"';
	$hd_desc_data = ' data-wow-delay="0.7s"';
	$hd_subt_data = ' data-wow-delay=" 1.2s"';
	$hd_title_plx_class = ' wow fadeInDown';
	$hd_desc_plx_class = ' wow fadeInUp';
	$hd_subt_plx_class = ' wow fadeInLeft';
	$wow_footer_item = ' wow fadeInUp';
} else {
	$data_attr_wow = ' data-use-wow="false"';
}

// params
$cur_page_class = ' not-home';
$container_class = 'dp-container mb';
$bg_img = '';

// Selector for body tag
if (is_front_page() && !is_paged()) {
	$body_class .= ' home';
} else {
	$body_class .= ' not-home';
}

// share count JS
if ( isset($options['disable_sns_share_count']) && !empty($options['disable_sns_share_count'])) {
	$body_class .= ' no-sns-count';
}

// Front page
if (is_front_page() ) {
	if (!is_paged() && !isset( $_REQUEST['q'])) {
		$cur_page_class = ' home';
	} elseif (is_paged()) {
		$cur_page_class = ' home paged';
	}
}

/**
 * Site main title
 */
$site_title = '';
if ( isset( $options['h1_title_as_what'] ) && $options['h1_title_as_what'] !== 'image') {
	$site_title = '<h1 class="hd-title txt' . $wow_title_css . '"' . $attr_delay_1 . '><a href="' . home_url('/') . '" title="' . esc_attr(get_bloginfo('name')) . '">' . dp_h1_title() . '</a></h1>';
} else {
	if (isset($options['dp_title_img_mobile']) && !empty($options['dp_title_img_mobile'])){
		$logo_img_url = $options['dp_title_img_mobile'];
		$site_title = '<h1 class="hd-title img' . $wow_title_css . '"' . $attr_delay_1 . '><a href="' . home_url('/') . '" title="' . esc_attr(get_bloginfo('name')) . '"><img src="' . $logo_img_url . '" alt="' . esc_attr( dp_h1_title() ) . '" /></a></h1>';
	}
}

/**
 * SNS share count setting
 */
$data_share_cache = ' data-ct-sns-cache="false"';
if (isset($options['share_count_cache']) && !empty($options['share_count_cache'])){
	$data_share_cache = ' data-ct-sns-cache-time="' . $options['share_count_cache_time'] . '"';
}

/**
 * use pjax?
 */
$data_attr_pjax = '';
if ( !( isset($options['disable_pjax_mobile']) && !empty($options['disable_pjax_mobile']) ) ) {
	$data_attr_pjax = ' data-use-pjax="true"';
	if (!(isset($options['disable_pjax_transition_mobile']) && !empty($options['disable_pjax_transition_mobile']))){
		$data_attr_pjax .= ' data-pjax-transition="true"';
	}
	if (isset($options['ignore_pjax_class']) && !empty($options['ignore_pjax_class'])){
		$data_attr_pjax .= ' data-pjax-ignore-class="' . $options['ignore_pjax_class'] . '"';
	}
}

/**
 * Fixed header bar?
 */
if ( isset($options['header_bar_pos_fixed_mobile']) && !empty($options['header_bar_pos_fixed_mobile']) ) {
	$pjax_container_class .= ' header_bar_pos_fixed';
	$header_bar_class .= ' pos_fixed';
}

/**
 * Piled layer exists
 */
if ( isset( $options['header_bar_add_layer'] ) && !empty( $options['header_bar_add_layer'] ) ) {
	$header_bar_class .= ' piled_layer';
}

/**
 * Content header
 */
$hd_title_show 	= true;
$hd_title_code 	= $hd_sub_title_code = '';
$page_desc = '';
$page_class	= '';
$meta_code = '';
$ct_hd_code = '';
$ct_hd_class = 'ct-hd';
$ct_whole_class = 'ct-whole';
$plx_bg_img_class = ' no_bgimg';
$eyecatch_to_bg = '';
$term_color = $term_video = '';
$hd_bg_img = $hd_bg_img_inner_code = '';
$edge_svg = '';

if ( !is_home() && !$IS_WOOCOMMERCE ) {

	// breadcrumb flag
	if ( !$ELEMENTS_SHOW['breadcrumb'] ){
		$ct_hd_class .= ' no_breadcrumb';
		$cur_page_class .= ' no_breadcrumb';
	}

	// Category or tag archive
	if ( ( is_category() || is_tag() ) && !is_search() ) {

		global $ARCHIVE_STYLE;

		if ( isset( $ARCHIVE_STYLE ) && is_array($ARCHIVE_STYLE) ) {

			$hd_sub_title_code = isset( $ARCHIVE_STYLE['sub_title'] ) && !empty( $ARCHIVE_STYLE['sub_title'] ) ? '<div class="sub-title" role="none">' . esc_html( $ARCHIVE_STYLE['sub_title'] ) . '</div>' : '';

			$hd_bg_img = isset( $ARCHIVE_STYLE['image'] ) && !empty( $ARCHIVE_STYLE['image'] ) ? esc_attr($ARCHIVE_STYLE['image']) : '';

			if ( !empty($hd_bg_img) ) {

				$hd_bg_img = ' style="--bg-image:url(\'' . $hd_bg_img . '\');"';
				$hd_bg_img_inner_code = '<div class="inner-bg mb" role="img"' . $hd_bg_img . '></div>';
				$plx_bg_img_class = ' bgimg';
			}

			// Category Color
			if ( $plx_bg_img_class == ' bgimg' ) {

				if ( $options['page_header_bgimg_overlay'] === 'term_color' ) {

					if ( isset($ARCHIVE_STYLE['color']) && !empty($ARCHIVE_STYLE['color']) ){

						$term_color = ' term-color' . $ARCHIVE_STYLE['term_id'] . ' ' . $options['page_header_bgimg_overlay'];
					}
				}
			} else {

				if ( $options['page_header_bgcolor_overlay'] === 'term_color' || $options['page_header_bgcolor_overlay'] === 'term_color_gradient' ) {

					if ( isset($ARCHIVE_STYLE['color']) && !empty($ARCHIVE_STYLE['color']) ){
						$term_color = ' term-color' . $ARCHIVE_STYLE['term_id'] . ' ' . $options['page_header_bgcolor_overlay'];
					}
				}
			}
		}
	}

	// Single pge
	if ( is_singular() ) {

		global $SINGLE_META, $page;

		$this_id = get_the_ID();
		$page_class = ' singular';
		$single_flag = '';

		// Base title
		$hd_title_code = the_title_attribute('before=&after=&echo=0');
		if  ( $page > 1 ) {
			$hd_title_code .= ' - ' . $page;
		}

		// Single or static page
		if ( $CURRENT_POST_TYPE === 'post' || $CURRENT_POST_TYPE === 'page' || $CURRENT_POST_TYPE === $options['news_cpt_slug_id'] ) {

			// Eyecatch to background image
			$eyecatch_to_bg = get_post_meta( $this_id, 'dp_eyecatch_to_bg', true );

			if ( (bool)$eyecatch_to_bg ) {
				$eyecatch_to_bg = ' body-bgimg';
			} else {
				$eyecatch_to_bg = '';
			}
			// Show eyecatch upper the title
			if( has_post_thumbnail() && $ELEMENTS_SHOW['eyecatch_header'] && $ELEMENTS_SHOW['eyecatch_entry_top'] ) {
				$post_img = get_post_thumbnail_id();
				$post_img = wp_get_attachment_image_src($post_img, 'full', true);
				$post_img = str_replace($arr_http,'',$post_img[0]);
				$hd_bg_img = ' style="--bg-image:url(\'' . $post_img . '\')"';
				$hd_bg_img_inner_code = '<div class="inner-bg mb" role="img"' . $hd_bg_img . '></div>';
				$plx_bg_img_class = ' bgimg';
			}

			// Title
			if ( !$ELEMENTS_SHOW['single_post_title'] ) {

				$hd_title_code = '';

				if ( !$ELEMENTS_SHOW['eyecatch_header'] ) {
					$hd_title_show = false;
					$header_bar_class .= ' no_ct_hd';
					$cur_page_class .= ' no_ct_hd';
				}
			}
		}

		// Post title
		$hd_title_code = !empty( $hd_title_code ) && $hd_title_show ? '<h2 class="hd-title single-title' . $hd_title_plx_class . '"' . $hd_title_data . '><span>' . $hd_title_code . '</span></h2>' : '';


		// Single post
		if ( $CURRENT_POST_TYPE === 'post' ) {

			global $post;

			// Category color
			if ( $plx_bg_img_class == ' bgimg' ) {

				if ( $options['page_header_bgimg_overlay'] === 'term_color' ) {

					if ( isset($SINGLE_META['arr_first_cat_color'] ) && !empty( $SINGLE_META['arr_first_cat_color'] ) ) {
						$term_color = ' term-color' . $SINGLE_META['arr_first_cat_color'][1] . ' ' . $options['page_header_bgimg_overlay'];
					}
				}
			} else {

				if ( $options['page_header_bgcolor_overlay'] === 'term_color' || $options['page_header_bgcolor_overlay'] === 'term_color_gradient' ) {

					if ( isset($SINGLE_META['arr_first_cat_color'] ) && !empty( $SINGLE_META['arr_first_cat_color'] ) ) {
						$term_color = ' term-color' . $SINGLE_META['arr_first_cat_color'][1] . ' ' . $options['page_header_bgcolor_overlay'];
					}
				}
			}

			// Category name
			if ( !empty( $SINGLE_META['cat_top_code'] ) ) {
				$hd_sub_title_code = '<div class="sub-title meta-cat" role="none">' . $SINGLE_META['cat_top_code'] . '</div>';
			}
		}

		// Date
		if ( !empty( $SINGLE_META['date_top'] ) ) {
			$eng_date = '';
			if ((bool)$options['date_eng_mode']) {
				$eng_date = ' eng';
			}
			$meta_code = '<div class="meta meta-date' . $eng_date . '">' . $SINGLE_META['date_top'] . $SINGLE_META['last_update'] . '</div>';
		}
		// Author
		$meta_code .= $SINGLE_META['author_top_code'];
		// Views
		$meta_code .= $SINGLE_META['views_top_code'];
		// Time for reading
		$meta_code .= $SINGLE_META['time_for_reading'];
		// edit link
		$meta_code .= $SINGLE_META['edit_link'];

		// Whole meta info
		if ( !empty($meta_code) ) {
			$meta_code = '<div class="hd-meta meta-info' . $hd_desc_plx_class . '"' . $hd_desc_data . '>' . $meta_code . '</div>';
		} else {
			if ( empty($hd_title_code) && empty($page_desc) ) {
				$page_class .= ' no-data';
			}
		}

	} else {
		// Get title description (create_title_desc.php)
		$arr_title = dp_current_page_title();
		// Not single page
		$hd_title_code = '<h2 class="hd-title' . $hd_title_plx_class . '"' . $hd_title_data . '><span>' . $arr_title['title'] . '</span></h2>';
		if ( !empty( $arr_title['desc'] ) ) {
			$page_desc = '<div class="hd-meta title-desc meta-info' . $hd_desc_plx_class . '"' . $hd_desc_data . ' role="note">' . $arr_title['desc'] . '</div>';
		}
	}

	// Bottom edge shape (SVG)
	if ( isset( $options['page_header_bottom_edge'] ) && $options['page_header_bottom_edge'] !== 'none' ){

		$ct_whole_class .= ' edge_shape_' . $options['page_header_bottom_edge'] . '_btm';
		$CONTAINER_EDGE = ' edge_' . $options['page_header_bottom_edge'];

		// Only wave 1, wave 2 and curve 2 shapes
		if ( $options['page_header_bottom_edge'] === 'wave1' || $options['page_header_bottom_edge'] === 'wave2' || $options['page_header_bottom_edge'] === 'curve1' || $options['page_header_bottom_edge'] === 'curve2' ) {

			$edge_svg = $options['page_header_bottom_edge'];
			$edge_svg_class = 'svg_edge pos_btm';

			if ( $options['page_header_bottom_edge_piled_layer'] ) {
				$edge_svg_class .= ' piled_layer';
				$edge_svg = '<svg class="' . $edge_svg_class . '"><use xlink:href="#svg_edge_' . $edge_svg . '__layer1" /><use xlink:href="#svg_edge_' . $edge_svg . '__layer2" /><use xlink:href="#svg_edge_' . $edge_svg . '__layer3" /></svg>';
			} else {
				$edge_svg = '<svg class="' . $edge_svg_class . '"><use xlink:href="#svg_edge_' . $edge_svg . '" /></svg>';
			}
		}
	}

	// Content header additional classes
	$ct_hd_class .= $plx_bg_img_class . $eyecatch_to_bg;
	$ct_whole_class .= $plx_bg_img_class . $eyecatch_to_bg . $cur_page_class . $page_class . $term_color;

	// Display
	if ( (bool)$hd_title_show ) {
		$ct_hd_code = '<section id="ct-hd" class="' . $ct_hd_class . $CONTAINER_EDGE . '"><div id="ct-whole" class="' . $ct_whole_class . '">' . $hd_bg_img_inner_code . '<div class="hd-content">' . $hd_title_code . $page_desc . $meta_code . '</div>' . $hd_sub_title_code . $edge_svg . '</div></section>';
	}
}

/**
 * Site container class
 */
$container_class .= $cur_page_class;?>
<body <?php body_class($body_class); echo $data_attr_pjax . $data_attr_wow . $data_share_cache; ?>><?php

/**
 *  inject code immediately following the opening <body> tag. * WP 5.2 over
 */
if ( function_exists( 'wp_body_open' ) ) {
	wp_body_open();
} else {
	do_action( 'wp_body_open' );
}

/**
 * Site header
 */?>
<header id="header_bar" class="<?php echo $header_bar_class; ?>"><?php

/**
 * Header main title
 */
echo $site_title;?>
</header>
<div id="dp-pjax-wrapper" aria-live="polite"><div class="<?php echo $pjax_container_class; ?>"><?php

/**
 * site banner
 */
dp_banner_contents();

/**
 * Content header
 */
echo $ct_hd_code;?>
<div id="container" class="<?php echo $container_class . $CONTAINER_EDGE; ?>"><?php

/**
 * Breadcrumb
 */
dp_breadcrumb();

/**
 * Container widget
 */
if ( !is_404() && is_active_sidebar('widget-container-top-mb') ) {
	// get the widget
	ob_start();
	dynamic_sidebar( 'widget-container-top-mb' );
	$widget_container_top_content = ob_get_contents();
	ob_end_clean();

	if ( !empty( $widget_container_top_content ) ) {
		echo '<div class="widget-container top mobile' . $cur_page_class . '">' . $widget_container_top_content .'</div>';
	}
}