<?php 
/**
 * Header
 */
include_once( TEMPLATEPATH . '/' . DP_MOBILE_THEME_DIR . '/header.php' );

/**
 * show posts
 */
// Check the query
if (isset( $_REQUEST['q'] )) {
	// Google Custom Search?>
<gcse:searchresults-only></gcse:searchresults-only><?php
} else {
	if ( isset($_GET['s']) && empty($_GET['s']) ) { ?>
<div class="entry not-found"><div><?php _e( 'Please enter a search word.', 'DigiPress'); ?></div></div><?php
	} else {

		if ( have_posts() ) {
			require_once( DP_THEME_DIR . '/inc/scr/article-loop.php' );
			$loop_code = dp_article_loop( $posts );
			echo $loop_code;
		} else {?>
<div class="entry not-found"><?php
			printf( __( 'Sorry, but nothing matched your search terms : %s.', 'DigiPress'), esc_html($_GET['s']) );?>
</div><?php
		}	// End of have_posts()
	}	// End of isset($_GET['s']) && empty($_GET['s'])
}	// End of isset( $_REQUEST['q'] )

/**
 * Footer
 */
include_once( TEMPLATEPATH . '/' . DP_MOBILE_THEME_DIR . '/footer.php' );