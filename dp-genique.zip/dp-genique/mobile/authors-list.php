<?php
// Import require functions
require_once( DP_THEME_DIR . '/inc/scr/generator/get_author_info.php' );
/**
 * Header
 */
include_once( TEMPLATEPATH . '/' . DP_MOBILE_THEME_DIR . '/header.php' );

// wow.js
$wow_author_item = '';
if (!(bool)$options['disable_wow_js_mobile']){
	$wow_author_item	= ' wow fadeInDown';
}

// Author params in current page
$number = 30;
$paged 	= (get_query_var('paged')) ? get_query_var('paged') : 1;
$offset = ($paged - 1) * $number;
$exclude = isset( $options['exclude_userid_in_authors_list']) ? explode(",",$options['exclude_userid_in_authors_list'] ) : array();
$arr_authors = array(
	'offset' => $offset,
	'number' => $number,
	'capability' => array( 'edit_posts' ),
	'exclude' => $exclude
);
// Capability queries were only introduced in WP 5.9.
if ( version_compare( $GLOBALS['wp_version'], '5.9-alpha', '<' ) ) {
    $arr_authors['who'] = 'authors';
    unset( $arr_authors['capability'] );
}
$users 		= get_users();
$query 		= get_users($arr_authors);
$total_users = count($users) - count($exclude);
$total_query = count($query);
$total_pages = $total_users % $number !== 0 ? ($total_users / $number) + 1 : $total_users / $number;

/**
 * Article area start
 */
while ( have_posts()) : the_post(); ?>
<article id="<?php echo $post_type.'-'.get_the_ID(); ?>" <?php post_class('single-article'); ?>><?php
	/**
	 * Main entry
	 */?>
<div class="entry entry-content"><?php
	// Content
	the_content();?>
</div><?php 	// End of class="entry"
/**
 * Authors Lists
 */?>
<div class="authors-list">
<ul class="authors_ul"><?php
	// Params
	$args = array('return_array'=> true,
				'is_microdata' 	=> false,
				'avatar_size' 	=> 300);
	foreach ( $query as $q ) :
		$args['user_id'] = $q->ID;
		$arr_author 	= dp_get_author_info($args);

		$author_code = '';
		if ( isset($arr_author['authors_list_ref_url']) && !empty($arr_author['authors_list_ref_url']) ) {
			if ( isset($arr_author['open_new_tab_ref_url']) && !empty($arr_author['open_new_tab_ref_url']) ) {
				$author_code = '<a href="' . $arr_author['authors_list_ref_url'] . '" rel="author" class="author_img" target="_blank">';
			} else {
				$author_code = '<a href="' . $arr_author['authors_list_ref_url'] . '" rel="author" class="author_img">';
			}
			$author_code .= $arr_author['avatar_img'] . '</a>';
		} else {
			$author_code = $arr_author['profile_img'];
		}
		$author_code .= $arr_author['author_role'].'<a href="'.$arr_author['author_posts_url'].'">'.$arr_author['author_name'].'</a>';?>
<li class="author_item clearfix<?php echo $wow_author_item; ?>"><?php echo $author_code; ?></li><?php
	endforeach;?>
</ul>
</div><?php // End of .authors_list_area
	/**
	 * Page navigation
	 */
	if ($total_users > $total_query) :?>
<nav class="navigation clearfix"><div class="dp-pagenavi clearfix"><?php
	  $current_page = max(1, get_query_var('paged'));
	  $arr_pages = paginate_links(array(
			'base' => get_pagenum_link(1) . '%_%',
			'format' => '/page/%#%/',
			'current' => $current_page,
			'total' => $total_pages,
			'prev_next'    => false,
			'type'         => 'array',
			'before_page_number' => '<span class="r-wrap">',
			'after_page_number' => '</span>'
	    ));
	foreach ($arr_pages as $key => $page_link) {
		echo $page_link;
	}?>
</div></nav><?php
	endif;	// End of $total_users > $total_query?>
</article><?php
endwhile;
/**
 * Footer
 */
include_once( TEMPLATEPATH . '/' . DP_MOBILE_THEME_DIR . '/footer.php' );