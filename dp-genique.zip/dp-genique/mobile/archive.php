<?php 
/**
 * Header
 */
include_once( TEMPLATEPATH .'/' . DP_MOBILE_THEME_DIR.'/header.php' );

/**
 * Show main content
 */
if ( $ARCHIVE_STYLE['children'] ) {

	// If sub categories are shown
	require_once( DP_THEME_DIR . '/inc/scr/parts/show_child_terms.php' );
	dp_show_child_terms();

}
else if (have_posts()) {
	require_once( DP_THEME_DIR . '/inc/scr/article-loop.php' );
	$loop_code = dp_article_loop( $posts );
	echo $loop_code;
}
else {
	// Not found...
	include_once( TEMPLATEPATH . '/not-found.php' );
}	// End of have_posts()

/**
 * Footer
 */
include_once( TEMPLATEPATH . '/' . DP_MOBILE_THEME_DIR . '/footer.php' );