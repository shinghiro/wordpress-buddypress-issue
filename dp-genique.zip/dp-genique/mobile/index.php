<?php 
/**
 * Header (main-wrap > container > content)
 */
include_once(TEMPLATEPATH .'/'.DP_MOBILE_THEME_DIR.'/header.php');

/**
 * show posts
 */
if ( $options['top_page_main_content'] === 'page' ) {
	// Display the specific static page
	$top_static_page = get_post( (int)$options['specific_page_id'] );
	$post_content = apply_filters( 'the_content', $top_static_page->post_content );
	echo '<article id="page-' . $options['specific_page_id'] . '" class="single-article as-home"><div class="entry entry-content">' . $post_content . '</div></article>';
} else {
	if ( have_posts() ) {
		require_once( DP_THEME_DIR . '/inc/scr/article-loop.php' );
		$loop_code = dp_article_loop( $posts );
		echo $loop_code;
	}
}

/**
 * Footer
 */
include_once( TEMPLATEPATH .'/'.DP_MOBILE_THEME_DIR.'/footer.php' );