<?php
// Whole code
$footer_bar_code = '';

// Bottom bar class
$footer_bar_class = 'footer_bar';

/**
 * Slide menu position
 */
$sl_menu_align = ' mleft';
if (isset($options['slide_menu_position_mobile']) && $options['slide_menu_position_mobile'] === 'right') {
	$sl_menu_align = ' mright';
}

/**
 * Global menu
 */
$global_menu_code = '';
$menu_class = 'main_slide_menu';
if (isset($options['disable_pjax']) && !empty($options['disable_pjax'])){
	$menu_class .= ' no_pjax';
}
if ( function_exists('wp_nav_menu') && has_nav_menu('top_menu_mobile') ) {
	ob_start();
	// Show menu
	wp_nav_menu(array(
		'theme_location'=> 'top_menu_mobile',
		'container'	=> '',
		'after_only_parent_link' => '',
		'menu_id'	=> 'main_slide_menu',
		'menu_class'=> $menu_class,
		'fallback_cb'=> function(){return;},
		'walker'	=> new dp_custom_menu_walker()
	));
	$global_menu_code = ob_get_contents();
	$global_menu_code = '<nav id="slide_menu_nav" class="slide_menu_nav">' . $global_menu_code . '</nav>';
	ob_end_clean();
}

/**
 * SNS icon links
 * From sns_contact_icons.php
 */
$sns_code = dp_sns_contact_icons( 'header' );

/**
 * Tel number
 */
$tel_code = '';
if ( isset($options['global_menu_tel']) && !empty($options['global_menu_tel']) ) {
	$tel_code = '<div class="menu_tel"><a href="tel:'.$options['global_menu_tel'].'" class="tel_a icon-phone"><span class="serif">'.$options['global_menu_tel'].'</span></a></div>';
}

/**
 * Search form
 */
$search_form = '';
if ( isset($options['global_menu_search_form']) && $options['global_menu_search_form'] !== 'none' ) {

	if ( $options['global_menu_search_form'] === 'gcs' ) {
		// Google Custom Search
		$search_form = '<div id="dp_hd_gcs"><gcse:searchbox-only></gcse:searchbox-only></div>';
	} else {
		/**
		 * Preset search form
		 */
		// Preset keywords
		$preset_phrase = isset( $options['global_menu_search_form_preset_kw_title'] ) && !empty( $options['global_menu_search_form_preset_kw_title'] ) ? $options['global_menu_search_form_preset_kw_title'] : '';
		$preset_words = isset( $options['global_menu_search_form_preset_kw'] ) && !empty( $options['global_menu_search_form_preset_kw'] ) ? $options['global_menu_search_form_preset_kw'] : '';

		// Defined at /scr/parts/search_form.php
		$search_form = dp_custom_search_form(false, array(
			'form_id' => 'menu_search_form',
			'show_input_title' => false,
			'param_cat' => false,
			'param_tag' => false,
			'param_type' => false,
			'param_range' => false,
			'preset_phrase' => $preset_phrase,
			'preset_words' => $preset_words)
		);
	}
}

/**
 * Slide panel
 */
if ( !empty( $global_menu_code ) || !empty( $sns_code ) || !empty( $tel_code ) || !empty( $search_form ) ){
	$global_menu_code = '<input type="checkbox" role="button" title="menu" class="hidden_elem" id="main_menu_flag"><label for="main_menu_flag" class="ftbar_btn ftbar_trigger for_menu" aria-hidden="true" title="menu"><div class="ftbtn_inner main_menu' . $sl_menu_align . '"><i class="menu_icon icon-spaced-menu"></i><span class="cap">' . __('Menu', 'DigiPress') . '</span></div></label><div class="modal_wrapper main_menu' . $sl_menu_align . '">' . $global_menu_code . $tel_code . $sns_code;
}


/**
 * Custom Bottom Bar or Default Bottom Bar?
 */
$search_menu_item = $prev_post_code = $next_post_code = '';


/**
 * Footer bar
 */
if ( isset($options['original_footer_bar_mobile']) && !empty($options['original_footer_bar_mobile']) ) {

	// Closure
	$global_menu_code .= !empty( $global_menu_code ) ? $search_form . '</div>' : '';

	// Custom Bottom Bar
	for($i = 1; $i < 6; ++$i ) {
		if ( isset($options['footer_bar_item_url_' . $i]) && !empty($options['footer_bar_item_url_' . $i]) ) {

			$external = isset($options['footer_bar_item_url_newtab_' . $i]) && !empty($options['footer_bar_item_url_newtab_' . $i]) ? ' target="_blank"' : '';

			$footer_bar_code .=  '<li class="ftbar_item"><a href="' . $options['footer_bar_item_url_' . $i] . '" class="ftbar_btn"' . $external . '><i class="menu_icon ' . $options['footer_bar_item_icon_' . $i] . '"></i><span class="cap">' . $options['footer_bar_item_heading_' . $i] . '</span></a></li>';
		}
	}

	if ( !empty( $footer_bar_code ) ) {
		$footer_bar_code = '<ul class="ftbar_ul">' . $footer_bar_code . '</ul>';
	}

} else {

	// Closure
	$global_menu_code .= !empty( $global_menu_code ) ? '</div>' : '';

	/**
	 * Search icon button
	 */
	if ( isset($options['global_menu_search_form']) && $options['global_menu_search_form'] !== 'none' ) {
		$search_menu_item = '<input type="checkbox" role="button" title="search" class="hidden_elem" id="search_form_flag"><label for="search_form_flag" class="ftbar_btn ftbar_trigger for_search" aria-hidden="true" title="search"><div class="ftbtn_inner search_form' . $sl_menu_align . '"><i class="menu_icon icon-search"></i><span class="cap">' . __('Search', 'DigiPress') . '</span></div></label><div class="modal_wrapper search_form">' . $search_form . '</div>';
	}

	/**
	 * Next / prev post link(Single page only)
	 * $prev_post, $next_post is defined in single.php
	 */
	if ( is_single() ){
		if ( isset( $prev_post ) && !empty( $prev_post ) ) {
			$nav_url = get_permalink($prev_post->ID);
			$prev_post_code = '<li class="ftbar_item"><a href="'.$nav_url.'" class="ftbar_btn" role="button"><i class="menu_icon icon-left-light"></i><span class="cap">'.__('Prev', 'DigiPress').'</span></a></li>';
		}
		if ( isset( $next_post ) && !empty( $next_post ) ) {
			$nav_url = get_permalink($next_post->ID);
			$next_post_code = '<li class="ftbar_item"><a href="'.$nav_url.'" class="ftbar_btn"><i class="menu_icon icon-right-light"></i><span class="cap">'.__('Next', 'DigiPress').'</span></a></li>';
		}
	}


	// Bottom bar code
	$footer_bar_code = '<ul class="ftbar_ul">' . $prev_post_code . '<li class="ftbar_item"><a href="' . home_url() . '" class="ftbar_btn gohome"><i class="menu_icon icon-home"></i><span class="cap">' . __('Home', 'DigiPress') . '</span></a></li><li class="ftbar_item"><div id="gotop" class="ftbar_btn" role="button"><i class="menu_icon mobile icon-up-open"></i><span class="cap">' . __('Go top', 'DigiPress') . '</span></div></li>' . $next_post_code . '</ul>';
}


// Additional buttom bar class
if ( !empty( $global_menu_code ) ) {
	if ( !empty($search_menu_item) ) {
		$footer_bar_class .= ' has_menu_sform';
	} else {
		$footer_bar_class .= ' has_menu';
	}
} else {
	if ( !empty($search_menu_item) ) {
		$footer_bar_class .= ' has_sform';
	}
}



// Build the bottom bar
$footer_bar_code = $global_menu_code . $search_menu_item . '<div id="footer_bar" class="' . $footer_bar_class . $sl_menu_align . '">' . $footer_bar_code . '</div>';

/**
 * Show bottom bar
 */
echo $footer_bar_code;