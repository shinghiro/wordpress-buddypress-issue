<?php
include_once( TEMPLATEPATH . '/' . DP_MOBILE_THEME_DIR . '/header.php' );
include_once( TEMPLATEPATH . '/not-found.php' );
include_once( TEMPLATEPATH . '/' . DP_MOBILE_THEME_DIR . '/footer.php' );