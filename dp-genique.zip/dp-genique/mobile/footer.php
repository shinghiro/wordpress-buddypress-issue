<?php
// ************
// Params
// ************
$footer_class = ' mb';
$edge_svg_class = $edge_svg = '';


if ( is_front_page() && !is_paged() &&  !isset( $_REQUEST['q']) ) {
	if ($options['dp_header_content_type'] !== 'none'){
		$footer_class .= ' show-header';
	}
}
if ( isset($options['dp_footer_bg_img']) && !empty($options['dp_footer_bg_img'] ) ) {
	$footer_class .= ' show-bg-img';
}


/**
 * Footer top edge shape
 */
if ( isset( $options['footer_top_edge'] ) && $options['footer_top_edge'] !== 'none' ){

	$edge_wrapper_class = 'ft_top_edge edge_shape_' . $options['footer_top_edge'] . '_top';

	// Only wave 1, wave 2 and curve 2 shapes
	if ( $options['footer_top_edge'] === 'wave1' || $options['footer_top_edge'] === 'wave2' || $options['footer_top_edge'] === 'curve1' || $options['footer_top_edge'] === 'curve2' ) {

		$edge_wrapper_class .= ' is_svg_edge';
		$edge_svg_class = 'svg_edge pos_top';
		$edge_svg = $options['footer_top_edge'];

		if ( $options['footer_top_edge_piled_layer'] ) {
			$edge_svg_class .= ' piled_layer';
			$edge_svg = '<svg class="' . $edge_svg_class . '"><use xlink:href="#svg_edge_' . $edge_svg . '__layer1" /><use xlink:href="#svg_edge_' . $edge_svg . '__layer2" /><use xlink:href="#svg_edge_' . $edge_svg . '__layer3" /></svg>';
		} else {
			$edge_svg = '<svg class="' . $edge_svg_class . '"><use xlink:href="#svg_edge_' . $edge_svg . '" /></svg>';
		}

	} else {
		$edge_wrapper_class .= ' is_clip_edge';
	}

	$edge_svg = '<div class="' . $edge_wrapper_class . '" role="none">' . $edge_svg . '</div>';
}


// Footer title
$footer_title = ( isset($options['copyright_name']) && !empty( $options['copyright_name']) ) ? $options['copyright_name'] : dp_h1_title();

/**
 * Container bottom widget area
 */
if ( is_active_sidebar( 'widget-container-bottom-mb' ) && !is_404()) {
	// get the widget
	ob_start();
	dynamic_sidebar( 'widget-container-bottom-mb' );
	$widget_container_bottom_content = ob_get_contents();
	ob_end_clean();

	if ( !empty( $widget_container_bottom_content ) ) {
		// Display
		echo '<div id="widget-container-bottom" class="widget-container bottom">' . $widget_container_bottom_content . '</div>';
	}
}?>
</div><?php // end of ".dp-container"


// **********************
// Bottom bar (with Offcanvas menu)
// **********************
include_once( TEMPLATEPATH . "/".DP_MOBILE_THEME_DIR . "/footer-bar.php" ); ?>
</div></div><?php // End of ".dp-pjax-container" and "#dp-pjax-wrapper"

/**
 * Footer
 */?>
<footer id="footer" class="footer<?php echo $footer_class; ?>"><?php

/**
 * Footer top edge
 */
echo $edge_svg;

/**
 * show footer widgets and menu (footer_widgets.php)
 */
dp_get_footer();


$ft_menu = $sns_code = $ft_title_img = $location_info = $contact_info = $contact_info_before = $contact_info_after = '';

/**
 * Custom Menu
 */
if ( function_exists( 'wp_nav_menu' ) ) {
	$theme_location = 'footer_menu_mobile';
	if ( has_nav_menu( $theme_location ) ) {
		$ft_menu = wp_nav_menu(array(
			'theme_location'	=> $theme_location,
			'container'			=> 'div',
			'container_class'	=> 'ft-btm__col' . $wow_footer_item,
			'menu_id'			=> 'footer_menu_ul',
			'menu_class'		=> 'footer_menu_ul mb-theme',
			'depth'				=> 1,
			'echo'				=> false,
			'fallback_cb'		=> '__return_false',
			'walker'			=> new dp_custom_menu_walker()
		));
	}
}

/**
 * SNS, Feed, Contact icons
 */
// From sns_contact_icons.php
$sns_code = dp_sns_contact_icons( 'footer' );
if ( !empty( $sns_code ) ) {
	$sns_code = '<div class="share-links">' . $sns_code . '</div>';
}

// Contact info
if ( isset($options['contact_info_before']) && !empty( $options['contact_info_before'] ) ){
	$contact_info_before = '<div class="c-before">' . htmlspecialchars_decode($options['contact_info_before']) . '</div>';
}
if ( isset($options['contact_info']) && !empty( $options['contact_info'] ) ){
	$contact_info = '<div class="c-middle"><span>' . htmlspecialchars_decode($options['contact_info']) . '</span></div>';
}
if ( isset($options['contact_info_after']) && !empty( $options['contact_info_after'] ) ){
	$contact_info_after = '<div class="c-after"><span>'.htmlspecialchars_decode($options['contact_info_after']).'</span></div>';
}
if ( !empty( $sns_code ) || !empty( $contact_info_before ) || !empty( $contact_info ) || !empty( $contact_info_after ) ){
	$contact_info = '<div class="ft-btm__col ct-info' . $wow_footer_item . '">' . $contact_info_before . $contact_info . $contact_info_after . $sns_code . '</div>';
}

// Logo
if ( !empty( $options['dp_ft_title_img'] ) ) {
	$ft_title_img = '<a href="' . home_url('/') . '" class="ft_logo"><img src="' . $options['dp_ft_title_img'] . '" alt="' . esc_attr($footer_title) . '" /></a>';
}
// Location
if ( isset( $options['location_info'] ) && !empty( $options['location_info'] ) ){
	$location_info = '<span class="location">' . htmlspecialchars_decode( $options['location_info'] ) . '</span>';
}
/**
 * logo + location
 */
if ( !empty( $location_info) || !empty( $ft_title_img ) ){
	$location_info = '<div class="ft-btm__col logo' . $wow_footer_item . '">' . $ft_title_img . $location_info . '</div>';
}

/**
 * Wrapping
 */
if ( !empty( $ft_menu ) || !empty( $location_info ) || !empty( $contact_info ) ) {
	echo '<div class="ft-btm__container">' . $ft_menu . $contact_info . $location_info . '</div>';
}


/**
 * Copyright
 */?>
<div id="cpright" class="cpright"><span class="cpmark">&copy;</span><?php

$current_year = (string)date('Y');

if ( isset($options['blog_start_year']) && !empty($options['blog_start_year']) ) {
	if ( $options['blog_start_year'] !== $current_year ){
		echo '<span class="year">' . $options['blog_start_year'] . ' - ' . $current_year . '</span>';
	} else {
		echo '<span class="year">' . $current_year . '</span>';
	}
} else {
	echo '<span class="year">' . $current_year . '</span>';
} ?> <?php echo '<span class="cpright_name">' . $footer_title . '</span>'; ?></div><?php
?></footer>
<div class="page-shutter top" role="none" aria-hidden="true"></div><div class="page-shutter bottom" role="none" aria-hidden="true"></div><?php

/**
 * WordPress Footer
 */
wp_footer();
/**
 * [dp_action_custom_head description]
 * @return [type] [description]
 */
function dp_action_custom_footer(){
	global $options;

	// Slider
	$code = dp_make_slider_js();

	// Javascript for sns
	$code .= js_for_sns_objects(false);

	// Google Custom Search
	if (!empty($options['gcs_id'])) {
		$code .= '<script>(function(){var cx=\''.$options['gcs_id'].'\';var gcse=document.createElement(\'script\');gcse.type=\'text/javascript\';gcse.async=true;gcse.src=(document.location.protocol==\'https:\'?\'https:\':\'http:\')+\'//cse.google.com/cse.js?cx=\'+cx;var s = document.getElementsByTagName(\'script\')[0];s.parentNode.insertBefore(gcse,s);})();</script>';
	}

	// SVG sprite
	include_once( DP_THEME_DIR . '/inc/scr/generator/svg_sprite.php' );

	// Insert custom code
	if (isset($options['custom_content_before_end_body_mobile']) && !empty($options['custom_content_before_end_body_mobile'])){
		$code .= $options['custom_content_before_end_body_mobile'];
	}

	// Minify
	$code = str_replace(array("\r\n","\r","\n","\t"), '', $code);
	// Insert
	echo $code;
}
add_action('dp_custom_footer', 'dp_action_custom_footer');

/**
 * Action in footer
 */
do_action('dp_custom_footer');

/**
 * JSON-LD for Structured Data
 */
dp_json_ld();?>
</body></html>