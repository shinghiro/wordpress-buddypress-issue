<?php
if (!$IS_MOBILE_DP) {
	// PC
	get_header();?>
<article id="<?php echo $CURRENT_POST_TYPE.'-'.get_the_ID(); ?>" <?php post_class('single-article'); ?>><div class="entry entry-content"><?php woocommerce_content(); ?></div></article><?php
/**
 * Content bottom widget
 */
if ( is_active_sidebar('widget-content-bottom') ) :
	ob_start();
	dynamic_sidebar( 'widget-content-bottom' );
	$widget_content_btm_content = ob_get_contents();
	ob_end_clean();

	if ( !empty( $widget_content_btm_content ) ) {
		echo '<div class="widget-content bottom clearfix">' . $widget_content_btm_content . '</div>';
	}
endif;?>
</main><?php // end of .content
	get_footer();
} else{
	// Mobile
	include_once(TEMPLATEPATH .'/'.DP_MOBILE_THEME_DIR.'/header.php');?>
<article id="<?php echo $CURRENT_POST_TYPE.'-'.get_the_ID(); ?>" <?php post_class('single-article'); ?>><div class="entry entry-content"><?php woocommerce_content(); ?></div></article><?php
	include_once(TEMPLATEPATH .'/'.DP_MOBILE_THEME_DIR.'/footer.php');
}