<?php 
/**
 * Header (main-wrap > container > content)
 */
get_header();

/**
 * Show main content
 */
if ( $ARCHIVE_STYLE['children'] ) {

	// If sub categories are shown
	require_once( DP_THEME_DIR . '/inc/scr/parts/show_child_terms.php' );
	dp_show_child_terms();

}
else if ( have_posts() ) {

	// List of articles (default)
	require_once( DP_THEME_DIR . '/inc/scr/article-loop.php' );
	$loop_code = dp_article_loop( $posts );
	echo $loop_code;

} else {

	// Not found...
	include_once(DP_THEME_DIR .'/not-found.php');

}	// End of have_posts()

// Content bottom widget
if ( is_active_sidebar('widget-content-bottom') ) {
	ob_start();
	dynamic_sidebar( 'widget-content-bottom' );
	$widget_content_btm_content = ob_get_contents();
	ob_end_clean();

	if ( !empty( $widget_content_btm_content ) ) {
		echo '<div class="widget-content bottom clearfix">' . $widget_content_btm_content . '</div>';
	}
}?>
</main><?php // end of .content
/**
 * Sidebar
 */
if ( $COLUMN_NUM === 2 ) get_sidebar();
/**
 * Footer
 */
get_footer();