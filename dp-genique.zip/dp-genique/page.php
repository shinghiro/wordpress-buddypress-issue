<?php 
/**
 * Header (main-wrap > container > content)
 */
get_header();

//For thumbnail size
$width = 1680;
$height = 1200;

// insert article class
$post_class = "single-article";

// Col class
$col_class = ' two-col';
if ( $COLUMN_NUM === 1 ) {
	$col_class = ' one-col';
}

// wow.js
$wow_title_css = $wow_eyecatch_css = '';
if (!(bool)$options['disable_wow_js']){
	$wow_title_css = ' wow fadeInDown';
	$wow_prof_css = ' wow fadeInRight';
	$wow_eyecatch_css = ' wow fadeInUp';
}

/**
 * show posts
 */
if (have_posts()) :
	$this_id = get_the_ID();

	// Variants
	$float_content = $first_row = $second_row = $meta_code_top = $meta_code_end = '';

	// Count Post View
	if (function_exists('dp_count_post_views')) {
		dp_count_post_views($this_id, true);
	}

	// Auto display eyecatch
	$show_eyecatch_first = $options['show_eyecatch_first'];
	// Show eyecatch on top
	$show_eyecatch_force 	= get_post_meta($this_id, 'dp_show_eyecatch_force', true);
	// Show eyecatch upper the title
	$eyecatch_on_container 	= get_post_meta($this_id, 'dp_eyecatch_on_container', true);
	// Slider image
	$sl_img1 = get_post_meta($this_id, 'dp_archive_slider_img1', true);
	$sl_img2 = get_post_meta($this_id, 'dp_archive_slider_img2', true);
	$sl_img3 = get_post_meta($this_id, 'dp_archive_slider_img3', true);

	/**
	 * Create meta data
	 */
	if (!(bool)post_password_required()) {
		/**
		 * float content
		 */
		// SNS buttons
		if (!empty($SINGLE_META['sns_btn'])) {
			$float_content = '<div id="single_float_div" class="single_float_div"><input type="checkbox" role="button" id="share-tgl-chk" title="shares" /><label for="share-tgl-chk" aria-hidden="true" class="share-tgl" title="shares"><i class="icon-share"></i></label><div class="inner">'.$SINGLE_META['sns_btn'].'</div></div>';
		}
		/**
		 * Meta No.1
		 */
		//*** filter hook
		if ( $CURRENT_POST_TYPE === 'page' ) {
			$filter_top_first = apply_filters('dp_single_meta_top_first', $this_id);
			$filter_top_end = apply_filters('dp_single_meta_top_end', $this_id);
			if (!empty($filter_top_first) && $filter_top_first != $this_id) {
				$meta_code_top = $filter_top_first;
			}
			if (!empty($filter_top_end) && $filter_top_end != $this_id) {
				$meta_code_top .= $filter_top_end;
			}
			if (!empty($meta_code_top)){
				$meta_code_top = '<div class="single_post_meta">'.$meta_code_top.'</div>';
			}
		}
		/**
		 * Meta No.2
		 */
		// Reset params
		//*** filter hook
		if ( $CURRENT_POST_TYPE === 'page' ) {
			$filter_bottom_first = apply_filters('dp_single_meta_bottom_first', $this_id);
			if (!empty($filter_bottom_first) && $filter_bottom_first != $this_id) {
				$first_row = $filter_bottom_first;
			}
		}
		// First row
		if (!empty($first_row)) {
			$first_row = '<div class="first_row">'.$first_row.'</div>';
		}

		// Date
		if (!empty($SINGLE_META['date_bottom'])) {
			$date_eng_flg = (bool)$options['date_eng_mode'] ? ' eng' : '';
			$second_row = '<div class="meta meta-date'.$date_eng_flg.'">'.$SINGLE_META['date_bottom'].$SINGLE_META['last_update'].'</div>';
		}
		// Combine others
		$second_row .= isset( $SINGLE_META['author_bottom_code'] ) && !empty( $SINGLE_META['author_bottom_code'] ) ? $SINGLE_META['author_bottom_code'] : '';
		$second_row .= isset( $SINGLE_META['edit_link'] ) && !empty( $SINGLE_META['edit_link'] ) ? $SINGLE_META['edit_link'] : '';
		// First row
		if (!empty($second_row)) {
			$second_row = '<div class="second_row">'.$second_row.'</div>';
		}

		//*** filter hook
		if ( $CURRENT_POST_TYPE === 'page' ) {
			$filter_bottom_end = apply_filters('dp_single_meta_bottom_end', $this_id);
			if (!empty($filter_bottom_end) && $filter_bottom_end != $this_id) {
				$second_row .= $filter_bottom_end;
			}
		}
		// meta on bottom
		if ( !empty($first_row) || !empty($second_row) ) {
			$meta_code_end = '<footer class="single_post_meta bottom">'.$first_row.$second_row.'</footer>';
		}
	}

	/**
	 * Article area start
	 */
	while (have_posts()) : the_post(); ?>
<article id="<?php echo $CURRENT_POST_TYPE.'-'.$this_id; ?>" <?php post_class($post_class); ?>><?php
		// header meta
		echo $meta_code_top;
		// Single header widget
		if (($CURRENT_POST_TYPE === 'page') && is_active_sidebar('widget-post-top') && !post_password_required()) : ?>
<div class="widget-content single clearfix"><?php dynamic_sidebar( 'widget-post-top' ); ?></div><?php 
		endif;	// End of widget
		/**
		 * Main entry
		 */?>
<div class="entry entry-content"><?php
		// ***********************************
		// Show eyecatch image
		// ***********************************
		global $page;
		$post_header_code = '';
		$flag_eyecatch_first = false;
		if ( has_post_thumbnail() && $CURRENT_POST_TYPE === 'page' && $page === 1 ) {
			if ( $show_eyecatch_first ) {
			 	if ( !($show_eyecatch_force && $eyecatch_on_container) ) {
			 		$flag_eyecatch_first = true;
				}
			} else {
				if ( $show_eyecatch_force && !$eyecatch_on_container ) {
					$flag_eyecatch_first = true;
				}
			}
		}
		if ( $flag_eyecatch_first || !empty($SINGLE_META['free_meta_code']) ) {
			$image_id	= get_post_thumbnail_id();
			$image_data	= wp_get_attachment_image_src($image_id, array($width, $height), true);
			$image_url 	= is_ssl() ? str_replace('http:', 'https:', $image_data[0]) : $image_data[0];
			$img_tag	= '<img src="'.$image_url.'" class="wp-post-image aligncenter" alt="'.strip_tags(get_the_title()).'" width="'.$image_data[1].'" height="'.$image_data[2].'" />';

			 $post_header_code = '<figure class="eyecatch-under-title'.$wow_eyecatch_css.'">' . $img_tag . '</figure>';
		}
		if (!empty($SINGLE_META['free_meta_code'])) {
			echo '<div class="fmeta_area"><div class="fmeta_cell one">'.$post_header_code.'</div><div class="fmeta_cell two">'.$SINGLE_META['free_meta_code'].'</div></div>'.$js_slider;
		} else {
			echo $post_header_code;
		}
		/**
		 * Content
		 */
		the_content();

		/**
		 * Paged navigation
		 */
		wp_link_pages(array(
			'before' => '<nav class="navigation"><div class="dp-pagenavi">',
			'after' => '</div></nav>',
			'link_before' => '<span class="page-number">',
			'link_after' => '</span>',
			'next_or_number' => 'next_and_number',
			// 'separator' => ' ',
			// 'next_or_number' => 'next',
			// 'nextpagelink'	=> __( 'Next Page', 'DigiPress' ),
			'nextpagelink'	=> get_post_meta( $this_id, 'nextpage_text', true ),
			'previouspagelink'	=> '',
			'echo' => 1,
		) );?>
</div><?php 	// End of class="entry"
		/**
		 * Single footer widget
		 */
		if ( $CURRENT_POST_TYPE === 'page' && is_active_sidebar('widget-post-bottom') && !post_password_required()) : ?>
<div class="widget-content single clearfix"><?php dynamic_sidebar( 'widget-post-bottom' ); ?></div><?php
		endif;
		/**
		 * Bottom meta
		 */
		echo $meta_code_end;?>
</article><?php
		/**
		 * Comments
		 */
		comments_template();
	endwhile;	// End of (have_posts())

	/**
	 * Content bottom widget
	 */
	if ( is_active_sidebar('widget-content-bottom') ) {
		ob_start();
		dynamic_sidebar( 'widget-content-bottom' );
		$widget_content_btm_content = ob_get_contents();
		ob_end_clean();

		if ( !empty( $widget_content_btm_content ) ) {
			echo '<div class="widget-content bottom clearfix">' . $widget_content_btm_content . '</div>';
		}
	}
	// Float content
	echo $float_content;
else :	// have_posts()
	// Not found...
	include_once(TEMPLATEPATH .'/not-found.php');
endif;	// End of have_posts()?>
</main><?php // end of .content
/**
 * Sidebar
 */
if ( $COLUMN_NUM === 2 ) get_sidebar();
/**
 * Footer
 */
get_footer();