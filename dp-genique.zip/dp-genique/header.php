<?php
/**
 * Original codes for head section
 * @return [type] [description]
 */
function dp_action_custom_head(){
	global $options;
	$code = isset($options['custom_head_content']) && !empty($options['custom_head_content']) ? $options['custom_head_content'] : '';
	$code = str_replace(array("\r\n","\r","\n","\t"), '', $code);
	echo $code;
}
add_action('dp_custom_head', 'dp_action_custom_head');

/**
 * Insert meta tags
 * @return [type] [description]
 */
function dp_action_insert_meta(){
	dp_meta_kw_desc();
	dp_show_ogp();
	dp_show_canonical();
}
add_action('dp_insert_meta', 'dp_action_insert_meta');

// Start header
global $options, $ARCHIVE_STYLE, $CURRENT_POST_TYPE, $SIDEBAR_FLOAT, $COLUMN_NUM, $IS_MOBILE_DP, $ELEMENTS_SHOW, $CONTAINER_EDGE, $IS_WOOCOMMERCE
;?>
<!DOCTYPE html><html <?php language_attributes(); ?>><?php
if ( is_singular() ) : ?>
<head prefix="og: http://ogp.me/ns# fb: http://ogp.me/ns/fb# article: http://ogp.me/ns/article#"><?php
else: ?>
<head prefix="og: http://ogp.me/ns# fb: http://ogp.me/ns/fb# blog: http://ogp.me/ns/website#"><?php
endif; ?>
<meta charset="utf-8" /><meta name="viewport" content="width=device-width,initial-scale=1,minimum-scale=1,user-scalable=yes" /><?php
if ( (is_front_page() || is_archive()) && is_paged()) : ?>
<meta name="robots" content="noindex,follow" /><?php
elseif ( is_singular() ) :
	if (get_post_meta(get_the_ID(), 'dp_noindex', true) &&
		get_post_meta(get_the_ID(), 'dp_nofollow', true) &&
		get_post_meta(get_the_ID(), 'dp_noarchive', true)) :?>
<meta name="robots" content="noindex,nofollow,noarchive" /><?php
	elseif (get_post_meta(get_the_ID(), 'dp_noindex', true) &&
		get_post_meta(get_the_ID(), 'dp_nofollow', true) &&
		!get_post_meta(get_the_ID(), 'dp_noarchive', true)) : ?>
<meta name="robots" content="noindex,nofollow" /><?php
	elseif (get_post_meta(get_the_ID(), 'dp_noindex', true) &&
		!get_post_meta(get_the_ID(), 'dp_nofollow', true) &&
		!get_post_meta(get_the_ID(), 'dp_noarchive', true)) :?>
<meta name="robots" content="noindex" /><?php
	elseif (!get_post_meta(get_the_ID(), 'dp_noindex', true) &&
		get_post_meta(get_the_ID(), 'dp_nofollow', true) &&
		get_post_meta(get_the_ID(), 'dp_noarchive', true)) :?>
<meta name="robots" content="nofollow,noarchive" /><?php
	elseif (!get_post_meta(get_the_ID(), 'dp_noindex', true) &&
		!get_post_meta(get_the_ID(), 'dp_nofollow', true) &&
		get_post_meta(get_the_ID(), 'dp_noarchive', true)) :?>
<meta name="robots" content="noarchive" /><?php
	elseif (!get_post_meta(get_the_ID(), 'dp_noindex', true) &&
		get_post_meta(get_the_ID(), 'dp_nofollow', true) &&
		!get_post_meta(get_the_ID(), 'dp_noarchive', true)) :?>
<meta name="robots" content="nofollow" /><?php
	elseif (get_post_meta(get_the_ID(), 'dp_noindex', true) &&
		!get_post_meta(get_the_ID(), 'dp_nofollow', true) &&
		get_post_meta(get_the_ID(), 'dp_noarchive', true)) :?>
<meta name="robots" content="noindex,noarchive" /><?php
	endif;
endif;

/**
 * Add meta tags
 */
do_action('dp_insert_meta');

/**
 * WordPress header
 */
wp_head();

/**
 * Custom header
 */
do_action('dp_custom_head');?>
</head><?php

/**
 * wow.js
 */
$data_attr_wow = '';
$wow_title_css = '';
$wow_desc_css = '';
$wow_menu_css = '';
$attr_delay = '';
$attr_delay_1 = '';
$attr_delay_2 = '';

$hd_title_data	= '';
$hd_desc_data	= '';
$hd_title_plx_class	= '';
$hd_desc_plx_class = '';

if ( !( isset($options['disable_wow_js']) && !empty($options['disable_wow_js']) ) ) {
	$data_attr_wow = ' data-use-wow="true"';

	$wow_title_css = ' wow fadeInDown';
	$wow_desc_css = ' wow fadeInUp';
	$attr_delay_1 = ' data-wow-delay="0.1s"';
	$attr_delay_2 = ' data-wow-delay="0.3s"';

	$hd_title_data = ' data-wow-delay="0.4s"';
	$hd_desc_data = ' data-wow-delay="0.7s"';
	$hd_title_plx_class = ' wow fadeInDown';
	$hd_desc_plx_class = ' wow fadeInUp';

	$wow_menu_css = ' is-fadein';

} else {
	$data_attr_wow = ' data-use-wow="false"';
}

/**
 * Main Body
 */
// class for body tag
$body_class = $IS_MOBILE_DP ? 'main-body mb' : 'main-body pc';
// params
$container_class = 'dp-container pc';
$cur_page_class = ' not-home';
$narrow_class = '';
$header_bar_class = 'header_bar pc';

// Selector for body tag
if ( ! ( is_front_page() && !is_paged() ) ) {
	$body_class .= ' not-home';
}

// share count JS
if ( isset($options['disable_sns_share_count']) && !empty($options['disable_sns_share_count'])) {
	$body_class .= ' no-sns-count';
}

// Front page
if ( is_front_page() ) {

	if ( !is_paged() && !isset( $_REQUEST['q']) ) {
		$cur_page_class = ' home';
	} elseif ( is_paged() ) {
		$cur_page_class = ' home paged';
	}

	if ($options['top_page_main_content'] === 'none') {

		$cur_page_class .= ' no-content';

	} else if ($options['top_page_main_content'] === 'page') {
		// Narrow content width
		if ( (bool)get_post_meta((int)$options['specific_page_id'], 'one_col_narrow', true)) {
			$narrow_class = ' narrow';
		}
	}

	if ( $options['dp_header_content_type'] === 'none' ) {
		$cur_page_class .= ' no_header';
	}

} elseif ( is_singular() ) {

	$cur_page_class .= ' singular';
	// Narrow content width
	if ( (bool)get_post_meta(get_the_ID(), 'one_col_narrow', true) ) {
		$narrow_class = ' narrow';
	}

} elseif ( $IS_WOOCOMMERCE ){
	$cur_page_class .= ' singular';
}


/**
 * Transparent header bar
 */
if ( $ELEMENTS_SHOW['header_bar_transparent'] && !$IS_WOOCOMMERCE ){
	$body_class .= ' hd_bar_trpt';
	$header_bar_class .= ' hd_bar_trpt';
}

/**
 * is global menu exists
 */
if ( ! has_nav_menu('global_menu') ) {
	$body_class .= ' no_global_menu';
	$header_bar_class .= ' no_global_menu';
	$cur_page_class .= ' no_global_menu';
}

/**
 * Piled layer exists
 */
if ( isset( $options['header_bar_add_layer'] ) && !empty( $options['header_bar_add_layer'] ) ) {
	$body_class .= ' piled_layer';
	$header_bar_class .= ' piled_layer';
}

/**
 * Site title position
 */
if ( isset( $options['h1_title_position'] ) && $options['h1_title_position'] === 'left' ){
	$header_bar_class .= ' title-pos-left';
}

/**
 * Site main title
 */
$site_title = '';
$caption = dp_h2_title('<div class="caption' . $wow_desc_css . '"' . $attr_delay_1 . '>', '</div>');
$cap_flag = empty($caption) ? ' no-cap' : '';

if ( !isset( $options['h1_title_as_what'] ) || $options['h1_title_as_what'] !== 'image') {

	$site_title = '<h1 class="hd-title txt' . $cap_flag . $wow_title_css .'"' . $attr_delay_1 . '><a href="' . home_url('/') . '" title="' . esc_attr(get_bloginfo('name')) . '">' . dp_h1_title() . '</a></h1>';

} else {

	if ( isset($options['dp_title_img']) && !empty($options['dp_title_img']) ){
		$site_title = '<h1 class="hd-title img' . $cap_flag . $wow_title_css . '"' . $attr_delay_1 . '><a href="' . home_url('/') . '" title="' . esc_attr(get_bloginfo('name')) . '"><img src="' . $options['dp_title_img'] . '" alt="' . esc_attr(dp_h1_title()) . '" /></a></h1>';
	}
}

/**
 * SNS share count setting
 */
$data_share_cache = '';
if (isset($options['share_count_cache']) && !empty($options['share_count_cache'])){
	$data_share_cache = ' data-ct-sns-cache="true" data-ct-sns-cache-time="' . $options['share_count_cache_time'] . '"';
}

/**
 * use pjax?
 */
$data_attr_pjax = '';
if ( !( isset($options['disable_pjax']) && !empty($options['disable_pjax']) ) ){
	$data_attr_pjax = ' data-use-pjax="true"';
	if ( !( isset($options['disable_pjax_transition']) && !empty($options['disable_pjax_transition']) ) ){
		$data_attr_pjax .= ' data-pjax-transition="true"';
	}
	if ( isset($options['ignore_pjax_class']) && !empty($options['ignore_pjax_class']) ){
		$data_attr_pjax .= ' data-pjax-ignore-class="' . $options['ignore_pjax_class'] . '"';
	}
}


/**
 * Header content
 */
$arr_http = array('http:','https:');
$plx_bg_img_class = ' no_bgimg';

// Main title (Except top page)
$hd_title_show 	= true;
$hd_title_code 	= $hd_sub_title_code = '';
$page_desc = '';
$page_class	= '';
$meta_code = '';
$ct_hd_code = '';
$ct_hd_class = 'ct-hd';
$ct_whole_class = 'ct-whole';
$eyecatch_to_bg = '';
$term_color = $term_video = '';
$hd_bg_img = $hd_bg_img_inner_code = '';
$edge_svg = '';

// Show title and description
if ( !is_home() && !$IS_WOOCOMMERCE ) {

	// breadcrumb flag
	if ( !$ELEMENTS_SHOW['breadcrumb'] ){
		$ct_hd_class .= ' no_breadcrumb';
		$cur_page_class .= ' no_breadcrumb';
	}

	// Category or tag archive
	if ( ( is_category() || is_tag() ) && !is_search() ) {

		global $ARCHIVE_STYLE;

		if ( isset( $ARCHIVE_STYLE ) && is_array($ARCHIVE_STYLE) ) {

			$hd_sub_title_code = isset( $ARCHIVE_STYLE['sub_title'] ) && !empty( $ARCHIVE_STYLE['sub_title'] ) ? '<div class="sub-title" role="none">' . esc_html( $ARCHIVE_STYLE['sub_title'] ) . '</div>' : '';

			$hd_bg_img = isset( $ARCHIVE_STYLE['image'] ) && !empty( $ARCHIVE_STYLE['image'] ) ? esc_attr($ARCHIVE_STYLE['image']) : '';

			$term_video = isset( $ARCHIVE_STYLE['video_id'] ) && !empty( $ARCHIVE_STYLE['video_id'] ) ? $ARCHIVE_STYLE['video_id'] : '';

			if ( !empty($term_video) ) {
				// set ID
				$term_video = ' data-video="' . $term_video . '"';
				$plx_bg_img_class .= ' video';
				$hd_bg_img = '';

			} else if ( !empty($hd_bg_img) ) {

				$hd_bg_img = ' style="--bg-image:url(\'' . $hd_bg_img . '\');"';
				$hd_bg_img_inner_code = '<div class="inner-bg" role="img"' . $hd_bg_img . '></div>';
				$plx_bg_img_class = ' bgimg';
			}

			// Category Color
			if ( $plx_bg_img_class == ' bgimg' ) {

				if ( $options['page_header_bgimg_overlay'] === 'term_color' ) {

					if ( isset($ARCHIVE_STYLE['color']) && !empty($ARCHIVE_STYLE['color']) ){

						$term_color = ' term-color' . $ARCHIVE_STYLE['term_id'] . ' ' . $options['page_header_bgimg_overlay'];
					}
				}
			} else {

				if ( $options['page_header_bgcolor_overlay'] === 'term_color' || $options['page_header_bgcolor_overlay'] === 'term_color_gradient' ) {

					if ( isset($ARCHIVE_STYLE['color']) && !empty($ARCHIVE_STYLE['color']) ){
						$term_color = ' term-color' . $ARCHIVE_STYLE['term_id'] . ' ' . $options['page_header_bgcolor_overlay'];
					}
				}
			}
		}
	}

	// Single page
	if ( is_singular() ) {

		global $SINGLE_META, $page;

		$this_id = get_the_ID();
		$page_class = ' singular';
		$single_flag = '';

		// Base title
		$hd_title_code = the_title_attribute('before=&after=&echo=0');
		if  ( $page > 1 ) {
			$hd_title_code .= ' - ' . $page;
		}

		// Single or static page
		if ( $CURRENT_POST_TYPE === 'post' || $CURRENT_POST_TYPE === 'page' || $CURRENT_POST_TYPE === $options['news_cpt_slug_id'] ) {

			// Eyecatch to background image
			$eyecatch_to_bg = get_post_meta($this_id, 'dp_eyecatch_to_bg', true);

			if ( (bool)$eyecatch_to_bg ) {
				$eyecatch_to_bg = ' body-bgimg';
			} else {
				$eyecatch_to_bg = '';
			}
			// Show eyecatch upper the title
			if( has_post_thumbnail() && $ELEMENTS_SHOW['eyecatch_header'] && $ELEMENTS_SHOW['eyecatch_entry_top'] ) {
				$post_img = get_post_thumbnail_id();
				$post_img = wp_get_attachment_image_src($post_img, 'full', true);
				$post_img = str_replace($arr_http,'',$post_img[0]);
				$hd_bg_img = ' style="--bg-image:url(\'' . $post_img . '\')"';
				$hd_bg_img_inner_code = '<div class="inner-bg" role="img"' . $hd_bg_img . '></div>';
				$plx_bg_img_class = ' bgimg';
			}

			// Title
			if ( !$ELEMENTS_SHOW['single_post_title'] ) {

				$hd_title_code = '';

				if ( !$ELEMENTS_SHOW['eyecatch_header'] ) {
					$hd_title_show = false;
					$header_bar_class .= ' no_ct_hd';
					$cur_page_class .= ' no_ct_hd';
				}
			}
		}

		// Post title
		$hd_title_code = !empty( $hd_title_code ) && $hd_title_show ? '<h2 class="hd-title single-title' . $hd_title_plx_class . '"' . $hd_title_data . '><span>' . $hd_title_code . '</span></h2>' : '';


		// Single post
		if ( $CURRENT_POST_TYPE === 'post' ) {

			global $post;

			// Category color
			if ( $plx_bg_img_class == ' bgimg' ) {

				if ( $options['page_header_bgimg_overlay'] === 'term_color' ) {

					if ( isset($SINGLE_META['arr_first_cat_color'] ) && !empty( $SINGLE_META['arr_first_cat_color'] ) ) {
						$term_color = ' term-color' . $SINGLE_META['arr_first_cat_color'][1] . ' ' . $options['page_header_bgimg_overlay'];
					}
				}
			} else {

				if ( $options['page_header_bgcolor_overlay'] === 'term_color' || $options['page_header_bgcolor_overlay'] === 'term_color_gradient' ) {

					if ( isset($SINGLE_META['arr_first_cat_color'] ) && !empty( $SINGLE_META['arr_first_cat_color'] ) ) {
						$term_color = ' term-color' . $SINGLE_META['arr_first_cat_color'][1] . ' ' . $options['page_header_bgcolor_overlay'];
					}
				}
			}

			// Category name
			if ( !empty( $SINGLE_META['cat_top_code'] ) ) {
				$hd_sub_title_code = '<div class="sub-title meta-cat" role="none">' . $SINGLE_META['cat_top_code'] . '</div>';
			}
		}

		// Date
		if ( !empty( $SINGLE_META['date_top'] ) ) {
			$eng_date = '';
			if ((bool)$options['date_eng_mode']) {
				$eng_date = ' eng';
			}
			$meta_code = '<div class="meta meta-date' . $eng_date . '">' . $SINGLE_META['date_top'] . $SINGLE_META['last_update'] . '</div>';
		}
		// Author
		$meta_code .= $SINGLE_META['author_top_code'];
		// Views
		$meta_code .= $SINGLE_META['views_top_code'];
		// Time for reading
		$meta_code .= $SINGLE_META['time_for_reading'];
		// edit link
		$meta_code .= $SINGLE_META['edit_link'];

		// Whole meta info
		if ( !empty($meta_code) ) {
			$meta_code = '<div class="hd-meta meta-info' . $hd_desc_plx_class . '"' . $hd_desc_data . '>' . $meta_code . '</div>';
		} else {
			if ( empty($hd_title_code) && empty($page_desc) ) {
				$page_class .= ' no-data';
			}
		}
	} else {
		// Get title description (create_title_desc.php)
		$arr_title = dp_current_page_title();
		// Not single page
		$hd_title_code = '<h2 class="hd-title' . $hd_title_plx_class . '"' . $hd_title_data . '><span>' . $arr_title['title'] . '</span></h2>';
		if ( !empty( $arr_title['desc'] ) ) {
			$page_desc = '<div class="hd-meta title-desc meta-info' . $hd_desc_plx_class . '"' . $hd_desc_data . ' role="note">' . $arr_title['desc'] . '</div>';
		}
	}


	// Bottom edge shape (SVG)
	if ( isset( $options['page_header_bottom_edge'] ) && $options['page_header_bottom_edge'] !== 'none' ){

		$ct_whole_class .= ' edge_shape_' . $options['page_header_bottom_edge'] . '_btm';
		$CONTAINER_EDGE = ' edge_' . $options['page_header_bottom_edge'];

		// Only wave 1, wave 2 and curve 2 shapes
		if ( $options['page_header_bottom_edge'] === 'wave1' || $options['page_header_bottom_edge'] === 'wave2' || $options['page_header_bottom_edge'] === 'curve1' || $options['page_header_bottom_edge'] === 'curve2' ) {

			$edge_svg = $options['page_header_bottom_edge'];
			$edge_svg_class = 'svg_edge pos_btm';

			if ( $options['page_header_bottom_edge_piled_layer'] ) {
				$edge_svg_class .= ' piled_layer';
				$edge_svg = '<svg class="' . $edge_svg_class . '"><use xlink:href="#svg_edge_' . $edge_svg . '__layer1" /><use xlink:href="#svg_edge_' . $edge_svg . '__layer2" /><use xlink:href="#svg_edge_' . $edge_svg . '__layer3" /></svg>';
			} else {
				$edge_svg = '<svg class="' . $edge_svg_class . '"><use xlink:href="#svg_edge_' . $edge_svg . '" /></svg>';
			}
		}
	}

	// Content header additional classes
	$ct_hd_class .= $plx_bg_img_class . $eyecatch_to_bg;
	$ct_whole_class .= $plx_bg_img_class . $eyecatch_to_bg . $cur_page_class . $page_class . $term_color;

	// Display
	if ( (bool)$hd_title_show ) {
		$ct_hd_code = '<section id="ct-hd" class="' . $ct_hd_class . $CONTAINER_EDGE . '"' . $term_video . '><div id="ct-whole" class="' . $ct_whole_class . '">' . $hd_bg_img_inner_code . '<div class="hd-content">' . $hd_title_code . $page_desc . $meta_code . '</div>' . $hd_sub_title_code . $edge_svg . '</div></section>';
	}
}

/**
 * Site container class
 */
$container_class .= $cur_page_class;
?>
<body <?php body_class($body_class); echo $data_attr_pjax . $data_attr_wow . $data_share_cache; ?>><?php
/**
 *  inject code immediately following the opening <body> tag. * WP 5.2 over
 */
if ( function_exists( 'wp_body_open' ) ) {
	wp_body_open();
} else {
	do_action( 'wp_body_open' );
}

/**
 * Site header
 */?>
<header id="header_bar" class="<?php echo $header_bar_class; ?>"><div class="h_group"><?php

/**
 * Header main title (*Defined in header.php)
 */
echo $site_title . $caption; ?>
</div><?php

/**
 * Global Menu
 */
include_once(TEMPLATEPATH . "/global-menu.php");?>
</header>
<div id="dp_main_wrapper" class="main-wrapper" aria-live="polite"><div id="dp-pjax-wrapper" data-barba="wrapper"><div class="dp-pjax-container" data-barba="container" data-barba-namespace="home"><?php

/**
 * site banner
 */
dp_banner_contents();?>
<div id="container" class="<?php echo $container_class . $CONTAINER_EDGE; ?>"><?php

/**
 * Show eyecatch on container 
 */
echo $ct_hd_code;

/**
 * Breadcrumb
 */
dp_breadcrumb();

/**
 * Container widget
 */
if ( !is_404() && is_active_sidebar( 'widget-container-top' ) ) {
	// get the widget
	ob_start();
	dynamic_sidebar( 'widget-container-top' );
	$widget_container_top_content = ob_get_contents();
	ob_end_clean();

	// Display
	if ( !empty( $widget_container_top_content ) ) {
		// Full wide flag
		if (isset($options['full_wide_container_widget_area_top']) && !empty($options['full_wide_container_widget_area_top'])) {
			$cur_page_class .= ' full-wide';
		}
		echo '<div class="widget-container top clearfix' . $cur_page_class . '">' . $widget_container_top_content.'</div>';
	}
}

/**
 * Main content
 */
$col_class	= ' two-col';
$sidebar_float_class = ' ' . $SIDEBAR_FLOAT;
$full_wide = '';
$top_or_archive = 'top';
extract($ARCHIVE_STYLE);
if ( $COLUMN_NUM === 1 || is_404() ) {
	$col_class = ' one-col';
	$sidebar_float_class = '';
	if (is_home() || is_archive() || is_search()) {
		if ( strpos($options[$top_or_archive . '_post_show_type'], 'portfolio') !== false ) {
			$full_wide = ' full-wide';
		}
	}
} else if ($COLUMN_NUM === 3) {
	$col_class = ' three-col';
}?>
<div class="content-wrap incontainer clearfix<?php echo $col_class . $cur_page_class . $full_wide; ?>">
<main id="content" class="content<?php echo $col_class . $sidebar_float_class . $narrow_class; ?>"><?php

/**
 * Content widget
 */
if (!is_404() && is_active_sidebar('widget-content-top')) {
	// get the widget
	ob_start();
	dynamic_sidebar( 'widget-content-top' );
	$widget_content_top_content = ob_get_contents();
	ob_end_clean();

	if ( !empty( $widget_content_top_content ) ) {
		echo '<div class="widget-content top clearfix">' . $widget_content_top_content . '</div>';
	}
}