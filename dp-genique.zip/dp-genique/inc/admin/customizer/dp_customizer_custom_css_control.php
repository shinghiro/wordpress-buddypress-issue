<?php
/**
 * Extend default custom CSS setting
 */
class DP_Customize_Custom_CSS_Control extends WP_Customize_Control {
	public function render() {
?><li id="customize-control-custom_css" class="customize-control customize-control-textarea">
	<?php $this->render_content(); ?>
</li><?php
	}

	public function render_content() {?>
<label>
<?php if ( ! empty( $this->label ) ) : ?>
	<span class="customize-control-title"><?php echo esc_html( $this->label ); ?></span>
<?php endif;
if ( ! empty( $this->description ) ) : ?>
	<span class="description customize-control-description"><?php echo $this->description; ?></span>
<?php endif; ?>
<textarea <?php echo 'id="dp_code_textarea" class="code dp_code_textarea"'; ?> <?php $this->link(); ?>><?php echo esc_textarea( $this->value() ); ?></textarea>
</label><?php
	}
}