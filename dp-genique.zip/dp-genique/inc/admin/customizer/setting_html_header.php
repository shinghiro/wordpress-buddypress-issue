<?php
// **********************************************
// HTML head section
// **********************************************
// remove pre control
$wp_customize->remove_control('blogname');
$wp_customize->remove_control('blogdescription');
$wp_customize->remove_control('display_header_text');
/**
 * <title>tag
 */
$id = 'title_site_name_top';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'sanitize_callback' => 'dp_sanitize_html',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'label' => __('Site title (Home)','DigiPress'),
	'description' => __('*This is used to title tag.','DigiPress'),
	'section' => 'title_tagline',
	'input_attrs' => array(
		'placeholder' => $def_options[$id],
	),
	'type' => 'text'
	)
));
$id = 'title_site_name';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'sanitize_callback' => 'dp_sanitize_html',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'label' => __('Site title (Except home)','DigiPress'),
	'description' => __('*This is used to title tag.','DigiPress'),
	'section' => 'title_tagline',
	'input_attrs' => array(
		'placeholder' => $def_options[$id],
	),
	'type' => 'text'
	)
));

/**
 * Disable meta keywords
 */
$id = 'disable_meta_keywords';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'label' => __('Disable insert meta keywords','DigiPress'),
	'fake_title' => __('meta keywords setting','DigiPress'),
	'note' => __('*Check this option to disable inserting meta keywords tag in head section.','DigiPress'),
	'description' => '',
	'section' => 'title_tagline',
	'type' => 'checkbox'
	)
));
/**
 * meta keywords
 */
$id = 'meta_def_kw';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'sanitize_callback' => 'sanitize_text_field',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'description' => __('Enter keywords for home meta tag.','DigiPress'),
	'note' => __('*Use comma to separate multiple keywords.', 'DigiPress'),
	'section' => 'title_tagline',
	'type' => 'text',
	'input_attrs' => array(
		'placeholder' => $def_options[$id],
		)
	)
));
/**
 * meta description
 */
$id = 'meta_def_desc';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'sanitize_callback' => 'sanitize_text_field',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'label' => __('Enter the description for meta tag','DigiPress'),
	'note' => __('*Within about 120 characters.', 'DigiPress'),
	'section' => 'title_tagline',
	'input_attrs' => array(
		'placeholder' => $def_options[$id],
	),
	'type' => 'textarea'
	)
));
/**
 * og:image
 */
$id = 'meta_ogp_img_url';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'sanitize_callback' => 'sanitize_text_field',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'label' => __('Thumbnail URL for OGP(og:image)','DigiPress'),
	'note' => __('*This image is used in top page or archive page. Eyecatch image is setted in single page.','DigiPress').'<br />'.__('*Recommended image size is over 1200 x 630 pixel.','DigiPress').'<br />'.__('*This option is disabled when All in One SEO Pack is enabled.','DigiPress'),
	'section' => 'title_tagline',
	'input_attrs' => array(
		'placeholder' => 'https://example.com/ogpimage.png',
	),
	'type' => 'text'
	)
));
/**
 * Original contents of head section(PC)
 */
$id = 'custom_head_content';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage'
));
if ( version_compare( $wp_version, '4.9', '>=' ) ) {
	$wp_customize->add_control( new WP_Customize_Code_Editor_Control(
		$wp_customize,
		'dp_theme_options['.$id.']', array(
		'setting'=> 'dp_theme_options['.$id.']',
		'label' => __('Custom codes in head section','DigiPress').'(PC)',
		'description' => __('*You can add your custom code(stats code, meta tag, link tag, style tag(CSS), Javascript, etc) to head tag.','DigiPress'),
		'code_type' => 'text/x-scss',
		'section' => 'title_tagline'
		)
	));
} else {
	$wp_customize->add_control( new DP_Customize_Textarea_Control(
		$wp_customize,
		'dp_theme_options['.$id.']', array(
		'settings' => 'dp_theme_options['.$id.']',
		'label' => __('Custom codes in head section','DigiPress').'(PC)',
		'note' => __('*You can add your custom code(stats code, meta tag, link tag, style tag(CSS), Javascript, etc) to head tag.','DigiPress'),
		'other_class' => 'dp_code_textarea html-head code',
		'section' => 'title_tagline',
		'type' => 'textarea'
		)
	));
}
$id = 'custom_head_content_mobile';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage'
));
if ( version_compare( $wp_version, '4.9', '>=' ) ) {
	$wp_customize->add_control( new WP_Customize_Code_Editor_Control(
		$wp_customize,
		'dp_theme_options['.$id.']', array(
		'setting'=> 'dp_theme_options['.$id.']',
		'label' => __('Custom codes in head section','DigiPress').__('(Mobile)','DigiPress'),
		'code_type' => 'text/x-scss',
		'section' => 'title_tagline'
		)
	));
} else {
	$wp_customize->add_control( new DP_Customize_Textarea_Control(
		$wp_customize,
		'dp_theme_options['.$id.']', array(
		'settings' => 'dp_theme_options['.$id.']',
		'label' => __('Custom codes in head section','DigiPress').__('(Mobile)','DigiPress'),
		'other_class' => 'dp_code_textarea html-head code',
		'section' => 'title_tagline',
		'type' => 'textarea'
		)
	));
}