<?php
/**
 * Expand default Code Editor Control
 */
class DP_Customize_Code_Editor_Control extends WP_Customize_Control {
	public $type = 'code_editor';
	public $code_type = '';
	public $editor_settings = array();

	public function enqueue() {
		$this->editor_settings = wp_enqueue_code_editor( array_merge(
			array(
				'type' => $this->code_type,
				'codemirror' => array(
					'indentUnit' => 2,
					'tabSize' => 2,
				),
			),
			$this->editor_settings
		) );
	}
	public function json() {
		$json = parent::json();
		$json['editor_settings'] = $this->editor_settings;
		$json['input_attrs'] = $this->input_attrs;
		return $json;
	}
}