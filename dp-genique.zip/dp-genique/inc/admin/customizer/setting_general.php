<?php
// **********************************************
// General Setting section
// **********************************************
$wp_customize->add_panel( 'dp_general_setting_panel', array(
	'priority' => 1,
	'title' => __('Site General Settings', 'DigiPress'),
	'description' => __('General settings for this site.', 'DigiPress')
));
// Standardization section
$wp_customize->add_section(
	'dp_standardization_section', array(
	'title' => __('Standardization', 'DigiPress'),
	'description' => __('Standardization options of this site.', 'DigiPress'),
	'panel' => 'dp_general_setting_panel',
	'priority' => 1
));
// Acceleration setting
$wp_customize->add_section(
	'dp_acceleration_section', array(
	'title' => __('Acceleration Setting', 'DigiPress'),
	'description' => __('Settings for web acceleration.', 'DigiPress'),
	'panel' => 'dp_general_setting_panel',
	'priority' => 5
));
// Accent color section
$wp_customize->add_section(
	'dp_accent_colors_section', array(
	'title' => __('Accent Colors', 'DigiPress'),
	'description' => __('Choose accent colors of this site.','DigiPress').'<br />'.__('These colors are used to several elements design.', 'DigiPress'),
	'panel' => 'dp_general_setting_panel',
	'priority' => 10
));
// Eyecatch section
$wp_customize->add_section(
	'dp_post_thumbnail_section', array(
	'title' => __('Post Thumbnail Setting', 'DigiPress'),
	'description' => __('Customize the NO IMAGE and the post thumbnail (eyecatch) image.','DigiPress'),
	'panel' => 'dp_general_setting_panel',
	'priority' => 20
));
// Custom post type section
$wp_customize->add_section(
	'dp_custom_post_type_section', array(
	'title' => __('Custom Post Type Setting', 'DigiPress'),
	'description' => __('Customize the preset news custom post type.', 'DigiPress'),
	'panel' => 'dp_general_setting_panel',
	'priority' => 30
));
// Social plugins section
$wp_customize->add_section(
	'dp_sns_connection_section', array(
	'title' => __('SNS Connection Setting', 'DigiPress'),
	'description' => __('API Settings for Social Plugins.', 'DigiPress'),
	'panel' => 'dp_general_setting_panel',
	'priority' => 40
));
// Google API section
$wp_customize->add_section(
	'dp_google_api_section', array(
	'title' => __('Google API Setting', 'DigiPress'),
	'description' => __('API Settings for Google API.', 'DigiPress'),
	'panel' => 'dp_general_setting_panel',
	'priority' => 50
));
// Body open code
$wp_customize->add_section(
	'dp_body_open_code_section', array(
	'title' => __( 'Custom codes under body tag','DigiPress' ),
	'description' => __( 'If there is any code that needs to be placed at the beginning of the body tag, such as Google Tag Manager\'s analysis code, enter it in this option.', 'DigiPress' ),
	'panel' => 'dp_general_setting_panel',
	'priority' => 60
));
// JSON-LD
$wp_customize->add_section(
	'dp_structured_data_section', array(
	'title' => __('Structured Data Setting', 'DigiPress'),
	'description' => __('Settings for structured data optimization.', 'DigiPress'),
	'panel' => 'dp_general_setting_panel',
	'priority' => 70
));
// Access analyze code
$wp_customize->add_section(
	'dp_access_code_section', array(
	'title' => __('Access Tracking Code', 'DigiPress'),
	'description' => __('Enter the tracking code for analyzing site traffic.', 'DigiPress'),
	'panel' => 'dp_general_setting_panel',
	'priority' => 80
));
// Editor settings
$wp_customize->add_section(
	'dp_editor_section', array(
	'title' => __('Editor Setting', 'DigiPress'),
	'description' => __('Setting about operation of WordPress editor.', 'DigiPress'),
	'panel' => 'dp_general_setting_panel',
	'priority' => 90
));
// Widget settings
$wp_customize->add_section(
	'dp_widget_section', array(
	'title' => __('Widget Screen Setting', 'DigiPress'),
	'description' => __('General settings for widget screen.', 'DigiPress'),
	'panel' => 'dp_general_setting_panel',
	'priority' => 100
));


/**
 * Google jQuery
 */
$id = 'use_google_jquery';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'label' => __('Replace the preset jQuery with that on Google CDN','DigiPress'),
	'note' => __('*Check this option to replace jQuery file on current server to on the Google CDN.','DigiPress'),
	'description' => '',
	'section' => 'dp_standardization_section',
	'priority' => null,
	'type' => 'checkbox'
	)
));
/**
 * Disable top page fade in
 */
// $id = 'disable_top_page_fadein';
// $wp_customize->add_setting(
// 	'dp_theme_options['.$id.']', array(
// 	'default' => $def_options[$id],
// 	'type' => 'option',
// 	'transport' => 'postMessage'
// ));
// $wp_customize->add_control( new DP_Customize_Control(
// 	$wp_customize,
// 	'dp_theme_options['.$id.']', array(
// 	'settings' => 'dp_theme_options['.$id.']',
// 	'label' => __('Disable top page fadein','DigiPress'),
// 	'note' => __('*Disable fadein when top page is showinig.','DigiPress'),
// 	'section' => 'dp_standardization_section',
// 	'type' => 'checkbox'
// 	)
// ));
/**
 * Disable wow.js
 */
$id = 'disable_wow_js';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'label' => __('Disable scroll fadein animation','DigiPress'),
	'note' => __('*Disable fadein animation width titles and articles by page scrolling.','DigiPress'),
	'section' => 'dp_standardization_section',
	'type' => 'checkbox'
	)
));

/**
 * Disable autop
 */
$id = 'disable_auto_format';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'refresh'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'label' => __('Disable auto paragraph function by WordPress','DigiPress'),
	'note' => __('*Check this option to diable the WordPress function that replacing line break to p tag or br tag automatically.','DigiPress'),
	'description' => '',
	'section' => 'dp_standardization_section',
	'type' => 'checkbox'
	)
));
/**
 * replace break to br tag
 */
$id = 'replace_p_to_br';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'refresh'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'label' => __('Replace line breaks with br tags','DigiPress'),
	'note' => __('*Please enable this option if you wish to replace article newlines by br tags after disabling automatic formatting.','DigiPress'),
	'description' => '',
	'section' => 'dp_standardization_section',
	'type' => 'checkbox',
	'active_callback' => 'cb_wpautop'
	)
));

/**
 * Disable OGP meta tags
 */
$id = 'disable_auto_ogp';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'label' => __('Disable insert OGP meta tags automatically','DigiPress'),
	'note' => __('*Check this option to disable inserting OGP meta tags for Facebook and Twitter.','DigiPress'),
	'description' => '',
	'section' => 'dp_standardization_section',
	'type' => 'checkbox'
	)
));
/**
 * Disable canonical tag
 */
$id = 'disable_canonical';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'label' => __('Disable insert canonical tag automatically','DigiPress'),
	'note' => __('*Check this option to disable inserting rel="canonical" tag in head section.','DigiPress'),
	'description' => '',
	'section' => 'dp_standardization_section',
	'type' => 'checkbox'
	)
));
/**
 * Disable DNS prefetch
 */
$id = 'disable_dns_prefetch';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'label' => __('Disable insert DNS prefetch link tag','DigiPress'),
	'note' => __('*Check this option to disable inserting link rel="dns-prefetch" tag in head section.','DigiPress'),
	'description' => '',
	'section' => 'dp_standardization_section',
	'type' => 'checkbox'
	)
));
/**
 * Prevent caching of static js and css
 */
$id = 'remove_resource_url_version_param';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'label' => __('Prevent cache of updated resource file','DigiPress'),
	'note' => __('*Check this option to remove version param from static resource file urls which are js and css, etc.','DigiPress'),
	'description' => '',
	'section' => 'dp_standardization_section',
	'type' => 'checkbox'
	)
));
/**
 * Disable emoji
 */
$id = 'disable_emoji';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage',
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'label' => __('Disable Emoji','DigiPress'),
	'note' => __('*Disable loading the css and javascript for Emoji function.','DigiPress'),
	'description' => '',
	'section' => 'dp_standardization_section',
	'type' => 'checkbox'
	)
));
/**
 * Disable oEmbed
 */
$id = 'disable_oembed';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage',
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'label' => __('Disable oEmbed','DigiPress'),
	'note' => __('*Disable loading the css and javascript for oEmbed function from WP 4.4.','DigiPress'),
	'description' => '',
	'section' => 'dp_standardization_section',
	'type' => 'checkbox'
	)
));
/**
 * Disable multibyte parmalink fix
 */
$id = 'disable_fix_post_slug';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage',
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'label' => __('Disable postslag normalization','DigiPress'),
	'note' => __('*For articles that have already been posted, posting slugs will not change by changing the presence or absence of this option.','DigiPress'),
	'section' => 'dp_standardization_section',
	'type' => 'checkbox'
	)
));
/**
 * Disable accordion effect with list widget
 */
$id = 'disable_li_widget_acc';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'refresh',
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'label' => __('Disable accordion effect of listing widget','DigiPress'),
	'note' => __('*Enable this option to disable the accordion opening and closing effect of the list widget.','DigiPress'),
	'description' => '',
	'section' => 'dp_standardization_section',
	'type' => 'checkbox'
	)
));
/**
 * Replace tha date width english dated
 */
$id = 'date_eng_mode';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'refresh'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'label' => __('Replace the date for english format','DigiPress'),
	'note' => __('*The date that in archive page and single page is changed to english format.', 'DigiPress'),
	'section' => 'dp_standardization_section',
	'type' => 'checkbox'
	)
));
/**
 * Disable breadcrumb
 */
$id = 'hide_breadcrumb';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'refresh'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'label' => __('Hide breadcrumb list','DigiPress'),
	'note' => __('*Breadcrumb list is hidden in top page.','DigiPress'),
	'section' => 'dp_standardization_section',
	'type' => 'checkbox'
	)
));
// For Selective refresh
if (isset($wp_customize->selective_refresh)){
	$wp_customize->selective_refresh->add_partial('dp_theme_options['.$id.']', array(
		'selector' => '#dp_breadcrumb_nav',
		'settings' => 'dp_theme_options['.$id.']'
	));
}

/**
 * Disable Block Editor CSS
 */
$id = 'disable_block_library_css';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage',
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'label' => __('Remove WordPress block library CSS','DigiPress'),
	'note' => __('*Disable loading the css for block contents from WP 5.0.','DigiPress'),
	'description' => '',
	'section' => 'dp_standardization_section',
	'type' => 'checkbox'
	)
));

/**
 * Redirect attachemnt page to home
 */
$id = 'redirect_attachment_page';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage',
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'label' => __('Redirect access to attachments page to home','DigiPress'),
	'note' => __('*Check this if you want to redirect to home of the site when you access the attached file page that is automatically generated for each image uploaded by WordPress.','DigiPress'),
	'description' => '',
	'section' => 'dp_standardization_section',
	'type' => 'checkbox'
	)
));




/**
 * Enable transient cache
 */
$id = 'enable_transient_cache';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'fake_title' => __('Cache Setting', 'DigiPress'),
	'label' => __('Enable cache','DigiPress'),
	'note' => __('*By using the Transients API, the generated content is cached in the database and reused, reducing the load on the server and increasing the speed.','DigiPress'),
	'section' => 'dp_acceleration_section',
	'type' => 'checkbox'
	)
));
/**
 * Disable cache for header banner
 */
$id = 'disable_cache__banner_contents';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'label' => __('Disable header banner caching','DigiPress'),
	'note' => __('*Disable caching of header banner content (header image, slider) on the top page.', 'DigiPress'),
	'section' => 'dp_acceleration_section',
	'type' => 'checkbox',
	'active_callback' => 'cb_transient_cache'
	)
));
/**
 * Disable cache in article loop
 */
$id = 'disable_cache__article_loop';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'label' => __('Disable article list caching in archive page','DigiPress'),
	'note' => __('*Disables caching of the article list on any archive page, such as the front page or category. By using the cache, the loop processing to acquire the article list is omitted, so the load on the server can be reduced.', 'DigiPress'),
	'section' => 'dp_acceleration_section',
	'type' => 'checkbox',
	'active_callback' => 'cb_transient_cache'
	)
));
/**
 * Disable cache for meta in article list
 */
$id = 'disable_cache__loop_post_meta';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'label' => __('Disable cache of the meta in loop','DigiPress'),
	'note' => __('*Disable caching of the article meta information acquired for each article by the widget that outputs the archive page and article list.', 'DigiPress'),
	'section' => 'dp_acceleration_section',
	'type' => 'checkbox',
	'active_callback' => 'cb_transient_cache'
	)
));
/**
 * Disable cache in single meta
 */
$id = 'disable_cache__single_post_meta';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'label' => __('Disable single page meta caching','DigiPress'),
	'note' => __('*Disable caching of article meta information output on a single page.', 'DigiPress'),
	'section' => 'dp_acceleration_section',
	'type' => 'checkbox',
	'active_callback' => 'cb_transient_cache'
	)
));
/**
 * Disable cache for related posts
 */
$id = 'disable_cache__related_posts';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'label' => __('Disable related posts caching','DigiPress'),
	'note' => __('*Disable caching of related articles that are output at the bottom of a single page.', 'DigiPress'),
	'section' => 'dp_acceleration_section',
	'type' => 'checkbox',
	'active_callback' => 'cb_transient_cache'
	)
));
/**
 * Disable cache for post thumbnail
 */
$id = 'disable_cache__post_thumbnail';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'label' => __('Disable post thumbnail caching','DigiPress'),
	'note' => __('*Disable the cache for omitting the acquisition of various images used as post thumbnails, such as post thumbnails uploaded to WordPress, thumbnails of YouTube and Vimeo, and output processing of img tags.', 'DigiPress'),
	'section' => 'dp_acceleration_section',
	'type' => 'checkbox',
	'active_callback' => 'cb_transient_cache'
	)
));
/**
 * Disable cache for thumbnail image size
 */
$id = 'disable_cache__thumbnail_size';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'label' => __('Disable thumbnail size caching','DigiPress'),
	'note' => __('*If you need a thumbnail image other than the image uploaded to WordPress and its size, disable caching to omit the process of calculating the size directly from the image file.', 'DigiPress'),
	'section' => 'dp_acceleration_section',
	'type' => 'checkbox',
	'active_callback' => 'cb_transient_cache'
	)
));
/**
 * Disable cache for JSON-LD
 */
$id = 'disable_cache__json_ld';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'label' => __('Disable structured data(JSON-LD) caching','DigiPress'),
	'note' => __('*Disables the caching of JSON-LD structured data that is automatically generated in the source.', 'DigiPress'),
	'section' => 'dp_acceleration_section',
	'type' => 'checkbox',
	'active_callback' => 'cb_transient_cache'
	)
));

// Dummy button to delete cache
$wp_customize->add_setting(
	'dummy_field_' . $id, array(
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dummy_field_' . $id, array(
	'separator' => true,
	'description' => __('*To delete the cache, go to the DigiPress settings panel.', 'DigiPress'),
	'before_text' => '<p><a href="admin.php?page=digipress" class="button" target="_blank">' . __('Open the setting panel', 'DigiPress') . '</a></p>',
	'section' => 'dp_acceleration_section',
	'type' => 'text',
	)
));



/**
 * Disable Barba.js(PJAX)
 */
$id = 'disable_pjax';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'fake_title' => __('Pjax Mode Setting', 'DigiPress'),
	'label' => __('Disable ajax page loading','DigiPress'),
	'note' => __('*Disable smooth asynchronous page transition by ajax.','DigiPress').'<br />'.__('*If you enable this option, the page transition effect will also be disabled.','DigiPress'),
	'section' => 'dp_acceleration_section',
	'type' => 'checkbox'
	)
));
/**
 * Disable pjax page transition effect
 */
$id = 'disable_pjax_transition';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'label' => __('Disable page transition effect in ajax loading','DigiPress'),
	'note' => __('*Disable the transition effect on asynchronous page transition by ajax.','DigiPress').'<br />'.__('*If you enable this option, the page transition time is the fastest.','DigiPress'),
	'section' => 'dp_acceleration_section',
	'type' => 'checkbox',
	'active_callback' => 'cb_pjax'
	)
));
/**
 * ignore classes for ajax page loading
 */
$id = 'ignore_pjax_class';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'sanitize_callback' => 'sanitize_text_field',
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'before_text' => __('Anchor classes to ignore ajax transition','DigiPress'),
	'section' => 'dp_acceleration_section',
	'note' => __('*If there is a link to disable asynchronous page transition by Ajax, specify the class of that anchor tag.','DigiPress').'<br />'.__('*If there are multiple classes that disable Ajax page loading, separate them with a comma.','DigiPress'),
	'type' => 'text',
	'input_attrs' => array(
		'placeholder' => $def_options[$id],
		),
	'active_callback' => 'cb_pjax'
	)
));




/**
 * Primary color
 */
$id = 'primary_color';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'sanitize_callback' => 'sanitize_hex_color',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new WP_Customize_Color_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'label' => __('Primary Color','DigiPress'),
	'section' => 'dp_accent_colors_section'
	)
));
/**
 * Enable gradient
 */
$id = 'enable_primary_color_gradient';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'label' => __('Enable common background color gradation', 'DigiPress'),
	'note' => __('*Gradients the element whose primary color is displayed as the background color.','DigiPress'),
	'section' => 'dp_accent_colors_section',
	'type' => 'checkbox'
	)
));
/**
 * Secondary color
 */
$id = 'secondary_color';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'sanitize_callback' => 'sanitize_hex_color',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new WP_Customize_Color_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'label' => __('Secondary Color','DigiPress'),
	'section' => 'dp_accent_colors_section'
	)
));

/**
 * NO Image setting
 */
$id = 'dp_no_image_url';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'sanitize_callback' => 'esc_url_raw',
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new WP_Customize_Image_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'label' => __('Your image for NO IMAGE','DigiPress'),
	'description' => __('*There is no restriction on the ratio of the image, but in consideration of the display on the high definition display, the width of the image should be at least 1600 pixels.', 'DigiPress') . '<br />' . __('*To restore the default NO IMAGE image, clear the specified image with the "Delete" button.', 'DigiPress'),
	'section' => 'dp_post_thumbnail_section'
	)
));
/**
 * Use the first url of article as eyecatch
 */
$id = 'set_eyecatch_first_img';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'fake_title' => __('Auto eyecatch image setting', 'DigiPress'),
	'label' => __('Use the first image URL of the article as eyecatch image', 'DigiPress'),
	'note' => __('*If you want to substitute the image URL specified in the first img tag in the article as eyecatching image in an article that does not have an eyecatch image specified, enable this option.', 'DigiPress'),
	'section' => 'dp_post_thumbnail_section',
	'type' => 'checkbox'
	)
));

/**
 * News Custom post type ID
 */
$id = 'news_cpt_slug_id';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'sanitize_callback' => 'sanitize_text_field',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'label' => __('News custom post type slug','DigiPress'),
	'note' => __('*Please blank this field to use default slug(news).','DigiPress').'<br />'.__('*After changing this setting, be sure to save the WordPress permalink setting again.','DigiPress'),
	'section' => 'dp_custom_post_type_section',
	'type' => 'text',
	'input_attrs' => array(
		'placeholder' => $def_options[$id],
		)
	)
));
/**
 * News Custom post type name
 */
$id = 'news_cpt_name';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'label' => __('News custom post type name','DigiPress'),
	'section' => 'dp_custom_post_type_section',
	'type' => 'text',
	'input_attrs' => array(
		'placeholder' => __($def_options[$id], 'DigiPress'),
		)
	)
));

/**
 * SNS count setting
 */
$id = 'disable_sns_share_count';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'fake_title' => __('SNS share count setting','DigiPress'),
	'label' => __('Do not count SNS shares, only show buttons', 'DigiPress'),
	'note' => __('*Do not display the number of shares of each SNS on the number of SNS shares displayed on the archive page or on the single page\'s SNS share button, and check only when displaying only the SNS button.<br />*If this option is enabled, the Javascript module for acquiring the number of shares will not be loaded, and communication with each API executed to obtain the number of shares will be lost, improving the page display speed.', 'DigiPress'),
	'section' => 'dp_sns_connection_section',
	'type' => 'checkbox'
	)
));

$id = 'share_count_cache';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'label' => __('Enable cache', 'DigiPress'),
	'section' => 'dp_sns_connection_section',
	'type' => 'checkbox'
	)
));

$id = 'share_count_cache_time';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'sanitize_callback' => 'absint',
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'before_text' => __('Cache time','DigiPress'),
	'unit' => __('milliseconds', 'DigiPress'),
	'note' => __('*Please enable the caching function as much as possible to improve the page display speed and reduce the load.','DigiPress').'<br />'.__('*Cache time range is from 1 hour(3600000) to 1 week(604800000).', 'DigiPress').'<br />'.__('*It is necessary to register the site in the following service in advance to acquire the number of tweets.','DigiPress').'<div><i class="dashicons-before dashicons-external"></i><a href="https://jsoon.digitiminimi.com/" target="_blank">count.jsoon</a></div>',
	'section' => 'dp_sns_connection_section',
	'type' => 'number',
	'input_attrs' => array('min' => 3600000,'max' => 86400000,'step' => 60000)
	)
));

/**
 * Facebook App ID
 */
$id = 'fb_app_id';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'sanitize_callback' => 'sanitize_text_field',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'label' => __('Facebook App ID','DigiPress'),
	'note' => __('* To display the Facebook page plug-in widget, you need to register as a developer at Facebook developers, and register "application ID" issued after creating a new application.', 'DigiPress').'<br /><i class="dashicons-before dashicons-external"></i><a href="https://developers.facebook.com/apps/" target="_blank">'.__('Generate or check on Facebook for developers', 'DigiPress').'</a>',
	'section' => 'dp_sns_connection_section',
	'type' => 'text',
	'input_attrs' => array(
		'placeholder' => '123456789012345'
		)
	)
));
/**
 * Facebook App language
 */
$id = 'fb_api_lang';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'before_text' => __('Display language','DigiPress'),
	'section' => 'dp_sns_connection_section',
	'type' => 'select',
	'choices' => array(
		'ja_JP' => __('Japanese', 'DigiPress'),
		'ja_KS' => __('Japanese(Kansai)','DigiPress'),
		'en_US' => __('English','DigiPress'),
		'fr_FR' => __('French','DigiPress'),
		'de_DE' => __('German','DigiPress'),
		'it_IT' => __('Italian','DigiPress'),
		'zh_HK' => __('Chinese','DigiPress')
			)
	)
));
/**
 * Twitter card
 */
$id = 'twitter_card_user_id';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'sanitize_callback' => 'sanitize_text_field',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'label' => __('Twitter user ID (*Exclude @ prefix)','DigiPress'),
	'note' => __('*Twitter user ID is required to display Twitter card automatically.','DigiPress').'<br />'.'<i class="dashicons-before dashicons-external"></i><a href="https://cards-dev.twitter.com/validator" target="_blank">'.__('How to validate twitter card', 'DigiPress').'</a>',
	'section' => 'dp_sns_connection_section',
	'type' => 'text',
	'input_attrs' => array(
		'placeholder' => 'twitter_user_id',
		)
	)
));

/**
 * Google custom search ID
 */
$id = 'gcs_id';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'sanitize_callback' => 'sanitize_text_field',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'label' => __('Google Custom Search Engine ID','DigiPress'),
	'note' => __('*It is necessary to use Google Custom Search instead of default site search form.','DigiPress').'<br /><i class="dashicons-before dashicons-external"></i><a href="https://cse.google.com/cse/manage/all" target="_blank">'.__('Create or check on Google', 'DigiPress').'</a>',
	'section' => 'dp_google_api_section',
	'type' => 'text',
	'input_attrs' => array(
		'placeholder' => '001234567890123456789:xxxxxxxxxxxx',
		)
	)
));
/**
 * Google Map API key
 */
$id = 'google_api_key';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'sanitize_callback' => 'sanitize_text_field',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'label' => __('Google Map API Key','DigiPress'),
	'note' => __('*It is necessary to show Google Map by [gmaps] shortcode.','DigiPress').'<br /><i class="dashicons-before dashicons-external"></i><a href="https://console.developers.google.com/projectcreate" target="_blank">'.__('Create on Google Cloud Platform', 'DigiPress').'</a>'.__(' or ', 'DigiPress'). '<i class="dashicons-before dashicons-external"></i><a href="https://console.cloud.google.com/apis/credentials" target="_blank">'.__('check the existing API key.', 'DigiPress').'</a>',
	'section' => 'dp_google_api_section',
	'type' => 'text',
	'input_attrs' => array(
		'placeholder' => 'ARtCBgPOb9_k2R9-l5erbuLoNFEwqzkfX9S3bPf',
		)
	)
));

/**
 * Custom code after opening body tag
 */
$id = 'body_open_code';
$wp_customize->add_setting(
	'dp_theme_options[' . $id . ']', array(
	'default' => $def_options[ $id ],
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new WP_Customize_Code_Editor_Control(
	$wp_customize,
	'dp_theme_options[' . $id . ']', array(
	'setting'=> 'dp_theme_options[' . $id . ']',
	'label' => __( 'Custom codes under body tag', 'DigiPress' ) . '(PC)',
	'code_type' => 'text/x-scss',
	'section' => 'dp_body_open_code_section'
	)
));
$id = 'body_open_code_mobile';
$wp_customize->add_setting(
	'dp_theme_options[' . $id . ']', array(
	'default' => $def_options[ $id ],
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new WP_Customize_Code_Editor_Control(
	$wp_customize,
	'dp_theme_options[' . $id . ']', array(
	'setting'=> 'dp_theme_options[' . $id . ']',
	'label' => __( 'Custom codes under body tag', 'DigiPress' ) . __( '(Mobile)','DigiPress' ),
	'code_type' => 'text/x-scss',
	'section' => 'dp_body_open_code_section'
	)
));

/**
 * Logo image for JSON-LD
 */
$id = 'json_ld_logo_img_url';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'sanitize_callback' => 'sanitize_text_field',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'label' => __('Site logo image URL(600 x 60px)','DigiPress'),
	'note' => __('*Specify the URL of the logo image of the site used for structured data (JSON-LD). The logo image must be 600 pixels wide and 60 pixels tall.', 'DigiPress').'<br />'.__('*When the URL of the logo image is not specified, the URL of the site title image is automatically used.','DigiPress'),
	'section' => 'dp_structured_data_section',
	'type' => 'text',
	'input_attrs' => array(
		'placeholder' => 'https://yoursite.com/uploads/site-logo600x60.png',
		)
	)
));

/**
 * Access tracking code
 */
$id = 'tracking_code';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage'
));
if ( version_compare( $wp_version, '4.9', '>=' ) ) {
	$wp_customize->add_control( new WP_Customize_Code_Editor_Control(
		$wp_customize,
		'dp_theme_options['.$id.']', array(
		'setting'=> 'dp_theme_options['.$id.']',
		'label' => __('Access tracking code','DigiPress'),
		'code_type' => 'text/x-scss',
		'section' => 'dp_access_code_section'
		)
	));
} else {
	$wp_customize->add_control( new DP_Customize_Textarea_Control(
		$wp_customize,
		'dp_theme_options['.$id.']', array(
		'settings' => 'dp_theme_options['.$id.']',
		'label' => __('Access tracking code','DigiPress'),
		'other_class' => 'dp_code_textarea html-head code',
		'section' => 'dp_access_code_section',
		'type' => 'textarea'
		)
	));
}
$id = 'no_track_admin';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'label' => __("Don't count the access of logged in user",'DigiPress'),
	'note' => __('*If you enable this option, access to the site of the administrator who is logging in will not be counted and will be passed through.','DigiPress'),
	'section' => 'dp_access_code_section',
	'type' => 'checkbox'
	)
));


/**
 * Editor settings
 */
// Disable to insert custom quick tags
$id = 'disable_add_quick_tags';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'fake_title' => __('Classic Editor (plugin)', 'DigiPress'),
	'label' => __('Disable additional quick tag buttons','DigiPress'),
	'note' => __('*Check this if you don\'t want to add the original quick tag button to the text editor.','DigiPress'),
	'section' => 'dp_editor_section',
	'type' => 'checkbox'
	)
));

// Enable half image sizes atrribute for img tag when img tag sending to editor
$id = 'retina_img_tag_to_editor';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'label' => __('Insert an img tag with resized width and height attributes for high definition displays','DigiPress'),
	'note' => __('* When inserting the img tag of the upload image from the editor, check it when inserting it as an img tag with width value and height value of half the actual image size for high definition display.', 'DigiPress') . '<br />' . __('* Make sure that the image you upload is twice as large (resolution) as you would like to see it.', 'DigiPress'),
	'section' => 'dp_editor_section',
	'type' => 'checkbox'
	)
));

/**
 * Widget settings
 */
// Disable block based widget
$id = 'disable_block_based_widget';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'fake_title' => __('Classic Widgets Screen', 'DigiPress'),
	'label' => __('Revert to Classic Widgets Screen','DigiPress'),
	'note' => __('*Check this if you want to revert the Block Based Widget screen implemented in WordPress 5.8 to the previous widget screen.','DigiPress'),
	'section' => 'dp_widget_section',
	'type' => 'checkbox'
	)
));


/**
 * Callbacks
 */
function cb_wpautop($control) {
	$disable_auto_format = $control->manager->get_setting('dp_theme_options[disable_auto_format]')->value();
	$control_id = $control->id;

	$result = false;
	if ($disable_auto_format && (
		$control_id === 'dp_theme_options[replace_p_to_br]'

	)){
		return true;
	}
	return $result;
}

function cb_pjax($control) {
	$disable_pjax = $control->manager->get_setting('dp_theme_options[disable_pjax]')->value();
	$control_id = $control->id;

	$result = true;
	if ($disable_pjax && (
		$control_id === 'dp_theme_options[disable_pjax_transition]' ||
		$control_id === 'dp_theme_options[ignore_pjax_class]'

	)){
		return false;
	}
	return $result;
}

function cb_transient_cache($control){
	$enable_cache = $control->manager->get_setting('dp_theme_options[enable_transient_cache]')->value();
	$control_id = $control->id;

	$result = false;
	if ( $enable_cache && (
		$control_id === 'dp_theme_options[disable_cache__banner_contents]' ||
		$control_id === 'dp_theme_options[disable_cache__article_loop]' ||
		$control_id === 'dp_theme_options[disable_cache__loop_post_meta]' ||
		$control_id === 'dp_theme_options[disable_cache__single_post_meta]' ||
		$control_id === 'dp_theme_options[disable_cache__related_posts]' ||
		$control_id === 'dp_theme_options[disable_cache__post_thumbnail]' ||
		$control_id === 'dp_theme_options[disable_cache__thumbnail_size]' ||
		$control_id === 'dp_theme_options[disable_cache__json_ld]'

	)){
		return true;
	}
	return $result;
}