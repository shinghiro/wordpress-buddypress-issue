<?php
/**
 * Extend default textarea control
 */
class DP_Customize_Textarea_Control extends WP_Customize_Control {
	public $note = '';
	public $other_class = '';
	public $separator = '';
	public $rows = '';

	public function render() {
		$id    = 'customize-control-' . str_replace( array( '[', ']' ), array( '-', '' ), $this->id );
		$class = 'customize-control customize-control-' . $this->type; 
?><li id="<?php echo esc_attr( $id ); ?>" class="<?php echo esc_attr( $class ); ?>"><?php $this->render_content(); ?></li><?php
	}

	public function render_content() {
		$other_class = isset($this->other_class) && !empty($this->other_class) ? ' class="'.esc_attr($this->other_class).'"' : '';
		$rows = isset($this->rows) && !empty($this->rows) ? esc_attr($this->rows) : '5';
		$note = isset($this->note) && !empty($this->note) ? '<div class="slide-title dashicons-before dashicons-info">'.__("Note...", "DigiPress").'</div><div class="slide-content">'.$this->note.'</div>' : '';
		$separator = isset($this->separator) && !empty($this->separator) ? '<hr />' : '';
?><label>
<?php if ( ! empty( $this->label ) ) : ?>
<span class="customize-control-title"><?php echo esc_html( $this->label ); ?></span>
<?php endif;
if ( ! empty( $this->description ) ) : ?>
<span class="description customize-control-description"><?php echo $this->description; ?></span>
<?php endif; ?>
<textarea rows="<?php echo $rows; ?>"<?php echo $other_class; ?> <?php $this->input_attrs(); ?> <?php $this->link(); ?>><?php echo esc_textarea( $this->value() ); ?></textarea><?php echo $note; ?>
</label><?php
		echo $separator;
	}
}