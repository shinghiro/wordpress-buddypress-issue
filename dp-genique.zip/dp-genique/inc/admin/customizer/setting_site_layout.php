<?php
// **********************************************
// Site Layout
// **********************************************
$wp_customize->add_section(
	'dp_site_layout_section', array(
	'priority' => 21,
	'title' => __('Site Layout / Columns', 'DigiPress'),
	'description' => __('Select the layout of this site.', 'DigiPress'),
));
/**
 * Column
 */
$id = 'site_layout';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'sanitize_callback' => 'sanitize_key',
	'type' => 'option',
	'transport' => 'refresh'
));
$wp_customize->add_control( new DP_Customize_Control_Radio_Image(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'label' => __('Site Colmuns Setting','DigiPress'),
	'section' => 'dp_site_layout_section',
	'choices'  => array(
		'content-sb' => array(
			'label' => esc_html__( 'Content / Sidebar', 'DigiPress' ),
			'url'   => '%s/inc/admin/img/content-sb.png'
			),
		'sb-content' => array(
			'label' => esc_html__( 'Sidebar / Content', 'DigiPress' ),
			'url'   => '%s/inc/admin/img/sb-content.png'
			),
		'content' => array(
			'label' => esc_html__( 'Content - One Column', 'DigiPress' ),
			'url'   => '%s/inc/admin/img/content.png'
			)
		)
	)
));
// For Selective refresh
if (isset($wp_customize->selective_refresh)){
	$wp_customize->selective_refresh->add_partial('dp_theme_options['.$id.']', array(
		'selector' => '.content-wrap',
		'settings' => 'dp_theme_options['.$id.']'
	));
}

/**
 * One column only top page
 */
$id = 'one_col_only_top';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'refresh'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'label' => __('Disable sidebar in top page','DigiPress'),
	'section' => 'dp_site_layout_section',
	'type' => 'checkbox'
	)
));


/**
 * Full wide container
 */
$id = 'full_wide_container_widget_area_top';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'refresh'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'fake_title' => __('Container Area Width', 'DigiPress'),
	'label' => __('Set the Container Area Top full-wide','DigiPress'),
	'section' => 'dp_site_layout_section',
	'type' => 'checkbox'
	)
));

$id = 'full_wide_container_widget_area_bottom';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'refresh'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'label' => __('Set the Container Area Bottom full-wide','DigiPress'),
	'note' => __('*Check this if you want to change the display width of the Container Area widget space from the fixed width of the normal container area to the liquid layout that varies according to the display width.', 'DigiPress'),
	'section' => 'dp_site_layout_section',
	'type' => 'checkbox'
	)
));