<?php
// **********************************************
// Site background setting
$wp_customize->add_section(
	'dp_site_background', array(
	'title' => __('Site Background Settings', 'DigiPress'),
	'description' => __('Customize the background views.', 'DigiPress'),
	'theme_supports' => 'custom-background',
	'priority' => 70
));

/**
 * Background color
 */
$id = 'container_bg_color';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'sanitize_callback' => 'sanitize_hex_color',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new WP_Customize_Color_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'label' => __('Container area background color','DigiPress'),
	'section' => 'dp_site_background'
	)
));


/**
 * Background color opacity
 */
$id = 'container_bg_opacity';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'sanitize_callback' => 'absint',
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Range_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'label' => __('Background color opacity','DigiPress'),
	'unit' => '%',
	'section' => 'dp_site_background',
	'type' => 'custom_range',
	'input_attrs' => array(
		'min' => 0,
		'max' => 100,
		'step' => 1
		)
	)
));

/**
 * Background image
 */
$id = 'background_img';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'sanitize_callback' => 'esc_url_raw',
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new WP_Customize_Image_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'label' => __('Background Image','DigiPress'),
	'section' => 'dp_site_background'
	)
));

$id = 'background_repeat';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'label' => __( 'Background Repeat','DigiPress'),
	'section' => 'dp_site_background',
	'type' => 'select',
	'choices' => array(
		'no-repeat' => __('No Repeat', 'DigiPress'),
		'repeat' => __('Repeat all', 'DigiPress'),
		'repeat-x' => __('Repeat horizontally', 'DigiPress'),
		'repeat-y' => __('Repeat vertically', 'DigiPress')
		)
	)
));