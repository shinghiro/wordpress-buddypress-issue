<?php
// init
$id = '';
// **********************************************
// Header bar area section
// **********************************************
$wp_customize->add_panel( 'dp_offcanvas_menu_area_panel', array(
	'priority' => 45,
	'title' => __('Offcanvas Menu Area Settings', 'DigiPress'),
	'description' => __('Settings for offcanvas menu area of this site.', 'DigiPress'),
));
// Hidden menu section
$wp_customize->add_section(
	'dp_offcanvas_menu_area_section', array(
	'title' => __('Color Settings', 'DigiPress'),
	'description' => __('Choose background color and link color in offcanvas menu area.', 'DigiPress'),
	'panel' => 'dp_offcanvas_menu_area_panel',
	'priority' => 10
));
// SNS and RSS section
$wp_customize->add_section(
	'dp_offcanvas_menu_area_sns_rss_section', array(
	'title' => __('SNS, RSS and Cotact Icons', 'DigiPress'),
	'description' => __('Select SNS and RSS links to display in header area.', 'DigiPress'),
	'panel' => 'dp_offcanvas_menu_area_panel',
	'priority' => 20
));
// Tel number section
$wp_customize->add_section(
	'dp_offcanvas_menu_area_tel_section', array(
	'title' => __('Telephone Number', 'DigiPress'),
	'description' => __('Enter the telephone number to display in header area.', 'DigiPress'),
	'panel' => 'dp_offcanvas_menu_area_panel',
	'priority' => 30
));
// Search form section
$wp_customize->add_section(
	'dp_offcanvas_menu_area_search_form_section', array(
	'title' => __('Search Form Setting', 'DigiPress'),
	'description' => __('Settings for search form in offcanvas area.', 'DigiPress'),
	'panel' => 'dp_offcanvas_menu_area_panel',
	'priority' => 40
));


/**
 * Dummy option to navigte target
 */
$wp_customize->add_setting( 'dp_dummy_hidden_menu', array(
	'transport' => 'postMessage'
));
$wp_customize->add_control( 'dp_dummy_hidden_menu', array(
    'section' => 'dp_offcanvas_menu_area_section'
));
// For Selective refresh
if (isset($wp_customize->selective_refresh)){
	$wp_customize->selective_refresh->add_partial('dp_dummy_hidden_menu', array(
		'selector' => '#offcanvas_menu_area'
	));
}
/**
 * Hidden menu bg color
 */
$id = 'hidden_menu_bgcolor';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage',
	'sanitize_callback' => 'sanitize_hex_color'
));
$wp_customize->add_control( new WP_Customize_Color_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'label' => __('Background color','DigiPress'),
	'section' => 'dp_offcanvas_menu_area_section'
	)
));
/**
 * Hidden menu link color
 */
$id = 'hidden_menu_link_color';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage',
	'sanitize_callback' => 'sanitize_hex_color'
));
$wp_customize->add_control( new WP_Customize_Color_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'label' => __('Font / link color','DigiPress'),
	'section' => 'dp_offcanvas_menu_area_section'
	)
));

/**
 * Header Facebook icon
 */
$id = 'global_menu_fb_url';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => '',
	'type' => 'option',
	'sanitize_callback' => 'esc_url_raw',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'label' => __('Facebook URL','DigiPress'),
	'section' => 'dp_offcanvas_menu_area_sns_rss_section',
	'input_attrs' => array(
		'placeholder' => $def_options[$id],
	),
	'type' => 'text'
	)
));
// For Selective refresh
if (isset($wp_customize->selective_refresh)){
	$wp_customize->selective_refresh->add_partial('dp_theme_options['.$id.']', array(
		'selector' => '#hd_sns_links .menu-item.fb',
		'settings' => 'dp_theme_options['.$id.']'
	));
}

/**
 * Header twitter icon
 */
$id = 'global_menu_twitter_url';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => '',
	'type' => 'option',
	'sanitize_callback' => 'esc_url_raw',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'label' => __('Twitter URL','DigiPress'),
	'section' => 'dp_offcanvas_menu_area_sns_rss_section',
	'input_attrs' => array(
		'placeholder' => $def_options[$id],
	),
	'type' => 'text'
	)
));
// For Selective refresh
if (isset($wp_customize->selective_refresh)){
	$wp_customize->selective_refresh->add_partial('dp_theme_options['.$id.']', array(
		'selector' => '#hd_sns_links .menu-item.tw',
		'settings' => 'dp_theme_options['.$id.']'
	));
}

/**
 * Header Instagram icon
 */
$id = 'global_menu_instagram_url';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => '',
	'type' => 'option',
	'sanitize_callback' => 'esc_url_raw',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'label' => __('Instagram URL','DigiPress'),
	'section' => 'dp_offcanvas_menu_area_sns_rss_section',
	'input_attrs' => array(
		'placeholder' => $def_options[$id],
	),
	'type' => 'text'
	)
));
// For Selective refresh
if (isset($wp_customize->selective_refresh)){
	$wp_customize->selective_refresh->add_partial('dp_theme_options['.$id.']', array(
		'selector' => '#hd_sns_links .menu-item.instagram',
		'settings' => 'dp_theme_options['.$id.']'
	));
}

/**
 * Header YouTube icon
 */
$id = 'global_menu_youtube_url';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => '',
	'type' => 'option',
	'sanitize_callback' => 'esc_url_raw',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'label' => __('YouTube URL','DigiPress'),
	'section' => 'dp_offcanvas_menu_area_sns_rss_section',
	'input_attrs' => array(
		'placeholder' => $def_options[$id],
	),
	'type' => 'text'
	)
));
// For Selective refresh
if (isset($wp_customize->selective_refresh)){
	$wp_customize->selective_refresh->add_partial('dp_theme_options['.$id.']', array(
		'selector' => '#hd_sns_links .menu-item.youtube',
		'settings' => 'dp_theme_options['.$id.']'
	));
}

/**
 * Contact URL
 */
$id = 'global_menu_contact_url';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => '',
	'type' => 'option',
	'sanitize_callback' => 'esc_url_raw',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'label' => __('Contact Page URL','DigiPress'),
	'section' => 'dp_offcanvas_menu_area_sns_rss_section',
	'input_attrs' => array(
		'placeholder' => $def_options[$id],
	),
	'type' => 'text'
	)
));
// For Selective refresh
if (isset($wp_customize->selective_refresh)){
	$wp_customize->selective_refresh->add_partial('dp_theme_options['.$id.']', array(
		'selector' => '#hd_sns_links .menu-item.contact_url',
		'settings' => 'dp_theme_options['.$id.']'
	));
}

/**
 * RSS Link
 */
$id = 'global_menu_rss';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'label' => __('RSS Icon Link','DigiPress'),
	'section' => 'dp_offcanvas_menu_area_sns_rss_section',
	'type' => 'select',
	'choices' => array(
		'none' => __('No RSS link','DigiPress'),
		'rss' => __('RSS icon link','DigiPress'),
		'feedly' => __('Feedly icon link','DigiPress')
		)
	)
));
// For Selective refresh
if (isset($wp_customize->selective_refresh)){
	$wp_customize->selective_refresh->add_partial('dp_theme_options['.$id.']', array(
		'selector' => '#hd_sns_links .menu-item.feed',
		'settings' => 'dp_theme_options['.$id.']'
	));
}


/**
 * Telephone number
 */
$id = 'global_menu_tel';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => '',
	'type' => 'option',
	'sanitize_callback' => 'dp_sanitize_html',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'label' => __('Telephone Number','DigiPress'),
	'section' => 'dp_offcanvas_menu_area_tel_section',
	'type' => 'text',
	'input_attrs' => array(
		'placeholder' => $def_options[$id]
		)
	)
));
// For Selective refresh
if (isset($wp_customize->selective_refresh)){
	$wp_customize->selective_refresh->add_partial('dp_theme_options['.$id.']', array(
		'selector' => '.hd_tel',
		'settings' => 'dp_theme_options['.$id.']',
		'render_callback' => function(){
			$options = get_option('dp_theme_options');
			echo '<a href="tel:'.$options['global_menu_tel'].'">'.$options['global_menu_tel'].'</a>';
		}
	));
}



/**
 * Search form
 */
$id = 'global_menu_search_form';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'refresh'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'label' => __('Search Form','DigiPress'),
	'note' => __('*Seach Engine ID is necessary to show Google Custom Search Form.', 'DigiPress').'<br />'.__('*Access [General Settiings] -> [Google API Setting] panel to set the Search Engine ID.', 'DigiPress'),
	'section' => 'dp_offcanvas_menu_area_search_form_section',
	'type' => 'select',
	'choices' => array(
		'none' => __('No search form','DigiPress'),
		'search' => __('Site search form','DigiPress'),
		'gcs' => __('Google Custom Search form','DigiPress')
			)
	)
));
// For Selective refresh
if (isset($wp_customize->selective_refresh)){
	$wp_customize->selective_refresh->add_partial('dp_theme_options['.$id.']', array(
		'selector' => '.hidden_search',
		'settings' => 'dp_theme_options['.$id.']'
	));
}

/**
 * Search options
 */
// Search target post type
$id = 'global_menu_search_form_post_type';
$choices = array(
	'any' => __('All','DigiPress'),
	'post' => __('Posts','DigiPress'),
	'page' => __('WordPress pages','DigiPress')
);
$arr_post_type = get_post_types( array(
	'public'	=> true,
	'_builtin'	=> false
), 'objects');
foreach ($arr_post_type as $key => $cpt ) {
	$choices[$cpt->name] = esc_html($cpt->label);
}
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'label' => __('Search options', 'DigiPress'),
	'description' => __('Search target', 'DigiPress'),
	'note' => __('*You can filter the search to content of specific post type.', 'DigiPress'),
	'section' => 'dp_offcanvas_menu_area_search_form_section',
	'type' => 'select',
	'choices' => $choices,
	'active_callback' => 'cb_offcanvas_search_form_settings'
	)
));

// Preset search
$id = 'global_menu_search_form_preset_kw_title';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => '',
	'type' => 'option',
	'sanitize_callback' => 'dp_sanitize_html',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'description' => sprintf( __('%s area title','DigiPress'), __('Preset search', 'DigiPress') ),
	'section' => 'dp_offcanvas_menu_area_search_form_section',
	'type' => 'text',
	'input_attrs' => array(
		'placeholder' => __($def_options[$id], 'DigiPress')
		),
	'active_callback' => 'cb_offcanvas_search_form_settings'
	)
));
// For Selective refresh
if (isset($wp_customize->selective_refresh)){
	$wp_customize->selective_refresh->add_partial('dp_theme_options['.$id.']', array(
		'selector' => '#hidden-searchform .wd-block-title',
		'settings' => 'dp_theme_options['.$id.']',
		'container_inclusive' => false,
		'render_callback' => function(){
			$options = get_option('dp_theme_options');
			echo $options['global_menu_search_form_preset_kw_title'];
		}
	));
}

// Preset search words
$id = 'global_menu_search_form_preset_kw';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => '',
	'type' => 'option',
	'sanitize_callback' => 'wp_filter_nohtml_kses',
	'transport' => 'refresh'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'description' => __('Preset search words','DigiPress'),
	'note' => __('* Please use comma for separate each keyword.', 'DigiPress'),
	'section' => 'dp_offcanvas_menu_area_search_form_section',
	'type' => 'text',
	'input_attrs' => array(
		'placeholder' => __($def_options[$id], 'DigiPress')
		),
	'active_callback' => 'cb_offcanvas_search_form_settings'
	)
));
// For Selective refresh
if (isset($wp_customize->selective_refresh)){
	$wp_customize->selective_refresh->add_partial('dp_theme_options['.$id.']', array(
		'selector' => '.hidden_search .preset-words-area',
		'settings' => 'dp_theme_options['.$id.']'
	));
}

/**
 * Serch form callback
 */
function cb_offcanvas_search_form_settings($control) {
	$type = $control->manager->get_setting('dp_theme_options[global_menu_search_form]')->value();
	$control_id = $control->id;

	if ( $type === 'search' && ( $control_id === 'dp_theme_options[global_menu_search_form_preset_kw_title]' || $control_id === 'dp_theme_options[global_menu_search_form_preset_kw]' || $control_id === 'dp_theme_options[global_menu_search_form_post_type]' ) ) {
		return true;
	}
	return false;
}
