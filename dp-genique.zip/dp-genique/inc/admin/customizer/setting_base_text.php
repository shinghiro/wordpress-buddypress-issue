<?php
// **********************************************
// Base font setting section
// **********************************************
$wp_customize->add_section(
	'dp_base_text_section', array(
	'title' => __('Base Text Settings', 'DigiPress'),
	'description' => __('Settings for base font, font color and link color about main content area and entry.', 'DigiPress'),
	'priority' => 75
));
/**
 * Typography
 */
$id = 'base_font_color';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'sanitize_callback' => 'sanitize_hex_color',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new WP_Customize_Color_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'label' => __('Typography setting', 'DigiPress' ),
	'description' => __('Font color', 'DigiPress' ),
	'section' => 'dp_base_text_section'
	)
));
$id = 'base_font_size';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'sanitize_callback' => 'dp_sanitize_float',
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'description' => __('Font size(PC)', 'DigiPress' ),
	'unit' => __('pixel', 'DigiPress' ),
	'section' => 'dp_base_text_section',
	'type' => 'number',
	'input_attrs' => array('min' => 8,'max' => 100,'step' => 0.1)
	)
));
$id = 'base_font_size_mb';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'sanitize_callback' => 'dp_sanitize_float',
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'description' => __('Font size(Mobile)', 'DigiPress' ),
	'unit' => __('pixel', 'DigiPress' ),
	'section' => 'dp_base_text_section',
	'type' => 'number',
	'input_attrs' => array('min' => 8,'max' => 100,'step' => 0.1)
	)
));
// Letter spacing
$id = 'base_letter_spacing';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'sanitize_callback' => 'dp_sanitize_float',
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'description' => __('Letter spacing', 'DigiPress' ),
	// 'note' => __('* The "main title part" is a header image, an article title, H1 to H6 in the text, a title of each section, a widget title, etc.', 'DigiPress'),
	'unit' => 'em (' . sprintf( __( 'Default: %s', 'DigiPress' ), $def_options[$id] ) . ')',
	'section' => 'dp_base_text_section',
	'type' => 'number',
	'input_attrs' => array( 'min' => -10, 'max' => 10, 'step' => 0.01 )
	)
));

$id = 'base_font_family';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'description' => __('Font family', 'DigiPress' ),
	'section' => 'dp_base_text_section',
	'note' => '<p class="description"><i class="dashicons dashicons-external"></i><a href="https://fonts.google.com/?subset=japanese" target="_blank">' . __('See Google Fonts for Japanese', 'DigiPress') . '</a></p><p class="description">' . __('※ For Windows, Meiryo is the standard font.', 'DigiPress') . '</p><p class="description">' . __('※ For Mac, "Hiragino Kakugo" is the standard font.', 'DigiPress' ) . '</p><p class="description">' . __('※ When using Noto Sans JP, you can also change the font weight.', 'DigiPress') . '</p>' ,
	'type' => 'select',
	'choices' => array(
		'default' => __('Default font', 'DigiPress' ),
		'yugothic-all' => sprintf( __('Use %s', 'DigiPress' ), __('Yu Gothic', 'DigiPress') ),
		'serif-all' => sprintf( __('Use %s', 'DigiPress' ), __('Yu Mincho', 'DigiPress') ),
		'notosans-all' => sprintf( __('Use %s', 'DigiPress' ), __('Noto Sans JP', 'DigiPress') ),
		'notoserif-all' => sprintf( __('Use %s', 'DigiPress' ), __('Noto Serif JP', 'DigiPress') ),
		'm-plus-1p-all' => sprintf( __('Use %s (%s)', 'DigiPress' ), __('M PLUS 1p', 'DigiPress'), 'Google Fonts'),
		'm-plus-rounded-1c-all' => sprintf( __('Use %s (%s)', 'DigiPress' ), __('M PLUS Rounded 1c', 'DigiPress'), 'Google Fonts'),
		'm-plus-1-code-all' => sprintf( __('Use %s (%s)', 'DigiPress' ), __('M PLUS 1 Code', 'DigiPress'), 'Google Fonts'),
		'kosugi-all' => sprintf( __('Use %s (%s)', 'DigiPress' ), __('Kosugi', 'DigiPress'), 'Google Fonts'),
		'kosugi-maru-all' => sprintf( __('Use %s (%s)', 'DigiPress' ), __('Kosugi Maru', 'DigiPress'), 'Google Fonts'),
		'sawarabi-gothic-all' => sprintf( __('Use %s (%s)', 'DigiPress' ), __('Sawarabi Gothic', 'DigiPress'), 'Google Fonts'),
		'sawarabi-mincho-all' => sprintf( __('Use %s (%s)', 'DigiPress' ), __('Sawarabi Mincho', 'DigiPress'), 'Google Fonts'),
		'hannari-all' => sprintf( __('Use %s (%s)', 'DigiPress' ), __('Hannari Mincho', 'DigiPress'), 'Google Fonts'),
		'kokoro-all' => sprintf( __('Use %s (%s)', 'DigiPress' ), __('Kokoro Mincho', 'DigiPress'), 'Google Fonts'),
		'kiwi-maru-all' => sprintf( __('Use %s (%s)', 'DigiPress' ), __('Kiwi Maru', 'DigiPress'), 'Google Fonts'),
		'reggae-one-all' => sprintf( __('Use %s (%s)', 'DigiPress' ), __('Reggae One', 'DigiPress'), 'Google Fonts'),
		'rocknroll-one-all' => sprintf( __('Use %s (%s)', 'DigiPress' ), __('RocknRoll One', 'DigiPress'), 'Google Fonts'),
		'yusei-magic-all' => sprintf( __('Use %s (%s)', 'DigiPress' ), __('Yusei Magic', 'DigiPress'), 'Google Fonts'),
		'hachi-maru-pop-all' => sprintf( __('Use %s (%s)', 'DigiPress' ), __('Hachi Maru Pop', 'DigiPress'), 'Google Fonts'),
		'shippori-mincho-all' => sprintf( __('Use %s (%s)', 'DigiPress' ), __('Shippori Mincho', 'DigiPress'), 'Google Fonts'),
		'shippori-mincho-b1-all' => sprintf( __('Use %s (%s)', 'DigiPress' ), __('Shippori Mincho', 'DigiPress') . ' B1', 'Google Fonts'),
		'shippori-antique-all' => sprintf( __('Use %s (%s)', 'DigiPress' ), __('Shippori Antique', 'DigiPress'), 'Google Fonts'),
		'shippori-antique-b1-all' => sprintf( __('Use %s (%s)', 'DigiPress' ), __('Shippori Antique', 'DigiPress') . ' B1', 'Google Fonts'),
		'new-tegomin-all' => sprintf( __('Use %s (%s)', 'DigiPress' ), __('New Tegomin', 'DigiPress'), 'Google Fonts'),
		'mochiy-pop-one-all' => sprintf( __('Use %s (%s)', 'DigiPress' ), __('Mochiy Pop One', 'DigiPress'), 'Google Fonts'),
		'yuji-mai-all' => sprintf( __('Use %s (%s)', 'DigiPress' ), __('Yuji Mai', 'DigiPress'), 'Google Fonts'),
		'yuji-boku-all' => sprintf( __('Use %s (%s)', 'DigiPress' ), __('Yuji Boku', 'DigiPress'), 'Google Fonts'),
		'yuji-syuku-all' => sprintf( __('Use %s (%s)', 'DigiPress' ), __('Yuji Syuku', 'DigiPress'), 'Google Fonts'),
		'zen-antique-soft-all' => sprintf( __('Use %s (%s)', 'DigiPress' ), __('Zen Antique Soft', 'DigiPress'), 'Google Fonts'),
		'zen-kurenaido-all' => sprintf( __('Use %s (%s)', 'DigiPress' ), __('Zen Kurenaido', 'DigiPress'), 'Google Fonts'),
		'zen-old-mincho-all' => sprintf( __('Use %s (%s)', 'DigiPress' ), __('Zen Old Mincho', 'DigiPress'), 'Google Fonts'),
		'zen-kaku-gothic-new-all' => sprintf( __('Use %s (%s)', 'DigiPress' ), __('Zen Kaku Gothic New', 'DigiPress'), 'Google Fonts'),
		'zen-maru-gothic-all' => sprintf( __('Use %s (%s)', 'DigiPress' ), __('Zen Maru Gothic', 'DigiPress'), 'Google Fonts'),
		'kaisei-haruno-umi-all' => sprintf( __('Use %s (%s)', 'DigiPress' ), __('Kaisei HarunoUmi', 'DigiPress'), 'Google Fonts'),
		'kaisei-decol-all' => sprintf( __('Use %s (%s)', 'DigiPress' ), __('Kaisei Decol', 'DigiPress'), 'Google Fonts'),
		'kaisei-opti-all' => sprintf( __('Use %s (%s)', 'DigiPress' ), __('Kaisei Opti', 'DigiPress'), 'Google Fonts'),
		'kaisei-tokumin-all' => sprintf( __('Use %s (%s)', 'DigiPress' ), __('Kaisei Tokumin', 'DigiPress'), 'Google Fonts'),
		'klee-one-all' => sprintf( __('Use %s (%s)', 'DigiPress' ), __('Klee One', 'DigiPress'), 'Google Fonts'),
		'yomogi-all' => sprintf( __('Use %s (%s)', 'DigiPress' ), __('Yomogi', 'DigiPress'), 'Google Fonts'),
		'hina-mincho-all' => sprintf( __('Use %s (%s)', 'DigiPress' ), __('Hina Mincho', 'DigiPress'), 'Google Fonts'),
		)
	)
));
$id = 'base_font_weight';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'description' => __('Noto Sans JP font weight', 'DigiPress' ),
	'section' => 'dp_base_text_section',
	'note' => __('*These classes will be enabled only using Noto Sans JP.', 'DigiPress' ).'<div class="box-c"><ul><li>'.__('Thin weight', 'DigiPress' ).'<input type="text" value="ff-noto1" class="ft12px" size="8" readonly=""></li><li>'.__('Light weight', 'DigiPress' ).'<input type="text" value="ff-noto2" class="ft12px" size="8" readonly=""></li><li>'.__('Demi light weight', 'DigiPress' ).'<input type="text" value="ff-noto3" class="ft12px" size="8" readonly=""></li><li>'.__('Regular weight', 'DigiPress' ).'<input type="text" value="ff-noto4" class="ft12px" size="8" readonly=""></li><li>'.__('Meduim weight', 'DigiPress' ).'<input type="text" value="ff-noto5" class="ft12px" size="8" readonly=""></li><li>'.__('Bold weight', 'DigiPress' ).'<input type="text" value="ff-noto6" class="ft12px" size="8" readonly=""></li><li>'.__('Black weight', 'DigiPress' ).'<input type="text" value="ff-noto7" class="ft12px" size="8" readonly=""></li></ul><p class="ft12px">'.__('Example : &lt;h2 class="ff-noto1"&gt;Show text using Noto Sans&lt;/h2&gt;', 'DigiPress').'</p></div>',
	'type' => 'select',
	'choices' => array(
		'100' => __('Thin weight', 'DigiPress' ),
		'300' => __('Light weight', 'DigiPress' ),
		'400' => __('Regular weight', 'DigiPress' ),
		'500' => __('Medium weight', 'DigiPress' ),
		'700' => __('Bold weight', 'DigiPress' ),
		'900' => __('Black weight', 'DigiPress' )
		),
	'active_callback' => 'cb_base_text_settings'
	)
));

/**
 * Alphanumeric font
 */
$id = 'alphanumeric_font_family';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'description' => __('Alphanumeric font family', 'DigiPress' ),
	'note' => '<p class="description">' . __('*If there is a font that you want to reflect only alphanumeric characters in preference to the font used on the whole site, you can specify it from among the listed Google Fonts (web fonts).', 'DigiPress') . '</p>
<ul>
<li><i class="dashicons dashicons-external"></i><a href="https://fonts.google.com/specimen/Roboto" target="_blank">Roboto</a></li>
<li><i class="dashicons dashicons-external"></i><a href="https://fonts.google.com/specimen/Lato" target="_blank">Lato</a></li>
<li><i class="dashicons dashicons-external"></i><a href="https://fonts.google.com/specimen/Josefin+Sans" target="_blank">Josefin Sans</a></li>
<li><i class="dashicons dashicons-external"></i><a href="https://fonts.google.com/specimen/Raleway" target="_blank">Raleway</a></li>
<li><i class="dashicons dashicons-external"></i><a href="https://fonts.google.com/specimen/Quicksand" target="_blank">Quicksand</a></li>
<li><i class="dashicons dashicons-external"></i><a href="https://fonts.google.com/specimen/Montserrat" target="_blank">Montserrat</a></li>
<li><i class="dashicons dashicons-external"></i><a href="https://fonts.google.com/specimen/Montserrat+Alternates" target="_blank">Montserrat Alternates</a></li>
<li><i class="dashicons dashicons-external"></i><a href="https://fonts.google.com/specimen/Ubuntu" target="_blank">Ubuntu</a></li>
<li><i class="dashicons dashicons-external"></i><a href="https://fonts.google.com/specimen/Open+Sans" target="_blank">Open Sans</a></li>
<li><i class="dashicons dashicons-external"></i><a href="https://fonts.google.com/specimen/Didact+Gothic" target="_blank">Didact Gothic</a></li>
<li><i class="dashicons dashicons-external"></i><a href="https://fonts.google.com/specimen/Reem+Kufi" target="_blank">Reem Kufi</a></li>
<li><i class="dashicons dashicons-external"></i><a href="https://fonts.google.com/specimen/Jost" target="_blank">Jost</a></li>
<li><i class="dashicons dashicons-external"></i><a href="https://fonts.google.com/specimen/Sansita+Swashed" target="_blank">Sansita Swashed</a></li>
<li><i class="dashicons dashicons-external"></i><a href="https://fonts.google.com/specimen/Playfair+Display" target="_blank">' . __('[Serif]', 'DigiPress') . ' Playfair Display</a></li>
<li><i class="dashicons dashicons-external"></i><a href="https://fonts.google.com/specimen/Josefin+Slab" target="_blank">' . __('[Serif]', 'DigiPress') . ' Josefin Slab</a></li>
<li><i class="dashicons dashicons-external"></i><a href="https://fonts.google.com/specimen/Crimson+Text" target="_blank">' . __('[Serif]', 'DigiPress') . ' Crimson Text</a></li>
<li><i class="dashicons dashicons-external"></i><a href="https://fonts.google.com/specimen/Lora" target="_blank">' . __('[Serif]', 'DigiPress') . ' Lora</a></li>
<li><i class="dashicons dashicons-external"></i><a href="https://fonts.google.com/specimen/Arvo" target="_blank">' . __('[Serif]', 'DigiPress') . ' Arvo</a></li>
<li><i class="dashicons dashicons-external"></i><a href="https://fonts.google.com/specimen/Libre+Baskerville" target="_blank">' . __('[Serif]', 'DigiPress') . ' Libre Baskerville</a></li>
</ul>',
	'section' => 'dp_base_text_section',
	'type' => 'select',
	'choices' => array(
		'none' => __('None', 'DigiPress') . ' (' . __('Default font', 'DigiPress' ) . ')',
		'Roboto' => 'Roboto (Google Fonts)',
		'Lato' => 'Lato (Google Fonts)',
		'Josefin+Sans' => 'Josefin Sans (Google Fonts)',
		'Raleway' => 'Raleway (Google Fonts)',
		'Quicksand' => 'Quicksand (Google Fonts)',
		'Montserrat' => 'Montserrat (Google Fonts)',
		'Montserrat+Alternates' => 'Montserrat Alternates (Google Fonts)',
		'Ubuntu' => 'Ubuntu (Google Fonts)',
		'Open+Sans' => 'Open Sans (Google Fonts)',
		'Didact+Gothic' => 'Didact Gothic (Google Fonts)',
		'Reem+Kufi' => 'Reem Kufi (Google Fonts)',
		'Jost' => 'Jost (Google Fonts)',
		'Sansita+Swashed' => 'Sansita Swashed (Google Fonts)',
		'Playfair+Display' => __('[Serif]', 'DigiPress'). ' ' . 'Playfair Display (Google Fonts)',
		'Josefin+Slab' => __('[Serif]', 'DigiPress'). ' ' . 'Josefin Slab (Google Fonts)',
		'Crimson+Text' => __('[Serif]', 'DigiPress'). ' ' . 'Crimson Text (Google Fonts)',
		'Lora' => __('[Serif]', 'DigiPress'). ' ' . 'Lora (Google Fonts)',
		'Arvo' => __('[Serif]', 'DigiPress'). ' ' . 'Arvo (Google Fonts)',
		'Libre+Baskerville' => __('[Serif]', 'DigiPress'). ' ' . 'Libre Baskerville (Google Fonts)',
		)
	)
));


// Use the font to major title only
$id = 'custom_font_only_title';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'fake_title' => __( 'Major title setting', 'DigiPress' ),
	'label' => __('Apply specified font to major titles only', 'DigiPress' ),
	'section' => 'dp_base_text_section',
	'type' => 'checkbox'
	)
));

// Show major titles as bold
$id = 'title_font_bold';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'label' => __('Bold weight for major titles', 'DigiPress' ),
	'section' => 'dp_base_text_section',
	'type' => 'checkbox'
	)
));

// Show major titles as italic
$id = 'title_font_style_italic';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'label' => __('Italic style for major titles', 'DigiPress' ),
	'section' => 'dp_base_text_section',
	'type' => 'checkbox'
	)
));

// Major title letter spacing
$id = 'title_letter_spacing';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'sanitize_callback' => 'dp_sanitize_float',
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'description' => __('Letter spacing', 'DigiPress' ),
	'note' => __('* The "main title part" is a header image, an article title, H1 to H6 in the text, a title of each section, a widget title, etc.', 'DigiPress'),
	'unit' => 'em (' . sprintf( __( 'Default: %s', 'DigiPress' ), $def_options[$id] ) . ')',
	'section' => 'dp_base_text_section',
	'type' => 'number',
	'input_attrs' => array( 'min' => -10, 'max' => 10, 'step' => 0.01 )
	)
));


/**
 * Link color
 */
$id = 'base_link_color';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'sanitize_callback' => 'sanitize_hex_color',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new WP_Customize_Color_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'label' => __('Base link setting', 'DigiPress' ),
	'description' => __('Link color', 'DigiPress' ),
	'section' => 'dp_base_text_section'
	)
));
$id = 'base_link_hover_color';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'sanitize_callback' => 'sanitize_hex_color',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new WP_Customize_Color_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'description' => __('Link color(Mouseover)', 'DigiPress' ),
	'section' => 'dp_base_text_section'
	)
));
$id = 'base_link_bold';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'label' => __('Show link as bold', 'DigiPress' ),
	'section' => 'dp_base_text_section',
	'type' => 'checkbox'
	)
));
$id = 'base_link_underline';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'description' => __('Link underline decoration', 'DigiPress' ),
	'section' => 'dp_base_text_section',
	'type' => 'select',
	'choices' => array(
		'none' => __('No underline', 'DigiPress' ),
		'not_mouseover' => __('On not mouseover', 'DigiPress' ),
		'mouseover' => __('On mouseover', 'DigiPress' )
		)
	)
));


// Head tag font size
$id = 'base_font_size_h1';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'sanitize_callback' => 'absint',
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'label' => __('Head tag sizes in entry', 'DigiPress'),
	'description' => 'h1 ' . __('tag', 'DigiPress'),
	'unit' => __('%', 'DigiPress' ) . ' (' . __('default', 'DigiPress') . ' : ' . $def_options[$id] . '%)',
	'section' => 'dp_base_text_section',
	'type' => 'number',
	'input_attrs' => array('min' => 1,'max' => 1000,'step' => 1)
	)
));

$id = 'base_font_size_h2';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'sanitize_callback' => 'absint',
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'description' => 'h2 ' . __('tag', 'DigiPress'),
	'unit' => __('%', 'DigiPress' ) . ' (' . __('default', 'DigiPress') . ' : ' . $def_options[$id] . '%)',
	'section' => 'dp_base_text_section',
	'type' => 'number',
	'input_attrs' => array('min' => 1,'max' => 1000,'step' => 1)
	)
));

$id = 'base_font_size_h3';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'sanitize_callback' => 'absint',
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'description' => 'h3 ' . __('tag', 'DigiPress'),
	'unit' => __('%', 'DigiPress' ) . ' (' . __('default', 'DigiPress') . ' : ' . $def_options[$id] . '%)',
	'section' => 'dp_base_text_section',
	'type' => 'number',
	'input_attrs' => array('min' => 1,'max' => 1000,'step' => 1)
	)
));

$id = 'base_font_size_h4';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'sanitize_callback' => 'absint',
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'description' => 'h4 ' . __('tag', 'DigiPress'),
	'unit' => __('%', 'DigiPress' ) . ' (' . __('default', 'DigiPress') . ' : ' . $def_options[$id] . '%)',
	'section' => 'dp_base_text_section',
	'type' => 'number',
	'input_attrs' => array('min' => 1,'max' => 1000,'step' => 1)
	)
));

$id = 'base_font_size_h5';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'sanitize_callback' => 'absint',
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'description' => 'h5 ' . __('tag', 'DigiPress'),
	'unit' => __('%', 'DigiPress' ) . ' (' . __('default', 'DigiPress') . ' : ' . $def_options[$id] . '%)',
	'section' => 'dp_base_text_section',
	'type' => 'number',
	'input_attrs' => array('min' => 1,'max' => 1000,'step' => 1)
	)
));

$id = 'base_font_size_h6';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'sanitize_callback' => 'absint',
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'description' => 'h6 ' . __('tag', 'DigiPress'),
	'note' => __('*You can change the size of the heading tags (h1 to h6) in the text, in a relative size (%) to the font size of typography.', 'DigiPress'),
	'unit' => __('%', 'DigiPress' ) . ' (' . __('default', 'DigiPress') . ' : ' . $def_options[$id] . '%)',
	'section' => 'dp_base_text_section',
	'type' => 'number',
	'input_attrs' => array('min' => 1,'max' => 1000,'step' => 1)
	)
));


/**
 * Button setting
 */
// $id = 'button_fill_style';
// $wp_customize->add_setting(
// 	'dp_theme_options['.$id.']', array(
// 	'default' => $def_options[$id],
// 	'type' => 'option',
// 	'transport' => 'postMessage'
// ));
// $wp_customize->add_control( new DP_Customize_Control(
// 	$wp_customize,
// 	'dp_theme_options['.$id.']', array(
// 	'label' => __('Button fill type', 'DigiPress' ),
// 	'section' => 'dp_base_text_section',
// 	'type' => 'select',
// 	'choices' => array(
// 		'fill_hover' => __('Fill with mouseover', 'DigiPress' ),
// 		'blank_hover' => __('Blank with mouseover', 'DigiPress' )
// 		)
// 	)
// ));

function cb_base_text_settings($control){
	$base_font_family = $control->manager->get_setting('dp_theme_options[base_font_family]')->value();
	$control_id = $control->id;

	if ( ($base_font_family === 'notosans-all' || $base_font_family === 'notosans-only' ) && $control_id === 'dp_theme_options[base_font_weight]') return true;

	return false;
}