<?php
/**
 * Expand default range control
 */
class DP_Customize_Range_Control extends WP_Customize_Control {

	public $type = 'custom_range';
	public $before_text = '';
	public $unit = '';
	public $separator = false;
    public $separator_top = false;

	public function render_content() {
		$before_text = isset($this->before_text) && !empty($this->before_text) ? '<span class="description customize-control-description">'.esc_html($this->before_text).'</span>' : '';
		$unit = isset($this->unit) && !empty($this->unit) ? esc_html($this->unit) : '';
		$separator = isset($this->separator) && !empty($this->separator) ? '<hr />' : '';
		$separator_top = isset($this->separator_top) && !empty($this->separator_top) ? '<hr />' : '';

		echo $separator_top;
?><label><?php 
		if ( ! empty( $this->label )) : ?>
<span class="customize-control-title"><?php echo esc_html($this->label); ?></span><?php
		endif;
		echo $before_text;?>
<input data-input-type="range" type="range" <?php $this->input_attrs(); ?> value="<?php echo esc_attr($this->value()); ?>" <?php $this->link(); ?> />
<input type="text" value="<?php echo esc_attr($this->value()); ?>" size="3" class="cs-range-value" readonly="readonly" /><?php
		echo $unit;
		if ( ! empty( $this->description )) : ?>
<span class="description customize-control-description"><?php echo $this->description; ?></span><?php
		endif; ?>
</label><?php
		echo $separator;
	}
}