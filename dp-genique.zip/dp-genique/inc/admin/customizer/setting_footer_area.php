<?php
// **********************************************
// Footer area setting
// **********************************************
$wp_customize->add_section(
	'dp_footer_area_section', array(
	'title' => __('Footer Area Settings', 'DigiPress'),
	'description' => __('Settings for site footer content area.', 'DigiPress'),
	'priority' => 67
));
/**
 * Footer widget column
 */
$id = 'footer_col_number';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'refresh'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'label' => __('Footer widget column number','DigiPress'),
	'section' => 'dp_footer_area_section',
	'type' => 'select',
	'choices' => array(
		'1' => __('1 column','DigiPress'),
		'2' => __('2 columns','DigiPress'),
		'3' => __('3 columns','DigiPress'),
		'4' => __('4 columns','DigiPress')
		)
	)
));

/**
 * Footer top edge
 */
$id = 'footer_top_edge';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'refresh'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'label' => __('Footer Area Top Edge Shape','DigiPress'),
	'section' => 'dp_footer_area_section',
	'type' => 'select',
	'choices' => array(
		'none' => __('None', 'DigiPress'),
		'mountain' => __('Mountain shape', 'DigiPress'),
		'vline' => __('V line', 'DigiPress'),
		'wline' => __('W line', 'DigiPress'),
		'mline' => __('M line', 'DigiPress'),
		'up_right' => __('Diagonally right', 'DigiPress'),
		'up_left' => __('Diagonally left','DigiPress'),
		'wave1' => __('Wave shape','DigiPress'),
		'wave2' => __('Wave shape','DigiPress') .' (' . __('Flip horizontal','DigiPress') . ')',
		'curve1' => __('Curve shape','DigiPress'),
		'curve2' => __('Curve shape','DigiPress') .' (' . __('Flip vertical','DigiPress') . ')',
		'saw1' => __('Saw wave','DigiPress'),
		'saw2' => __('Saw wave','DigiPress') .' (' . __('Flip horizontal','DigiPress') . ')'
		)
	)
));
/**
 * Footer edge piled layer
 */
$id = 'footer_top_edge_piled_layer';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'label' => __('Enable piled layer','DigiPress'),
	'note' => __('*Check this option to show the edge with piled layer. This is for wave or curve edge only.', 'DigiPress'),
	'description' => '',
	'section' => 'dp_footer_area_section',
	'type' => 'checkbox',
	'active_callback' => 'cb_footer_top_edge',
	)
));

/**
 * Callback
 */
function cb_footer_top_edge($control){
	$control_id = $control->id;
	$edge = $control->manager->get_setting('dp_theme_options[footer_top_edge]')->value();

	if ( ( $edge === 'wave1' || $edge === 'wave2' || $edge === 'curve1' || $edge === 'curve2' ) && $control_id === 'dp_theme_options[footer_top_edge_piled_layer]' ) {
		return true;
	}

	return false;
}


/**
 * Dummy navigate
 */
$wp_customize->add_setting(
	'dummy_field_footer_area', array(
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dummy_field_footer_area', array(
	'section' => 'dp_footer_area_section',
	'type' => 'text'
	)
));
// For Selective refresh
if (isset($wp_customize->selective_refresh)){
	$wp_customize->selective_refresh->add_partial('dummy_field_footer_area', array(
		'selector' => '#footer'
	));
}

/**
 * Font color
 */
$id = 'footer_text_color';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'sanitize_callback' => 'sanitize_hex_color',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new WP_Customize_Color_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'label' => __('Text color setting','DigiPress'),
	'description' => __('Font color','DigiPress'),
	'section' => 'dp_footer_area_section'
	)
));
$id = 'footer_link_color';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'sanitize_callback' => 'sanitize_hex_color',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new WP_Customize_Color_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'description' => __('Link color','DigiPress'),
	'section' => 'dp_footer_area_section'
	)
));
$id = 'footer_link_hover_color';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'sanitize_callback' => 'sanitize_hex_color',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new WP_Customize_Color_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'description' => __('Link color(Mouseover)','DigiPress'),
	'section' => 'dp_footer_area_section'
	)
));
/**
 * Background color
 */
$id = 'footer_bgcolor';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'sanitize_callback' => 'sanitize_hex_color',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new WP_Customize_Color_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'label' => __('Background design setting','DigiPress'),
	'description' => __('Background color','DigiPress'),
	'section' => 'dp_footer_area_section',
	)
));

/**
 * Background color opacity
 */
$id = 'footer_bg_opacity';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'sanitize_callback' => 'absint',
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Range_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'before_text' => __('Background color opacity','DigiPress'),
	'unit' => '%',
	'section' => 'dp_footer_area_section',
	'type' => 'custom_range',
	'input_attrs' => array(
		'min' => 0,
		'max' => 100,
		'step' => 1
		)
	)
));

// Background image
$id = 'dp_footer_bg_img';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'sanitize_callback' => 'esc_url_raw',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new WP_Customize_Image_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'description' => __('Background image','DigiPress'),
	'section' => 'dp_footer_area_section'
	)
));


/**
 * Contact info
 */
$id = 'contact_info_before';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'sanitize_callback' => 'dp_sanitize_html',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'fake_title' => __('Contact info','DigiPress'),
	'before_text' => __('The text above the contact info', 'DigiPress'),
	'section' => 'dp_footer_area_section',
	'type' => 'text',
	'input_attrs' => array(
		'placeholder' => __('Contact by phone here', 'DigiPress'),
		)
	)
));
// For Selective refresh
if (isset($wp_customize->selective_refresh)){
	$wp_customize->selective_refresh->add_partial('dp_theme_options['.$id.']', array(
		'selector' => '#footer .ft-btm__col .c-before',
		'settings' => 'dp_theme_options['.$id.']',
		'container_inclusive' => false,
		'render_callback' => function(){
			$options = get_option('dp_theme_options');
			echo '<span>'.$options['contact_info_before'].'</span>';
		}
	));
}
$id = 'contact_info';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'sanitize_callback' => 'dp_sanitize_html',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'before_text' => __('Contact info','DigiPress'),
	'section' => 'dp_footer_area_section',
	'type' => 'textarea',
	'input_attrs' => array(
		'placeholder' => __('Phone number or e-mail', 'DigiPress'),
		)
	)
));
// For Selective refresh
if (isset($wp_customize->selective_refresh)){
	$wp_customize->selective_refresh->add_partial('dp_theme_options['.$id.']', array(
		'selector' => '#footer .ft-btm__col .c-middle',
		'settings' => 'dp_theme_options['.$id.']',
		'container_inclusive' => false,
		'render_callback' => function(){
			$options = get_option('dp_theme_options');
			echo '<span>'.$options['contact_info'].'</span>';
		}
	));
}
$id = 'contact_info_after';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'sanitize_callback' => 'dp_sanitize_html',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'before_text' => __('The text under the contact info', 'DigiPress'),
	'note' => __('*You can inert HTML code in this area.','DigiPress'),
	'section' => 'dp_footer_area_section',
	'type' => 'text',
	'input_attrs' => array(
		'placeholder' => __('From 9:00 to 17:00', 'DigiPress'),
		)
	)
));
// For Selective refresh
if ( isset($wp_customize->selective_refresh) ){
	$wp_customize->selective_refresh->add_partial('dp_theme_options['.$id.']', array(
		'selector' => '#footer .ft-btm__col .c-after',
		'settings' => 'dp_theme_options['.$id.']',
		'container_inclusive' => false,
		'render_callback' => function(){
			$options = get_option('dp_theme_options');
			echo '<span>'.$options['contact_info_after'].'</span>';
		}
	));
}

/**
 * Header Facebook icon
 */
$id = 'footer_sns_fb_url';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => '',
	'type' => 'option',
	'sanitize_callback' => 'esc_url_raw',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'fake_title' => __( 'SNS, RSS and Cotact Icons', 'DigiPress' ) ,
	'before_text' => __('Facebook URL','DigiPress'),
	'section' => 'dp_footer_area_section',
	'input_attrs' => array(
		'placeholder' => $def_options[$id],
	),
	'type' => 'text'
	)
));
// For Selective refresh
if (isset($wp_customize->selective_refresh)){
	$wp_customize->selective_refresh->add_partial('dp_theme_options['.$id.']', array(
		'selector' => '#footer .menu-item.fb',
		'settings' => 'dp_theme_options['.$id.']'
	));
}

/**
 * Header twitter icon
 */
$id = 'footer_sns_twitter_url';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => '',
	'type' => 'option',
	'sanitize_callback' => 'esc_url_raw',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'before_text' => __('Twitter URL','DigiPress'),
	'section' => 'dp_footer_area_section',
	'input_attrs' => array(
		'placeholder' => $def_options[$id],
	),
	'type' => 'text'
	)
));
// For Selective refresh
if (isset($wp_customize->selective_refresh)){
	$wp_customize->selective_refresh->add_partial('dp_theme_options['.$id.']', array(
		'selector' => '#footer .menu-item.tw',
		'settings' => 'dp_theme_options['.$id.']'
	));
}

/**
 * Header Instagram icon
 */
$id = 'footer_sns_instagram_url';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => '',
	'type' => 'option',
	'sanitize_callback' => 'esc_url_raw',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'before_text' => __('Instagram URL','DigiPress'),
	'section' => 'dp_footer_area_section',
	'input_attrs' => array(
		'placeholder' => $def_options[$id],
	),
	'type' => 'text'
	)
));
// For Selective refresh
if (isset($wp_customize->selective_refresh)){
	$wp_customize->selective_refresh->add_partial('dp_theme_options['.$id.']', array(
		'selector' => '#footer .menu-item.instagram',
		'settings' => 'dp_theme_options['.$id.']'
	));
}

/**
 * Header YouTube icon
 */
$id = 'footer_sns_youtube_url';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => '',
	'type' => 'option',
	'sanitize_callback' => 'esc_url_raw',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'before_text' => __('YouTube URL','DigiPress'),
	'section' => 'dp_footer_area_section',
	'input_attrs' => array(
		'placeholder' => $def_options[$id],
	),
	'type' => 'text'
	)
));
// For Selective refresh
if (isset($wp_customize->selective_refresh)){
	$wp_customize->selective_refresh->add_partial('dp_theme_options['.$id.']', array(
		'selector' => '#footer .menu-item.youtube',
		'settings' => 'dp_theme_options['.$id.']'
	));
}

/**
 * Contact URL
 */
$id = 'footer_sns_contact_url';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => '',
	'type' => 'option',
	'sanitize_callback' => 'esc_url_raw',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'before_text' => __('Contact Page URL','DigiPress'),
	'section' => 'dp_footer_area_section',
	'input_attrs' => array(
		'placeholder' => $def_options[$id],
	),
	'type' => 'text'
	)
));
// For Selective refresh
if (isset($wp_customize->selective_refresh)){
	$wp_customize->selective_refresh->add_partial('dp_theme_options['.$id.']', array(
		'selector' => '#footer .menu-item.contact_url',
		'settings' => 'dp_theme_options['.$id.']'
	));
}

/**
 * RSS Link
 */
$id = 'footer_sns_rss';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'before_text' => __('RSS Icon Link','DigiPress'),
	'section' => 'dp_footer_area_section',
	'type' => 'select',
	'choices' => array(
		'none' => __('No RSS link','DigiPress'),
		'rss' => __('RSS icon link','DigiPress'),
		'feedly' => __('Feedly icon link','DigiPress')
		)
	)
));
// For Selective refresh
if (isset($wp_customize->selective_refresh)){
	$wp_customize->selective_refresh->add_partial('dp_theme_options['.$id.']', array(
		'selector' => '#footer .menu-item.feed',
		'settings' => 'dp_theme_options['.$id.']'
	));
}

/**
 * Footer logo image
 */
$id = 'dp_ft_title_img';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new WP_Customize_Image_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'label' => __('Footer logo image','DigiPress'),
	'section' => 'dp_footer_area_section'
	)
));
// For Selective refresh
if (isset($wp_customize->selective_refresh)){
	$wp_customize->selective_refresh->add_partial('dp_theme_options['.$id.']', array(
		'selector' => '#footer .ft_logo',
		'settings' => 'dp_theme_options['.$id.']',
		'container_inclusive' => false,
		'render_callback' => function(){
			$options = get_option('dp_theme_options');
			if ( isset( $options['dp_ft_title_img'] ) && !empty( $options['dp_ft_title_img'] ) ) {
				echo '<img src="' . $options['dp_ft_title_img'] . '" alt="logo" />';
			} else {
				echo '';
			}
		}
	));
}

/**
 * location info
 */
$id = 'location_info';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'sanitize_callback' => 'dp_sanitize_html',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'label' => __('Location / address','DigiPress'),
	'note' => __('*You can inert HTML code in this area.','DigiPress'),
	'section' => 'dp_footer_area_section',
	'type' => 'textarea',
	'input_attrs' => array(
		'placeholder' => __('1-23 Shibuya, Tokyo', 'DigiPress'),
		)
	)
));
// For Selective refresh
if (isset($wp_customize->selective_refresh)){
	$wp_customize->selective_refresh->add_partial('dp_theme_options['.$id.']', array(
		'selector' => '#footer .ft-btm__col.logo .location',
		'settings' => 'dp_theme_options['.$id.']',
		'container_inclusive' => false,
		'render_callback' => function(){
			$options = get_option('dp_theme_options');
			echo $options['location_info'];
		}
	));
}


/**
 *  Set the Year that the site opened
 */
$id = 'blog_start_year';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'sanitize_callback' => 'sanitize_text_field',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'fake_title' => __('Copyright setting','DigiPress'),
	'before_text' => __('Site opened year','DigiPress'),
	'section' => 'dp_footer_area_section',
	'type' => 'text'
	)
));
// For Selective refresh
if (isset($wp_customize->selective_refresh)){
	$wp_customize->selective_refresh->add_partial('dp_theme_options['.$id.']', array(
		'selector' => '#cpright .year',
		'settings' => 'dp_theme_options['.$id.']',
		'container_inclusive' => false,
		'render_callback' => function(){
			$options = get_option('dp_theme_options');
			echo $options['blog_start_year'] . ' - ' . (string)date('Y');
		}
	));
}

/**
 * Copyright text
 */
$id = 'copyright_name';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'sanitize_callback' => 'dp_sanitize_html',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'before_text' => __('Copyright text','DigiPress'),
	'section' => 'dp_footer_area_section',
	'type' => 'text',
	'input_attrs' => array(
		'placeholder' => get_bloginfo('name'),
		)
	)
));
// For Selective refresh
if (isset($wp_customize->selective_refresh)){
	$wp_customize->selective_refresh->add_partial('dp_theme_options['.$id.']', array(
		'selector' => '#cpright .cpright_name',
		'settings' => 'dp_theme_options['.$id.']',
		'container_inclusive' => false,
		'render_callback' => function(){
			$options = get_option('dp_theme_options');
			echo $options['copyright_name'];
		}
	));
}

/**
 * Original contents of before </body> (PC)
 */
$id = 'custom_content_before_end_body';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage'
));
if ( version_compare( $wp_version, '4.9', '>=' ) ) {
	$wp_customize->add_control( new WP_Customize_Code_Editor_Control(
		$wp_customize,
		'dp_theme_options['.$id.']', array(
		'setting'=> 'dp_theme_options['.$id.']',
		'label' => __('Custom codes before end of body tag','DigiPress').'(PC)',
		'description' => __('*You can add your custom code (eg. Javascript) before end of body tag.','DigiPress'),
		'code_type' => 'text/html',
		'section' => 'dp_footer_area_section'
		)
	));
} else {
	$wp_customize->add_control( new DP_Customize_Textarea_Control(
		$wp_customize,
		'dp_theme_options['.$id.']', array(
		'settings' => 'dp_theme_options['.$id.']',
		'label' => __('Custom codes before end of body tag','DigiPress').'(PC)',
		'note' => __('*You can add your custom code (eg. Javascript) before end of body tag.','DigiPress'),
		'other_class' => 'dp_code_textarea html-head code',
		'section' => 'dp_footer_area_section',
		'type' => 'textarea'
		)
	));
}
/**
 * Original contents of before </body> (Mobile)
 */
$id = 'custom_content_before_end_body_mobile';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage'
));
if ( version_compare( $wp_version, '4.9', '>=' ) ) {
	$wp_customize->add_control( new WP_Customize_Code_Editor_Control(
		$wp_customize,
		'dp_theme_options['.$id.']', array(
		'setting'=> 'dp_theme_options['.$id.']',
		'label' => __('Custom codes before end of body tag','DigiPress').__('(Mobile)','DigiPress'),
		'code_type' => 'text/html',
		'section' => 'dp_footer_area_section'
		)
	));
} else {
	$wp_customize->add_control( new DP_Customize_Textarea_Control(
		$wp_customize,
		'dp_theme_options['.$id.']', array(
		'settings' => 'dp_theme_options['.$id.']',
		'label' => __('Custom codes before end of body tag','DigiPress').__('(Mobile)','DigiPress'),
		'other_class' => 'dp_code_textarea html-head code',
		'section' => 'dp_footer_area_section',
		'type' => 'textarea'
		)
	));
}