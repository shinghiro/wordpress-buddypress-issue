<?php
/**
 * navigate to backup / restore
 */
$wp_customize->add_section(
	'dp_backup_restore_section', array(
	'title' => __('Backup / Restore', 'DigiPress'),
	'description' => __('Navigate to export and import section of this theme option.','DigiPress'),
	'priority' => 900
));
$wp_customize->add_setting(
	'navigate_backup_restore', array(
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'navigate_backup_restore', array(
	'before_text' => '<a href="admin.php?page=digipress" class="button" target="_blank">'.__('Backup / Restore','DigiPress').'</a>',
	'section' => 'dp_backup_restore_section',
	'type' => 'text'
	)
));