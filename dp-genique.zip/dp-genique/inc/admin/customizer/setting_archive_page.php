<?php
// **********************************************
// Archive page section
// **********************************************
$wp_customize->add_panel(
	'dp_archive_page_panel', array(
	'title' => __('Archive Page Settings', 'DigiPress'),
	'description' => __('Settings for archive page contents.', 'DigiPress'),
	'priority' => 65
));
$wp_customize->add_section(
	'dp_archive_page_details_section', array(
	'title' => __('Contents Detail Setting', 'DigiPress'),
	'panel' => 'dp_archive_page_panel',
	'priority' => 10
));
$wp_customize->add_section(
	'dp_archive_page_infeed_ads_section', array(
	'title' => __('Infeed Ads Setting', 'DigiPress'),
	'panel' => 'dp_archive_page_panel',
	'priority' => 20
));

/**
 * Post count (PC)
 */
$id = 'number_posts_category';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'sanitize_callback' => 'absint',
	'type' => 'option',
	'transport' => 'refresh'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'label' => __('Number of posts(PC)','DigiPress'),
	'unit' => __('posts', 'DigiPress').': '.__('Category page', 'DigiPress'),
	'after_text' => '<i class="dashicons-before dashicons-external"></i><a href="edit-tags.php?taxonomy=category" target="_blank">' . sprintf( __('Set by each %s', 'DigiPress'), __('category', 'DigiPress') ) . '</a>',
	'section' => 'dp_archive_page_details_section',
	'type' => 'number',
	'input_attrs' => array('min' => 1,'max' => 100,'step' => 1),
	)
));
$id = 'number_posts_tag';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'sanitize_callback' => 'absint',
	'type' => 'option',
	'transport' => 'refresh'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'section' => 'dp_archive_page_details_section',
	'unit' => __('posts', 'DigiPress').': '.__('Tag page', 'DigiPress'),
	'after_text' => '<i class="dashicons-before dashicons-external"></i><a href="edit-tags.php?taxonomy=post_tag" target="_blank">' . sprintf( __('Set by each %s', 'DigiPress'), __('post tag', 'DigiPress') ) . '</a>',
	'type' => 'number',
	'input_attrs' => array('min' => 1,'max' => 100,'step' => 1),
	)
));
$id = 'number_posts_search';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'sanitize_callback' => 'absint',
	'type' => 'option',
	'transport' => 'refresh'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'section' => 'dp_archive_page_details_section',
	'unit' => __('posts', 'DigiPress').': '.__('Search results page', 'DigiPress'),
	'type' => 'number',
	'input_attrs' => array('min' => 1,'max' => 100,'step' => 1),
	)
));
$id = 'number_posts_date';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'sanitize_callback' => 'absint',
	'type' => 'option',
	'transport' => 'refresh'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'section' => 'dp_archive_page_details_section',
	'unit' => __('posts', 'DigiPress').': '.__('Date based archive', 'DigiPress'),
	'type' => 'number',
	'input_attrs' => array('min' => 1,'max' => 100,'step' => 1),
	)
));
$id = 'number_posts_author';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'sanitize_callback' => 'absint',
	'type' => 'option',
	'transport' => 'refresh'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'section' => 'dp_archive_page_details_section',
	'unit' => __('posts', 'DigiPress').': '.__('Author archive', 'DigiPress'),
	'type' => 'number',
	'input_attrs' => array('min' => 1,'max' => 100,'step' => 1),
	)
));

/**
 * Post count (Mobile)
 */
$id = 'number_posts_category_mobile';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'sanitize_callback' => 'absint',
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'label' => __('Number of posts(Mobile)','DigiPress'),
	'unit' => __('posts', 'DigiPress').': '.__('Category page', 'DigiPress'),
	'after_text' => '<i class="dashicons-before dashicons-external"></i><a href="edit-tags.php?taxonomy=category" target="_blank">' . sprintf( __('Set by each %s', 'DigiPress'), __('category', 'DigiPress') ) . '</a>',
	'section' => 'dp_archive_page_details_section',
	'type' => 'number',
	'input_attrs' => array('min' => 1,'max' => 100,'step' => 1),
	)
));
$id = 'number_posts_tag_mobile';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'sanitize_callback' => 'absint',
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'section' => 'dp_archive_page_details_section',
	'unit' => __('posts', 'DigiPress').': '.__('Tag page', 'DigiPress'),
	'after_text' => '<i class="dashicons-before dashicons-external"></i><a href="edit-tags.php?taxonomy=post_tag" target="_blank">' . sprintf( __('Set by each %s', 'DigiPress'), __('post tag', 'DigiPress') ) . '</a>',
	'type' => 'number',
	'input_attrs' => array('min' => 1,'max' => 100,'step' => 1),
	)
));
$id = 'number_posts_search_mobile';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'sanitize_callback' => 'absint',
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'section' => 'dp_archive_page_details_section',
	'unit' => __('posts', 'DigiPress').': '.__('Search results page', 'DigiPress'),
	'type' => 'number',
	'input_attrs' => array('min' => 1,'max' => 100,'step' => 1),
	)
));
$id = 'number_posts_date_mobile';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'sanitize_callback' => 'absint',
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'section' => 'dp_archive_page_details_section',
	'unit' => __('posts', 'DigiPress').': '.__('Date based archive', 'DigiPress'),
	'type' => 'number',
	'input_attrs' => array('min' => 1,'max' => 100,'step' => 1),
	)
));
$id = 'number_posts_author_mobile';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'sanitize_callback' => 'absint',
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'section' => 'dp_archive_page_details_section',
	'unit' => __('posts', 'DigiPress').': '.__('Author archive', 'DigiPress'),
	'type' => 'number',
	'input_attrs' => array('min' => 1,'max' => 100,'step' => 1),
	)
));

/**
 * Layout
 */
$id = 'archive_post_show_type';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
		'label' => __('Layout design','DigiPress'),
		'note' => __('*For categories and tags, you can specify the layout individually on the Add New or Edit page.', 'DigiPress') . '<p><i class="dashicons-before dashicons-external"></i><a href="edit-tags.php?taxonomy=category" target="_blank">' . sprintf( __('Set by each %s', 'DigiPress'), __('category', 'DigiPress') ) . '</a><br /><i class="dashicons-before dashicons-external"></i><a href="edit-tags.php?taxonomy=post_tag" target="_blank">' . sprintf( __('Set by each %s', 'DigiPress'), __('post tag', 'DigiPress') ) . '</a></p>',
		'section' => 'dp_archive_page_details_section',
		'type' => 'select',
		'choices' => array(
			'normal' => __('Standard layout','DigiPress'),
			'portfolio' => __('Portfolio layout','DigiPress'),
			'magazine' => __('Magazine layout','DigiPress'),
			'news' => __('Simple list layout','DigiPress'),
			'simple' => __('Simple list layout','DigiPress') . ' (' . __('with thumbnail', 'DigiPress') . ')'
		),
	)
));
// For Selective refresh
if (isset($wp_customize->selective_refresh)){
	$wp_customize->selective_refresh->add_partial('dp_theme_options['.$id.']', array(
		'selector' => '.loop-section.lp-archive .loop-div',
		'settings' => 'dp_theme_options['.$id.']'
	));
}



/**
 * Overlay color
 */
$id = 'archive_overlay_color';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'refresh'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'before_text' => __('Overlay color','DigiPress'),
	'section' => 'dp_archive_page_details_section',
	'note' => __('*You can set the category color in <a href="edit-tags.php?taxonomy=category" target="_blank">category list page</a>.', 'DigiPress'),
	'type' => 'select',
	'choices' => array(
		'black' => __('Black','DigiPress'),
		'white' => __('White','DigiPress'),
		'pri_color' => __('Primary Color','DigiPress'),
		'cat' => __('Category color','DigiPress')
	),
	'active_callback' => 'cb_archive_page_settings'
	)
));
/**
 * Column of article layout
 */
$id = 'archive_loop_col';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'refresh'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'before_text' => __('Number of columns','DigiPress'),
	'section' => 'dp_archive_page_details_section',
	'type' => 'select',
	'choices' => array(
		'2' => __('Two columns','DigiPress'),
		'3' => __('Three columns','DigiPress'),
		'4' => __('Four columns(Enable in no-sidebar)','DigiPress'),
		'5' => __('Five columns(Enable in no-sidebar)','DigiPress')
			),
	'active_callback' => 'cb_archive_page_settings'
	)
));

/**
 * Fix height
 */
$id = 'archive_fix_article_height';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'refresh'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'label' => __('Fix the thumbnail height','DigiPress'),
	'section' => 'dp_archive_page_details_section',
	'type' => 'checkbox',
	'active_callback' => 'cb_archive_page_settings'
	)
));

/**
 * Rounded corners?
 */
$id = 'archive_article_round_corner';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'refresh'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'label' => __('Round element corners','DigiPress'),
	'section' => 'dp_archive_page_details_section',
	'type' => 'checkbox',
	'active_callback' => 'cb_archive_page_settings'
	)
));

/**
 * Show boxshadow?
 */
$id = 'archive_article_box_shadow';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'refresh'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'label' => __('Show box shadow on each article','DigiPress'),
	'section' => 'dp_archive_page_details_section',
	'type' => 'checkbox',
	'active_callback' => 'cb_archive_page_settings'
	)
));

/**
 * Altenate post listing
 */
$id = 'archive_article_alternately';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'refresh'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'label' => __('Display thumbnails alternately','DigiPress'),
	'section' => 'dp_archive_page_details_section',
	'type' => 'checkbox',
	'active_callback' => 'cb_archive_page_settings'
	)
));

/**
 * Magagine frame design
 */
$id = 'archive_magazine_cover_frame';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'sanitize_callback' => 'sanitize_text_field',
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control_Radio_Image(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'label' => __('Custom Magazine style','DigiPress'),
	'separator_top' => true,
	// 'separator' => true,
	'description' => __( 'Frame design', 'DigiPress' ),
	'note' => __( 'If you want to change the design for each article, you can customize from "Post Options" on the editor of each article.', 'DigiPress' ),
	'section' => 'dp_archive_page_details_section',
	'column' => 3,
	'choices'  => array(
		'' => array(
			'label' => __( 'None', 'DigiPress' ),
			'url'   => '%s/inc/admin/img/mgz-frame-none.jpg'
			),
		'has-frame line-frame __solid' => array(
			'label' => __( 'Solid line', 'DigiPress' ),
			'url'   => '%s/inc/admin/img/mgz-frame-line.jpg'
			),
		'has-frame line-frame __double' => array(
			'label' => __( 'Double line', 'DigiPress' ),
			'url'   => '%s/inc/admin/img/mgz-frame-line-double.jpg'
			),
		'has-frame line-frame __dashed' => array(
			'label' => __( 'Dashed line', 'DigiPress' ),
			'url'   => '%s/inc/admin/img/mgz-frame-line-dashed.jpg'
			),
		'has-frame line-frame __dot' => array(
			'label' => __( 'Dot line', 'DigiPress' ),
			'url'   => '%s/inc/admin/img/mgz-frame-line-dot.jpg'
			),
		'has-frame thick-bd' => array(
			'label' => __( 'Thick border', 'DigiPress' ),
			'url'   => '%s/inc/admin/img/mgz-frame-bd.jpg'
			),
		'has-frame thick-bd no-r no-btm' => array(
			'label' => __( 'Thick border', 'DigiPress' ) . __('(top, left)', 'DigiPress'),
			'url'   => '%s/inc/admin/img/mgz-frame-bd-l-t.jpg'
			),
		'has-frame thick-bd no-l no-btm' => array(
			'label' => __( 'Thick border', 'DigiPress' ) . __('(top, right)', 'DigiPress'),
			'url'   => '%s/inc/admin/img/mgz-frame-bd-r-t.jpg'
			),
		'has-frame thick-bd no-r no-top' => array(
			'label' => __( 'Thick border', 'DigiPress' ) . __('(bottom, left)', 'DigiPress'),
			'url'   => '%s/inc/admin/img/mgz-frame-bd-l-b.jpg'
			),
		'has-frame thick-bd no-l no-top' => array(
			'label' => __( 'Thick border', 'DigiPress' ) . __('(bottom, right)', 'DigiPress'),
			'url'   => '%s/inc/admin/img/mgz-frame-bd-r-b.jpg'
			),
		'has-frame thick-bd no-l no-r no-btm' => array(
			'label' => __( 'Thick border', 'DigiPress' ) . __('(top)', 'DigiPress'),
			'url'   => '%s/inc/admin/img/mgz-frame-bd-t.jpg'
			),
		'has-frame thick-bd no-l no-r no-top' => array(
			'label' => __( 'Thick border', 'DigiPress' ) . __('(bottom)', 'DigiPress'),
			'url'   => '%s/inc/admin/img/mgz-frame-bd-b.jpg'
			),
	),
	'active_callback' => 'cb_archive_page_settings'
	)
));


/**
 * Frame border color
 */
$id = 'archive_magazine_cover_frame_color';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage',
	'sanitize_callback' => 'sanitize_hex_color'
));
$wp_customize->add_control( new WP_Customize_Color_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	// 'label' => __('Background Design','DigiPress'),
	'description' => __('Frame color', 'DigiPress'),
	'section' => 'dp_archive_page_details_section',
	'active_callback' => 'cb_archive_page_settings'
	)
));

/**
 * Magazine title position
 */
$id = 'archive_magazine_title_position';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'sanitize_callback' => 'sanitize_text_field',
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control_Radio_Image(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	// 'label' => __('Site Colmuns Setting','DigiPress'),
	'separator_top' => true,
	'separator' => true,
	'description' => __( 'Title position', 'DigiPress' ),
	'section' => 'dp_archive_page_details_section',
	'column' => 3,
	'choices'  => array(
		'' => array(
			'label' => esc_html__( 'Center', 'DigiPress' ),
			'url'   => '%s/inc/admin/img/title-pos-center.jpg'
			),
		'title-pos__top title-pos__l' => array(
			'label' => esc_html__( 'Upper left', 'DigiPress' ),
			'url'   => '%s/inc/admin/img/title-pos-upper-left.jpg'
			),
		'title-pos__top' => array(
			'label' => esc_html__( 'Upper center', 'DigiPress' ),
			'url'   => '%s/inc/admin/img/title-pos-upper-center.jpg'
			),
		'title-pos__top title-pos__r' => array(
			'label' => esc_html__( 'Upper right', 'DigiPress' ),
			'url'   => '%s/inc/admin/img/title-pos-upper-right.jpg'
			),
		'title-pos__btm title-pos__l' => array(
			'label' => esc_html__( 'Bottom left', 'DigiPress' ),
			'url'   => '%s/inc/admin/img/title-pos-bottom-left.jpg'
			),
		'title-pos__btm' => array(
			'label' => esc_html__( 'Bottom center', 'DigiPress' ),
			'url'   => '%s/inc/admin/img/title-pos-bottom-center.jpg'
			),
		'title-pos__btm title-pos__r' => array(
			'label' => esc_html__( 'Bottom right', 'DigiPress' ),
			'url'   => '%s/inc/admin/img/title-pos-bottom-right.jpg'
			),
	),
	'active_callback' => 'cb_archive_page_settings'
	)
));

/**
 * Magazine title background
 */
$id = 'archive_magazine_title_back';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'sanitize_callback' => 'sanitize_text_field',
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control_Radio_Image(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	// 'label' => __('Site Colmuns Setting','DigiPress'),
	'separator' => true,
	'description' => __( 'Title background', 'DigiPress' ),
	'section' => 'dp_archive_page_details_section',
	'column' => 2,
	'choices'  => array(
		'' => array(
			'label' => esc_html__( 'None', 'DigiPress' ),
			'url'   => '%s/inc/admin/img/title-frame-none.jpg'
			),
		'has-title-back' => array(
			'label' => esc_html__( 'Show', 'DigiPress' ),
			'url'   => '%s/inc/admin/img/title-frame.jpg'
			),
	),
	'active_callback' => 'cb_archive_page_settings'
	)
));

/**
 * Magazine title color
 */
$id = 'archive_magazine_title_color';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage',
	'sanitize_callback' => 'sanitize_hex_color'
));
$wp_customize->add_control( new WP_Customize_Color_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	// 'label' => __('Background Design','DigiPress'),
	'description' => __('Title color', 'DigiPress'),
	'section' => 'dp_archive_page_details_section',
	'active_callback' => 'cb_archive_page_settings'
	)
));

/**
 * Magazine title background color
 */
$id = 'archive_magazine_title_back_color';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage',
	'sanitize_callback' => 'sanitize_hex_color'
));
$wp_customize->add_control( new WP_Customize_Color_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	// 'label' => __('Background Design','DigiPress'),
	'description' => __('Title background color', 'DigiPress'),
	'section' => 'dp_archive_page_details_section',
	'active_callback' => 'cb_archive_page_settings'
	)
));

/**
 * Magazine title background color opacity
 */
$id = 'archive_magazine_title_back_color_opacity';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'sanitize_callback' => 'absint',
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Range_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'before_text' => __('Title background opacity','DigiPress'),
	'section' => 'dp_archive_page_details_section',
	'unit' => '%',
	'type' => 'custom_range',
	'input_attrs' => array(
		'min' => 1,
		'max' => 100,
		'step' => 1
		),
	'active_callback' => 'cb_archive_page_settings'
	)
));

/**
 * Magazine text background with border
 */
$id = 'archive_magazine_title_back_border';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'sanitize_callback' => 'sanitize_text_field',
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control_Radio_Image(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	// 'label' => __('Site Colmuns Setting','DigiPress'),
	// 'separator' => true,
	'description' => __( 'Title background border', 'DigiPress' ),
	'section' => 'dp_archive_page_details_section',
	'column' => 2,
	'choices'  => array(
		'' => array(
			'label' => __( 'None', 'DigiPress' ),
			'url'   => '%s/inc/admin/img/title-bg-bd-none.jpg'
			),
		'has-title-bd title-back-bd' => array(
			'label' => 'Solid border',
			'url'   => '%s/inc/admin/img/title-bg-bd-solid.jpg'
			),
		'has-title-bd title-back-bd__double' => array(
			'label' => 'Double border',
			'url'   => '%s/inc/admin/img/title-bg-bd-double.jpg'
			),
		'has-title-bd title-back-bd__dashed' => array(
			'label' => 'Dashed border',
			'url'   => '%s/inc/admin/img/title-bg-bd-dashed.jpg'
			),
		'has-title-bd title-back-bd__dot' => array(
			'label' => 'Dot border',
			'url'   => '%s/inc/admin/img/title-bg-bd-dot.jpg'
			),
		),
	'active_callback' => 'cb_archive_page_settings'
	)
));


/**
 * Magazine title shows as bold
 */
$id = 'archive_magazine_title_by_bold';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'sanitize_callback' => 'sanitize_text_field',
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control_Radio_Image(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	// 'label' => __('Site Colmuns Setting','DigiPress'),
	'separator_top' => true,
	'separator' => true,
	'description' => __( 'Title font weight', 'DigiPress' ),
	'section' => 'dp_archive_page_details_section',
	'column' => 2,
	'choices'  => array(
		'' => array(
			'label' => esc_html__( 'Bold weight', 'DigiPress' ),
			'url'   => '%s/inc/admin/img/title-bold-weight.jpg'
			),
		'title-normal-weight' => array(
			'label' => esc_html__( 'Normal weight', 'DigiPress' ),
			'url'   => '%s/inc/admin/img/title-normal-weight.jpg'
			),
	),
	'active_callback' => 'cb_archive_page_settings'
	)
));

/**
 * Magazine title tilt
 */
$id = 'archive_magazine_title_tilt';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'sanitize_callback' => 'sanitize_text_field',
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control_Radio_Image(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	// 'label' => __('Site Colmuns Setting','DigiPress'),
	'separator' => true,
	'description' => __( 'Title tilt', 'DigiPress' ),
	'section' => 'dp_archive_page_details_section',
	'column' => 3,
	'choices'  => array(
		'' => array(
			'label' => __( 'None', 'DigiPress' ),
			'url'   => '%s/inc/admin/img/title-tilt-none.jpg'
			),
		'title-tilt' => array(
			'label' => __( 'Upper to right', 'DigiPress' ),
			'url'   => '%s/inc/admin/img/title-tilt1.jpg'
			),
		'title-tilt down-to-r' => array(
			'label' => __( 'Downward to right', 'DigiPress' ),
			'url'   => '%s/inc/admin/img/title-tilt2.jpg'
			),
	),
	'active_callback' => 'cb_archive_page_settings'
	)
));

/**
 * Magazine title shows as serif font
 */
$id = 'archive_magazine_text_by_serif';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'sanitize_callback' => 'sanitize_text_field',
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control_Radio_Image(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	// 'label' => __('Site Colmuns Setting','DigiPress'),
	'separator' => true,
	'description' => __( 'Gothic / Mincho', 'DigiPress' ),
	'section' => 'dp_archive_page_details_section',
	'column' => 2,
	'choices'  => array(
		'' => array(
			'label' => esc_html__( 'Gothic', 'DigiPress' ),
			'url'   => '%s/inc/admin/img/text-gothic.jpg'
			),
		'serif' => array(
			'label' => esc_html__( 'Mincho', 'DigiPress' ),
			'url'   => '%s/inc/admin/img/text-mincho.jpg'
			),
	),
	'active_callback' => 'cb_archive_page_settings'
	)
));

/**
 * Magazine text vertically
 */
$id = 'archive_magazine_text_vertically';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'sanitize_callback' => 'sanitize_text_field',
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control_Radio_Image(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	// 'label' => __('Site Colmuns Setting','DigiPress'),
	'separator' => true,
	'description' => __( 'Writing direction', 'DigiPress' ),
	'section' => 'dp_archive_page_details_section',
	'column' => 2,
	'choices'  => array(
		'' => array(
			'label' => esc_html__( 'Horizontal writing', 'DigiPress' ),
			'url'   => '%s/inc/admin/img/text-horizontally.jpg'
			),
		'txt-vertical' => array(
			'label' => esc_html__( 'Vertical writing', 'DigiPress' ),
			'url'   => '%s/inc/admin/img/text-vertically.jpg'
			),
	),
	'active_callback' => 'cb_archive_page_settings'
	)
));


/**
 * Magazine date design
 */
$id = 'archive_magazine_date_design';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'sanitize_callback' => 'sanitize_text_field',
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control_Radio_Image(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	// 'label' => __('Site Colmuns Setting','DigiPress'),
	'separator' => true,
	'description' => __( 'Date design', 'DigiPress' ),
	'section' => 'dp_archive_page_details_section',
	'column' => 2,
	'choices'  => array(
		'date1' => array(
			'label' => '#1',
			'url'   => '%s/inc/admin/img/magazine-date1.jpg'
			),
		'date2' => array(
			'label' => '#2',
			'url'   => '%s/inc/admin/img/magazine-date2.jpg'
			),
		'date3' => array(
			'label' => '#3',
			'url'   => '%s/inc/admin/img/magazine-date3.jpg'
			),
		'date4' => array(
			'label' => '#4',
			'url'   => '%s/inc/admin/img/magazine-date4.jpg'
			),
		),
	'active_callback' => 'cb_archive_page_settings'
	)
));

/**
 * Magazine accent shape
 */
$id = 'archive_magazine_accent_shape';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'sanitize_callback' => 'sanitize_text_field',
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control_Radio_Image(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	// 'label' => __('Site Colmuns Setting','DigiPress'),
	'description' => __( 'Accent shape', 'DigiPress' ),
	'section' => 'dp_archive_page_details_section',
	'column' => 3,
	'choices'  => array(
		'' => array(
			'label' => __('None', 'DigiPress'),
			'url'   => '%s/inc/admin/img/magazine-accent-shape-none.png'
			),
		'has-acc-shape acc__shape1' => array(
			'label' => '#1',
			'url'   => '%s/inc/admin/img/magazine-accent-shape1.png'
			),
		'has-acc-shape acc__shape2' => array(
			'label' => '#2',
			'url'   => '%s/inc/admin/img/magazine-accent-shape2.png'
			),
		'has-acc-shape acc__shape3' => array(
			'label' => '#3',
			'url'   => '%s/inc/admin/img/magazine-accent-shape3.png'
			),
		'has-acc-shape acc__shape4' => array(
			'label' => '#4',
			'url'   => '%s/inc/admin/img/magazine-accent-shape4.png'
			),
		'has-acc-shape acc__shape5' => array(
			'label' => '#5',
			'url'   => '%s/inc/admin/img/magazine-accent-shape5.png'
			),
		'has-acc-shape acc__shape6' => array(
			'label' => '#6',
			'url'   => '%s/inc/admin/img/magazine-accent-shape6.png'
			),
		'has-acc-shape acc__shape7' => array(
			'label' => '#7',
			'url'   => '%s/inc/admin/img/magazine-accent-shape7.png'
			),
		'has-acc-shape acc__shape8' => array(
			'label' => '#8',
			'url'   => '%s/inc/admin/img/magazine-accent-shape8.png'
			),
		),
	'active_callback' => 'cb_archive_page_settings'
	)
));

/**
 * Magazine accent shape color
 */
$id = 'archive_magazine_accent_shape_color';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage',
	'sanitize_callback' => 'sanitize_hex_color'
));
$wp_customize->add_control( new WP_Customize_Color_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	// 'label' => __('Background Design','DigiPress'),
	'description' => __('Accent shape color', 'DigiPress'),
	'section' => 'dp_archive_page_details_section',
	'active_callback' => 'cb_archive_page_settings'
	)
));

/**
 * Magazine accent shape color opacity
 */
$id = 'archive_magazine_accent_shape_opacity';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'sanitize_callback' => 'absint',
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Range_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'before_text' => __('Accent shape opacity','DigiPress'),
	'section' => 'dp_archive_page_details_section',
	'unit' => '%',
	'type' => 'custom_range',
	'input_attrs' => array(
		'min' => 1,
		'max' => 100,
		'step' => 1
		),
	'active_callback' => 'cb_archive_page_settings'
	)
));

/**
 * Meta info
 */
$id = 'archive_archive_list_date';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'refresh'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'fake_title' => __('Post meta info setting','DigiPress'),
	'label' => __('Show posted date','DigiPress'),
	'section' => 'dp_archive_page_details_section',
	'type' => 'checkbox'
	)
));
$id = 'archive_archive_list_author';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'refresh'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'label' => __('Show author name','DigiPress'),
	'section' => 'dp_archive_page_details_section',
	'type' => 'checkbox'
	)
));
$id = 'archive_archive_list_cat';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'refresh'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'label' => __('Show category','DigiPress'),
	'section' => 'dp_archive_page_details_section',
	'type' => 'checkbox'
	)
));
$id = 'archive_archive_list_views';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'refresh'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'label' => __('Show page views','DigiPress'),
	'section' => 'dp_archive_page_details_section',
	'type' => 'checkbox',
	'active_callback' => 'cb_archive_page_settings'
	)
));
$id = 'likes_number_after_title_archive';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'refresh'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'label' => __('Show Facebook likes','DigiPress'),
	'section' => 'dp_archive_page_details_section',
	'type' => 'checkbox',
	'active_callback' => 'cb_archive_page_settings'
	)
));
$id = 'tweets_number_after_title_archive';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'refresh'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'label' => __('Show tweeted counts','DigiPress').' (*)',
	'section' => 'dp_archive_page_details_section',
	'type' => 'checkbox',
	'active_callback' => 'cb_archive_page_settings'
	)
));
$id = 'hatebu_number_after_title_archive';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'refresh'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'label' => __('Show hatena bookmark counts','DigiPress'),
	'section' => 'dp_archive_page_details_section',
	'type' => 'checkbox',
	'active_callback' => 'cb_archive_page_settings'
	)
));
// Excerpt length
$id = 'archive_article_excerpt_length';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'sanitize_callback' => 'absint',
	'type' => 'option',
	'transport' => 'refresh'
));
$wp_customize->add_control( new DP_Customize_Range_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'label' => __('Excerpt length','DigiPress'),
	'section' => 'dp_archive_page_details_section',
	'unit' => __('words','DigiPress'),
	'type' => 'custom_range',
	'input_attrs' => array(
		'min' => 0,
		'max' => 320,
		'step' => 1
		),
	'active_callback' => 'cb_archive_page_settings'
	)
));
// read more
$id = 'archive_readmore_str';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'sanitize_callback' => 'dp_sanitize_html',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'label' => __('Read more label(Each posts)','DigiPress'),
	'section' => 'dp_archive_page_details_section',
	'type' => 'text',
	'input_attrs' => array(
		'placeholder' => $def_options[$id],
		),
	'active_callback' => 'cb_archive_page_settings'
	)
));
// For Selective refresh
if (isset($wp_customize->selective_refresh)){
	$wp_customize->selective_refresh->add_partial('dp_theme_options['.$id.']', array(
		'selector' => '.loop-section.lp-archive .more-link>a',
		'settings' => 'dp_theme_options['.$id.']',
		'container_inclusive' => false,
		'render_callback' => function(){
			$options = get_option('dp_theme_options');
			echo '<span>'.$options['archive_readmore_str'].'</span>';
		}
	));
}

// Navigation text to next page
$id = 'navigation_text_to_2page_archive';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'sanitize_callback' => 'dp_sanitize_html',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'label' => __('Label for second page','DigiPress'),
	'section' => 'dp_archive_page_details_section',
	'type' => 'text',
	'input_attrs' => array(
		'placeholder' => $def_options[$id],
		)
	)
));
// For Selective refresh
if (isset($wp_customize->selective_refresh)){
	$wp_customize->selective_refresh->add_partial('dp_theme_options['.$id.']', array(
		'selector' => 'body.archive .nav_to_paged>a',
		'settings' => 'dp_theme_options['.$id.']',
		'container_inclusive' => false,
		'render_callback' => function(){
			$options = get_option('dp_theme_options');
			echo '<span>'.$options['navigation_text_to_2page_archive'].'</span>';
		}
	));
}


/**
  * Infeed Ads setting in archive page
  */
 $id = 'archive_infeed_ads_code';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'refresh'
));
if ( version_compare( $wp_version, '4.9', '>=' ) ) {
	$wp_customize->add_control( new WP_Customize_Code_Editor_Control(
		$wp_customize,
		'dp_theme_options['.$id.']', array(
		'setting'=> 'dp_theme_options['.$id.']',
		'label' => __('Ads code(PC)','DigiPress'),
		'code_type' => 'text/x-scss',
		'section' => 'dp_archive_page_infeed_ads_section'
		)
	));
} else {
	$wp_customize->add_control( new DP_Customize_Textarea_Control(
		$wp_customize,
		'dp_theme_options['.$id.']', array(
		'settings' => 'dp_theme_options['.$id.']',
		'label' => __('Ads code(PC)','DigiPress'),
		'other_class' => 'dp_code_textarea html-head code',
		'rows' => 10,
		'section' => 'dp_archive_page_infeed_ads_section',
		'type' => 'textarea'
		)
	));
}
$id = 'archive_infeed_ads_order';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'refresh',
	'sanitize_callback' => 'sanitize_text_field'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'before_text' => __('Numbers of insert ads order(PC)','DigiPress'),
	'note' => __('*Numbers should be specified as non multibyte.','DigiPress').'<br />'.__('*You need using comma with order number to set multiple order.','DigiPress'),
	'separator' => true,
	'section' => 'dp_archive_page_infeed_ads_section',
	'type' => 'text',
	'input_attrs' => array(
		'placeholder' => '3,7',
		)
	)
));
// For Mobile
$id = 'archive_infeed_ads_code_mobile';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'refresh'
));
if ( version_compare( $wp_version, '4.9', '>=' ) ) {
	$wp_customize->add_control( new WP_Customize_Code_Editor_Control(
		$wp_customize,
		'dp_theme_options['.$id.']', array(
		'setting'=> 'dp_theme_options['.$id.']',
		'label' => __('Ads code(Mobile)','DigiPress'),
'code_type' => 'text/x-scss',
		'section' => 'dp_archive_page_infeed_ads_section'
		)
	));
} else {
	$wp_customize->add_control( new DP_Customize_Textarea_Control(
		$wp_customize,
		'dp_theme_options['.$id.']', array(
		'settings' => 'dp_theme_options['.$id.']',
		'label' => __('Ads code(Mobile)','DigiPress'),
		'other_class' => 'dp_code_textarea html-head code',
		'rows' => 10,
		'section' => 'dp_archive_page_infeed_ads_section',
		'type' => 'textarea'
		)
	));
}
$id = 'archive_infeed_ads_order_mb';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'refresh',
	'sanitize_callback' => 'sanitize_text_field'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'before_text' => __('Numbers of insert ads order(Mobile)','DigiPress'),
	'note' => __('*Numbers should be specified as non multibyte.','DigiPress').'<br />'.__('*You need using comma with order number to set multiple order.','DigiPress'),
	'section' => 'dp_archive_page_infeed_ads_section',
	'type' => 'text',
	'input_attrs' => array(
		'placeholder' => '3,6',
		)
	)
));

function cb_archive_page_settings($control) {
	$layout = $control->manager->get_setting('dp_theme_options[archive_post_show_type]')->value();
	$text_vertically = $control->manager->get_setting('dp_theme_options[archive_magazine_text_vertically]')->value();
	$title_back = $control->manager->get_setting('dp_theme_options[archive_magazine_title_back]')->value();
	$control_id = $control->id;

	$result = true;

	if ($layout === 'normal' && (
		$control_id === 'dp_theme_options[archive_loop_col]' ||
		$control_id === 'dp_theme_options[archive_fix_article_height]' ||
		$control_id === 'dp_theme_options[archive_magazine_cover_frame]' ||
		$control_id === 'dp_theme_options[archive_magazine_cover_frame_color]' ||
		$control_id === 'dp_theme_options[archive_magazine_title_position]' ||
		$control_id === 'dp_theme_options[archive_magazine_title_tilt]' ||
		$control_id === 'dp_theme_options[archive_magazine_text_by_serif]' ||
		$control_id === 'dp_theme_options[archive_magazine_text_vertically]' ||
		$control_id === 'dp_theme_options[archive_magazine_date_design]' ||
		$control_id === 'dp_theme_options[archive_magazine_accent_shape]' ||
		$control_id === 'dp_theme_options[archive_magazine_accent_shape_color]' ||
		$control_id === 'dp_theme_options[archive_magazine_accent_shape_opacity]' ||
		$control_id === 'dp_theme_options[archive_magazine_title_color]' ||
		$control_id === 'dp_theme_options[archive_magazine_title_by_bold]' ||
		$control_id === 'dp_theme_options[archive_magazine_title_back]' ||
		$control_id === 'dp_theme_options[archive_magazine_title_back_color]' ||
		$control_id === 'dp_theme_options[archive_magazine_title_back_border]' ||
		$control_id === 'dp_theme_options[archive_magazine_title_back_color_opacity]'
		)
	) $result = false;

	if ($layout === 'portfolio' && (
		$control_id === 'dp_theme_options[archive_article_excerpt_length]' ||
		$control_id === 'dp_theme_options[archive_readmore_str]' ||
		$control_id === 'dp_theme_options[archive_article_alternately]' ||
		$control_id === 'dp_theme_options[archive_magazine_cover_frame]' ||
		$control_id === 'dp_theme_options[archive_magazine_cover_frame_color]' ||
		$control_id === 'dp_theme_options[archive_magazine_title_position]' ||
		$control_id === 'dp_theme_options[archive_magazine_title_tilt]' ||
		$control_id === 'dp_theme_options[archive_magazine_text_by_serif]' ||
		$control_id === 'dp_theme_options[archive_magazine_text_vertically]' ||
		$control_id === 'dp_theme_options[archive_magazine_date_design]' ||
		$control_id === 'dp_theme_options[archive_magazine_accent_shape]' ||
		$control_id === 'dp_theme_options[archive_magazine_accent_shape_color]' ||
		$control_id === 'dp_theme_options[archive_magazine_accent_shape_opacity]' ||
		$control_id === 'dp_theme_options[archive_magazine_title_color]' ||
		$control_id === 'dp_theme_options[archive_magazine_title_by_bold]' ||
		$control_id === 'dp_theme_options[archive_magazine_title_back]' ||
		$control_id === 'dp_theme_options[archive_magazine_title_back_color]' ||
		$control_id === 'dp_theme_options[archive_magazine_title_back_border]' ||
		$control_id === 'dp_theme_options[archive_magazine_title_back_color_opacity]'
		)
	) $result = false;

	if ( $layout === 'magazine' && (
		$control_id === 'dp_theme_options[archive_fix_article_height]' ||
		$control_id === 'dp_theme_options[archive_overlay_color]' ||
		$control_id === 'dp_theme_options[archive_article_round_corner]' ||
		$control_id === 'dp_theme_options[archive_article_box_shadow]' ||
		$control_id === 'dp_theme_options[archive_article_alternately]'
		)
	) $result = false;

	if ( ( $layout === 'news' ||  $layout === 'simple' ) && (
		$control_id === 'dp_theme_options[archive_loop_col]' ||
		$control_id === 'dp_theme_options[archive_article_round_corner]' ||
		$control_id === 'dp_theme_options[archive_article_box_shadow]' ||
		$control_id === 'dp_theme_options[archive_fix_article_height]' ||
		$control_id === 'dp_theme_options[archive_overlay_color]' ||
		$control_id === 'dp_theme_options[archive_archive_list_views]' ||
		$control_id === 'dp_theme_options[likes_number_after_title_archive]' ||
		$control_id === 'dp_theme_options[tweets_number_after_title_archive]' ||
		$control_id === 'dp_theme_options[hatebu_number_after_title_archive]' ||
		$control_id === 'dp_theme_options[archive_article_excerpt_length]' ||
		$control_id === 'dp_theme_options[archive_readmore_str]' ||
		$control_id === 'dp_theme_options[archive_article_alternately]' ||
		$control_id === 'dp_theme_options[archive_magazine_cover_frame]' ||
		$control_id === 'dp_theme_options[archive_magazine_cover_frame_color]' ||
		$control_id === 'dp_theme_options[archive_magazine_title_position]' ||
		$control_id === 'dp_theme_options[archive_magazine_title_tilt]' ||
		$control_id === 'dp_theme_options[archive_magazine_text_by_serif]' ||
		$control_id === 'dp_theme_options[archive_magazine_text_vertically]' ||
		$control_id === 'dp_theme_options[archive_magazine_date_design]' ||
		$control_id === 'dp_theme_options[archive_magazine_accent_shape]' ||
		$control_id === 'dp_theme_options[archive_magazine_accent_shape_color]' ||
		$control_id === 'dp_theme_options[archive_magazine_accent_shape_opacity]' ||
		$control_id === 'dp_theme_options[archive_magazine_title_color]' ||
		$control_id === 'dp_theme_options[archive_magazine_title_by_bold]' ||
		$control_id === 'dp_theme_options[archive_magazine_title_back]' ||
		$control_id === 'dp_theme_options[archive_magazine_title_back_color]' ||
		$control_id === 'dp_theme_options[archive_magazine_title_back_border]' ||
		$control_id === 'dp_theme_options[archive_magazine_title_back_color_opacity]'
		)
	) $result = false;

	if ( ( $layout == 'magazine' && $text_vertically ) && (
		$control_id === 'dp_theme_options[archive_magazine_title_position]'
		)
	) $result = false;

	if ( ( $layout == 'magazine' && empty( $title_back ) ) && (
		$control_id === 'dp_theme_options[archive_magazine_title_back_color]' ||
		$control_id === 'dp_theme_options[archive_magazine_title_back_color_opacity]' ||
		$control_id === 'dp_theme_options[archive_magazine_title_back_border]'
		)
	) $result = false;

	return $result;
}