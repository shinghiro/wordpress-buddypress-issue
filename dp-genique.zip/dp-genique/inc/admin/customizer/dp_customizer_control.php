<?php
/**
 * Expand default control
 */
class DP_Customize_Control extends WP_Customize_Control {
	public $note = '';
	public $fake_title = '';
	public $before_text = '';
	public $unit = '';
	public $separator = false;
	public $separator_top = false;
	public $hierarchy = '';
	public $iframe_video = '';

	public function render() {
		$id    = 'customize-control-' . str_replace( array( '[', ']' ), array( '-', '' ), $this->id );
		$unit = isset($this->unit) && !empty($this->unit) ? ' show-unit' : '';
		$before_text = isset($this->before_text) && !empty($this->before_text) ? stripslashes(wp_filter_post_kses($this->before_text)) : '';
		$fake_title = isset($this->fake_title) && !empty($this->fake_title) ? '<span class="customize-control-title">'.esc_html($this->fake_title).'</span>' : '';
		$hierarchy = isset($this->hierarchy) && !empty($this->hierarchy) ? ' sub-'.esc_attr($this->hierarchy) : '';
		$class = 'customize-control customize-control-' . $this->type . $unit . $hierarchy;
		$note = isset($this->note) && !empty($this->note) ? '<div class="slide-title dashicons-before dashicons-info">'.__("Note...", "DigiPress").'</div><div class="slide-content">'.$this->note.'</div>' : '';
		$separator = isset($this->separator) && !empty($this->separator) ? '<hr />' : '';
		$separator_top = isset($this->separator_top) && !empty($this->separator_top) ? '<hr />' : '';

		if (isset($this->iframe_video) && !empty($this->iframe_video) ){
			if (preg_match("/^[0-9]+$/",$this->iframe_video)) {
				// Vimeo
				$iframe_video = '<div class="if-video"><iframe src="https://player.vimeo.com/video/'.$this->iframe_video.'?title=0&byline=0&portrait=0&badge=0" webkitallowfullscreen mozallowfullscreen allowfullscreen></iframe></div>';
			} else {
				// YouTube
				$iframe_video = '<div class="if-video"><iframe src="https://www.youtube.com/embed/'.$this->iframe_video.'/?wmode=transparent&hd=1&autohide=1&rel=0" allowfullscreen></iframe></div>';

			}
		} else {
			$iframe_video = '';
		}?>
<li id="<?php echo esc_attr( $id ); ?>" class="<?php echo esc_attr( $class ); ?>"><?php
echo $separator_top . $fake_title . $before_text;
$this->render_content();
echo esc_html($this->unit) . $iframe_video . $note . $separator;?>
</li><?php
	}
}