<?php
// init
$id = '';
// **********************************************
// Header image / slideshow section
// **********************************************
$wp_customize->add_panel( 'dp_header_contents_panel', array(
	'priority' => 50,
	'title' => __('Header Area Settings', 'DigiPress'),
	'description' => __('Settings for page header area.', 'DigiPress'),
));
// Header image / slideshow
$wp_customize->add_section(
	'dp_header_area_media_section', array(
	'title' => __('Header Image / Slider', 'DigiPress'),
	'description' => sprintf( __('Customize the header image or slider in top page header. %s', 'DigiPress'), '<br />' . __( 'For settings for mobile themes, go to [Mobile theme settings] → [Header image / Slider settings].', 'DigiPress') ),
	'panel' => 'dp_header_contents_panel',
));
// Header area settings in archive or single page
$wp_customize->add_section(
	'dp_header_area_in_archive_single_section', array(
	'title' => __('Settings for Archive / Single Page', 'DigiPress'),
	'description' => __('Settings for the header area in archive and single page.', 'DigiPress'),
	'panel' => 'dp_header_contents_panel',
));

/**
 * Choices for header media type
 */
$id = 'dp_header_content_type';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'refresh'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'label' => __('Header Content Type','DigiPress'),
	'description' => __('*Choose header area content.','DigiPress'),
	'section' => 'dp_header_area_media_section',
	'separator' => true,
	'type' => 'select',
	'choices' => array(
		'none' => __('Display nothing', 'DigiPress'),
		'image' => __('Header image','DigiPress'),
		'slideshow_selected_media' => __('Slider (Image/video)','DigiPress'),
		'slideshow' => __('Slider (Post/page)','DigiPress')
		)
	)
));
// For Selective refresh
if (isset($wp_customize->selective_refresh)){
	$wp_customize->selective_refresh->add_partial('dp_theme_options['.$id.']', array(
		'selector' => '#header-banner-outer',
		'settings' => 'dp_theme_options['.$id.']'
	));
}

/**
 * Header image
 */
$id = 'dp_header_img';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'sanitize_callback' => 'esc_url_raw',
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new WP_Customize_Image_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'label' => __('Header Image','DigiPress'),
	'section' => 'dp_header_area_media_section',
	'active_callback' => 'cb_header_content_type'
	)
));
/**
 * Header image title and caption
 */
$id = 'header_img_title';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => '',
	'type' => 'option',
	'sanitize_callback' => 'dp_sanitize_html',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'label' => __('Header Image Title and Caption','DigiPress'),
	'description' => __('Title', 'DigiPress'),
	'input_attrs' => array(
		'placeholder' => $def_options[$id]
		),
	'section' => 'dp_header_area_media_section',
	'type' => 'text',
	'active_callback' => 'cb_header_content_type'
	)
));
// For Selective refresh
if (isset($wp_customize->selective_refresh)){
	$wp_customize->selective_refresh->add_partial('dp_theme_options['.$id.']', array(
		'selector' => '#banner_title',
		'settings' => 'dp_theme_options['.$id.']',
		'container_inclusive' => false,
		'render_callback' => function(){
			$options = get_option('dp_theme_options');
			echo '<h2 class="btitle">'.$options['header_img_title'].'</h2>';
		}
	));
}

// Caption
$id = 'header_img_caption';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => '',
	'type' => 'option',
	'sanitize_callback' => 'dp_sanitize_html',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'description' => __('Caption','DigiPress'),
	'note' => __('*You can use HTML.', 'DigiPress').__('However, if text reveal animation is enabled, it will not be reflected.', 'DigiPress'),
	'input_attrs' => array(
		'placeholder' => $def_options[$id]
		),
	'section' => 'dp_header_area_media_section',
	'type' => 'textarea',
	'active_callback' => 'cb_header_content_type'
	)
));
// For Selective refresh
if (isset($wp_customize->selective_refresh)){
	$wp_customize->selective_refresh->add_partial('dp_theme_options['.$id.']', array(
		'selector' => '#banner_caption',
		'settings' => 'dp_theme_options['.$id.']',
		'container_inclusive' => false,
		'render_callback' => function(){
			$options = get_option('dp_theme_options');
			echo '<h3 class="bcaption">'.$options['header_img_caption'].'</h3>';
		}
	));
}

// Title position
$id = 'header_title_pos';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'description' => __('Title and caption position', 'DigiPress'),
	'section' => 'dp_header_area_media_section',
	'type' => 'select',
	'choices' => array(
		'center' => __('Display in center', 'DigiPress'),
		'left' => __('Display in left', 'DigiPress'),
		'right' => __('Display in right','DigiPress')
		),
	'active_callback' => 'cb_header_content_type'
	)
));

// enable animation reveal
$id = 'header_img_text_animate';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'refresh'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'label' => __('Enable title reveal animation','DigiPress'),
	'section' => 'dp_header_area_media_section',
	'type' => 'checkbox',
	'active_callback' => 'cb_header_content_type'
	)
));

// Vertical text
$id = 'header_text_vertically';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'label' => __('Display text vertically','DigiPress'),
	'note' => __('*If the title or caption contains a large number of characters, adjust the height by inserting line breaks with an appropriate number of characters.', 'DigiPress'),
	'section' => 'dp_header_area_media_section',
	'type' => 'checkbox',
	'active_callback' => 'cb_header_content_type'
	)
));


/**
 * Slider settings
 */
$id = 'dp_slider_post_or_page';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'refresh'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'label' => __('Slider Target','DigiPress'),
	'section' => 'dp_header_area_media_section',
	'note' => __('*You need check the post to include as header slider item in each post option.','DigiPress'),
	'type' => 'radio',
	'choices' => array(
		'post' => __('Selected posts','DigiPress'),
		'page' => __('Selected static pages','DigiPress')
		),
	'active_callback' => 'cb_header_content_type'
	)
));

/**
 * Number of slide
 */
$id = 'dp_number_of_slideshow';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'sanitize_callback' => 'absint',
	'type' => 'option',
	'transport' => 'refresh'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'label' => __('Number of Slide','DigiPress'),
	'unit' => __('Slides', 'DigiPress'),
	'section' => 'dp_header_area_media_section',
	'type' => 'number',
	'input_attrs' => array(
		'min' => 1, 'step' => 1, 'max' => 40
	),
	'active_callback' => 'cb_header_content_type'
	)
));

/**
 * Slider order
 */
$id = 'dp_slider_order';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'refresh'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'label' => __('Slider Order','DigiPress'),
	'section' => 'dp_header_area_media_section',
	'type' => 'select',
	'choices' => array(
		'date' => __('Order by posted date', 'DigiPress'),
		'rand' => __('Random','DigiPress'),
		'comment_count' => __('Order by comment count','DigiPress'),
		'title' => __('Order post title','DigiPress')
		),
	'active_callback' => 'cb_header_content_type'
	)
));

/**
 * Slider style
 */
$id = 'dp_slider_style';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'refresh'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'label' => __('Slider Style','DigiPress'),
	'section' => 'dp_header_area_media_section',
	'type' => 'select',
	'choices' => array(
		'fade' => __('Fade in/out', 'DigiPress'),
		'horizontal' => __('Horizontal slider', 'DigiPress'),
		'vertical' => __('Vertical slider', 'DigiPress'),
		'split' => __('Split slider(2 slides)', 'DigiPress'),
		'thumb' => __('Slider with thumbnail nav', 'DigiPress'),
		'carousel' => __('Carousel','DigiPress'),
		'center three' => sprintf(__('Centered(%s slides)','DigiPress'), '3'),
		'center five' => sprintf(__('Centered(%s slides)','DigiPress'), '5'),
		'coverflow one' => sprintf(__('3D coverflow(%s slides)','DigiPress'), '1'),
		'coverflow three' => sprintf(__('3D coverflow(%s slides)','DigiPress'), '3'),
		'coverflow five' => sprintf(__('3D coverflow(%s slides)','DigiPress'), '5'),
		'creative one' => __( 'Slice', 'DigiPress' ),
		'creative two' => __( 'Shifting slider', 'DigiPress' ),
		'creative three' => __( 'Horizontal rotation', 'DigiPress' ),
		'creative four' => '3D ' . __( 'Horizontal rotation', 'DigiPress' ),
		'creative five' => '3D ' . __( 'Vertical rotation', 'DigiPress' ),
		'creative six' => __( 'Central rotation', 'DigiPress' )
		),
	'active_callback' => 'cb_header_content_type'
	)
));

/**
 * Replace each title caption to static title and caption
 */
$id = 'dp_slider_only_one_title';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'refresh'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'label' => __('Display only one main title and caption','DigiPress'),
	'note' => __('*Check this to show static title and caption instead of each slide title and caption. If you check this option, each slide title and caption will be disabled.', 'DigiPress'),
	'section' => 'dp_header_area_media_section',
	'type' => 'checkbox',
	'active_callback' => 'cb_header_content_type'
	)
));

/**
 * Show the background image
 */
$id = 'dp_header_area_show_bgimg';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'refresh'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'fake_title' => __('Advanced Settings', 'DigiPress'),
	'label' => __('Show margin and background image around','DigiPress'),
	'note' => __('*Check this to display some margin on the header image or slider and display the background image.', 'DigiPress'),
	'section' => 'dp_header_area_media_section',
	'type' => 'checkbox',
	'active_callback' => 'cb_header_content_type'
	)
));


/**
 * Enable parallax scroll transition
 */
$id = 'dp_slider_parallax_transition';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'refresh'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'label' => __('Enable parallax transition','DigiPress'),
	'note' => __('*If you check this option, video slides are disabled for autoplay.', 'DigiPress'),
	'section' => 'dp_header_area_media_section',
	'type' => 'checkbox',
	'active_callback' => 'cb_header_content_type'
	)
));



/**
 * Header area top edge
 */
$id = 'dp_header_area_top_edge';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'refresh'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'fake_title' => __('Header Area Edge Shape','DigiPress'),
	'before_text' => __('Header Area Top Edge Shape','DigiPress'),
	'section' => 'dp_header_area_media_section',
	'type' => 'select',
	'choices' => array(
		'none' => __('None', 'DigiPress'),
		'mountain' => __('Mountain shape', 'DigiPress'),
		'vline' => __('V line', 'DigiPress'),
		'wline' => __('W line', 'DigiPress'),
		'mline' => __('M line', 'DigiPress'),
		'up_right' => __('Diagonally right', 'DigiPress'),
		'up_left' => __('Diagonally left','DigiPress'),
		'wave1' => __('Wave shape','DigiPress'),
		'wave2' => __('Wave shape','DigiPress') .' (' . __('Flip horizontal','DigiPress') . ')',
		'curve1' => __('Curve shape','DigiPress'),
		'curve2' => __('Curve shape','DigiPress') .' (' . __('Flip vertical','DigiPress') . ')',
		'saw1' => __('Saw wave','DigiPress'),
		'saw2' => __('Saw wave','DigiPress') .' (' . __('Flip horizontal','DigiPress') . ')'
		),
	'active_callback' => 'cb_header_content_type'
	)
));

/**
 * Header area bottom edge
 */
$id = 'dp_header_area_bottom_edge';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'refresh'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'before_text' => __('Header Area Bottom Edge Shape','DigiPress'),
	'section' => 'dp_header_area_media_section',
	'type' => 'select',
	'choices' => array(
		'none' => __('None', 'DigiPress'),
		'mountain' => __('Mountain shape', 'DigiPress'),
		'vline' => __('V line', 'DigiPress'),
		'wline' => __('W line', 'DigiPress'),
		'mline' => __('M line', 'DigiPress'),
		'up_right' => __('Diagonally right', 'DigiPress'),
		'up_left' => __('Diagonally left','DigiPress'),
		'wave1' => __('Wave shape','DigiPress'),
		'wave2' => __('Wave shape','DigiPress') .' (' . __('Flip horizontal','DigiPress') . ')',
		'curve1' => __('Curve shape','DigiPress'),
		'curve2' => __('Curve shape','DigiPress') .' (' . __('Flip vertical','DigiPress') . ')',
		'saw1' => __('Saw wave','DigiPress'),
		'saw2' => __('Saw wave','DigiPress') .' (' . __('Flip horizontal','DigiPress') . ')'
		),
	'active_callback' => 'cb_header_content_type'
	)
));

/**
 * Header area edge piled layer
 */
$id = 'dp_header_area_edge_piled_layer';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'refresh'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'label' => __('Enable piled layer','DigiPress'),
	'note' => __('*Check this option to show the edge with piled layer. This is for wave or curve edge only.','DigiPress'),
	'description' => '',
	'section' => 'dp_header_area_media_section',
	'type' => 'checkbox',
	'active_callback' => 'cb_header_content_type',
	)
));


/**
 * Slide speed
 */
$id = 'dp_slider_show_time';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'sanitize_callback' => 'absint',
	'type' => 'option',
	'transport' => 'refresh'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'label' => __('Auto Slide Time','DigiPress'),
	'unit' => __('mili second', 'DigiPress'),
	'section' => 'dp_header_area_media_section',
	'type' => 'number',
	'input_attrs' => array(
		'min' => 100, 'step' => 1, 'max' => 100000
	),
	'active_callback' => 'cb_header_content_type'
	)
));
/**
 * Disable auto play
 */
$id = 'dp_slider_disable_autoplay';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'refresh'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'label' => __('Disable autoplay','DigiPress'),
	'section' => 'dp_header_area_media_section',
	'type' => 'checkbox',
	'active_callback' => 'cb_header_content_type'
	)
));
/**
 * Transition time
 */
$id = 'dp_slider_transition_time';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'sanitize_callback' => 'absint',
	'type' => 'option',
	'transport' => 'refresh'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'label' => __('Transition Setting','DigiPress'),
	'description' => __('Transition Time','DigiPress'),
	'unit' => __('mili second', 'DigiPress'),
	'section' => 'dp_header_area_media_section',
	'type' => 'number',
	'input_attrs' => array(
		'min' => 100, 'step' => 10, 'max' => 100000
	),
	'active_callback' => 'cb_header_content_type'
	)
));
/**
 * Next/Prev navigation button
 */
$id = 'dp_slider_nav_button';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'refresh'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'label' => __('Show next / prev navigation button','DigiPress'),
	'section' => 'dp_header_area_media_section',
	'type' => 'checkbox',
	'active_callback' => 'cb_header_content_type'
	)
));
/**
 * Slide page navigation
 */
$id = 'dp_slider_control_button';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'refresh'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'label' => __('Show navigation control button','DigiPress'),
	'section' => 'dp_header_area_media_section',
	'type' => 'checkbox',
	'active_callback' => 'cb_header_content_type'
	)
));

/**
 * Title and caption color
 */
$id = 'header_banner_text_color';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'sanitize_callback' => 'sanitize_hex_color',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new WP_Customize_Color_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'label' => __('Font color / Text shadow','DigiPress'),
	'description' => __('Font / link color','DigiPress'),
	'section' => 'dp_header_area_media_section',
	'active_callback' => 'cb_header_content_type'
	)
));
/**
 * Title and caption text shadow
 */
$id = 'header_banner_text_shadow_enable';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'label' => __('Enable text shadow','DigiPress'),
	'section' => 'dp_header_area_media_section',
	'type' => 'checkbox',
	'active_callback' => 'cb_header_content_type'
	)
));
/**
 * Text shadow
 */
$id = 'header_banner_text_shadow_color';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'sanitize_callback' => 'sanitize_hex_color',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new WP_Customize_Color_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'description' => __('Text shadow color','DigiPress'),
	'section' => 'dp_header_area_media_section',
	'active_callback' => 'cb_header_content_type'
	)
));

/**
 * Color Overlay settings
 */
$id = 'header_banner_overlay_color';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'sanitize_callback' => 'sanitize_hex_color',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new WP_Customize_Color_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'label' => __('Color Overlay Setting','DigiPress'),
	'description' => __('Overlay color','DigiPress'),
	'section' => 'dp_header_area_media_section',
	'active_callback' => 'cb_header_content_type'
	)
));
/**
 * Overlay opacity
 */
$id = 'header_banner_overlay_opacity';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'sanitize_callback' => 'absint',
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Range_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'before_text' => __('Overlay opacity','DigiPress'),
	'section' => 'dp_header_area_media_section',
	'unit' => '%',
	'type' => 'custom_range',
	'input_attrs' => array(
		'min' => 0,
		'max' => 100,
		'step' => 1
		),
	'active_callback' => 'cb_header_content_type'
	)
));

/**
 * Layer Mask setting
 */
$id = 'dp_header_area_mask_pattern';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'label' => __('Layer Mask Setting', 'DigiPress'),
	'description' => __('Layer mask pattern','DigiPress'),
	'section' => 'dp_header_area_media_section',
	'type' => 'select',
	'choices' => array(
		'none' => __('None', 'DigiPress'),
		'dot1' => __('Dot patern', 'DigiPress') . ' ' . __('(Black)', 'DigiPress'),
		'dot1w' => __('Dot patern', 'DigiPress') . ' ' . __('(White)', 'DigiPress'),
		'dot2' => __('Tiny dot pattern', 'DigiPress') . ' ' . __('(Black)', 'DigiPress'),
		'dot2w' => __('Tiny dot pattern', 'DigiPress') . ' ' . __('(White)', 'DigiPress'),
		'stripe1' => sprintf( __('Stripe%s pattern', 'DigiPress'), '') . ' ' . __('(Black)', 'DigiPress'),
		'stripe1w' => sprintf( __('Stripe%s pattern', 'DigiPress'), '') . ' ' . __('(White)', 'DigiPress'),
		'stripe2' => sprintf( __('Stripe%s pattern', 'DigiPress'), __(' rotated 45 degree', 'DigiPress') ) . ' ' . __('(Black)', 'DigiPress'),
		'stripe2w' => sprintf( __('Stripe%s pattern', 'DigiPress'), __(' rotated 45 degree', 'DigiPress') ) . ' ' . __('(White)', 'DigiPress'),
		'border' => __('Border pattern', 'DigiPress') . ' ' . __('(Black)', 'DigiPress'),
		'borderw' => __('Border pattern', 'DigiPress') . ' ' . __('(White)', 'DigiPress'),
		'mesh' => __('Mesh pattern','DigiPress') . ' ' . __('(Black)', 'DigiPress'),
		'meshw' => __('Mesh pattern','DigiPress') . ' ' . __('(White)', 'DigiPress')
		),
	'active_callback' => 'cb_header_content_type'
	)
));
/**
 * Layer Mask opacity
 */
$id = 'dp_header_area_mask_opacity';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'sanitize_callback' => 'absint',
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Range_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'before_text' => __('Layer mask opacity','DigiPress'),
	'section' => 'dp_header_area_media_section',
	'unit' => '%',
	'type' => 'custom_range',
	'input_attrs' => array(
		'min' => 0,
		'max' => 100,
		'step' => 1
		),
	'active_callback' => 'cb_header_content_type'
	)
));
/**
 * Layer Mask line thickness
 */
$id = 'dp_header_area_mask_line_thickness';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'sanitize_callback' => 'absint',
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'description' => __('Line thickness','DigiPress'),
	'unit' => __('pixel','DigiPress'),
	'section' => 'dp_header_area_media_section',
	'type' => 'number',
	'input_attrs' => array('min' => 1,'max' => 100,'step' => 1),
	'active_callback' => 'cb_header_content_type'
	)
));
/**
 * Layer Mask line thickness
 */
$id = 'dp_header_area_mask_line_spacing';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'sanitize_callback' => 'absint',
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'description' => __('Line spacing','DigiPress'),
	'unit' => __('pixel','DigiPress'),
	'section' => 'dp_header_area_media_section',
	'type' => 'number',
	'input_attrs' => array('min' => 1,'max' => 100,'step' => 1),
	'active_callback' => 'cb_header_content_type'
	)
));

/**
 * Selected slide images or video
 */
// Slide 1
$id = 'dp_slider_background1';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'refresh'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'label' => sprintf(__('Slide %s Setting','DigiPress'), '1'),
	'description' => __('Slide media', 'DigiPress'),
	'before_text' => '<hr />',
	'section' => 'dp_header_area_media_section',
	'type' => 'select',
	'choices' => array(
		'none' => __('None','DigiPress'),
		'image' => __('Image', 'DigiPress'),
		'video' => __('Uploaded Video(MP4)','DigiPress'),
		'youtube' => __('YouTube video', 'DigiPress'),
		'vimeo' => __('Vimeo video', 'DigiPress')
		),
	'active_callback' => 'cb_header_content_type'
	)
));
$id = 'dp_slider_image1';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'sanitize_callback' => 'esc_url_raw',
	'type' => 'option',
	'transport' => 'refresh'
));
$wp_customize->add_control( new WP_Customize_Image_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'description' => __('Slide image','DigiPress'),
	'section' => 'dp_header_area_media_section',
	'active_callback' => 'cb_header_content_type'
	)
));
$id = 'dp_slider_video1';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'refresh'
));
$wp_customize->add_control( new WP_Customize_Media_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'description' => __('Slide video','DigiPress'),
	'section' => 'dp_header_area_media_section',
	'mime_type' => 'video',
	'button_labels'  => array(
		'select' => __( 'Select Video' ),
		'change' => __( 'Change Video' ),
		'placeholder' => __( 'No video selected' ),
		'frame_title' => __( 'Select Video' ),
		'frame_button' => __( 'Choose Video' ),
		),
	'active_callback' => 'cb_header_content_type'
	)
));
/**
 * YouTube / vimeo ID
 */
$id = 'dp_slider_youtube_vimeo_id1';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'refresh'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'description' => __('YouTube or Vimeo video ID','DigiPress'),
	'iframe_video' => isset(get_option('dp_theme_options')[$id]) ? get_option('dp_theme_options')[$id] : null,
	'section' => 'dp_header_area_media_section',
	'type' => 'text',
	'active_callback' => 'cb_header_content_type'
	)
));
/**
 * Video start time
 */
$id = 'dp_slider_video_start_time1';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'sanitize_callback' => 'absint',
	'type' => 'option',
	'transport' => 'refresh'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'before_text' => '<span class="description customize-control-description">'.__('Seek Time','DigiPress').'</span>',
	'unit' => __('Seconds after', 'DigiPress'),
	'section' => 'dp_header_area_media_section',
	'type' => 'number',
	'input_attrs' => array(
		'min' => 0, 'step' => 1, 'max' => 100000
	),
	'active_callback' => 'cb_header_content_type'
	)
));
/**
 * title 1
 */
$id = 'dp_slider_title1';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => '',
	'type' => 'option',
	'sanitize_callback' => 'dp_sanitize_html',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'description' => __('Slide title','DigiPress'),
	'section' => 'dp_header_area_media_section',
	'type' => 'text',
	'input_attrs' => array(
		'placeholder' => $def_options[$id]
		),
	'active_callback' => 'cb_header_content_type'
	)
));
// For Selective refresh
if (isset($wp_customize->selective_refresh)){
	$wp_customize->selective_refresh->add_partial('dp_theme_options['.$id.']', array(
		'selector' => '.sl-content.slc-1 .title',
		'settings' => 'dp_theme_options['.$id.']',
		'container_inclusive' => false,
		'render_callback' => function(){
			$options = get_option('dp_theme_options');
			echo $options['dp_slider_title1'];
		}
	));
}

/**
 * caption
 */
$id = 'dp_slider_caption1';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => '',
	'type' => 'option',
	'sanitize_callback' => 'dp_sanitize_html',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'description' => __('Slide caption','DigiPress'),
	'section' => 'dp_header_area_media_section',
	'type' => 'text',
	'input_attrs' => array(
		'placeholder' => $def_options[$id]
		),
	'active_callback' => 'cb_header_content_type'
	)
));
// For Selective refresh
if (isset($wp_customize->selective_refresh)){
	$wp_customize->selective_refresh->add_partial('dp_theme_options['.$id.']', array(
		'selector' => '.sl-content.slc-1 .caption',
		'settings' => 'dp_theme_options['.$id.']',
		'container_inclusive' => false,
		'render_callback' => function(){
			$options = get_option('dp_theme_options');
			echo $options['dp_slider_caption1'];
		}
	));
}

// Button
$id = 'dp_slider_button_text1';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => '',
	'type' => 'option',
	'sanitize_callback' => 'dp_sanitize_html',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'description' => __('Button text','DigiPress'),
	'section' => 'dp_header_area_media_section',
	'type' => 'text',
	'input_attrs' => array(
		'placeholder' => __('Click Here', 'DigiPress')
		),
	'active_callback' => 'cb_header_content_type'
	)
));
// For Selective refresh
if (isset($wp_customize->selective_refresh)){
	$wp_customize->selective_refresh->add_partial('dp_theme_options['.$id.']', array(
		'selector' => '.sl-content.slc-1 .btn_area .title_cap_btn',
		'settings' => 'dp_theme_options['.$id.']',
		'container_inclusive' => false,
		'render_callback' => function(){
			$options = get_option('dp_theme_options');
			echo $options['dp_slider_button_text1'];
		}
	));
}
$id = 'dp_slider_button_url1';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => '',
	'type' => 'option',
	'sanitize_callback' => 'esc_url_raw',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'description' => __('Button target URL','DigiPress'),
	'section' => 'dp_header_area_media_section',
	'type' => 'text',
	'input_attrs' => array(
		'placeholder' => 'https://example.com/target/',
	),
	'active_callback' => 'cb_header_content_type'
	)
));
// $id = 'dp_slider_button_color1';
// $wp_customize->add_setting(
// 	'dp_theme_options['.$id.']', array(
// 	'default' => $def_options[$id],
// 	'type' => 'option',
// 	'transport' => 'postMessage',
// 	'sanitize_callback' => 'sanitize_hex_color'
// ));
// $wp_customize->add_control( new WP_Customize_Color_Control(
// 	$wp_customize,
// 	'dp_theme_options['.$id.']', array(
// 	'settings' => 'dp_theme_options['.$id.']',
// 	'description' => __('Button Color','DigiPress'),
// 	'section' => 'dp_header_area_media_section',
// 	'active_callback' => 'cb_header_content_type'
// 	)
// ));
/**
 * Title position
 */
$id = 'dp_slider_title_pos1';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'description' => __('Title and caption position', 'DigiPress'),
	'section' => 'dp_header_area_media_section',
	'type' => 'select',
	'choices' => array(
		'center' => __('Display in center', 'DigiPress'),
		'left' => __('Display in left', 'DigiPress'),
		'right' => __('Display in right','DigiPress')
		),
	'separator' => true,
	'active_callback' => 'cb_header_content_type'
	)
));

// Slide 2
$id = 'dp_slider_background2';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'refresh'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'label' => sprintf(__('Slide %s Setting','DigiPress'), '2'),
	'description' => __('Slide media', 'DigiPress'),
	'section' => 'dp_header_area_media_section',
	'type' => 'select',
	'choices' => array(
		'none' => __('None','DigiPress'),
		'image' => __('Image', 'DigiPress'),
		'video' => __('Uploaded Video(MP4)','DigiPress'),
		'youtube' => __('YouTube video', 'DigiPress'),
		'vimeo' => __('Vimeo video', 'DigiPress')
		),
	'active_callback' => 'cb_header_content_type'
	)
));
$id = 'dp_slider_image2';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'sanitize_callback' => 'esc_url_raw',
	'type' => 'option',
	'transport' => 'refresh'
));
$wp_customize->add_control( new WP_Customize_Image_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'description' => __('Slide image','DigiPress'),
	'section' => 'dp_header_area_media_section',
	'active_callback' => 'cb_header_content_type'
	)
));
$id = 'dp_slider_video2';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'refresh'
));
$wp_customize->add_control( new WP_Customize_Media_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'description' => __('Slide video','DigiPress'),
	'section' => 'dp_header_area_media_section',
	'mime_type' => 'video',
	'button_labels'  => array(
		'select' => __( 'Select Video' ),
		'change' => __( 'Change Video' ),
		'placeholder' => __( 'No video selected' ),
		'frame_title' => __( 'Select Video' ),
		'frame_button' => __( 'Choose Video' ),
		),
	'active_callback' => 'cb_header_content_type'
	)
));
/**
 * YouTube / vimeo ID
 */
$id = 'dp_slider_youtube_vimeo_id2';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'refresh'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'description' => __('YouTube or Vimeo video ID','DigiPress'),
	'iframe_video' => isset(get_option('dp_theme_options')[$id]) ? get_option('dp_theme_options')[$id] : null,
	'section' => 'dp_header_area_media_section',
	'type' => 'text',
	'active_callback' => 'cb_header_content_type'
	)
));
/**
 * Video start time
 */
$id = 'dp_slider_video_start_time2';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'sanitize_callback' => 'absint',
	'type' => 'option',
	'transport' => 'refresh'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'before_text' => '<span class="description customize-control-description">'.__('Seek Time','DigiPress').'</span>',
	'unit' => __('Seconds after', 'DigiPress'),
	'section' => 'dp_header_area_media_section',
	'type' => 'number',
	'input_attrs' => array(
		'min' => 0, 'step' => 1, 'max' => 100000
	),
	'active_callback' => 'cb_header_content_type'
	)
));
/**
 * title
 */
$id = 'dp_slider_title2';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => '',
	'type' => 'option',
	'sanitize_callback' => 'dp_sanitize_html',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'description' => __('Slide title','DigiPress'),
	'section' => 'dp_header_area_media_section',
	'type' => 'text',
	'input_attrs' => array(
		'placeholder' => $def_options[$id]
		),
	'active_callback' => 'cb_header_content_type'
	)
));
// For Selective refresh
if (isset($wp_customize->selective_refresh)){
	$wp_customize->selective_refresh->add_partial('dp_theme_options['.$id.']', array(
		'selector' => '.sl-content.slc-2 .title',
		'settings' => 'dp_theme_options['.$id.']',
		'container_inclusive' => false,
		'render_callback' => function(){
			$options = get_option('dp_theme_options');
			echo $options['dp_slider_title2'];
		}
	));
}
/**
 * caption
 */
$id = 'dp_slider_caption2';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => '',
	'type' => 'option',
	'sanitize_callback' => 'dp_sanitize_html',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'description' => __('Slide caption','DigiPress'),
	'section' => 'dp_header_area_media_section',
	'type' => 'text',
	'input_attrs' => array(
		'placeholder' => $def_options[$id]
		),
	'active_callback' => 'cb_header_content_type'
	)
));
// For Selective refresh
if (isset($wp_customize->selective_refresh)){
	$wp_customize->selective_refresh->add_partial('dp_theme_options['.$id.']', array(
		'selector' => '.sl-content.slc-2 .caption',
		'settings' => 'dp_theme_options['.$id.']',
		'container_inclusive' => false,
		'render_callback' => function(){
			$options = get_option('dp_theme_options');
			echo $options['dp_slider_caption2'];
		}
	));
}

/**
 * button
 */
$id = 'dp_slider_button_text2';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => '',
	'type' => 'option',
	'sanitize_callback' => 'dp_sanitize_html',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'description' => __('Button text','DigiPress'),
	'section' => 'dp_header_area_media_section',
	'type' => 'text',
	'input_attrs' => array(
		'placeholder' => __('Click Here', 'DigiPress')
		),
	'active_callback' => 'cb_header_content_type'
	)
));
// For Selective refresh
if (isset($wp_customize->selective_refresh)){
	$wp_customize->selective_refresh->add_partial('dp_theme_options['.$id.']', array(
		'selector' => '.sl-content.slc-2 .btn_area .title_cap_btn',
		'settings' => 'dp_theme_options['.$id.']',
		'container_inclusive' => false,
		'render_callback' => function(){
			$options = get_option('dp_theme_options');
			echo $options['dp_slider_button_text2'];
		}
	));
}
$id = 'dp_slider_button_url2';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => '',
	'type' => 'option',
	'sanitize_callback' => 'esc_url_raw',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'description' => __('Button target URL','DigiPress'),
	'section' => 'dp_header_area_media_section',
	'type' => 'text',
	'input_attrs' => array(
		'placeholder' => 'https://example.com/target/',
	),
	'active_callback' => 'cb_header_content_type'
	)
));
// $id = 'dp_slider_button_color2';
// $wp_customize->add_setting(
// 	'dp_theme_options['.$id.']', array(
// 	'default' => $def_options[$id],
// 	'type' => 'option',
// 	'transport' => 'postMessage',
// 	'sanitize_callback' => 'sanitize_hex_color'
// ));
// $wp_customize->add_control( new WP_Customize_Color_Control(
// 	$wp_customize,
// 	'dp_theme_options['.$id.']', array(
// 	'settings' => 'dp_theme_options['.$id.']',
// 	'description' => __('Button Color','DigiPress'),
// 	'section' => 'dp_header_area_media_section',
// 	'active_callback' => 'cb_header_content_type'
// 	)
// ));

/**
 * Title position
 */
$id = 'dp_slider_title_pos2';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'description' => __('Title and caption position', 'DigiPress'),
	'section' => 'dp_header_area_media_section',
	'type' => 'select',
	'choices' => array(
		'center' => __('Display in center', 'DigiPress'),
		'left' => __('Display in left', 'DigiPress'),
		'right' => __('Display in right','DigiPress')
		),
	'separator' => true,
	'active_callback' => 'cb_header_content_type'
	)
));

// Slide 3
$id = 'dp_slider_background3';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'refresh'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'label' => sprintf(__('Slide %s Setting','DigiPress'), '3'),
	'description' => __('Slide media', 'DigiPress'),
	'section' => 'dp_header_area_media_section',
	'type' => 'select',
	'choices' => array(
		'none' => __('None','DigiPress'),
		'image' => __('Image', 'DigiPress'),
		'video' => __('Uploaded Video(MP4)','DigiPress'),
		'youtube' => __('YouTube video', 'DigiPress'),
		'vimeo' => __('Vimeo video', 'DigiPress')
		),
	'active_callback' => 'cb_header_content_type'
	)
));
$id = 'dp_slider_image3';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'sanitize_callback' => 'esc_url_raw',
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new WP_Customize_Image_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'description' => __('Slide image','DigiPress'),
	'section' => 'dp_header_area_media_section',
	'active_callback' => 'cb_header_content_type'
	)
));
$id = 'dp_slider_video3';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new WP_Customize_Media_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'description' => __('Slide video','DigiPress'),
	'section' => 'dp_header_area_media_section',
	'mime_type' => 'video',
	'button_labels'  => array(
		'select' => __( 'Select Video' ),
		'change' => __( 'Change Video' ),
		'placeholder' => __( 'No video selected' ),
		'frame_title' => __( 'Select Video' ),
		'frame_button' => __( 'Choose Video' ),
		),
	'active_callback' => 'cb_header_content_type'
	)
));
/**
 * YouTube / vimeo ID
 */
$id = 'dp_slider_youtube_vimeo_id3';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'description' => __('YouTube or Vimeo video ID','DigiPress'),
	'iframe_video' => isset(get_option('dp_theme_options')[$id]) ? get_option('dp_theme_options')[$id] : null,
	'section' => 'dp_header_area_media_section',
	'type' => 'text',
	'active_callback' => 'cb_header_content_type'
	)
));
/**
 * Video start time
 */
$id = 'dp_slider_video_start_time3';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'sanitize_callback' => 'absint',
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'before_text' => '<span class="description customize-control-description">'.__('Seek Time','DigiPress').'</span>',
	'unit' => __('Seconds after', 'DigiPress'),
	'section' => 'dp_header_area_media_section',
	'type' => 'number',
	'input_attrs' => array(
		'min' => 0, 'step' => 1, 'max' => 1000001
	),
	'active_callback' => 'cb_header_content_type'
	)
));
/**
 * title
 */
$id = 'dp_slider_title3';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => '',
	'type' => 'option',
	'sanitize_callback' => 'dp_sanitize_html',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'description' => __('Slide title','DigiPress'),
	'section' => 'dp_header_area_media_section',
	'type' => 'text',
	'input_attrs' => array(
		'placeholder' => $def_options[$id]
		),
	'active_callback' => 'cb_header_content_type'
	)
));
// For Selective refresh
if (isset($wp_customize->selective_refresh)){
	$wp_customize->selective_refresh->add_partial('dp_theme_options['.$id.']', array(
		'selector' => '.sl-content.slc-3 .title',
		'settings' => 'dp_theme_options['.$id.']',
		'container_inclusive' => false,
		'render_callback' => function(){
			$options = get_option('dp_theme_options');
			echo $options['dp_slider_title3'];
		}
	));
}
/**
 * caption
 */
$id = 'dp_slider_caption3';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => '',
	'type' => 'option',
	'sanitize_callback' => 'dp_sanitize_html',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'description' => __('Slide caption','DigiPress'),
	'section' => 'dp_header_area_media_section',
	'type' => 'text',
	'input_attrs' => array(
		'placeholder' => $def_options[$id]
		),
	'active_callback' => 'cb_header_content_type'
	)
));
// For Selective refresh
if (isset($wp_customize->selective_refresh)){
	$wp_customize->selective_refresh->add_partial('dp_theme_options['.$id.']', array(
		'selector' => '.sl-content.slc-3 .caption',
		'settings' => 'dp_theme_options['.$id.']',
		'container_inclusive' => false,
		'render_callback' => function(){
			$options = get_option('dp_theme_options');
			echo $options['dp_slider_caption3'];
		}
	));
}

/**
 * Button
 */
$id = 'dp_slider_button_text3';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => '',
	'type' => 'option',
	'sanitize_callback' => 'dp_sanitize_html',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'description' => __('Button text','DigiPress'),
	'section' => 'dp_header_area_media_section',
	'type' => 'text',
	'input_attrs' => array(
		'placeholder' => __('Click Here', 'DigiPress')
		),
	'active_callback' => 'cb_header_content_type'
	)
));
// For Selective refresh
if (isset($wp_customize->selective_refresh)){
	$wp_customize->selective_refresh->add_partial('dp_theme_options['.$id.']', array(
		'selector' => '.sl-content.slc-3 .btn_area .title_cap_btn',
		'settings' => 'dp_theme_options['.$id.']',
		'container_inclusive' => false,
		'render_callback' => function(){
			$options = get_option('dp_theme_options');
			echo $options['dp_slider_button_text3'];
		}
	));
}
$id = 'dp_slider_button_url3';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => '',
	'type' => 'option',
	'sanitize_callback' => 'esc_url_raw',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'description' => __('Button target URL','DigiPress'),
	'section' => 'dp_header_area_media_section',
	'type' => 'text',
	'input_attrs' => array(
		'placeholder' => 'https://example.com/target/',
	),
	'active_callback' => 'cb_header_content_type'
	)
));
// $id = 'dp_slider_button_color3';
// $wp_customize->add_setting(
// 	'dp_theme_options['.$id.']', array(
// 	'default' => $def_options[$id],
// 	'type' => 'option',
// 	'transport' => 'postMessage',
// 	'sanitize_callback' => 'sanitize_hex_color'
// ));
// $wp_customize->add_control( new WP_Customize_Color_Control(
// 	$wp_customize,
// 	'dp_theme_options['.$id.']', array(
// 	'settings' => 'dp_theme_options['.$id.']',
// 	'description' => __('Button Color','DigiPress'),
// 	'section' => 'dp_header_area_media_section',
// 	'active_callback' => 'cb_header_content_type'
// 	)
// ));

/**
 * Title position
 */
$id = 'dp_slider_title_pos3';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'description' => __('Title and caption position', 'DigiPress'),
	'section' => 'dp_header_area_media_section',
	'type' => 'select',
	'choices' => array(
		'center' => __('Display in center', 'DigiPress'),
		'left' => __('Display in left', 'DigiPress'),
		'right' => __('Display in right','DigiPress')
		),
	'separator' => true,
	'active_callback' => 'cb_header_content_type'
	)
));

// Slide 4
$id = 'dp_slider_background4';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'refresh'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'label' => sprintf(__('Slide %s Setting','DigiPress'), '4'),
	'description' => __('Slide media', 'DigiPress'),
	'section' => 'dp_header_area_media_section',
	'type' => 'select',
	'choices' => array(
		'none' => __('None','DigiPress'),
		'image' => __('Image', 'DigiPress'),
		'video' => __('Uploaded Video(MP4)','DigiPress'),
		'youtube' => __('YouTube video', 'DigiPress'),
		'vimeo' => __('Vimeo video', 'DigiPress')
		),
	'active_callback' => 'cb_header_content_type'
	)
));
$id = 'dp_slider_image4';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'sanitize_callback' => 'esc_url_raw',
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new WP_Customize_Image_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'description' => __('Slide image','DigiPress'),
	'section' => 'dp_header_area_media_section',
	'active_callback' => 'cb_header_content_type'
	)
));
$id = 'dp_slider_video4';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new WP_Customize_Media_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'description' => __('Slide video','DigiPress'),
	'section' => 'dp_header_area_media_section',
	'mime_type' => 'video',
	'button_labels'  => array(
		'select' => __( 'Select Video' ),
		'change' => __( 'Change Video' ),
		'placeholder' => __( 'No video selected' ),
		'frame_title' => __( 'Select Video' ),
		'frame_button' => __( 'Choose Video' ),
		),
	'active_callback' => 'cb_header_content_type'
	)
));
/**
 * YouTube / vimeo ID
 */
$id = 'dp_slider_youtube_vimeo_id4';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'description' => __('YouTube or Vimeo video ID','DigiPress'),
	'iframe_video' => isset(get_option('dp_theme_options')[$id]) ? get_option('dp_theme_options')[$id] : null,
	'section' => 'dp_header_area_media_section',
	'type' => 'text',
	'active_callback' => 'cb_header_content_type'
	)
));
/**
 * Video start time
 */
$id = 'dp_slider_video_start_time4';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'sanitize_callback' => 'absint',
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'before_text' => '<span class="description customize-control-description">'.__('Seek Time','DigiPress').'</span>',
	'unit' => __('Seconds after', 'DigiPress'),
	'section' => 'dp_header_area_media_section',
	'type' => 'number',
	'input_attrs' => array(
		'min' => 0, 'step' => 1, 'max' => 100000
	),
	'active_callback' => 'cb_header_content_type'
	)
));
/**
 * title
 */
$id = 'dp_slider_title4';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => '',
	'type' => 'option',
	'sanitize_callback' => 'dp_sanitize_html',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'description' => __('Slide title','DigiPress'),
	'section' => 'dp_header_area_media_section',
	'type' => 'text',
	'input_attrs' => array(
		'placeholder' => $def_options[$id]
		),
	'active_callback' => 'cb_header_content_type'
	)
));
// For Selective refresh
if (isset($wp_customize->selective_refresh)){
	$wp_customize->selective_refresh->add_partial('dp_theme_options['.$id.']', array(
		'selector' => '.sl-content.slc-4 .title',
		'settings' => 'dp_theme_options['.$id.']',
		'container_inclusive' => false,
		'render_callback' => function(){
			$options = get_option('dp_theme_options');
			echo $options['dp_slider_title4'];
		}
	));
}
/**
 * caption
 */
$id = 'dp_slider_caption4';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => '',
	'type' => 'option',
	'sanitize_callback' => 'dp_sanitize_html',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'description' => __('Slide caption','DigiPress'),
	'section' => 'dp_header_area_media_section',
	'type' => 'text',
	'input_attrs' => array(
		'placeholder' => $def_options[$id]
		),
	'active_callback' => 'cb_header_content_type'
	)
));
// For Selective refresh
if (isset($wp_customize->selective_refresh)){
	$wp_customize->selective_refresh->add_partial('dp_theme_options['.$id.']', array(
		'selector' => '.sl-content.slc-4 .caption',
		'settings' => 'dp_theme_options['.$id.']',
		'container_inclusive' => false,
		'render_callback' => function(){
			$options = get_option('dp_theme_options');
			echo $options['dp_slider_caption4'];
		}
	));
}

/**
 * button
 */
$id = 'dp_slider_button_text4';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => '',
	'type' => 'option',
	'sanitize_callback' => 'dp_sanitize_html',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'description' => __('Button text','DigiPress'),
	'section' => 'dp_header_area_media_section',
	'type' => 'text',
	'input_attrs' => array(
		'placeholder' => __('Click Here', 'DigiPress')
		),
	'active_callback' => 'cb_header_content_type'
	)
));
// For Selective refresh
if (isset($wp_customize->selective_refresh)){
	$wp_customize->selective_refresh->add_partial('dp_theme_options['.$id.']', array(
		'selector' => '.sl-content.slc-4 .btn_area .title_cap_btn',
		'settings' => 'dp_theme_options['.$id.']',
		'container_inclusive' => false,
		'render_callback' => function(){
			$options = get_option('dp_theme_options');
			echo $options['dp_slider_button_text4'];
		}
	));
}
$id = 'dp_slider_button_url4';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => '',
	'type' => 'option',
	'sanitize_callback' => 'esc_url_raw',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'description' => __('Button target URL','DigiPress'),
	'section' => 'dp_header_area_media_section',
	'type' => 'text',
	'input_attrs' => array(
		'placeholder' => 'https://example.com/target/',
	),
	'active_callback' => 'cb_header_content_type'
	)
));
// $id = 'dp_slider_button_color4';
// $wp_customize->add_setting(
// 	'dp_theme_options['.$id.']', array(
// 	'default' => $def_options[$id],
// 	'type' => 'option',
// 	'transport' => 'postMessage',
// 	'sanitize_callback' => 'sanitize_hex_color'
// ));
// $wp_customize->add_control( new WP_Customize_Color_Control(
// 	$wp_customize,
// 	'dp_theme_options['.$id.']', array(
// 	'settings' => 'dp_theme_options['.$id.']',
// 	'description' => __('Button Color','DigiPress'),
// 	'section' => 'dp_header_area_media_section',
// 	'active_callback' => 'cb_header_content_type'
// 	)
// ));

/**
 * Title position
 */
$id = 'dp_slider_title_pos4';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'description' => __('Title and caption position', 'DigiPress'),
	'section' => 'dp_header_area_media_section',
	'type' => 'select',
	'choices' => array(
		'center' => __('Display in center', 'DigiPress'),
		'left' => __('Display in left', 'DigiPress'),
		'right' => __('Display in right','DigiPress')
		),
	'separator' => true,
	'active_callback' => 'cb_header_content_type'
	)
));

// Slide 5
$id = 'dp_slider_background5';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'refresh'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'label' => sprintf(__('Slide %s Setting','DigiPress'), '5'),
	'description' => __('Slide media', 'DigiPress'),
	'section' => 'dp_header_area_media_section',
	'type' => 'select',
	'choices' => array(
		'none' => __('None','DigiPress'),
		'image' => __('Image', 'DigiPress'),
		'video' => __('Uploaded Video(MP4)','DigiPress'),
		'youtube' => __('YouTube video', 'DigiPress'),
		'vimeo' => __('Vimeo video', 'DigiPress')
		),
	'active_callback' => 'cb_header_content_type'
	)
));
$id = 'dp_slider_image5';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'sanitize_callback' => 'esc_url_raw',
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new WP_Customize_Image_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'description' => __('Slide image','DigiPress'),
	'section' => 'dp_header_area_media_section',
	'active_callback' => 'cb_header_content_type'
	)
));
$id = 'dp_slider_video5';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new WP_Customize_Media_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'description' => __('Slide video','DigiPress'),
	'section' => 'dp_header_area_media_section',
	'mime_type' => 'video',
	'button_labels'  => array(
		'select' => __( 'Select Video' ),
		'change' => __( 'Change Video' ),
		'placeholder' => __( 'No video selected' ),
		'frame_title' => __( 'Select Video' ),
		'frame_button' => __( 'Choose Video' ),
		),
	'active_callback' => 'cb_header_content_type'
	)
));
/**
 * YouTube / vimeo ID
 */
$id = 'dp_slider_youtube_vimeo_id5';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'description' => __('YouTube or Vimeo video ID','DigiPress'),
	'iframe_video' => isset(get_option('dp_theme_options')[$id]) ? get_option('dp_theme_options')[$id] : null,
	'section' => 'dp_header_area_media_section',
	'type' => 'text',
	'active_callback' => 'cb_header_content_type'
	)
));
/**
 * Video start time
 */
$id = 'dp_slider_video_start_time5';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'sanitize_callback' => 'absint',
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'before_text' => '<span class="description customize-control-description">'.__('Seek Time','DigiPress').'</span>',
	'unit' => __('Seconds after', 'DigiPress'),
	'section' => 'dp_header_area_media_section',
	'type' => 'number',
	'input_attrs' => array(
		'min' => 0, 'step' => 1, 'max' => 100000
	),
	'active_callback' => 'cb_header_content_type'
	)
));
/**
 * title
 */
$id = 'dp_slider_title5';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => '',
	'type' => 'option',
	'sanitize_callback' => 'dp_sanitize_html',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'description' => __('Slide title','DigiPress'),
	'section' => 'dp_header_area_media_section',
	'type' => 'text',
	'input_attrs' => array(
		'placeholder' => $def_options[$id]
		),
	'active_callback' => 'cb_header_content_type'
	)
));
// For Selective refresh
if (isset($wp_customize->selective_refresh)){
	$wp_customize->selective_refresh->add_partial('dp_theme_options['.$id.']', array(
		'selector' => '.sl-content.slc-5 .title',
		'settings' => 'dp_theme_options['.$id.']',
		'container_inclusive' => false,
		'render_callback' => function(){
			$options = get_option('dp_theme_options');
			echo $options['dp_slider_title5'];
		}
	));
}
/**
 * caption
 */
$id = 'dp_slider_caption5';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => '',
	'type' => 'option',
	'sanitize_callback' => 'dp_sanitize_html',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'description' => __('Slide caption','DigiPress'),
	'section' => 'dp_header_area_media_section',
	'type' => 'text',
	'input_attrs' => array(
		'placeholder' => $def_options[$id]
		),
	'active_callback' => 'cb_header_content_type'
	)
));
// For Selective refresh
if (isset($wp_customize->selective_refresh)){
	$wp_customize->selective_refresh->add_partial('dp_theme_options['.$id.']', array(
		'selector' => '.sl-content.slc-5 .caption',
		'settings' => 'dp_theme_options['.$id.']',
		'container_inclusive' => false,
		'render_callback' => function(){
			$options = get_option('dp_theme_options');
			echo $options['dp_slider_caption5'];
		}
	));
}

/**
 * Button
 */
$id = 'dp_slider_button_text5';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => '',
	'type' => 'option',
	'sanitize_callback' => 'dp_sanitize_html',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'description' => __('Button text','DigiPress'),
	'section' => 'dp_header_area_media_section',
	'type' => 'text',
	'input_attrs' => array(
		'placeholder' => __('Click Here', 'DigiPress')
		),
	'active_callback' => 'cb_header_content_type'
	)
));
// For Selective refresh
if (isset($wp_customize->selective_refresh)){
	$wp_customize->selective_refresh->add_partial('dp_theme_options['.$id.']', array(
		'selector' => '.sl-content.slc-5 .btn_area .title_cap_btn',
		'settings' => 'dp_theme_options['.$id.']',
		'container_inclusive' => false,
		'render_callback' => function(){
			$options = get_option('dp_theme_options');
			echo $options['dp_slider_button_text5'];
		}
	));
}
$id = 'dp_slider_button_url5';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => '',
	'type' => 'option',
	'sanitize_callback' => 'esc_url_raw',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'description' => __('Button target URL','DigiPress'),
	'section' => 'dp_header_area_media_section',
	'type' => 'text',
	'input_attrs' => array(
		'placeholder' => 'https://example.com/target/',
	),
	'active_callback' => 'cb_header_content_type'
	)
));
// $id = 'dp_slider_button_color5';
// $wp_customize->add_setting(
// 	'dp_theme_options['.$id.']', array(
// 	'default' => $def_options[$id],
// 	'type' => 'option',
// 	'transport' => 'postMessage',
// 	'sanitize_callback' => 'sanitize_hex_color'
// ));
// $wp_customize->add_control( new WP_Customize_Color_Control(
// 	$wp_customize,
// 	'dp_theme_options['.$id.']', array(
// 	'settings' => 'dp_theme_options['.$id.']',
// 	'description' => __('Button Color','DigiPress'),
// 	'section' => 'dp_header_area_media_section',
// 	'active_callback' => 'cb_header_content_type'
// 	)
// ));

/**
 * Title position
 */
$id = 'dp_slider_title_pos5';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'description' => __('Title and caption position', 'DigiPress'),
	'section' => 'dp_header_area_media_section',
	'type' => 'select',
	'choices' => array(
		'center' => __('Display in center', 'DigiPress'),
		'left' => __('Display in left', 'DigiPress'),
		'right' => __('Display in right','DigiPress')
		),
	'separator' => true,
	'active_callback' => 'cb_header_content_type'
	)
));

// Slide 6
$id = 'dp_slider_background6';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'refresh'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'label' => sprintf(__('Slide %s Setting','DigiPress'), '6'),
	'description' => __('Slide media', 'DigiPress'),
	'section' => 'dp_header_area_media_section',
	'type' => 'select',
	'choices' => array(
		'none' => __('None','DigiPress'),
		'image' => __('Image', 'DigiPress'),
		'video' => __('Uploaded Video(MP4)','DigiPress'),
		'youtube' => __('YouTube video', 'DigiPress'),
		'vimeo' => __('Vimeo video', 'DigiPress')
		),
	'active_callback' => 'cb_header_content_type'
	)
));
$id = 'dp_slider_image6';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'sanitize_callback' => 'esc_url_raw',
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new WP_Customize_Image_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'description' => __('Slide image','DigiPress'),
	'section' => 'dp_header_area_media_section',
	'active_callback' => 'cb_header_content_type'
	)
));
$id = 'dp_slider_video6';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new WP_Customize_Media_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'description' => __('Slide video','DigiPress'),
	'section' => 'dp_header_area_media_section',
	'mime_type' => 'video',
	'button_labels'  => array(
		'select' => __( 'Select Video' ),
		'change' => __( 'Change Video' ),
		'placeholder' => __( 'No video selected' ),
		'frame_title' => __( 'Select Video' ),
		'frame_button' => __( 'Choose Video' ),
		),
	'active_callback' => 'cb_header_content_type'
	)
));
/**
 * YouTube / vimeo ID
 */
$id = 'dp_slider_youtube_vimeo_id6';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'description' => __('YouTube or Vimeo video ID','DigiPress'),
	'iframe_video' => isset(get_option('dp_theme_options')[$id]) ? get_option('dp_theme_options')[$id] : null,
	'section' => 'dp_header_area_media_section',
	'type' => 'text',
	'active_callback' => 'cb_header_content_type'
	)
));
/**
 * Video start time
 */
$id = 'dp_slider_video_start_time6';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'sanitize_callback' => 'absint',
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'before_text' => '<span class="description customize-control-description">'.__('Seek Time','DigiPress').'</span>',
	'unit' => __('Seconds after', 'DigiPress'),
	'section' => 'dp_header_area_media_section',
	'type' => 'number',
	'input_attrs' => array(
		'min' => 0, 'step' => 1, 'max' => 100000
	),
	'active_callback' => 'cb_header_content_type'
	)
));
/**
 * title
 */
$id = 'dp_slider_title6';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => '',
	'type' => 'option',
	'sanitize_callback' => 'dp_sanitize_html',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'description' => __('Slide title','DigiPress'),
	'section' => 'dp_header_area_media_section',
	'type' => 'text',
	'input_attrs' => array(
		'placeholder' => $def_options[$id]
		),
	'active_callback' => 'cb_header_content_type'
	)
));
// For Selective refresh
if (isset($wp_customize->selective_refresh)){
	$wp_customize->selective_refresh->add_partial('dp_theme_options['.$id.']', array(
		'selector' => '.sl-content.slc-6 .title',
		'settings' => 'dp_theme_options['.$id.']',
		'container_inclusive' => false,
		'render_callback' => function(){
			$options = get_option('dp_theme_options');
			echo $options['dp_slider_title6'];
		}
	));
}
/**
 * caption
 */
$id = 'dp_slider_caption6';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => '',
	'type' => 'option',
	'sanitize_callback' => 'dp_sanitize_html',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'description' => __('Slide caption','DigiPress'),
	'section' => 'dp_header_area_media_section',
	'type' => 'text',
	'input_attrs' => array(
		'placeholder' => $def_options[$id]
		),
	'active_callback' => 'cb_header_content_type'
	)
));
// For Selective refresh
if (isset($wp_customize->selective_refresh)){
	$wp_customize->selective_refresh->add_partial('dp_theme_options['.$id.']', array(
		'selector' => '.sl-content.slc-6 .caption',
		'settings' => 'dp_theme_options['.$id.']',
		'container_inclusive' => false,
		'render_callback' => function(){
			$options = get_option('dp_theme_options');
			echo $options['dp_slider_caption6'];
		}
	));
}

/**
 * Button
 */
$id = 'dp_slider_button_text6';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => '',
	'type' => 'option',
	'sanitize_callback' => 'dp_sanitize_html',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'description' => __('Button text','DigiPress'),
	'section' => 'dp_header_area_media_section',
	'type' => 'text',
	'input_attrs' => array(
		'placeholder' => __('Click Here', 'DigiPress')
		),
	'active_callback' => 'cb_header_content_type'
	)
));
// For Selective refresh
if (isset($wp_customize->selective_refresh)){
	$wp_customize->selective_refresh->add_partial('dp_theme_options['.$id.']', array(
		'selector' => '.sl-content.slc-6 .btn_area .title_cap_btn',
		'settings' => 'dp_theme_options['.$id.']',
		'container_inclusive' => false,
		'render_callback' => function(){
			$options = get_option('dp_theme_options');
			echo $options['dp_slider_button_text6'];
		}
	));
}
$id = 'dp_slider_button_url6';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => '',
	'type' => 'option',
	'sanitize_callback' => 'esc_url_raw',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'description' => __('Button target URL','DigiPress'),
	'section' => 'dp_header_area_media_section',
	'type' => 'text',
	'input_attrs' => array(
		'placeholder' => 'https://example.com/target/',
	),
	'active_callback' => 'cb_header_content_type'
	)
));
// $id = 'dp_slider_button_color6';
// $wp_customize->add_setting(
// 	'dp_theme_options['.$id.']', array(
// 	'default' => $def_options[$id],
// 	'type' => 'option',
// 	'transport' => 'postMessage',
// 	'sanitize_callback' => 'sanitize_hex_color'
// ));
// $wp_customize->add_control( new WP_Customize_Color_Control(
// 	$wp_customize,
// 	'dp_theme_options['.$id.']', array(
// 	'settings' => 'dp_theme_options['.$id.']',
// 	'description' => __('Button Color','DigiPress'),
// 	'section' => 'dp_header_area_media_section',
// 	'active_callback' => 'cb_header_content_type'
// 	)
// ));

/**
 * Title position
 */
$id = 'dp_slider_title_pos6';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'description' => __('Title and caption position', 'DigiPress'),
	'section' => 'dp_header_area_media_section',
	'type' => 'select',
	'choices' => array(
		'center' => __('Display in center', 'DigiPress'),
		'left' => __('Display in left', 'DigiPress'),
		'right' => __('Display in right','DigiPress')
		),
	'separator' => true,
	'active_callback' => 'cb_header_content_type'
	)
));


// Slide 7
$id = 'dp_slider_background7';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'refresh'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'label' => sprintf(__('Slide %s Setting','DigiPress'), '7'),
	'description' => __('Slide media', 'DigiPress'),
	'section' => 'dp_header_area_media_section',
	'type' => 'select',
	'choices' => array(
		'none' => __('None','DigiPress'),
		'image' => __('Image', 'DigiPress'),
		'video' => __('Uploaded Video(MP4)','DigiPress'),
		'youtube' => __('YouTube video', 'DigiPress'),
		'vimeo' => __('Vimeo video', 'DigiPress')
		),
	'active_callback' => 'cb_header_content_type'
	)
));
$id = 'dp_slider_image7';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'sanitize_callback' => 'esc_url_raw',
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new WP_Customize_Image_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'description' => __('Slide image','DigiPress'),
	'section' => 'dp_header_area_media_section',
	'active_callback' => 'cb_header_content_type'
	)
));
$id = 'dp_slider_video7';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new WP_Customize_Media_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'description' => __('Slide video','DigiPress'),
	'section' => 'dp_header_area_media_section',
	'mime_type' => 'video',
	'button_labels'  => array(
		'select' => __( 'Select Video' ),
		'change' => __( 'Change Video' ),
		'placeholder' => __( 'No video selected' ),
		'frame_title' => __( 'Select Video' ),
		'frame_button' => __( 'Choose Video' ),
		),
	'active_callback' => 'cb_header_content_type'
	)
));
/**
 * YouTube / vimeo ID
 */
$id = 'dp_slider_youtube_vimeo_id7';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'description' => __('YouTube or Vimeo video ID','DigiPress'),
	'iframe_video' => isset(get_option('dp_theme_options')[$id]) ? get_option('dp_theme_options')[$id] : null,
	'section' => 'dp_header_area_media_section',
	'type' => 'text',
	'active_callback' => 'cb_header_content_type'
	)
));
/**
 * Video start time
 */
$id = 'dp_slider_video_start_time7';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'sanitize_callback' => 'absint',
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'before_text' => '<span class="description customize-control-description">'.__('Seek Time','DigiPress').'</span>',
	'unit' => __('Seconds after', 'DigiPress'),
	'section' => 'dp_header_area_media_section',
	'type' => 'number',
	'input_attrs' => array(
		'min' => 0, 'step' => 1, 'max' => 100000
	),
	'active_callback' => 'cb_header_content_type'
	)
));
/**
 * title
 */
$id = 'dp_slider_title7';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => '',
	'type' => 'option',
	'sanitize_callback' => 'dp_sanitize_html',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'description' => __('Slide title','DigiPress'),
	'section' => 'dp_header_area_media_section',
	'type' => 'text',
	'input_attrs' => array(
		'placeholder' => $def_options[$id]
		),
	'active_callback' => 'cb_header_content_type'
	)
));
// For Selective refresh
if (isset($wp_customize->selective_refresh)){
	$wp_customize->selective_refresh->add_partial('dp_theme_options['.$id.']', array(
		'selector' => '.sl-content.slc-7 .title',
		'settings' => 'dp_theme_options['.$id.']',
		'container_inclusive' => false,
		'render_callback' => function(){
			$options = get_option('dp_theme_options');
			echo $options['dp_slider_title7'];
		}
	));
}
/**
 * caption
 */
$id = 'dp_slider_caption7';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => '',
	'type' => 'option',
	'sanitize_callback' => 'dp_sanitize_html',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'description' => __('Slide caption','DigiPress'),
	'section' => 'dp_header_area_media_section',
	'type' => 'text',
	'input_attrs' => array(
		'placeholder' => $def_options[$id]
		),
	'active_callback' => 'cb_header_content_type'
	)
));
// For Selective refresh
if (isset($wp_customize->selective_refresh)){
	$wp_customize->selective_refresh->add_partial('dp_theme_options['.$id.']', array(
		'selector' => '.sl-content.slc-7 .caption',
		'settings' => 'dp_theme_options['.$id.']',
		'container_inclusive' => false,
		'render_callback' => function(){
			$options = get_option('dp_theme_options');
			echo $options['dp_slider_caption7'];
		}
	));
}

/**
 * Button
 */
$id = 'dp_slider_button_text7';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => '',
	'type' => 'option',
	'sanitize_callback' => 'dp_sanitize_html',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'description' => __('Button text','DigiPress'),
	'section' => 'dp_header_area_media_section',
	'type' => 'text',
	'input_attrs' => array(
		'placeholder' => __('Click Here', 'DigiPress')
		),
	'active_callback' => 'cb_header_content_type'
	)
));
// For Selective refresh
if (isset($wp_customize->selective_refresh)){
	$wp_customize->selective_refresh->add_partial('dp_theme_options['.$id.']', array(
		'selector' => '.sl-content.slc-7 .btn_area .title_cap_btn',
		'settings' => 'dp_theme_options['.$id.']',
		'container_inclusive' => false,
		'render_callback' => function(){
			$options = get_option('dp_theme_options');
			echo $options['dp_slider_button_text7'];
		}
	));
}
$id = 'dp_slider_button_url7';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => '',
	'type' => 'option',
	'sanitize_callback' => 'esc_url_raw',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'description' => __('Button target URL','DigiPress'),
	'section' => 'dp_header_area_media_section',
	'type' => 'text',
	'input_attrs' => array(
		'placeholder' => 'https://example.com/target/',
	),
	'active_callback' => 'cb_header_content_type'
	)
));
// $id = 'dp_slider_button_color7';
// $wp_customize->add_setting(
// 	'dp_theme_options['.$id.']', array(
// 	'default' => $def_options[$id],
// 	'type' => 'option',
// 	'transport' => 'postMessage',
// 	'sanitize_callback' => 'sanitize_hex_color'
// ));
// $wp_customize->add_control( new WP_Customize_Color_Control(
// 	$wp_customize,
// 	'dp_theme_options['.$id.']', array(
// 	'settings' => 'dp_theme_options['.$id.']',
// 	'description' => __('Button Color','DigiPress'),
// 	'section' => 'dp_header_area_media_section',
// 	'active_callback' => 'cb_header_content_type'
// 	)
// ));

/**
 * Title position
 */
$id = 'dp_slider_title_pos7';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'description' => __('Title and caption position', 'DigiPress'),
	'section' => 'dp_header_area_media_section',
	'type' => 'select',
	'choices' => array(
		'center' => __('Display in center', 'DigiPress'),
		'left' => __('Display in left', 'DigiPress'),
		'right' => __('Display in right','DigiPress')
		),
	'separator' => true,
	'active_callback' => 'cb_header_content_type'
	)
));


// Slide 8
$id = 'dp_slider_background8';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'refresh'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'label' => sprintf(__('Slide %s Setting','DigiPress'), '8'),
	'description' => __('Slide media', 'DigiPress'),
	'section' => 'dp_header_area_media_section',
	'type' => 'select',
	'choices' => array(
		'none' => __('None','DigiPress'),
		'image' => __('Image', 'DigiPress'),
		'video' => __('Uploaded Video(MP4)','DigiPress'),
		'youtube' => __('YouTube video', 'DigiPress'),
		'vimeo' => __('Vimeo video', 'DigiPress')
		),
	'active_callback' => 'cb_header_content_type'
	)
));
$id = 'dp_slider_image8';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'sanitize_callback' => 'esc_url_raw',
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new WP_Customize_Image_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'description' => __('Slide image','DigiPress'),
	'section' => 'dp_header_area_media_section',
	'active_callback' => 'cb_header_content_type'
	)
));
$id = 'dp_slider_video8';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new WP_Customize_Media_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'description' => __('Slide video','DigiPress'),
	'section' => 'dp_header_area_media_section',
	'mime_type' => 'video',
	'button_labels'  => array(
		'select' => __( 'Select Video' ),
		'change' => __( 'Change Video' ),
		'placeholder' => __( 'No video selected' ),
		'frame_title' => __( 'Select Video' ),
		'frame_button' => __( 'Choose Video' ),
		),
	'active_callback' => 'cb_header_content_type'
	)
));
/**
 * YouTube / vimeo ID
 */
$id = 'dp_slider_youtube_vimeo_id8';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'description' => __('YouTube or Vimeo video ID','DigiPress'),
	'iframe_video' => isset(get_option('dp_theme_options')[$id]) ? get_option('dp_theme_options')[$id] : null,
	'section' => 'dp_header_area_media_section',
	'type' => 'text',
	'active_callback' => 'cb_header_content_type'
	)
));
/**
 * Video start time
 */
$id = 'dp_slider_video_start_time8';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'sanitize_callback' => 'absint',
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'before_text' => '<span class="description customize-control-description">'.__('Seek Time','DigiPress').'</span>',
	'unit' => __('Seconds after', 'DigiPress'),
	'section' => 'dp_header_area_media_section',
	'type' => 'number',
	'input_attrs' => array(
		'min' => 0, 'step' => 1, 'max' => 100000
	),
	'active_callback' => 'cb_header_content_type'
	)
));
/**
 * title
 */
$id = 'dp_slider_title8';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => '',
	'type' => 'option',
	'sanitize_callback' => 'dp_sanitize_html',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'description' => __('Slide title','DigiPress'),
	'section' => 'dp_header_area_media_section',
	'type' => 'text',
	'input_attrs' => array(
		'placeholder' => $def_options[$id]
		),
	'active_callback' => 'cb_header_content_type'
	)
));
// For Selective refresh
if (isset($wp_customize->selective_refresh)){
	$wp_customize->selective_refresh->add_partial('dp_theme_options['.$id.']', array(
		'selector' => '.sl-content.slc-8 .title',
		'settings' => 'dp_theme_options['.$id.']',
		'container_inclusive' => false,
		'render_callback' => function(){
			$options = get_option('dp_theme_options');
			echo $options['dp_slider_title8'];
		}
	));
}
/**
 * caption
 */
$id = 'dp_slider_caption8';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => '',
	'type' => 'option',
	'sanitize_callback' => 'dp_sanitize_html',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'description' => __('Slide caption','DigiPress'),
	'section' => 'dp_header_area_media_section',
	'type' => 'text',
	'input_attrs' => array(
		'placeholder' => $def_options[$id]
		),
	'active_callback' => 'cb_header_content_type'
	)
));
// For Selective refresh
if (isset($wp_customize->selective_refresh)){
	$wp_customize->selective_refresh->add_partial('dp_theme_options['.$id.']', array(
		'selector' => '.sl-content.slc-8 .caption',
		'settings' => 'dp_theme_options['.$id.']',
		'container_inclusive' => false,
		'render_callback' => function(){
			$options = get_option('dp_theme_options');
			echo $options['dp_slider_caption8'];
		}
	));
}

/**
 * Button
 */
$id = 'dp_slider_button_text8';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => '',
	'type' => 'option',
	'sanitize_callback' => 'dp_sanitize_html',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'description' => __('Button text','DigiPress'),
	'section' => 'dp_header_area_media_section',
	'type' => 'text',
	'input_attrs' => array(
		'placeholder' => __('Click Here', 'DigiPress')
		),
	'active_callback' => 'cb_header_content_type'
	)
));
// For Selective refresh
if (isset($wp_customize->selective_refresh)){
	$wp_customize->selective_refresh->add_partial('dp_theme_options['.$id.']', array(
		'selector' => '.sl-content.slc-8 .btn_area .title_cap_btn',
		'settings' => 'dp_theme_options['.$id.']',
		'container_inclusive' => false,
		'render_callback' => function(){
			$options = get_option('dp_theme_options');
			echo $options['dp_slider_button_text8'];
		}
	));
}
$id = 'dp_slider_button_url8';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => '',
	'type' => 'option',
	'sanitize_callback' => 'esc_url_raw',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'description' => __('Button target URL','DigiPress'),
	'section' => 'dp_header_area_media_section',
	'type' => 'text',
	'input_attrs' => array(
		'placeholder' => 'https://example.com/target/',
	),
	'active_callback' => 'cb_header_content_type'
	)
));
// $id = 'dp_slider_button_color8';
// $wp_customize->add_setting(
// 	'dp_theme_options['.$id.']', array(
// 	'default' => $def_options[$id],
// 	'type' => 'option',
// 	'transport' => 'postMessage',
// 	'sanitize_callback' => 'sanitize_hex_color'
// ));
// $wp_customize->add_control( new WP_Customize_Color_Control(
// 	$wp_customize,
// 	'dp_theme_options['.$id.']', array(
// 	'settings' => 'dp_theme_options['.$id.']',
// 	'description' => __('Button Color','DigiPress'),
// 	'section' => 'dp_header_area_media_section',
// 	'active_callback' => 'cb_header_content_type'
// 	)
// ));

/**
 * Title position
 */
$id = 'dp_slider_title_pos8';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'description' => __('Title and caption position', 'DigiPress'),
	'section' => 'dp_header_area_media_section',
	'type' => 'select',
	'choices' => array(
		'center' => __('Display in center', 'DigiPress'),
		'left' => __('Display in left', 'DigiPress'),
		'right' => __('Display in right','DigiPress')
		),
	'separator' => true,
	'active_callback' => 'cb_header_content_type'
	)
));





function cb_header_content_type($control){
	$control_id = $control->id;
	$content_type = $control->manager->get_setting('dp_theme_options[dp_header_content_type]')->value();
	$slider_style = $control->manager->get_setting('dp_theme_options[dp_slider_style]')->value();
	$slider_only_one_title = $control->manager->get_setting('dp_theme_options[dp_slider_only_one_title]')->value();
	$layer_mask_pattern = $control->manager->get_setting('dp_theme_options[dp_header_area_mask_pattern]')->value();
	$slide1_bg_type = $control->manager->get_setting('dp_theme_options[dp_slider_background1]')->value();
	$slide2_bg_type = $control->manager->get_setting('dp_theme_options[dp_slider_background2]')->value();
	$slide3_bg_type = $control->manager->get_setting('dp_theme_options[dp_slider_background3]')->value();
	$slide4_bg_type = $control->manager->get_setting('dp_theme_options[dp_slider_background4]')->value();
	$slide5_bg_type = $control->manager->get_setting('dp_theme_options[dp_slider_background5]')->value();
	$slide6_bg_type = $control->manager->get_setting('dp_theme_options[dp_slider_background6]')->value();
	$slide7_bg_type = $control->manager->get_setting('dp_theme_options[dp_slider_background7]')->value();
	$slide8_bg_type = $control->manager->get_setting('dp_theme_options[dp_slider_background8]')->value();
	$edge_top = $control->manager->get_setting('dp_theme_options[dp_header_area_top_edge]')->value();
	$edge_bottom = $control->manager->get_setting('dp_theme_options[dp_header_area_bottom_edge]')->value();

	if ( ($control_id === 'dp_theme_options[dp_header_img]'
			|| $control_id === 'dp_theme_options[header_img_title]'
			|| $control_id === 'dp_theme_options[header_img_caption]'
			|| $control_id === 'dp_theme_options[header_img_text_animate]'
			|| $control_id === 'dp_theme_options[header_text_vertically]'
			|| $control_id === 'dp_theme_options[header_title_pos]')
		&& $content_type === 'image') return true;

	if ( ($control_id === 'dp_theme_options[dp_number_of_slideshow]'
			|| $control_id === 'dp_theme_options[dp_slider_post_or_page]'
			|| $control_id === 'dp_theme_options[dp_slider_order]')
		&& $content_type === 'slideshow') return true;

	if ( ($control_id === 'dp_theme_options[dp_slider_style]'
			|| $control_id === 'dp_theme_options[dp_slider_show_time]'
			|| $control_id === 'dp_theme_options[dp_slider_disable_autoplay]'
			|| $control_id === 'dp_theme_options[dp_slider_transition_time]'
			|| $control_id === 'dp_theme_options[dp_slider_nav_button]'
			|| $control_id === 'dp_theme_options[dp_slider_control_button]')
		&& ($content_type === 'slideshow' || $content_type === 'slideshow_selected_media') ) return true;

	// Accept parallax transition( Horizontal or vertical slider )
	if ( $control_id === 'dp_theme_options[dp_slider_parallax_transition]'
		&& $content_type !== 'image' && $content_type !== 'none' && ($slider_style === 'horizontal' || $slider_style === 'vertical' || $slider_style === 'thumb' || strpos($slider_style, 'center') !== false ) ) return true;

	// Accept common title and caption ( Fade, horizontal, vertical, split, coverflow #1 with selected media )
	if ( $control_id === 'dp_theme_options[dp_slider_only_one_title]'
		&& ( $slider_style === 'fade' || $slider_style === 'horizontal' || $slider_style === 'vertical' || $slider_style === 'split' || $slider_style === 'coverflow one' || strpos( $slider_style, 'creative' ) !== false )
		&& $content_type === 'slideshow_selected_media' ) return true;

	if ( ( $control_id === 'dp_theme_options[header_img_title]'
			|| $control_id === 'dp_theme_options[header_img_caption]'
			|| $control_id === 'dp_theme_options[header_img_text_animate]'
			|| $control_id === 'dp_theme_options[header_title_pos]' )
		&& $content_type === 'slideshow_selected_media'
		&& ( $slider_style === 'fade' || $slider_style === 'horizontal' || $slider_style === 'vertical' || $slider_style === 'split' || $slider_style === 'coverflow one' || strpos( $slider_style, 'creative' ) !== false )
		&& $slider_only_one_title ) return true;

	// Vertical writing mode
	if ( $control_id === 'dp_theme_options[header_text_vertically]'
		&& $content_type === 'slideshow_selected_media'
		&& ( $slider_style !== 'carousel' && $slider_style !== 'center five' && $slider_style !== 'coverflow five' ) ) return true;

	if ( ( $control_id === 'dp_theme_options[dp_header_area_top_edge]' || $control_id === 'dp_theme_options[dp_header_area_bottom_edge]' ) && $content_type === 'image' ) return true;


	if ( ( $control_id === 'dp_theme_options[dp_header_area_top_edge]' || $control_id === 'dp_theme_options[dp_header_area_bottom_edge]' || $control_id === 'dp_theme_options[dp_header_area_edge_piled_layer]' )
		&& ( $content_type === 'slideshow' || $content_type === 'slideshow_selected_media' ) ) {

		if ( $slider_style === 'fade' || $slider_style === 'horizontal' || $slider_style === 'vertical' || $slider_style === 'split' || $slider_style === 'center three' || $slider_style === 'center five' || $slider_style === 'thumb' || strpos( $slider_style, 'creative' ) !== false ) {

			if ( $control_id === 'dp_theme_options[dp_header_area_edge_piled_layer]' ) {
				if ( $edge_top === 'wave1' || $edge_top === 'wave2' || $edge_top === 'curve1' || $edge_top === 'curve2' || $edge_bottom === 'wave1' || $edge_bottom === 'wave2' || $edge_bottom === 'curve1' || $edge_bottom === 'curve2' ) {
					return true;
				}
			} else {
				return true;
			}
		}
	}

	if ( $control_id === 'dp_theme_options[dp_header_area_show_bgimg]' && $content_type !== 'none' ) {
		if ( $content_type === 'image' ) {
			return true;
		} else {
			if ( $slider_style === 'fade' || $slider_style === 'horizontal' || $slider_style === 'vertical' || $slider_style === 'carousel' || $slider_style === 'center three' || $slider_style === 'center five' ){
				return true;
			}
		}
	}

	if ( ($control_id === 'dp_theme_options[header_banner_text_color]'
			|| $control_id === 'dp_theme_options[header_banner_text_shadow_enable]'
			|| $control_id === 'dp_theme_options[header_banner_text_shadow_color]'
			|| $control_id === 'dp_theme_options[header_banner_overlay_color]'
			|| $control_id === 'dp_theme_options[header_banner_overlay_opacity]'
			|| $control_id === 'dp_theme_options[dp_header_area_mask_pattern]'
			|| $control_id === 'dp_theme_options[dp_header_area_mask_opacity]'
		)
		&& $content_type !== 'none' ) return true;

	if ( ( $control_id === 'dp_theme_options[dp_header_area_mask_line_thickness]' || $control_id === 'dp_theme_options[dp_header_area_mask_line_spacing]' )
			&& ( strpos($layer_mask_pattern, 'stripe') !== false || strpos($layer_mask_pattern, 'border') !== false ) 
			&& $content_type !== 'none' ) {
		return true;
	}

	if ( $control_id === 'dp_theme_options[dp_header_area_mask_line_thickness]' && strpos($layer_mask_pattern, 'mesh') !== false && $content_type !== 'none' ) {
		return true;
	}

	if ( $control_id === 'dp_theme_options[dp_slider_background1]' && $content_type === 'slideshow_selected_media') return true;
	if ( $control_id === 'dp_theme_options[dp_slider_image1]' && $content_type === 'slideshow_selected_media' && $slide1_bg_type === 'image') return true;
	if ( $control_id === 'dp_theme_options[dp_slider_video1]' && $content_type === 'slideshow_selected_media' && $slide1_bg_type === 'video') return true;
	if ( ($control_id === 'dp_theme_options[dp_slider_youtube_vimeo_id1]' || $control_id === 'dp_theme_options[dp_slider_video_start_time1]') && $content_type === 'slideshow_selected_media' && ($slide1_bg_type === 'youtube' || $slide1_bg_type === 'vimeo') ) return true;


	if ( $control_id === 'dp_theme_options[dp_slider_background2]' && $content_type === 'slideshow_selected_media') return true;
	if ( $control_id === 'dp_theme_options[dp_slider_image2]' && $content_type === 'slideshow_selected_media' && $slide2_bg_type === 'image') return true;
	if ( $control_id === 'dp_theme_options[dp_slider_video2]' && $content_type === 'slideshow_selected_media' && $slide2_bg_type === 'video') return true;
	if ( ($control_id === 'dp_theme_options[dp_slider_youtube_vimeo_id2]' || $control_id === 'dp_theme_options[dp_slider_video_start_time2]') && $content_type === 'slideshow_selected_media' && ($slide2_bg_type === 'youtube' || $slide2_bg_type === 'vimeo') ) return true;

	if ( $control_id === 'dp_theme_options[dp_slider_background3]' && $content_type === 'slideshow_selected_media') return true;
	if ( $control_id === 'dp_theme_options[dp_slider_image3]' && $content_type === 'slideshow_selected_media' && $slide3_bg_type === 'image') return true;
	if ( $control_id === 'dp_theme_options[dp_slider_video3]' && $content_type === 'slideshow_selected_media' && $slide3_bg_type === 'video') return true;
	if ( ($control_id === 'dp_theme_options[dp_slider_youtube_vimeo_id3]' || $control_id === 'dp_theme_options[dp_slider_video_start_time3]') && $content_type === 'slideshow_selected_media' && ($slide3_bg_type === 'youtube' || $slide3_bg_type === 'vimeo') ) return true;

	if ( $control_id === 'dp_theme_options[dp_slider_background4]' && $content_type === 'slideshow_selected_media') return true;
	if ( $control_id === 'dp_theme_options[dp_slider_image4]' && $content_type === 'slideshow_selected_media' && $slide4_bg_type === 'image') return true;
	if ( $control_id === 'dp_theme_options[dp_slider_video4]' && $content_type === 'slideshow_selected_media' && $slide4_bg_type === 'video') return true;
	if ( ($control_id === 'dp_theme_options[dp_slider_youtube_vimeo_id4]' || $control_id === 'dp_theme_options[dp_slider_video_start_time4]') && $content_type === 'slideshow_selected_media' && ($slide4_bg_type === 'youtube' || $slide4_bg_type === 'vimeo') ) return true;

	if ( $control_id === 'dp_theme_options[dp_slider_background5]' && $content_type === 'slideshow_selected_media') return true;
	if ( $control_id === 'dp_theme_options[dp_slider_image5]' && $content_type === 'slideshow_selected_media' && $slide5_bg_type === 'image') return true;
	if ( $control_id === 'dp_theme_options[dp_slider_video5]' && $content_type === 'slideshow_selected_media' && $slide5_bg_type === 'video') return true;
	if ( ($control_id === 'dp_theme_options[dp_slider_youtube_vimeo_id5]' || $control_id === 'dp_theme_options[dp_slider_video_start_time5]') && $content_type === 'slideshow_selected_media' && ($slide5_bg_type === 'youtube' || $slide5_bg_type === 'vimeo') ) return true;

	if ( $control_id === 'dp_theme_options[dp_slider_background6]' && $content_type === 'slideshow_selected_media') return true;
	if ( $control_id === 'dp_theme_options[dp_slider_image6]' && $content_type === 'slideshow_selected_media' && $slide6_bg_type === 'image') return true;
	if ( $control_id === 'dp_theme_options[dp_slider_video6]' && $content_type === 'slideshow_selected_media' && $slide6_bg_type === 'video') return true;
	if ( ($control_id === 'dp_theme_options[dp_slider_youtube_vimeo_id6]' || $control_id === 'dp_theme_options[dp_slider_video_start_time6]') && $content_type === 'slideshow_selected_media' && ($slide6_bg_type === 'youtube' || $slide6_bg_type === 'vimeo') ) return true;

	if ( $control_id === 'dp_theme_options[dp_slider_background7]' && $content_type === 'slideshow_selected_media') return true;
	if ( $control_id === 'dp_theme_options[dp_slider_image7]' && $content_type === 'slideshow_selected_media' && $slide7_bg_type === 'image') return true;
	if ( $control_id === 'dp_theme_options[dp_slider_video7]' && $content_type === 'slideshow_selected_media' && $slide7_bg_type === 'video') return true;
	if ( ($control_id === 'dp_theme_options[dp_slider_youtube_vimeo_id7]' || $control_id === 'dp_theme_options[dp_slider_video_start_time7]') && $content_type === 'slideshow_selected_media' && ($slide7_bg_type === 'youtube' || $slide7_bg_type === 'vimeo') ) return true;

	if ( $control_id === 'dp_theme_options[dp_slider_background8]' && $content_type === 'slideshow_selected_media') return true;
	if ( $control_id === 'dp_theme_options[dp_slider_image8]' && $content_type === 'slideshow_selected_media' && $slide8_bg_type === 'image') return true;
	if ( $control_id === 'dp_theme_options[dp_slider_video8]' && $content_type === 'slideshow_selected_media' && $slide8_bg_type === 'video') return true;
	if ( ($control_id === 'dp_theme_options[dp_slider_youtube_vimeo_id8]' || $control_id === 'dp_theme_options[dp_slider_video_start_time8]') && $content_type === 'slideshow_selected_media' && ($slide8_bg_type === 'youtube' || $slide8_bg_type === 'vimeo') ) return true;

	if ( ($control_id === 'dp_theme_options[dp_slider_title1]'
			|| $control_id === 'dp_theme_options[dp_slider_title2]'
			|| $control_id === 'dp_theme_options[dp_slider_title3]'
			|| $control_id === 'dp_theme_options[dp_slider_title4]'
			|| $control_id === 'dp_theme_options[dp_slider_title5]'
			|| $control_id === 'dp_theme_options[dp_slider_title6]'
			|| $control_id === 'dp_theme_options[dp_slider_title7]'
			|| $control_id === 'dp_theme_options[dp_slider_title8]'
			|| $control_id === 'dp_theme_options[dp_slider_caption1]'
			|| $control_id === 'dp_theme_options[dp_slider_caption2]'
			|| $control_id === 'dp_theme_options[dp_slider_caption3]'
			|| $control_id === 'dp_theme_options[dp_slider_caption4]'
			|| $control_id === 'dp_theme_options[dp_slider_caption5]'
			|| $control_id === 'dp_theme_options[dp_slider_caption6]'
			|| $control_id === 'dp_theme_options[dp_slider_caption7]'
			|| $control_id === 'dp_theme_options[dp_slider_caption8]'
			|| $control_id === 'dp_theme_options[dp_slider_button_text1]'
			|| $control_id === 'dp_theme_options[dp_slider_button_text2]'
			|| $control_id === 'dp_theme_options[dp_slider_button_text3]'
			|| $control_id === 'dp_theme_options[dp_slider_button_text4]'
			|| $control_id === 'dp_theme_options[dp_slider_button_text5]'
			|| $control_id === 'dp_theme_options[dp_slider_button_text6]'
			|| $control_id === 'dp_theme_options[dp_slider_button_text7]'
			|| $control_id === 'dp_theme_options[dp_slider_button_text8]'
			|| $control_id === 'dp_theme_options[dp_slider_button_url1]'
			|| $control_id === 'dp_theme_options[dp_slider_button_url2]'
			|| $control_id === 'dp_theme_options[dp_slider_button_url3]'
			|| $control_id === 'dp_theme_options[dp_slider_button_url4]'
			|| $control_id === 'dp_theme_options[dp_slider_button_url5]'
			|| $control_id === 'dp_theme_options[dp_slider_button_url6]'
			|| $control_id === 'dp_theme_options[dp_slider_button_url7]'
			|| $control_id === 'dp_theme_options[dp_slider_button_url8]'
			// || $control_id === 'dp_theme_options[dp_slider_button_color1]'
			// || $control_id === 'dp_theme_options[dp_slider_button_color2]'
			// || $control_id === 'dp_theme_options[dp_slider_button_color3]'
			// || $control_id === 'dp_theme_options[dp_slider_button_color4]'
			// || $control_id === 'dp_theme_options[dp_slider_button_color5]'
			// || $control_id === 'dp_theme_options[dp_slider_button_color6]'
			// || $control_id === 'dp_theme_options[dp_slider_button_color7]'
			// || $control_id === 'dp_theme_options[dp_slider_button_color8]'
			|| $control_id === 'dp_theme_options[dp_slider_title_pos1]'
			|| $control_id === 'dp_theme_options[dp_slider_title_pos2]'
			|| $control_id === 'dp_theme_options[dp_slider_title_pos3]'
			|| $control_id === 'dp_theme_options[dp_slider_title_pos4]'
			|| $control_id === 'dp_theme_options[dp_slider_title_pos5]'
			|| $control_id === 'dp_theme_options[dp_slider_title_pos6]'
			|| $control_id === 'dp_theme_options[dp_slider_title_pos7]'
			|| $control_id === 'dp_theme_options[dp_slider_title_pos8]'
		)
		&& $content_type === 'slideshow_selected_media' ) {
			if ( ! ( ( $slider_style === 'fade' || $slider_style === 'horizontal' || $slider_style === 'vertical' || $slider_style === 'split' ) && $slider_only_one_title) ) {
				return true;
			}
		}

	return false;
}



/**
 * Dummy navigate
 */
$wp_customize->add_setting(
	'dummy_field_hd_padding', array(
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dummy_field_hd_padding', array(
	'section' => 'dp_header_area_in_archive_single_section',
	'type' => 'text'
	)
));
// For Selective refresh
if (isset($wp_customize->selective_refresh)){
	$wp_customize->selective_refresh->add_partial('dummy_field_hd_padding', array(
		'selector' => '#ct-hd'
	));
}

/**
 * Top padding size
 */
$id = '';
$wp_customize->add_setting(
	'dp_theme_options[dp_page_header_padding_top]', array(
	'default' => $def_options['dp_page_header_padding_top'],
	'sanitize_callback' => 'absint',
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options[dp_page_header_padding_top]', array(
	'settings' => 'dp_theme_options[dp_page_header_padding_top]',
	'fake_title' => __('Header Margin (PC)','DigiPress'),
	'before_text' => '<div>'.__('Top margin','DigiPress').' :</div>',
	'unit' => __('%', 'DigiPress'),
	'section' => 'dp_header_area_in_archive_single_section',
	'type' => 'number',
	'input_attrs' => array(
		'min' => 1, 'step' => 1, 'max' => 100
		)
	)
));
/**
 * Bottom padding size
 */
$id = '';
$wp_customize->add_setting(
	'dp_theme_options[dp_page_header_padding_bottom]', array(
	'default' => $def_options['dp_page_header_padding_bottom'],
	'sanitize_callback' => 'absint',
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options[dp_page_header_padding_bottom]', array(
	'settings' => 'dp_theme_options[dp_page_header_padding_bottom]',
	'before_text' => '<div>'.__('Bottom margin','DigiPress').' :</div>',
	'unit' => __('%', 'DigiPress'),
	'section' => 'dp_header_area_in_archive_single_section',
	'type' => 'number',
	'input_attrs' => array(
		'min' => 1, 'step' => 1, 'max' => 100
		)
	)
));
/**
 * Top padding size on mobile
 */
$id = '';
$wp_customize->add_setting(
	'dp_theme_options[dp_page_header_padding_top_mb]', array(
	'default' => $def_options['dp_page_header_padding_top_mb'],
	'sanitize_callback' => 'absint',
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options[dp_page_header_padding_top_mb]', array(
	'settings' => 'dp_theme_options[dp_page_header_padding_top_mb]',
	'fake_title' => __('Header Margin (Mobile)','DigiPress'),
	'before_text' => '<div>'.__('Top margin','DigiPress').' :</div>',
	'unit' => __('%', 'DigiPress'),
	'section' => 'dp_header_area_in_archive_single_section',
	'type' => 'number',
	'input_attrs' => array(
		'min' => 1, 'step' => 1, 'max' => 100
		)
	)
));
/**
 * Bottom padding size on mobile
 */
$id = 'dp_page_header_padding_bottom_mb';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'sanitize_callback' => 'absint',
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'before_text' => '<div>'.__('Bottom margin','DigiPress').' :</div>',
	'unit' => __('%', 'DigiPress'),
	'section' => 'dp_header_area_in_archive_single_section',
	'type' => 'number',
	'input_attrs' => array(
		'min' => 1, 'step' => 1, 'max' => 100
		)
	)
));


/**
 * Content header color setting
 */
$id = 'page_header_text_color';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'sanitize_callback' => 'sanitize_hex_color',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new WP_Customize_Color_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'label' => __('Font color / Text shadow','DigiPress'),
	'description' => __('Font / link color','DigiPress'),
	'section' => 'dp_header_area_in_archive_single_section'
	)
));
/**
 * Text shadow
 */
$id = 'page_header_text_shadow_enable';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'label' => __('Enable text shadow','DigiPress'),
	'section' => 'dp_header_area_in_archive_single_section',
	'type' => 'checkbox'
	)
));
/**
 * Text shadow
 */
$id = 'page_header_text_shadow_color';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'sanitize_callback' => 'sanitize_hex_color',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new WP_Customize_Color_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'description' => __('Text shadow color','DigiPress'),
	'section' => 'dp_header_area_in_archive_single_section'
	)
));

/**
 * Overlay in header area(no background image)
 */
$id = 'page_header_bgcolor_overlay';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'fake_title' => __('Background Overlay Setting','DigiPress'),
	'before_text' => __('Overlay effect (Filled color)','DigiPress'),
	'section' => 'dp_header_area_in_archive_single_section',
	'type' => 'select',
	'choices' => array(
		'none' => __('Primary Color', 'DigiPress'),
		'primary_gradient' => __('Primary color gradient','DigiPress'),
		'primary_secondary_gradient' => __('Primary / secondary color gradient','DigiPress'),
		'term_color' => __('Image color (Category, tag)','DigiPress'),
		'term_color_gradient' => __('Image color / primary color gradient','DigiPress'),
		)
	)
));

/**
 * Overlay in header area(show background image)
 */
$id = 'page_header_bgimg_overlay';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'before_text' => __('Overlay effect (Background image)','DigiPress'),
	'section' => 'dp_header_area_in_archive_single_section',
	'note' => __('*Header area in archive and single page is filled by primary color or category color. This option is for overlay color in header area as color layer.', 'DigiPress'),
	'type' => 'select',
	'choices' => array(
		'none' => __('None','DigiPress'),
		'primary_gradient' => __('Primary color gradient','DigiPress'),
		'primary_secondary_gradient' => __('Primary / secondary color gradient','DigiPress'),
		'term_color' => __('Image color (Category, tag)','DigiPress'),
		'darken' => __('Darken the background image','DigiPress')
		)
	)
));

/**
 * Blur
 */
$id = 'page_header_bgimg_blur';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'sanitize_callback' => 'absint',
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'before_text' => __('Blur degree','DigiPress').' : ',
	'unit' => __('px', 'DigiPress'),
	'note' => __('*When the background image is displayed in the header area, you can specify the degree of blur.', 'DigiPress'),
	'section' => 'dp_header_area_in_archive_single_section',
	'type' => 'number',
	'input_attrs' => array(
		'min' => 0, 'step' => 1, 'max' => 100
		)
	)
));


/**
 * Layer Mask setting
 */
$id = 'page_header_bgimg_mask_pattern';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'description' => __('Layer mask pattern','DigiPress'),
	'note' => __('*When the background image is displayed in the header area, the layer mask can be displayed.', 'DigiPress'),
	'section' => 'dp_header_area_in_archive_single_section',
	'type' => 'select',
	'choices' => array(
		'none' => __('None', 'DigiPress'),
		'dot1' => __('Dot patern', 'DigiPress') . ' ' . __('(Black)', 'DigiPress'),
		'dot1w' => __('Dot patern', 'DigiPress') . ' ' . __('(White)', 'DigiPress'),
		'dot2' => __('Tiny dot pattern', 'DigiPress') . ' ' . __('(Black)', 'DigiPress'),
		'dot2w' => __('Tiny dot pattern', 'DigiPress') . ' ' . __('(White)', 'DigiPress'),
		'stripe1' => sprintf( __('Stripe%s pattern', 'DigiPress'), '') . ' ' . __('(Black)', 'DigiPress'),
		'stripe1w' => sprintf( __('Stripe%s pattern', 'DigiPress'), '') . ' ' . __('(White)', 'DigiPress'),
		'stripe2' => sprintf( __('Stripe%s pattern', 'DigiPress'), __(' rotated 45 degree', 'DigiPress') ) . ' 2 ' . __('(Black)', 'DigiPress'),
		'stripe2w' => sprintf( __('Stripe%s pattern', 'DigiPress'), __(' rotated 45 degree', 'DigiPress') ) . ' 2 ' . __('(White)', 'DigiPress'),
		'border' => __('Border pattern', 'DigiPress') . ' ' . __('(Black)', 'DigiPress'),
		'borderw' => __('Border pattern', 'DigiPress') . ' ' . __('(White)', 'DigiPress'),
		'mesh' => __('Mesh pattern','DigiPress') . ' ' . __('(Black)', 'DigiPress'),
		'meshw' => __('Mesh pattern','DigiPress') . ' ' . __('(White)', 'DigiPress')
		),
	)
));
/**
 * Layer Mask opacity
 */
$id = 'page_header_bgimg_mask_opacity';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'sanitize_callback' => 'absint',
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Range_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'before_text' => __('Layer mask opacity','DigiPress'),
	'section' => 'dp_header_area_in_archive_single_section',
	'unit' => '%',
	'type' => 'custom_range',
	'input_attrs' => array(
		'min' => 0,
		'max' => 100,
		'step' => 1
		),
	)
));
/**
 * Layer Mask line thickness
 */
$id = 'page_header_bgimg_mask_line_thickness';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'sanitize_callback' => 'absint',
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'description' => __('Line thickness','DigiPress'),
	'unit' => __('pixel','DigiPress'),
	'section' => 'dp_header_area_in_archive_single_section',
	'type' => 'number',
	'input_attrs' => array('min' => 1,'max' => 100,'step' => 1),
	'active_callback' => 'cb_page_header_overlay',
	)
));
/**
 * Layer Mask line thickness
 */
$id = 'page_header_bgimg_mask_line_spacing';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'sanitize_callback' => 'absint',
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'description' => __('Line spacing','DigiPress'),
	'unit' => __('pixel','DigiPress'),
	'section' => 'dp_header_area_in_archive_single_section',
	'type' => 'number',
	'input_attrs' => array('min' => 1,'max' => 100,'step' => 1),
	'active_callback' => 'cb_page_header_overlay',
	)
));

/**
 * Callback for page header overlay
 */
function cb_page_header_overlay($control){
	$control_id = $control->id;
	$layer_mask_pattern = $control->manager->get_setting('dp_theme_options[dp_header_area_mask_pattern]')->value();

	if ( ( $control_id === 'dp_theme_options[page_header_bgimg_mask_line_thickness]' || $control_id === 'dp_theme_options[page_header_bgimg_mask_line_spacing]' )
			&& ( strpos($layer_mask_pattern, 'stripe') !== false || strpos($layer_mask_pattern, 'border') !== false || strpos($layer_mask_pattern, 'mesh') !== false ) ) {
		return true;
	}

	return false;
}


/**
 * Bottom edge
 */
$id = 'page_header_bottom_edge';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'refresh'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'label' => __('Header Area Bottom Edge Shape','DigiPress'),
	'section' => 'dp_header_area_in_archive_single_section',
	'type' => 'select',
	'choices' => array(
		'none' => __('None', 'DigiPress'),
		'mountain' => __('Mountain shape', 'DigiPress'),
		'vline' => __('V line', 'DigiPress'),
		'wline' => __('W line', 'DigiPress'),
		'mline' => __('M line', 'DigiPress'),
		'up_right' => __('Diagonally right', 'DigiPress'),
		'up_left' => __('Diagonally left','DigiPress'),
		'wave1' => __('Wave shape','DigiPress'),
		'wave2' => __('Wave shape','DigiPress') .' (' . __('Flip horizontal','DigiPress') . ')',
		'curve1' => __('Curve shape','DigiPress'),
		'curve2' => __('Curve shape','DigiPress') .' (' . __('Flip vertical','DigiPress') . ')',
		'saw1' => __('Saw wave','DigiPress'),
		'saw2' => __('Saw wave','DigiPress') .' (' . __('Flip horizontal','DigiPress') . ')'
		)
	)
));
/**
 * Bottom edge piled layer
 */
$id = 'page_header_bottom_edge_piled_layer';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'label' => __('Enable piled layer','DigiPress'),
	'note' => __('*Check this option to show the edge with piled layer. This is for wave or curve edge only.','DigiPress'),
	'description' => '',
	'section' => 'dp_header_area_in_archive_single_section',
	'type' => 'checkbox',
	'active_callback' => 'cb_page_header_bottom_edge',
	)
));

/**
 * Callback for page header overlay
 */
function cb_page_header_bottom_edge($control){
	$control_id = $control->id;
	$edge = $control->manager->get_setting('dp_theme_options[page_header_bottom_edge]')->value();

	if ( ( $edge === 'wave1' || $edge === 'wave2' || $edge === 'curve1' || $edge === 'curve2' ) && $control_id === 'dp_theme_options[page_header_bottom_edge_piled_layer]' ) {
		return true;
	}

	return false;
}