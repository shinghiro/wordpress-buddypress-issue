<?php
// **********************************************
// Mobile theme section
// **********************************************
$wp_customize->add_panel( 'dp_mobile_theme_panel', array(
	'priority' => 6,
	'title' => __('Mobile Theme Settings', 'DigiPress'),
	'description' => __('Customize the mobile operation system.', 'DigiPress')
));
$wp_customize->add_section(
	'dp_mobile_theme_general_settings_section', array(
	'title' => __('Site General Settings', 'DigiPress'),
	'description' => __('General settings for mobile theme.', 'DigiPress'),
	'panel' => 'dp_mobile_theme_panel'
));
// Acceleration setting
$wp_customize->add_section(
	'dp_mobile_acceleration_section', array(
	'title' => __('Acceleration Setting', 'DigiPress'),
	'description' => __('Settings for web acceleration.', 'DigiPress'),
	'panel' => 'dp_mobile_theme_panel',
));
// Header bar section
$wp_customize->add_section(
	'dp_mobile_theme_header_bar_section', array(
	'title' => __('Header Bar Area Settings', 'DigiPress'),
	'description' => __('Settings for the header bar area in mobile theme.', 'DigiPress'),
	'panel' => 'dp_mobile_theme_panel'
));
// Header image / slider section
$wp_customize->add_section(
	'dp_mobile_theme_header_area_section', array(
	'title' => __('Header Image / Slider', 'DigiPress'),
	'description' => sprintf( __('Customize the header image or slider in top page header. %s', 'DigiPress'), '<br />' . __( 'This option is for mobile theme.', 'DigiPress') ),
	'panel' => 'dp_mobile_theme_panel'
));
// footer bar section
$wp_customize->add_section(
	'dp_mobile_theme_footer_bar_section', array(
	'title' => __('Footer Bar Area Setting', 'DigiPress'),
	'description' => __('Settings for the footer bar area in mobile theme.', 'DigiPress'),
	'panel' => 'dp_mobile_theme_panel'
));



/**
 * Mobile theme options
 */
$id = 'disable_mobile_theme';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'label' => __('Disable mobile theme (Responsive only)','DigiPress'),
	'separator' => true,
	'section' => 'dp_mobile_theme_general_settings_section',
	'type' => 'checkbox'
	)
));

/**
 * Disable wow in mobile
 */
$id = 'disable_wow_js_mobile';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'fake_title' => __('Standardization', 'DigiPress'),
	'label' => __('Disable scroll fadein animation','DigiPress'),
	'note' => __('*Disable fadein animation width titles and articles by page scrolling.','DigiPress'),
	'section' => 'dp_mobile_theme_general_settings_section',
	'type' => 'checkbox',
	'active_callback' => 'cb_use_mobile_theme'
	)
));

/**
 * Callback
 */
function cb_use_mobile_theme($control){
	$disable_mobile_theme = $control->manager->get_setting('dp_theme_options[disable_mobile_theme]')->value();
	if ( $disable_mobile_theme) return false;
	return true;
}


/**
 * Disable Barba.js(PJAX)
 */
$id = 'disable_pjax_mobile';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'label' => __('Disable ajax page loading','DigiPress'),
	'note' => __('*Disable smooth asynchronous page transition by ajax.','DigiPress').'<br />'.__('*If you enable this option, the page transition effect will also be disabled.','DigiPress'),
	'section' => 'dp_mobile_acceleration_section',
	'type' => 'checkbox',
	'active_callback' => 'cb_use_mobile_theme'
	)
));
/**
 * Disable pjax page transition effect
 */
$id = 'disable_pjax_transition_mobile';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'label' => __('Disable page transition effect in ajax loading','DigiPress'),
	'note' => __('*Disable the transition effect on asynchronous page transition by ajax.','DigiPress').'<br />'.__('*If you enable this option, the page transition time is the fastest.','DigiPress'),
	'section' => 'dp_mobile_acceleration_section',
	'type' => 'checkbox',
	'active_callback' => 'cb_use_mobile_theme'
	)
));

/**
 * Header bar float
 */
$id = 'header_bar_pos_fixed_mobile';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'label' => __('Header bar fixed at top','DigiPress'),
	'note' => __('*Check this if you want the header bar to remain at the top even when scrolling.','DigiPress'),
	'section' => 'dp_mobile_theme_header_bar_section',
	'type' => 'checkbox',
	)
));


/**
 * Choices for header media type
 */
$id = 'dp_header_content_type_mobile';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'label' => __('Header Content Type','DigiPress'),
	'description' => __('*Choose header area content.','DigiPress'),
	'section' => 'dp_mobile_theme_header_area_section',
	'separator' => true,
	'type' => 'select',
	'choices' => array(
		'none' => __('Display nothing', 'DigiPress'),
		'image' => __('Header image','DigiPress'),
		'slideshow_selected_media' => __('Slider (Image)','DigiPress'),
		'slideshow' => __('Slider (Post/page)','DigiPress')
		)
	)
));
/**
 * Header image
 */
$id = 'dp_header_img_mobile';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new WP_Customize_Image_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'label' => __('Header Image','DigiPress'),
	'section' => 'dp_mobile_theme_header_area_section',
	'active_callback' => 'cb_header_content_type_mobile'
	)
));
/**
 * Header image title
 */
$id = 'header_img_title_mobile';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'sanitize_callback' => 'dp_sanitize_html',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'label' => __('Header Image Title and Caption','DigiPress'),
	'description' => __('Title', 'DigiPress'),
	'section' => 'dp_mobile_theme_header_area_section',
	'type' => 'text',
	'active_callback' => 'cb_header_content_type_mobile'
	)
));
/**
 * Header title caption
 */
$id = 'header_img_caption_mobile';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'sanitize_callback' => 'dp_sanitize_html',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'description' => __('Caption','DigiPress'),
	'note' => __('*You can use HTML.', 'DigiPress').__('However, if text reveal animation is enabled, it will not be reflected.', 'DigiPress'),
	'section' => 'dp_mobile_theme_header_area_section',
	'type' => 'textarea',
	'active_callback' => 'cb_header_content_type_mobile'
	)
));

// enable animation reveal
$id = 'header_img_text_animate_mobile';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'label' => __('Enable title reveal animation','DigiPress'),
	'section' => 'dp_mobile_theme_header_area_section',
	'type' => 'checkbox',
	'active_callback' => 'cb_header_content_type_mobile'
	)
));

// Vertical text
$id = 'header_text_vertically_mobile';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'label' => __('Display text vertically','DigiPress'),
	'note' => __('*If the title or caption contains a large number of characters, adjust the height by inserting line breaks with an appropriate number of characters.', 'DigiPress'),
	'section' => 'dp_mobile_theme_header_area_section',
	'type' => 'checkbox',
	'active_callback' => 'cb_header_content_type_mobile'
	)
));

/**
 * Slideshow settings
 */
$id = 'dp_slider_post_or_page_mobile';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'label' => __('Slider Target','DigiPress'),
	'section' => 'dp_mobile_theme_header_area_section',
	'note' => __('*You need check the post to include as header slider item in each post option.','DigiPress'),
	'type' => 'radio',
	'choices' => array(
		'post' => __('Selected posts','DigiPress'),
		'page' => __('Selected static pages','DigiPress')
		),
	'active_callback' => 'cb_header_content_type_mobile'
	)
));
/**
 * Number of slide
 */
$id = 'dp_number_of_slideshow_mobile';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'label' => __('Number of Slide','DigiPress'),
	'unit' => __('Slides', 'DigiPress'),
	'section' => 'dp_mobile_theme_header_area_section',
	'type' => 'number',
	'input_attrs' => array(
		'min' => 1, 'step' => 1, 'max' => 30
	),
	'active_callback' => 'cb_header_content_type_mobile'
	)
));
/**
 * Slideshow order
 */
$id = 'dp_slider_order_mobile';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'label' => __('Slider Order','DigiPress'),
	'section' => 'dp_mobile_theme_header_area_section',
	'type' => 'select',
	'choices' => array(
		'date' => __('Order by posted date', 'DigiPress'),
		'rand' => __('Random','DigiPress'),
		'comment_count' => __('Order by comment count','DigiPress'),
		'title' => __('Order post title','DigiPress')
		),
	'active_callback' => 'cb_header_content_type_mobile'
	)
));
/**
 * Slideshow Effect
 */
$id = 'dp_slider_style_mobile';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'label' => __('Slider Style','DigiPress'),
	'section' => 'dp_mobile_theme_header_area_section',
	'type' => 'select',
	'choices' => array(
		'fade' => __('Fade in/out', 'DigiPress'),
		'horizontal' => __('Horizontal slider', 'DigiPress'),
		'vertical' => __('Vertical slider', 'DigiPress'),
		'coverflow one' => sprintf(__('3D coverflow(%s slides)','DigiPress'), '1'),
		'creative one' => __( 'Slice', 'DigiPress' ),
		'creative two' => __( 'Shifting slider', 'DigiPress' ),
		'creative three' => __( 'Horizontal rotation', 'DigiPress' ),
		'creative four' => '3D ' . __( 'Horizontal rotation', 'DigiPress' ),
		'creative five' => '3D ' . __( 'Vertical rotation', 'DigiPress' ),
		'creative six' => __( 'Central rotation', 'DigiPress' )
		),
	'active_callback' => 'cb_header_content_type_mobile'
	)
));

/**
 * Replace each title caption to static title and caption
 */
$id = 'dp_slider_only_one_title_mobile';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'label' => __('Display only one main title and caption','DigiPress'),
	'note' => __('*Check this to show static title and caption instead of each slide title and caption. If you check this option, each slide title and caption will be disabled.', 'DigiPress'),
	'section' => 'dp_mobile_theme_header_area_section',
	'type' => 'checkbox',
	'active_callback' => 'cb_header_content_type_mobile'
	)
));

/**
 * Enable parallax scroll transition
 */
$id = 'dp_slider_parallax_transition_mobile';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'fake_title' => __('Advanced Settings', 'DigiPress'),
	'label' => __('Enable parallax transition','DigiPress'),
	'note' => __('*If you check this option, video slides are disabled for autoplay.', 'DigiPress'),
	'section' => 'dp_mobile_theme_header_area_section',
	'type' => 'checkbox',
	'active_callback' => 'cb_header_content_type_mobile'
	)
));

/**
 * Slider bottom edge
 */
$id = 'dp_header_area_bottom_edge_mobile';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'label' => __('Header Area Bottom Edge Shape','DigiPress'),
	'section' => 'dp_mobile_theme_header_area_section',
	'type' => 'select',
	'choices' => array(
		'none' => __('None', 'DigiPress'),
		'mountain' => __('Mountain shape', 'DigiPress'),
		'vline' => __('V line', 'DigiPress'),
		'wline' => __('W line', 'DigiPress'),
		'mline' => __('M line', 'DigiPress'),
		'up_right' => __('Diagonally right', 'DigiPress'),
		'up_left' => __('Diagonally left','DigiPress'),
		'wave1' => __('Wave shape','DigiPress'),
		'wave2' => __('Wave shape','DigiPress') .' (' . __('Flip horizontal','DigiPress') . ')',
		'curve1' => __('Curve shape','DigiPress'),
		'curve2' => __('Curve shape','DigiPress') .' (' . __('Flip vertical','DigiPress') . ')',
		'saw1' => __('Saw wave','DigiPress'),
		'saw2' => __('Saw wave','DigiPress') .' (' . __('Flip horizontal','DigiPress') . ')'
		),
	'active_callback' => 'cb_header_content_type_mobile'
	)
));

/**
 * Header area edge piled layer
 */
$id = 'dp_header_area_edge_piled_layer_mobile';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'label' => __('Enable piled layer','DigiPress'),
	'note' => __('*Check this option to show the edge with piled layer. This is for wave or curve edge only.','DigiPress'),
	'description' => '',
	'section' => 'dp_mobile_theme_header_area_section',
	'type' => 'checkbox',
	'active_callback' => 'cb_header_content_type_mobile',
	)
));


/**
 * Slide speed
 */
$id = 'dp_slider_show_time_mobile';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'label' => __('Auto Slide Time','DigiPress'),
	'unit' => __('mili second', 'DigiPress'),
	'section' => 'dp_mobile_theme_header_area_section',
	'type' => 'number',
	'input_attrs' => array(
		'min' => 100, 'step' => 1, 'max' => 100000
	),
	'active_callback' => 'cb_header_content_type_mobile'
	)
));
/**
 * Disable auto play
 */
$id = 'dp_slider_disable_autoplay_mobile';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'label' => __('Disable autoplay','DigiPress'),
	'section' => 'dp_mobile_theme_header_area_section',
	'type' => 'checkbox',
	'active_callback' => 'cb_header_content_type_mobile'
	)
));
/**
 * Transition time
 */
$id = 'dp_slider_transition_time_mobile';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'label' => __('Transition Time','DigiPress'),
	'unit' => __('mili second', 'DigiPress'),
	'section' => 'dp_mobile_theme_header_area_section',
	'type' => 'number',
	'input_attrs' => array(
		'min' => 100, 'step' => 1, 'max' => 100000
	),
	'active_callback' => 'cb_header_content_type_mobile'
	)
));

/**
 * Title and caption color
 */
$id = 'header_banner_text_color_mobile';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'sanitize_callback' => 'sanitize_hex_color',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new WP_Customize_Color_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'label' => __('Font color / Text shadow','DigiPress'),
	'description' => __('Font / link color','DigiPress'),
	'section' => 'dp_mobile_theme_header_area_section',
	'active_callback' => 'cb_header_content_type_mobile'
	)
));
/**
 * Title and caption text shadow
 */
$id = 'header_banner_text_shadow_enable_mobile';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'label' => __('Enable text shadow','DigiPress'),
	'section' => 'dp_mobile_theme_header_area_section',
	'type' => 'checkbox',
	'active_callback' => 'cb_header_content_type_mobile'
	)
));
$id = 'header_banner_text_shadow_color_mobile';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'sanitize_callback' => 'sanitize_hex_color',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new WP_Customize_Color_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'description' => __('Text shadow color','DigiPress'),
	'section' => 'dp_mobile_theme_header_area_section',
	'active_callback' => 'cb_header_content_type_mobile'
	)
));

/**
 * Color overlay
 */
$id = 'header_banner_overlay_color_mobile';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'sanitize_callback' => 'sanitize_hex_color',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new WP_Customize_Color_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'label' => __('Color Overlay Setting','DigiPress'),
	'description' => __('Overlay color','DigiPress'),
	'section' => 'dp_mobile_theme_header_area_section',
	'active_callback' => 'cb_header_content_type_mobile'
	)
));
$id = 'header_banner_overlay_opacity_mobile';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Range_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'before_text' => __('Overlay opacity','DigiPress'),
	'section' => 'dp_mobile_theme_header_area_section',
	'unit' => '%',
	'type' => 'custom_range',
	'input_attrs' => array(
		'min' => 0,
		'max' => 100,
		'step' => 1
		),
	'active_callback' => 'cb_header_content_type_mobile'
	)
));

/**
 * Selected slide images or video
 */
// Slide 1
$id = 'dp_slider_image1_mobile';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new WP_Customize_Image_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'label' => sprintf(__('Slide %s Setting','DigiPress'), '1'),
	'description' => __('Slide image','DigiPress'),
	'section' => 'dp_mobile_theme_header_area_section',
	'active_callback' => 'cb_header_content_type_mobile'
	)
));
/**
 * title 1
 */
$id = 'dp_slider_title1_mobile';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => '',
	'type' => 'option',
	'sanitize_callback' => 'dp_sanitize_html',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'description' => __('Slide title','DigiPress'),
	'section' => 'dp_mobile_theme_header_area_section',
	'type' => 'text',
	'input_attrs' => array(
		'placeholder' => $def_options[$id],
	),
	'active_callback' => 'cb_header_content_type_mobile'
	)
));
$id = 'dp_slider_caption1_mobile';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => '',
	'type' => 'option',
	'sanitize_callback' => 'dp_sanitize_html',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'description' => __('Slide caption','DigiPress'),
	'section' => 'dp_mobile_theme_header_area_section',
	'type' => 'text',
	'input_attrs' => array(
		'placeholder' => $def_options[$id],
	),
	'active_callback' => 'cb_header_content_type_mobile'
	)
));
$id = 'dp_slider_url1_mobile';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'sanitize_callback' => 'esc_url_raw',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'description' => __('URL to navigate','DigiPress'),
	'note' => __('*You can specify the URL to move when visitor clicks this slider.','DigiPress'),
	'section' => 'dp_mobile_theme_header_area_section',
	'type' => 'text',
	'input_attrs' => array(
		'placeholder' => 'https://example.com/target/',
	),
	'active_callback' => 'cb_header_content_type_mobile'
	)
));

// Slide 2
$id = 'dp_slider_image2_mobile';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new WP_Customize_Image_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'label' => sprintf(__('Slide %s Setting','DigiPress'), '2'),
	'description' => __('Slide image','DigiPress'),
	'section' => 'dp_mobile_theme_header_area_section',
	'active_callback' => 'cb_header_content_type_mobile'
	)
));
$id = 'dp_slider_title2_mobile';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => '',
	'type' => 'option',
	'sanitize_callback' => 'dp_sanitize_html',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'description' => __('Slide title','DigiPress'),
	'section' => 'dp_mobile_theme_header_area_section',
	'type' => 'text',
	'input_attrs' => array(
		'placeholder' => $def_options[$id],
	),
	'active_callback' => 'cb_header_content_type_mobile'
	)
));
$id = 'dp_slider_caption2_mobile';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => '',
	'type' => 'option',
	'sanitize_callback' => 'dp_sanitize_html',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'description' => __('Slide caption','DigiPress'),
	'section' => 'dp_mobile_theme_header_area_section',
	'type' => 'text',
	'input_attrs' => array(
		'placeholder' => $def_options[$id],
	),
	'active_callback' => 'cb_header_content_type_mobile'
	)
));
$id = 'dp_slider_url2_mobile';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'sanitize_callback' => 'esc_url_raw',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'description' => __('URL to navigate','DigiPress'),
	'note' => __('*You can specify the URL to move when visitor clicks this slider.','DigiPress'),
	'section' => 'dp_mobile_theme_header_area_section',
	'type' => 'text',
	'input_attrs' => array(
		'placeholder' => 'https://example.com/target/',
	),
	'active_callback' => 'cb_header_content_type_mobile'
	)
));

// Slide 3
$id = 'dp_slider_image3_mobile';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new WP_Customize_Image_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'label' => sprintf(__('Slide %s Setting','DigiPress'), '3'),
	'description' => __('Slide image','DigiPress'),
	'section' => 'dp_mobile_theme_header_area_section',
	'active_callback' => 'cb_header_content_type_mobile'
	)
));
$id = 'dp_slider_title3_mobile';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => '',
	'type' => 'option',
	'sanitize_callback' => 'dp_sanitize_html',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'description' => __('Slide title','DigiPress'),
	'section' => 'dp_mobile_theme_header_area_section',
	'type' => 'text',
	'input_attrs' => array(
		'placeholder' => $def_options[$id],
	),
	'active_callback' => 'cb_header_content_type_mobile'
	)
));
$id = 'dp_slider_caption3_mobile';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => '',
	'type' => 'option',
	'sanitize_callback' => 'dp_sanitize_html',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'description' => __('Slide caption','DigiPress'),
	'section' => 'dp_mobile_theme_header_area_section',
	'type' => 'text',
	'input_attrs' => array(
		'placeholder' => $def_options[$id],
	),
	'active_callback' => 'cb_header_content_type_mobile'
	)
));
$id = 'dp_slider_url3_mobile';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'sanitize_callback' => 'esc_url_raw',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'description' => __('URL to navigate','DigiPress'),
	'note' => __('*You can specify the URL to move when visitor clicks this slider.','DigiPress'),
	'section' => 'dp_mobile_theme_header_area_section',
	'type' => 'text',
	'input_attrs' => array(
		'placeholder' => 'https://example.com/target/',
	),
	'active_callback' => 'cb_header_content_type_mobile'
	)
));

// Slide 4
$id = 'dp_slider_image4_mobile';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new WP_Customize_Image_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'label' => sprintf(__('Slide %s Setting','DigiPress'), '4'),
	'description' => __('Slide image','DigiPress'),
	'section' => 'dp_mobile_theme_header_area_section',
	'active_callback' => 'cb_header_content_type_mobile'
	)
));
$id = 'dp_slider_title4_mobile';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => '',
	'type' => 'option',
	'sanitize_callback' => 'dp_sanitize_html',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'description' => __('Slide title','DigiPress'),
	'section' => 'dp_mobile_theme_header_area_section',
	'type' => 'text',
	'input_attrs' => array(
		'placeholder' => $def_options[$id],
	),
	'active_callback' => 'cb_header_content_type_mobile'
	)
));
$id = 'dp_slider_caption4_mobile';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => '',
	'type' => 'option',
	'sanitize_callback' => 'dp_sanitize_html',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'description' => __('Slide caption','DigiPress'),
	'section' => 'dp_mobile_theme_header_area_section',
	'type' => 'text',
	'input_attrs' => array(
		'placeholder' => $def_options[$id],
	),
	'active_callback' => 'cb_header_content_type_mobile'
	)
));
$id = 'dp_slider_url4_mobile';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'sanitize_callback' => 'esc_url_raw',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'description' => __('URL to navigate','DigiPress'),
	'note' => __('*You can specify the URL to move when visitor clicks this slider.','DigiPress'),
	'section' => 'dp_mobile_theme_header_area_section',
	'type' => 'text',
	'input_attrs' => array(
		'placeholder' => 'https://example.com/target/',
	),
	'active_callback' => 'cb_header_content_type_mobile'
	)
));

// Slide 5
$id = 'dp_slider_image5_mobile';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new WP_Customize_Image_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'label' => sprintf(__('Slide %s Setting','DigiPress'), '5'),
	'description' => __('Slide image','DigiPress'),
	'section' => 'dp_mobile_theme_header_area_section',
	'active_callback' => 'cb_header_content_type_mobile'
	)
));
$id = 'dp_slider_title5_mobile';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => '',
	'type' => 'option',
	'sanitize_callback' => 'dp_sanitize_html',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'description' => __('Slide title','DigiPress'),
	'section' => 'dp_mobile_theme_header_area_section',
	'type' => 'text',
	'input_attrs' => array(
		'placeholder' => $def_options[$id],
	),
	'active_callback' => 'cb_header_content_type_mobile'
	)
));
$id = 'dp_slider_caption5_mobile';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => '',
	'type' => 'option',
	'sanitize_callback' => 'dp_sanitize_html',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'description' => __('Slide caption','DigiPress'),
	'section' => 'dp_mobile_theme_header_area_section',
	'type' => 'text',
	'input_attrs' => array(
		'placeholder' => $def_options[$id],
	),
	'active_callback' => 'cb_header_content_type_mobile'
	)
));
$id = 'dp_slider_url5_mobile';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'sanitize_callback' => 'esc_url_raw',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'description' => __('URL to navigate','DigiPress'),
	'note' => __('*You can specify the URL to move when visitor clicks this slider.','DigiPress'),
	'section' => 'dp_mobile_theme_header_area_section',
	'type' => 'text',
	'input_attrs' => array(
		'placeholder' => 'https://example.com/target/',
	),
	'active_callback' => 'cb_header_content_type_mobile'
	)
));

// Slide 6
$id = 'dp_slider_image6_mobile';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new WP_Customize_Image_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'label' => sprintf(__('Slide %s Setting','DigiPress'), '6'),
	'description' => __('Slide image','DigiPress'),
	'section' => 'dp_mobile_theme_header_area_section',
	'active_callback' => 'cb_header_content_type_mobile'
	)
));
$id = 'dp_slider_title6_mobile';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => '',
	'type' => 'option',
	'sanitize_callback' => 'dp_sanitize_html',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'description' => __('Slide title','DigiPress'),
	'section' => 'dp_mobile_theme_header_area_section',
	'type' => 'text',
	'input_attrs' => array(
		'placeholder' => $def_options[$id],
	),
	'active_callback' => 'cb_header_content_type_mobile'
	)
));
$id = 'dp_slider_caption6_mobile';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => '',
	'type' => 'option',
	'sanitize_callback' => 'dp_sanitize_html',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'description' => __('Slide caption','DigiPress'),
	'section' => 'dp_mobile_theme_header_area_section',
	'type' => 'text',
	'input_attrs' => array(
		'placeholder' => $def_options[$id],
	),
	'active_callback' => 'cb_header_content_type_mobile'
	)
));
$id = 'dp_slider_url6_mobile';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'sanitize_callback' => 'esc_url_raw',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'description' => __('URL to navigate','DigiPress'),
	'note' => __('*You can specify the URL to move when visitor clicks this slider.','DigiPress'),
	'section' => 'dp_mobile_theme_header_area_section',
	'type' => 'text',
	'input_attrs' => array(
		'placeholder' => 'https://example.com/target/',
	),
	'active_callback' => 'cb_header_content_type_mobile'
	)
));

// Slide 7
$id = 'dp_slider_image7_mobile';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new WP_Customize_Image_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'label' => sprintf(__('Slide %s Setting','DigiPress'), '7'),
	'description' => __('Slide image','DigiPress'),
	'section' => 'dp_mobile_theme_header_area_section',
	'active_callback' => 'cb_header_content_type_mobile'
	)
));
$id = 'dp_slider_title7_mobile';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => '',
	'type' => 'option',
	'sanitize_callback' => 'dp_sanitize_html',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'description' => __('Slide title','DigiPress'),
	'section' => 'dp_mobile_theme_header_area_section',
	'type' => 'text',
	'input_attrs' => array(
		'placeholder' => $def_options[$id],
	),
	'active_callback' => 'cb_header_content_type_mobile'
	)
));
$id = 'dp_slider_caption7_mobile';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => '',
	'type' => 'option',
	'sanitize_callback' => 'dp_sanitize_html',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'description' => __('Slide caption','DigiPress'),
	'section' => 'dp_mobile_theme_header_area_section',
	'type' => 'text',
	'input_attrs' => array(
		'placeholder' => $def_options[$id],
	),
	'active_callback' => 'cb_header_content_type_mobile'
	)
));
$id = 'dp_slider_url7_mobile';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'sanitize_callback' => 'esc_url_raw',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'description' => __('URL to navigate','DigiPress'),
	'note' => __('*You can specify the URL to move when visitor clicks this slider.','DigiPress'),
	'section' => 'dp_mobile_theme_header_area_section',
	'type' => 'text',
	'input_attrs' => array(
		'placeholder' => 'https://example.com/target/',
	),
	'active_callback' => 'cb_header_content_type_mobile'
	)
));

// Slide 8
$id = 'dp_slider_image8_mobile';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new WP_Customize_Image_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'label' => sprintf(__('Slide %s Setting','DigiPress'), '8'),
	'description' => __('Slide image','DigiPress'),
	'section' => 'dp_mobile_theme_header_area_section',
	'active_callback' => 'cb_header_content_type_mobile'
	)
));
$id = 'dp_slider_title8_mobile';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => '',
	'type' => 'option',
	'sanitize_callback' => 'dp_sanitize_html',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'description' => __('Slide title','DigiPress'),
	'section' => 'dp_mobile_theme_header_area_section',
	'type' => 'text',
	'input_attrs' => array(
		'placeholder' => $def_options[$id],
	),
	'active_callback' => 'cb_header_content_type_mobile'
	)
));
$id = 'dp_slider_caption8_mobile';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => '',
	'type' => 'option',
	'sanitize_callback' => 'dp_sanitize_html',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'description' => __('Slide caption','DigiPress'),
	'section' => 'dp_mobile_theme_header_area_section',
	'type' => 'text',
	'input_attrs' => array(
		'placeholder' => $def_options[$id],
	),
	'active_callback' => 'cb_header_content_type_mobile'
	)
));
$id = 'dp_slider_url8_mobile';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'sanitize_callback' => 'esc_url_raw',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'description' => __('URL to navigate','DigiPress'),
	'note' => __('*You can specify the URL to move when visitor clicks this slider.','DigiPress'),
	'section' => 'dp_mobile_theme_header_area_section',
	'type' => 'text',
	'input_attrs' => array(
		'placeholder' => 'https://example.com/target/',
	),
	'active_callback' => 'cb_header_content_type_mobile'
	)
));


/**
 * Callback
 */
function cb_header_content_type_mobile($control){
	$control_id = $control->id;
	$content_type = $control->manager->get_setting('dp_theme_options[dp_header_content_type_mobile]')->value();
	$slider_style = $control->manager->get_setting('dp_theme_options[dp_slider_style_mobile]')->value();
	$slider_only_one_title = $control->manager->get_setting('dp_theme_options[dp_slider_only_one_title_mobile]')->value();
	$edge_bottom = $control->manager->get_setting('dp_theme_options[dp_header_area_bottom_edge_mobile]')->value();

	if ( (
		$control_id === 'dp_theme_options[dp_header_img_mobile]' ||
		$control_id === 'dp_theme_options[header_img_title_mobile]' ||
		$control_id === 'dp_theme_options[header_img_caption_mobile]' ||
		$control_id === 'dp_theme_options[header_img_text_animate_mobile]' ||
		$control_id === 'dp_theme_options[header_text_vertically_mobile]'
	) && $content_type === 'image') return true;


	if ( ( $control_id === 'dp_theme_options[header_img_title_mobile]'
			|| $control_id === 'dp_theme_options[header_img_caption_mobile]'
			|| $control_id === 'dp_theme_options[header_img_text_animate_mobile]'
		) &&
		( $content_type === 'slideshow_selected_media' && $slider_only_one_title ) ) return true;

	if ( (
		$control_id === 'dp_theme_options[dp_slider_post_or_page_mobile]' ||
		$control_id === 'dp_theme_options[dp_number_of_slideshow_mobile]' ||
		$control_id === 'dp_theme_options[dp_slider_order_mobile]'
	) && $content_type === 'slideshow') return true;


	if ( (
		$control_id === 'dp_theme_options[dp_slider_style_mobile]' ||
		$control_id === 'dp_theme_options[dp_slider_show_time_mobile]' ||
		$control_id === 'dp_theme_options[dp_slider_disable_autoplay_mobile]' ||
		$control_id === 'dp_theme_options[dp_slider_transition_time_mobile]'
	) && ($content_type === 'slideshow' || $content_type === 'slideshow_selected_media') ) return true;


	if ( (
		$control_id === 'dp_theme_options[header_banner_text_color_mobile]' ||
		$control_id === 'dp_theme_options[header_banner_text_shadow_enable_mobile]' ||
		$control_id === 'dp_theme_options[header_banner_text_shadow_color_mobile]' ||
		$control_id === 'dp_theme_options[header_banner_overlay_color_mobile]' ||
		$control_id === 'dp_theme_options[header_banner_overlay_opacity_mobile]'
	) && $content_type !== 'none') return true;


	if ( (
		$control_id === 'dp_theme_options[header_text_vertically_mobile]' ||
		$control_id === 'dp_theme_options[dp_slider_image1_mobile]' ||
		$control_id === 'dp_theme_options[dp_slider_image2_mobile]' ||
		$control_id === 'dp_theme_options[dp_slider_image3_mobile]' ||
		$control_id === 'dp_theme_options[dp_slider_image4_mobile]' ||
		$control_id === 'dp_theme_options[dp_slider_image5_mobile]' ||
		$control_id === 'dp_theme_options[dp_slider_image6_mobile]' ||
		$control_id === 'dp_theme_options[dp_slider_image7_mobile]' ||
		$control_id === 'dp_theme_options[dp_slider_image8_mobile]'
	) && $content_type === 'slideshow_selected_media') return true;


	if ( $content_type === 'slideshow_selected_media' ) {
		if ( !$slider_only_one_title ) {
			if (
				$control_id === 'dp_theme_options[dp_slider_title1_mobile]' ||
				$control_id === 'dp_theme_options[dp_slider_title2_mobile]' ||
				$control_id === 'dp_theme_options[dp_slider_title3_mobile]' ||
				$control_id === 'dp_theme_options[dp_slider_title4_mobile]' ||
				$control_id === 'dp_theme_options[dp_slider_title5_mobile]' ||
				$control_id === 'dp_theme_options[dp_slider_title6_mobile]' ||
				$control_id === 'dp_theme_options[dp_slider_title7_mobile]' ||
				$control_id === 'dp_theme_options[dp_slider_title8_mobile]' ||
				$control_id === 'dp_theme_options[dp_slider_caption1_mobile]' ||
				$control_id === 'dp_theme_options[dp_slider_caption2_mobile]' ||
				$control_id === 'dp_theme_options[dp_slider_caption3_mobile]' ||
				$control_id === 'dp_theme_options[dp_slider_caption4_mobile]' ||
				$control_id === 'dp_theme_options[dp_slider_caption5_mobile]' ||
				$control_id === 'dp_theme_options[dp_slider_caption6_mobile]' ||
				$control_id === 'dp_theme_options[dp_slider_caption7_mobile]' ||
				$control_id === 'dp_theme_options[dp_slider_caption8_mobile]' ||
				$control_id === 'dp_theme_options[dp_slider_url1_mobile]' ||
				$control_id === 'dp_theme_options[dp_slider_url2_mobile]' ||
				$control_id === 'dp_theme_options[dp_slider_url3_mobile]' ||
				$control_id === 'dp_theme_options[dp_slider_url4_mobile]' ||
				$control_id === 'dp_theme_options[dp_slider_url5_mobile]' ||
				$control_id === 'dp_theme_options[dp_slider_url6_mobile]' ||
				$control_id === 'dp_theme_options[dp_slider_url7_mobile]' ||
				$control_id === 'dp_theme_options[dp_slider_url8_mobile]'
			) return true;
		}
	}

	if ( $control_id === 'dp_theme_options[dp_header_area_bottom_edge_mobile]' || $control_id === 'dp_theme_options[dp_header_area_edge_piled_layer_mobile]' ) {

		if ( $content_type === 'slideshow' || $content_type === 'slideshow_selected_media' ) {
			if ( $slider_style === 'fade' || $slider_style === 'horizontal' || $slider_style === 'vertical' || strpos( $slider_style, 'creative' ) !== false ) {

			if ( $control_id === 'dp_theme_options[dp_header_area_edge_piled_layer_mobile]' ) {
				if ( $edge_bottom === 'wave1' || $edge_bottom === 'wave2' || $edge_bottom === 'curve1' || $edge_bottom === 'curve2' ) {
					return true;
				}
			} else {
				return true;
			}
		}
		} else if ( $content_type === 'image' ) {
			return true;
		}
	}

	// Accept parallax transition( Horizontal or vertical slider )
	if ( $control_id === 'dp_theme_options[dp_slider_parallax_transition_mobile]'
		&& $content_type !== 'image' && ($slider_style === 'horizontal' || $slider_style === 'vertical') ) return true;


	// Accept common title and caption ( Fade, horizontal, vertical, split, coverflow #1 with selected media )
	if ( $control_id === 'dp_theme_options[dp_slider_only_one_title_mobile]' && $content_type === 'slideshow_selected_media' ) return true;

	return false;
}


/**
 * Slide menu position
 */
$id = 'slide_menu_position_mobile';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'label' => __('Slide menu position','DigiPress'),
	'section' => 'dp_mobile_theme_footer_bar_section',
	'type' => 'radio',
	'choices' => array(
		'left' => __('Slide from left','DigiPress'),
		'right' => __('Slide from right','DigiPress')
		)
	)
));

/**
 * Original footer bar
 */
$id = 'original_footer_bar_mobile';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'label' => __('Change to original footer bar contents','DigiPress'),
	'note' => __('Even if you change each menu on the footer bar to any link, it will be displayed with the hamburger menu.', 'DigiPress'),
	'fake_title' => __('Custom footer bar', 'DigiPress'),
	'separator' => true,
	'section' => 'dp_mobile_theme_footer_bar_section',
	'type' => 'checkbox'
	)
));

// Item 1
$id = 'footer_bar_item_heading_1';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => '',
	'type' => 'option',
	'sanitize_callback' => 'dp_sanitize_html',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'description' => __('Item heading','DigiPress') . ' #1',
	'section' => 'dp_mobile_theme_footer_bar_section',
	'type' => 'text',
	'input_attrs' => array(
		'placeholder' => 'Home',
	),
	'separator' => false,
	'active_callback' => 'cb_footer_bar_mobile'
	)
));

$id = 'footer_bar_item_url_1';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => '',
	'type' => 'option',
	'sanitize_callback' => 'esc_url_raw',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'description' => __('URL','DigiPress') . ' #1',
	'section' => 'dp_mobile_theme_footer_bar_section',
	'type' => 'text',
	'input_attrs' => array(
		'placeholder' => 'https://example.com/target/',
	),
	'separator' => false,
	'active_callback' => 'cb_footer_bar_mobile'
	)
));

$id = 'footer_bar_item_url_newtab_1';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'label' => __('Open URL in new tab','DigiPress'),
	'section' => 'dp_mobile_theme_footer_bar_section',
	'type' => 'checkbox',
	'active_callback' => 'cb_footer_bar_mobile'
	)
));

$id = 'footer_bar_item_icon_1';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => '',
	'type' => 'option',
	'sanitize_callback' => 'sanitize_text_field',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'description' => __('Icon class','DigiPress') . ' #1',
	'note' => '<a href="https://digipress.info/manual/icon-font-map/" class="button" target="_blank">' . __('See the icon class list', 'DigiPress') . '</a>',
	'section' => 'dp_mobile_theme_footer_bar_section',
	'type' => 'text',
	'input_attrs' => array(
		'placeholder' => 'icon-home',
	),
	'separator' => true,
	'active_callback' => 'cb_footer_bar_mobile'
	)
));

// Item 2
$id = 'footer_bar_item_heading_2';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => '',
	'type' => 'option',
	'sanitize_callback' => 'dp_sanitize_html',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'description' => __('Item heading','DigiPress') . ' #2',
	'section' => 'dp_mobile_theme_footer_bar_section',
	'type' => 'text',
	'input_attrs' => array(
		'placeholder' => 'Home',
	),
	'separator' => false,
	'active_callback' => 'cb_footer_bar_mobile'
	)
));

$id = 'footer_bar_item_url_2';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => '',
	'type' => 'option',
	'sanitize_callback' => 'esc_url_raw',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'description' => __('URL','DigiPress') . ' #2',
	'section' => 'dp_mobile_theme_footer_bar_section',
	'type' => 'text',
	'input_attrs' => array(
		'placeholder' => 'https://example.com/target/',
	),
	'separator' => false,
	'active_callback' => 'cb_footer_bar_mobile'
	)
));

$id = 'footer_bar_item_url_newtab_2';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'label' => __('Open URL in new tab','DigiPress'),
	'section' => 'dp_mobile_theme_footer_bar_section',
	'type' => 'checkbox',
	'active_callback' => 'cb_footer_bar_mobile'
	)
));

$id = 'footer_bar_item_icon_2';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => '',
	'type' => 'option',
	'sanitize_callback' => 'sanitize_text_field',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'description' => __('Icon class','DigiPress') . ' #2',
	'note' => '<a href="https://digipress.info/manual/icon-font-map/" class="button" target="_blank">' . __('See the icon class list', 'DigiPress') . '</a>',
	'section' => 'dp_mobile_theme_footer_bar_section',
	'type' => 'text',
	'input_attrs' => array(
		'placeholder' => 'icon-home',
	),
	'separator' => true,
	'active_callback' => 'cb_footer_bar_mobile'
	)
));

// Item 3
$id = 'footer_bar_item_heading_3';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => '',
	'type' => 'option',
	'sanitize_callback' => 'dp_sanitize_html',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'description' => __('Item heading','DigiPress') . ' #3',
	'section' => 'dp_mobile_theme_footer_bar_section',
	'type' => 'text',
	'input_attrs' => array(
		'placeholder' => 'Home',
	),
	'separator' => false,
	'active_callback' => 'cb_footer_bar_mobile'
	)
));

$id = 'footer_bar_item_url_3';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => '',
	'type' => 'option',
	'sanitize_callback' => 'esc_url_raw',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'description' => __('URL','DigiPress') . ' #3',
	'section' => 'dp_mobile_theme_footer_bar_section',
	'type' => 'text',
	'input_attrs' => array(
		'placeholder' => 'https://example.com/target/',
	),
	'separator' => false,
	'active_callback' => 'cb_footer_bar_mobile'
	)
));

$id = 'footer_bar_item_url_newtab_3';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'label' => __('Open URL in new tab','DigiPress'),
	'section' => 'dp_mobile_theme_footer_bar_section',
	'type' => 'checkbox',
	'active_callback' => 'cb_footer_bar_mobile'
	)
));

$id = 'footer_bar_item_icon_3';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => '',
	'type' => 'option',
	'sanitize_callback' => 'sanitize_text_field',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'description' => __('Icon class','DigiPress') . ' #3',
	'note' => '<a href="https://digipress.info/manual/icon-font-map/" class="button" target="_blank">' . __('See the icon class list', 'DigiPress') . '</a>',
	'section' => 'dp_mobile_theme_footer_bar_section',
	'type' => 'text',
	'input_attrs' => array(
		'placeholder' => 'icon-home',
	),
	'separator' => true,
	'active_callback' => 'cb_footer_bar_mobile'
	)
));

// Item 4
$id = 'footer_bar_item_heading_4';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => '',
	'type' => 'option',
	'sanitize_callback' => 'dp_sanitize_html',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'description' => __('Item heading','DigiPress') . ' #4',
	'section' => 'dp_mobile_theme_footer_bar_section',
	'type' => 'text',
	'input_attrs' => array(
		'placeholder' => 'Home',
	),
	'separator' => false,
	'active_callback' => 'cb_footer_bar_mobile'
	)
));

$id = 'footer_bar_item_url_4';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => '',
	'type' => 'option',
	'sanitize_callback' => 'esc_url_raw',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'description' => __('URL','DigiPress') . ' #4',
	'section' => 'dp_mobile_theme_footer_bar_section',
	'type' => 'text',
	'input_attrs' => array(
		'placeholder' => 'https://example.com/target/',
	),
	'separator' => false,
	'active_callback' => 'cb_footer_bar_mobile'
	)
));

$id = 'footer_bar_item_url_newtab_4';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'label' => __('Open URL in new tab','DigiPress'),
	'section' => 'dp_mobile_theme_footer_bar_section',
	'type' => 'checkbox',
	'active_callback' => 'cb_footer_bar_mobile'
	)
));

$id = 'footer_bar_item_icon_4';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => '',
	'type' => 'option',
	'sanitize_callback' => 'sanitize_text_field',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'description' => __('Icon class','DigiPress') . ' #4',
	'note' => '<a href="https://digipress.info/manual/icon-font-map/" class="button" target="_blank">' . __('See the icon class list', 'DigiPress') . '</a>',
	'section' => 'dp_mobile_theme_footer_bar_section',
	'type' => 'text',
	'input_attrs' => array(
		'placeholder' => 'icon-home',
	),
	'separator' => true,
	'active_callback' => 'cb_footer_bar_mobile'
	)
));

// Item 5
$id = 'footer_bar_item_heading_5';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => '',
	'type' => 'option',
	'sanitize_callback' => 'dp_sanitize_html',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'description' => __('Item heading','DigiPress') . ' #5',
	'section' => 'dp_mobile_theme_footer_bar_section',
	'type' => 'text',
	'input_attrs' => array(
		'placeholder' => 'Home',
	),
	'separator' => false,
	'active_callback' => 'cb_footer_bar_mobile'
	)
));

$id = 'footer_bar_item_url_5';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => '',
	'type' => 'option',
	'sanitize_callback' => 'esc_url_raw',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'description' => __('URL','DigiPress') . ' #5',
	'section' => 'dp_mobile_theme_footer_bar_section',
	'type' => 'text',
	'input_attrs' => array(
		'placeholder' => 'https://example.com/target/',
	),
	'separator' => false,
	'active_callback' => 'cb_footer_bar_mobile'
	)
));

$id = 'footer_bar_item_url_newtab_5';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'label' => __('Open URL in new tab','DigiPress'),
	'section' => 'dp_mobile_theme_footer_bar_section',
	'type' => 'checkbox',
	'active_callback' => 'cb_footer_bar_mobile'
	)
));

$id = 'footer_bar_item_icon_5';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => '',
	'type' => 'option',
	'sanitize_callback' => 'sanitize_text_field',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'description' => __('Icon class','DigiPress') . ' #5',
	'note' => '<a href="https://digipress.info/manual/icon-font-map/" class="button" target="_blank">' . __('See the icon class list', 'DigiPress') . '</a>',
	'section' => 'dp_mobile_theme_footer_bar_section',
	'type' => 'text',
	'input_attrs' => array(
		'placeholder' => 'icon-home',
	),
	'separator' => true,
	'active_callback' => 'cb_footer_bar_mobile'
	)
));

/**
 * Callback
 */
function cb_footer_bar_mobile($control){
	$original_footer_bar = $control->manager->get_setting('dp_theme_options[original_footer_bar_mobile]')->value();

	if ( $original_footer_bar ) return;

	return false;
}