<?php
// init
$id = '';
// **********************************************
// Header bar area section
// **********************************************
$wp_customize->add_panel( 'dp_header_bar_area_panel', array(
	'priority' => 40,
	'title' => __( 'Header Bar Area Settings', 'DigiPress' ),
	'description' => __( 'Settings for header bar contents of this site.', 'DigiPress' ),
));
// Title section
$wp_customize->add_section(
	'dp_header_bar_area_title_section', array(
	'title' => __( 'Title Settings', 'DigiPress' ),
	'description' => __( 'Settings for the title and the caption in site header area.', 'DigiPress' ),
	'panel' => 'dp_header_bar_area_panel',
	'priority' => 10
));
// Color / Font section
$wp_customize->add_section(
	'dp_header_bar_area_design_section', array(
	'title' => __( 'Header Bar Design Settings', 'DigiPress' ),
	'description' => __( 'Customize the header bar area design.', 'DigiPress' ),
	'panel' => 'dp_header_bar_area_panel',
	'priority' => 20
));
// Global menu
$wp_customize->add_section(
	'dp_header_bar_menu_section', array(
	'title' => __( 'Global Menu Settings', 'DigiPress' ),
	'description' => __( 'Customize global menu design.', 'DigiPress' ),
	'panel' => 'dp_header_bar_area_panel',
	'priority' => 30
));
// Mega menu section
$wp_customize->add_section(
	'dp_header_bar_mega_menu_section', array(
	'title' => __( 'Category Mega Menu Settings', 'DigiPress' ),
	'description' => __( 'Customize post meta info in category mega menu.', 'DigiPress' ),
	'panel' => 'dp_header_bar_area_panel',
	'priority' => 40
));



/**
 * Header bar title
 */
$id = 'h1_title';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'sanitize_callback' => 'dp_sanitize_html',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'label' => __( 'Main title (H1)', 'DigiPress' ),
	'section' => 'dp_header_bar_area_title_section',
	'input_attrs' => array(
		'placeholder' => $def_options[$id]
	),
	'type' => 'text'
	)
));


/**
 * Header bar title caption
 */
$id = 'h2_title';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'sanitize_callback' => 'dp_sanitize_html',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'label' => __( 'Title caption (H2)', 'DigiPress' ),
	'description' => __( '*Keep this blank to hide the caption.', 'DigiPress' ),
	'section' => 'dp_header_bar_area_title_section',
	'input_attrs' => array(
		'placeholder' => $def_options[$id]
	),
	'type' => 'text'
	)
));

/**
 * Which text or image
 */
$id = 'h1_title_as_what';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'label' => __( 'Title display', 'DigiPress' ),
	'note' => __( '*Main title is used as alt attribute value, if you display the image as title.', 'DigiPress' ),
	'section' => 'dp_header_bar_area_title_section',
	'type' => 'radio',
	'choices' => array(
		'text' => __( 'Show title by text', 'DigiPress' ),
		'image' => __( 'Show title by image', 'DigiPress' )
		)
	)
));
// For Selective refresh
if (isset($wp_customize->selective_refresh)){
	$wp_customize->selective_refresh->add_partial('dp_theme_options['.$id.']', array(
		'selector' => '#header_bar .h_group',
		'settings' => 'dp_theme_options['.$id.']',
		'render_callback' => function(){
			$options = get_option('dp_theme_options');
			if ($options['h1_title_as_what'] === 'text') {
				echo '<h1 class="hd-title txt"><a href="'.home_url('/').'">'.$options['h1_title'].'</a></h1><h2 class="caption">'.$options['h2_title'].'</h2>';
			} else if ($options['h1_title_as_what'] === 'image') {
				echo '<h1 class="hd-title img"><a href="'.home_url('/').'"><img src="'.$options['dp_title_img'].'" alt="'.esc_attr(dp_h1_title()).'" /></a></h1><h2 class="caption">'.$options['h2_title'].'</h2>';
			}
		}
	));
}

/**
 * Site Title image
 */
$id = 'dp_title_img';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'sanitize_callback' => 'esc_url_raw',
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new WP_Customize_Image_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'label' => __( 'Title image', 'DigiPress' ).__( '(PC)', 'DigiPress' ),
	'section' => 'dp_header_bar_area_title_section',
	'active_callback' => 'cb_dp_title_img'
	)
));
/**
 * Site title image (Mobile)
 */
$id = 'dp_title_img_mobile';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'sanitize_callback' => 'esc_url_raw',
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new WP_Customize_Image_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'label' => __( 'Title image', 'DigiPress' ).__( '(Mobile)', 'DigiPress' ),
	'section' => 'dp_header_bar_area_title_section',
	'active_callback' => 'cb_dp_title_img'
	)
));
function cb_dp_title_img($control){
	$setting = $control->manager->get_setting('dp_theme_options[h1_title_as_what]')->value();
	if ( $setting === 'image') return true;
	return false;
}

/**
 * Title position
 */
$id = 'h1_title_position';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'label' => __( 'Title Position', 'DigiPress' ),
	'section' => 'dp_header_bar_area_title_section',
	'type' => 'radio',
	'choices' => array(
		'left' => __( 'Align left', 'DigiPress' ),
		'center' => __( 'Align center', 'DigiPress' )
		)
	)
));


/**
 * Dummy option to navigte target
 */
$wp_customize->add_setting( 'dp_dummy_header_bar_color', array(
	'transport' => 'postMessage'
));
$wp_customize->add_control( 'dp_dummy_header_bar_color', array(
    'section' => 'dp_header_bar_area_design_section'
));
// For Selective refresh
if (isset($wp_customize->selective_refresh)){
	$wp_customize->selective_refresh->add_partial('dp_dummy_header_bar_color', array(
		'selector' => '#header_bar'
	));
}

/**
 * Header bar bg color
 */
$id = 'header_bar_bgcolor';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage',
	'sanitize_callback' => 'sanitize_hex_color'
));
$wp_customize->add_control( new WP_Customize_Color_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'label' => __( 'Background Design', 'DigiPress' ),
	'description' => __( 'Background color', 'DigiPress' ),
	'section' => 'dp_header_bar_area_design_section'
	)
));

/**
 * Transparent when no scroll
 */
$id = 'header_bar_transparent';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'label' => __( 'Transparent header content', 'DigiPress' ),
	'note' => __( '*This option is disabled when the header slider is in carousel, center mode, or 3D cover flow.', 'DigiPress' ),
	'section' => 'dp_header_bar_area_design_section',
	'type' => 'checkbox'
	)
));

/**
 * Pile up the layer
 */
$id = 'header_bar_add_layer';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'label' => __( 'Overlay accent layers', 'DigiPress' ),
	'section' => 'dp_header_bar_area_design_section',
	'type' => 'checkbox'
	)
));
/**
 * Piled layer color
 */
$id = 'header_bar_layer_color';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage',
	'sanitize_callback' => 'sanitize_hex_color'
));
$wp_customize->add_control( new WP_Customize_Color_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'description' => __( 'Piled background layer color', 'DigiPress' ),
	'section' => 'dp_header_bar_area_design_section',
	'active_callback' => 'cb_header_bar_piled_layer'
	)
));
function cb_header_bar_piled_layer($control){
	$control_id = $control->id;
	$content_type = $control->manager->get_setting('dp_theme_options[header_bar_add_layer]')->value();

	if ( $content_type && $control_id === 'dp_theme_options[header_bar_layer_color]' ) {
		return true;
	}

	return false;
}


/**
 * Font/link color
 */
$id = 'header_bar_link_color';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage',
	'sanitize_callback' => 'sanitize_hex_color'
));
$wp_customize->add_control( new WP_Customize_Color_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'label' => __( 'Font / link color', 'DigiPress' ),
	'section' => 'dp_header_bar_area_design_section'
	)
));


/**
 * Link hover bg color
 */
$id = 'global_menu_mouseover_accent_color';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage',
	'sanitize_callback' => 'sanitize_hex_color'
));
$wp_customize->add_control( new WP_Customize_Color_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'label' => __( 'Global Menu Settings', 'DigiPress' ),
	'description' => __( 'Global menu mouseover accent color', 'DigiPress' ),
	'section' => 'dp_header_bar_menu_section'
	)
));
/**
 * Menu link font size
 */
$id = 'header_bar_menu_font_size';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'sanitize_callback' => 'dp_sanitize_float',
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'description' => __( 'Menu font size', 'DigiPress' ),
	'unit' => __( 'pixel', 'DigiPress' ),
	'section' => 'dp_header_bar_menu_section',
	'type' => 'number',
	'input_attrs' => array('min' => 8,'max' => 20,'step' => 0.1)
	)
));
/**
 * Menu text letter spacing
 */
$id = 'header_bar_menu_letter_spacing';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'sanitize_callback' => 'dp_sanitize_float',
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'description' => __('Letter spacing', 'DigiPress' ),
	'note' => __( '*This letter spacing applies only to the parent menu.', 'DigiPress' ),
	'unit' => 'em (' . sprintf( __( 'Default: %s', 'DigiPress' ), $def_options[$id] ) . ')',
	'section' => 'dp_header_bar_menu_section',
	'type' => 'number',
	'input_attrs' => array( 'min' => -10, 'max' => 10, 'step' => 0.01 )
	)
));
/**
 * Menu link font as bold
 */
$id = 'header_bar_menu_font_bold';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'label' => __( 'Show menu link as bold', 'DigiPress' ),
	'section' => 'dp_header_bar_menu_section',
	'type' => 'checkbox'
	)
));
/**
 * Dummy option to navigte target
 */
$wp_customize->add_setting( 'dp_dummy_header_bar_menu', array(
	'transport' => 'postMessage'
));
$wp_customize->add_control( 'dp_dummy_header_bar_menu', array(
    'section' => 'dp_header_bar_menu_section'
));
// For Selective refresh
if (isset($wp_customize->selective_refresh)){
	$wp_customize->selective_refresh->add_partial('dp_dummy_header_bar_menu', array(
		'selector' => '#global_menu_nav'
	));
}



/**
 * Category Mega menu
 */
// Orderby
$id = 'global_nemu_cat_posts_order';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'refresh'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'label' => __( 'Article display order', 'DigiPress' ),
	'section' => 'dp_header_bar_mega_menu_section',
	'type' => 'select',
	'choices' => array(
		'date' => __( 'Order by posted date', 'DigiPress' ),
		'modified' => __( 'Order by last modified', 'DigiPress' ),
		'meta_value_num' => __( 'Order by viewed count', 'DigiPress' ),
		'comment_count' => __( 'Order by comment count', 'DigiPress' ),
		'ID' => __( 'Order by ID', 'DigiPress' ),
		'rand' => __( 'Random order', 'DigiPress' ),
		'author' => __( 'Order by author', 'DigiPress' )
		)
	)
));
// date
$id = 'global_nemu_cat_posts_meta_date';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'refresh'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'fake_title' => __( 'Meta info', 'DigiPress' ),
	'label' => __( 'Show date', 'DigiPress' ),
	'section' => 'dp_header_bar_mega_menu_section',
	'type' => 'checkbox'
	)
));
// Category
$id = 'global_nemu_cat_posts_meta_cat';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'refresh'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'label' => __( 'Show category', 'DigiPress' ),
	'section' => 'dp_header_bar_mega_menu_section',
	'type' => 'checkbox'
	)
));
// Author
$id = 'global_nemu_cat_posts_meta_author';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'refresh'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'label' => __( 'Show author', 'DigiPress' ),
	'section' => 'dp_header_bar_mega_menu_section',
	'type' => 'checkbox'
	)
));