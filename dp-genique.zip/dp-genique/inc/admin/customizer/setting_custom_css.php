<?php
/**
 * Custom CSS
 */
$wp_customize->add_section(
	'dp_custom_css_section', array(
	'title' => __('Additional CSS', 'DigiPress'),
	// 'description' => __('CSS allows you to customize the appearance and layout of your site with code. Separate CSS is saved for each of your themes. In the editing area the Tab key enters a tab character. To move below this area by pressing Tab, press the Esc key followed by the Tab key.'),
	'description_hidden' => true,
	'priority' => 90
));
$id = 'original_css';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	// 'sanitize_callback' => 'wp_kses',
	'capability' => 'edit_css',
	'transport' => 'postMessage'
));
if ( version_compare( $wp_version, '4.9', '>=' ) ) {
	$wp_customize->add_control( new WP_Customize_Code_Editor_Control(
		$wp_customize,
		'dp_theme_options['.$id.']', array(
		'setting'=> 'dp_theme_options['.$id.']',
		'description' => __('Without editing the CSS of this theme directly, you can incorporate the original CSS into this theme.','DigiPress'),
		'code_type'   => 'text/css',
		'editor_settings' => array(
			'codemirror' => array(
				'mode'=> 'text/css'
			)
		),
		'section' => 'dp_custom_css_section'
		)
	));
} else {
	$wp_customize->add_control( new DP_Customize_Custom_CSS_Control(
		$wp_customize,
		'dp_theme_options['.$id.']', array(
		'settings' => 'dp_theme_options['.$id.']',
		'type' => 'textarea',
		'label' => __('Additional CSS', 'DigiPress'),
		'description' => __('Without editing the CSS of this theme directly, you can incorporate the original CSS into this theme.','DigiPress'),
		'section' => 'dp_custom_css_section'
		)
	));
}