<?php
// **********************************************
// Base font setting section
// **********************************************
$wp_customize->add_section(
	'dp_sort_section', array(
	'title' => __('Sort Articles Settings', 'DigiPress'),
	'description' => __('On the top page and each archive page, set whether or not the site viewer can sort the articles and the details about the function.', 'DigiPress'),
	'priority' => 70
));

/**
 * Sortable page
 */
// Top page
$id = 'sort_enable_top';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'fake_title' => __('Sortable pages by visitors', 'DigiPress'),
	'label' => __('Top page', 'DigiPress'),
	'section' => 'dp_sort_section',
	'type' => 'checkbox'
	)
));
// For Selective refresh
if (isset($wp_customize->selective_refresh)){
	$wp_customize->selective_refresh->add_partial('dp_theme_options['.$id.']', array(
		'selector' => '.sort-form-area .sort-form-title',
		'settings' => 'dp_theme_options['.$id.']'
	));
}

// Category page
$id = 'sort_enable_cat';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'label' => __('Category page', 'DigiPress'),
	'section' => 'dp_sort_section',
	'type' => 'checkbox'
	)
));

// Tag page
$id = 'sort_enable_tag';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'label' => __('Tag page', 'DigiPress'),
	'section' => 'dp_sort_section',
	'type' => 'checkbox'
	)
));

// Search result
$id = 'sort_enable_search';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'label' => __('Search results page', 'DigiPress'),
	'section' => 'dp_sort_section',
	'type' => 'checkbox'
	)
));

// Date archive
$id = 'sort_enable_date';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'label' => __('Date archive page', 'DigiPress'),
	'section' => 'dp_sort_section',
	'type' => 'checkbox'
	)
));

// Author archive
$id = 'sort_enable_author';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'label' => __('Author archive page', 'DigiPress'),
	'note' => __('*Category and tag page, you can set the order of articles in advance. To change the default order, please go from the category edit page.', 'DigiPress') . '<p><i class="dashicons-before dashicons-external"></i><a href="edit-tags.php?taxonomy=category" target="_blank">' . sprintf( __('Set by each %s', 'DigiPress'), __('category', 'DigiPress') ) . '</a><br /><i class="dashicons-before dashicons-external"></i><a href="edit-tags.php?taxonomy=post_tag" target="_blank">' . sprintf( __('Set by each %s', 'DigiPress'), __('post tag', 'DigiPress') ) . '</a></p>',
	'section' => 'dp_sort_section',
	'type' => 'checkbox'
	)
));


/**
 * Selectable sort method
 */
// Newest label
$id = 'sort_by_newest_label';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => __($def_options[$id], 'DigiPress'),
	'type' => 'option',
	'sanitize_callback' => 'dp_sanitize_html',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'label' => __('Selectable sort method','DigiPress'),
	'description' => '<span class="customize-control-checkbox"><span class="customize-inside-control-row"><input type="checkbox" value="1" checked="checked" disabled /><label>' . __('Order by newest', 'DigiPress') . ' (' . __('*required', 'DigiPress') . ')</label></span></span>' . __('Display name', 'DigiPress'),
	'section' => 'dp_sort_section',
	'type' => 'text',
	'input_attrs' => array(
		'placeholder' => __($def_options[$id], 'DigiPress'),
		)
	)
));

// Sort by modified
$id = 'sort_by_modified';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'label' => __('Order by modified', 'DigiPress'),
	'section' => 'dp_sort_section',
	'type' => 'checkbox'
	)
));
// Sort label
$id = 'sort_by_modified_label';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => __($def_options[$id], 'DigiPress'),
	'type' => 'option',
	'sanitize_callback' => 'dp_sanitize_html',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'description' => __('Display name', 'DigiPress'),
	'section' => 'dp_sort_section',
	'type' => 'text',
	'input_attrs' => array(
		'placeholder' => __($def_options[$id], 'DigiPress'),
		)
	)
));

// Sort by views
$id = 'sort_by_popular';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'label' => __('Order by views', 'DigiPress'),
	'section' => 'dp_sort_section',
	'type' => 'checkbox'
	)
));
// Sort label
$id = 'sort_by_popular_label';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => __($def_options[$id], 'DigiPress'),
	'type' => 'option',
	'sanitize_callback' => 'dp_sanitize_html',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'description' => __('Display name', 'DigiPress'),
	'section' => 'dp_sort_section',
	'type' => 'text',
	'input_attrs' => array(
		'placeholder' => __($def_options[$id], 'DigiPress'),
		)
	)
));

// Sort by commented count
$id = 'sort_by_comments';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'label' => __('Order by comment count', 'DigiPress'),
	'section' => 'dp_sort_section',
	'type' => 'checkbox'
	)
));
// Sort label
$id = 'sort_by_comments_label';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => __($def_options[$id], 'DigiPress'),
	'type' => 'option',
	'sanitize_callback' => 'dp_sanitize_html',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'description' => __('Display name', 'DigiPress'),
	'section' => 'dp_sort_section',
	'type' => 'text',
	'input_attrs' => array(
		'placeholder' => __($def_options[$id], 'DigiPress'),
		)
	)
));

// Sort by title
$id = 'sort_by_title';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'label' => __('Order by title', 'DigiPress'),
	'section' => 'dp_sort_section',
	'type' => 'checkbox'
	)
));
// Sort label
$id = 'sort_by_title_label';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => __($def_options[$id], 'DigiPress'),
	'type' => 'option',
	'sanitize_callback' => 'dp_sanitize_html',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'description' => __('Display name', 'DigiPress'),
	'section' => 'dp_sort_section',
	'type' => 'text',
	'input_attrs' => array(
		'placeholder' => __($def_options[$id], 'DigiPress'),
		)
	)
));

// Sort by slug
$id = 'sort_by_name';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'label' => __('Order by slug', 'DigiPress'),
	'section' => 'dp_sort_section',
	'type' => 'checkbox'
	)
));
// Sort label
$id = 'sort_by_name_label';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => __($def_options[$id], 'DigiPress'),
	'type' => 'option',
	'sanitize_callback' => 'dp_sanitize_html',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'description' => __('Display name', 'DigiPress'),
	'section' => 'dp_sort_section',
	'type' => 'text',
	'input_attrs' => array(
		'placeholder' => __($def_options[$id], 'DigiPress'),
		)
	)
));