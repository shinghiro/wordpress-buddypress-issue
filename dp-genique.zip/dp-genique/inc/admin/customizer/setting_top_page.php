<?php
// initialize
$id = '';
// **********************************************
// Top page panel
// **********************************************
/**
* get categories for select form
*/
// $select_option = '';
// $categories = get_categories();
//  foreach ($categories as $category) {
// 	$select_option = '<option value="'.$category->cat_ID.'">'.$category->cat_name.'</option>';
// }
/**
 * get custom post type
 */
$post_types = get_post_types(
	array(
		'public'	=> true,
		'_builtin'	=> false),
	'objects'
	);
$cpt_list = array();
foreach ($post_types as $ctype ) {
	$cpt_list += array($ctype->name => $ctype->label);
}
$wp_customize->add_panel(
	'dp_top_page_panel', array(
	'title' => __('Top Page Settings', 'DigiPress'),
	'description' => __('Settings for top page contents.', 'DigiPress'),
	'priority' => 60
));
$wp_customize->add_section(
	'dp_top_page_details_section', array(
	'title' => __('Contents Detail Setting', 'DigiPress'),
	'panel' => 'dp_top_page_panel',
	'priority' => 10
));
$wp_customize->add_section(
	'dp_top_page_infeed_ads_section', array(
	'title' => __('Infeed Ads Setting', 'DigiPress'),
	'panel' => 'dp_top_page_panel',
	'priority' => 20
));

/**
 * Top target contents
 */
$id = 'top_page_main_content';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'label' => __('Target content','DigiPress'),
	'section' => 'dp_top_page_details_section',
	'type' => 'select',
	'choices' => array(
		'default' => __('Recent articles','DigiPress'),
		'cat' => __('Specific category','DigiPress'),
		'custom' => __('Specific custom post type','DigiPress'),
		'page' => __('Specific static page','DigiPress'),
		'none' => __('No contents', 'DigiPress')
			),
	'active_callback' => 'cb_show_top_under_content'
	)
));
// For Selective refresh
if (isset($wp_customize->selective_refresh)){
	$wp_customize->selective_refresh->add_partial('dp_theme_options['.$id.']', array(
		'selector' => '.home #content',
		'settings' => 'dp_theme_options['.$id.']',
		'container_inclusive' => true
	));
}

/**
 * Category lists
 */
$id = 'top_target_cat_ids';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'refresh'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'label' => __('Target categories(ID)','DigiPress'),
	'settings' => 'dp_theme_options['.$id.']',
	'section' => 'dp_top_page_details_section',
	'type' => 'text',
	'active_callback' => 'cb_top_page_main_content'
	)
));
/**
 * Exception
 */
$id = 'top_target_cat_exclude';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'refresh'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'label' => __('Exclude their categories','DigiPress'),
	'section' => 'dp_top_page_details_section',
	'note' => __('*Category ID must be a number.','DigiPress').'<br />'.__('*Use comma between category IDs to set multiple categories.', 'DigiPress'),
	'type' => 'checkbox',
	'active_callback' => 'cb_top_page_main_content'
	)
));

/**
 * Custom post types
 */
$wp_customize->add_setting(
	'dp_theme_options[specific_post_type_index]', array(
	'default' => $def_options['specific_post_type_index'],
	'type' => 'option',
	'transport' => 'refresh'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options[specific_post_type_index]', array(
	'label' => __('Target custom post type','DigiPress'),
	'settings' => 'dp_theme_options[specific_post_type_index]',
	'section' => 'dp_top_page_details_section',
	'type' => 'select',
	'choices' => $cpt_list,
	'active_callback' => 'cb_top_page_main_content'
	)
));

/**
 * Pages
 */
$wp_customize->add_setting(
	'dp_theme_options[specific_page_id]', array(
	'default' => $def_options['specific_page_id'],
	'type' => 'option',
	'transport' => 'refresh'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options[specific_page_id]', array(
	'label' => __('Target static page','DigiPress'),
	'settings' => 'dp_theme_options[specific_page_id]',
	'section' => 'dp_top_page_details_section',
	'type' => 'dropdown-pages',
	'active_callback' => 'cb_top_page_main_content'
	)
));
function cb_top_page_main_content($control){
	$setting = $control->manager->get_setting('dp_theme_options[top_page_main_content]')->value();
	$control_id = $control->id;
	if ($setting === 'cat' && (
			$control_id === 'dp_theme_options[top_target_cat_ids]' ||
			$control_id === 'dp_theme_options[top_target_cat_exclude]'
		)
	) return true;
	if ($setting === 'custom' && $control_id === 'dp_theme_options[specific_post_type_index]') return true;
	if ($setting === 'page' && $control_id === 'dp_theme_options[specific_page_id]') return true;
	return false;
}

/**
 * Post count
 */
$wp_customize->add_setting(
	'dp_theme_options[number_posts_index]', array(
	'default' => $def_options['number_posts_index'],
	'sanitize_callback' => 'absint',
	'type' => 'option',
	'transport' => 'refresh'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options[number_posts_index]', array(
	'label' => __('Number of posts(PC)','DigiPress'),
	'unit' => __('posts/page', 'DigiPress'),
	'section' => 'dp_top_page_details_section',
	'type' => 'number',
	'input_attrs' => array('min' => 1,'max' => 100,'step' => 1),
	'active_callback' => 'cb_show_top_under_content'
	)
));
$wp_customize->add_setting(
	'dp_theme_options[number_posts_index_mobile]', array(
	'default' => $def_options['number_posts_index_mobile'],
	'sanitize_callback' => 'absint',
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options[number_posts_index_mobile]', array(
	'label' => __('Number of posts(Mobile)','DigiPress'),
	'unit' => __('posts/page', 'DigiPress'),
	'section' => 'dp_top_page_details_section',
	'type' => 'number',
	'input_attrs' => array('min' => 1,'max' => 100,'step' => 1),
	'active_callback' => 'cb_show_top_under_content'
	)
));

/**
 * Sort order
 */
$id = 'top_post_orderby';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'refresh'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'label' => __('Sort Order','DigiPress'),
	'section' => 'dp_top_page_details_section',
	'type' => 'select',
	'choices' => array(
		'date' => __('Order by date','DigiPress'),
		'modified' => __('Order by modified','DigiPress'),
		'post_views_count' => __('Order by views','DigiPress'),
		'comment_count' => __('Order by comment count','DigiPress'),
		'title' => __('Order by title','DigiPress'),
		'name' => __('Order by slug','DigiPress'),
		'author' => __('Order by author','DigiPress'),
		'rand' => __('Random order','DigiPress'),
	),
	'active_callback' => 'cb_show_top_under_content'
	)
));

/**
 * Ascending Descending
 */
$id = 'top_post_order';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'refresh'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'section' => 'dp_top_page_details_section',
	'type' => 'radio',
	'choices' => array(
		'ASC' => __('Ascending', 'DigiPress') . ' ' . __('(1,2,3... / a,b,c...)', 'DigiPress'),
		'DESC' => __('Descending', 'DigiPress') . ' ' . __('(3,2,1... / z,y,x...)', 'DigiPress')
		),
	'active_callback' => 'cb_show_top_under_content'
	)
));

/**
 * Main Title
 */
$id = 'top_posts_list_title';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'sanitize_callback' => 'dp_sanitize_html',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'label' => __('Main title','DigiPress'),
	'section' => 'dp_top_page_details_section',
	'type' => 'text',
	'input_attrs' => array(
		'placeholder' => $def_options[$id],
		),
	'active_callback' => 'cb_show_top_under_content'
	)
));
// For Selective refresh
if (isset($wp_customize->selective_refresh)){
	$wp_customize->selective_refresh->add_partial('dp_theme_options['.$id.']', array(
		'selector' => '.lp-top .loop-sec-header .inside-title',
		'settings' => 'dp_theme_options['.$id.']',
		'container_inclusive' => false,
		'render_callback' => function(){
			$options = get_option('dp_theme_options');
			echo '<span>'.$options['top_posts_list_title'].'</span>';
		}
	));
}

/**
 * Layout
 */
$id = 'top_post_show_type';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'label' => __('Layout design','DigiPress'),
	'description' => __('Layout','DigiPress'),
	'section' => 'dp_top_page_details_section',
	'type' => 'select',
	'choices' => array(
		'normal' => __('Standard layout','DigiPress'),
		'portfolio' => __('Portfolio layout','DigiPress'),
		'magazine' => __('Magazine layout','DigiPress'),
		'news' => __('Simple list layout','DigiPress'),
		'simple' => __('Simple list layout','DigiPress') . ' (' . __('with thumbnail', 'DigiPress') . ')'
	),
	'active_callback' => 'cb_show_top_under_content'
	)
));
// For Selective refresh
if (isset($wp_customize->selective_refresh)){
	$wp_customize->selective_refresh->add_partial('dp_theme_options['.$id.']', array(
		'selector' => '#content .loop-section.lp-top .loop-div',
		'settings' => 'dp_theme_options['.$id.']'
	));
}

/**
 * Overlay color
 */
$id = 'top_overlay_color';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'refresh'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'before_text' => __('Overlay color','DigiPress'),
	'section' => 'dp_top_page_details_section',
	'note' => __('*You can set the category color in <a href="edit-tags.php?taxonomy=category" target="_blank">category list page</a>.', 'DigiPress'),
	'type' => 'select',
	'choices' => array(
		'black' => __('Black','DigiPress'),
		'white' => __('White','DigiPress'),
		'pri_color' => __('Primary Color','DigiPress'),
		'cat' => __('Category color','DigiPress')
	),
	'active_callback' => 'cb_show_top_under_content'
	)
));
/**
 * Column of article layout
 */
$id = 'top_loop_col';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'refresh'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'before_text' => __('Number of columns','DigiPress'),
	'section' => 'dp_top_page_details_section',
	'type' => 'select',
	'choices' => array(
		'2' => __('Two columns','DigiPress'),
		'3' => __('Three columns','DigiPress'),
		'4' => __('Four columns(Enable in no-sidebar)','DigiPress'),
		'5' => __('Five columns(Enable in no-sidebar)','DigiPress')
			),
	'active_callback' => 'cb_show_top_under_content'
	)
));


/**
 * Fix height
 */
$id = 'top_fix_article_height';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'refresh'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'label' => __('Fix the thumbnail height','DigiPress'),
	'section' => 'dp_top_page_details_section',
	'type' => 'checkbox',
	'active_callback' => 'cb_show_top_under_content'
	)
));

/**
 * Rounded corners?
 */
$id = 'top_article_round_corner';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'refresh'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'label' => __('Round element corners','DigiPress'),
	'section' => 'dp_top_page_details_section',
	'type' => 'checkbox',
	'active_callback' => 'cb_show_top_under_content'
	)
));

/**
 * Show boxshadow?
 */
$id = 'top_article_box_shadow';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'refresh'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'label' => __('Show box shadow on each article','DigiPress'),
	'section' => 'dp_top_page_details_section',
	'type' => 'checkbox',
	'active_callback' => 'cb_show_top_under_content'
	)
));

/**
 * Altenate post listing
 */
$id = 'top_article_alternately';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'refresh'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'label' => __('Display thumbnails alternately','DigiPress'),
	'section' => 'dp_top_page_details_section',
	'type' => 'checkbox',
	'active_callback' => 'cb_show_top_under_content'
	)
));



/**
 * Custom Design for Magazine cover style
 */
// $id = 'top_magazine_auto_design';
// $wp_customize->add_setting(
// 	'dp_theme_options['.$id.']', array(
// 	'default' => $def_options[$id],
// 	'type' => 'option',
// 	'transport' => 'postMessage'
// ));
// $wp_customize->add_control( new DP_Customize_Control(
// 	$wp_customize,
// 	'dp_theme_options['.$id.']', array(
// 	'label' => __('Custom Magazine style','DigiPress'),
// 	'description' => __('Automation design','DigiPress'),
// 	'separator_top' => true,
// 	'section' => 'dp_top_page_details_section',
// 	'type' => 'select',
// 	'choices' => array(
// 		'' => __('Disable','DigiPress') . ' (' . __('Self-design', 'DigiPress') . ')',
// 		'auto' => __('Enable','DigiPress') . ' (' . __('Based on accent color', 'DigiPress') . ')',
// 		'japanese' => __('Enable','DigiPress') . ' (' . __('Japanese style', 'DigiPress') . ')',
// 			),
// 	'active_callback' => 'cb_show_top_under_content'
// 	)
// ));

/**
 * Magagine frame design
 */
$id = 'top_magazine_cover_frame';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'sanitize_callback' => 'sanitize_text_field',
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control_Radio_Image(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'label' => __('Custom Magazine style','DigiPress'),
	'separator_top' => true,
	// 'separator' => true,
	'description' => __( 'Frame design', 'DigiPress' ),
	'note' => __( 'If you want to change the design for each article, you can customize from "Post Options" on the editor of each article.', 'DigiPress' ),
	'section' => 'dp_top_page_details_section',
	'column' => 3,
	'choices'  => array(
		'' => array(
			'label' => __( 'None', 'DigiPress' ),
			'url'   => '%s/inc/admin/img/mgz-frame-none.jpg'
			),
		'has-frame line-frame __solid' => array(
			'label' => __( 'Solid line', 'DigiPress' ),
			'url'   => '%s/inc/admin/img/mgz-frame-line.jpg'
			),
		'has-frame line-frame __double' => array(
			'label' => __( 'Double line', 'DigiPress' ),
			'url'   => '%s/inc/admin/img/mgz-frame-line-double.jpg'
			),
		'has-frame line-frame __dashed' => array(
			'label' => __( 'Dashed line', 'DigiPress' ),
			'url'   => '%s/inc/admin/img/mgz-frame-line-dashed.jpg'
			),
		'has-frame line-frame __dot' => array(
			'label' => __( 'Dot line', 'DigiPress' ),
			'url'   => '%s/inc/admin/img/mgz-frame-line-dot.jpg'
			),
		'has-frame thick-bd' => array(
			'label' => __( 'Thick border', 'DigiPress' ),
			'url'   => '%s/inc/admin/img/mgz-frame-bd.jpg'
			),
		'has-frame thick-bd no-r no-btm' => array(
			'label' => __( 'Thick border', 'DigiPress' ) . __('(top, left)', 'DigiPress'),
			'url'   => '%s/inc/admin/img/mgz-frame-bd-l-t.jpg'
			),
		'has-frame thick-bd no-l no-btm' => array(
			'label' => __( 'Thick border', 'DigiPress' ) . __('(top, right)', 'DigiPress'),
			'url'   => '%s/inc/admin/img/mgz-frame-bd-r-t.jpg'
			),
		'has-frame thick-bd no-r no-top' => array(
			'label' => __( 'Thick border', 'DigiPress' ) . __('(bottom, left)', 'DigiPress'),
			'url'   => '%s/inc/admin/img/mgz-frame-bd-l-b.jpg'
			),
		'has-frame thick-bd no-l no-top' => array(
			'label' => __( 'Thick border', 'DigiPress' ) . __('(bottom, right)', 'DigiPress'),
			'url'   => '%s/inc/admin/img/mgz-frame-bd-r-b.jpg'
			),
		'has-frame thick-bd no-l no-r no-btm' => array(
			'label' => __( 'Thick border', 'DigiPress' ) . __('(top)', 'DigiPress'),
			'url'   => '%s/inc/admin/img/mgz-frame-bd-t.jpg'
			),
		'has-frame thick-bd no-l no-r no-top' => array(
			'label' => __( 'Thick border', 'DigiPress' ) . __('(bottom)', 'DigiPress'),
			'url'   => '%s/inc/admin/img/mgz-frame-bd-b.jpg'
			),
	),
	'active_callback' => 'cb_show_top_under_content'
	)
));


/**
 * Frame border color
 */
$id = 'top_magazine_cover_frame_color';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage',
	'sanitize_callback' => 'sanitize_hex_color'
));
$wp_customize->add_control( new WP_Customize_Color_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	// 'label' => __('Background Design','DigiPress'),
	'description' => __('Frame color', 'DigiPress'),
	'section' => 'dp_top_page_details_section',
	'active_callback' => 'cb_show_top_under_content'
	)
));

/**
 * Magazine title position
 */
$id = 'top_magazine_title_position';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'sanitize_callback' => 'sanitize_text_field',
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control_Radio_Image(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	// 'label' => __('Site Colmuns Setting','DigiPress'),
	'separator_top' => true,
	'separator' => true,
	'description' => __( 'Title position', 'DigiPress' ),
	'section' => 'dp_top_page_details_section',
	'column' => 3,
	'choices'  => array(
		'' => array(
			'label' => esc_html__( 'Center', 'DigiPress' ),
			'url'   => '%s/inc/admin/img/title-pos-center.jpg'
			),
		'title-pos__top title-pos__l' => array(
			'label' => esc_html__( 'Upper left', 'DigiPress' ),
			'url'   => '%s/inc/admin/img/title-pos-upper-left.jpg'
			),
		'title-pos__top' => array(
			'label' => esc_html__( 'Upper center', 'DigiPress' ),
			'url'   => '%s/inc/admin/img/title-pos-upper-center.jpg'
			),
		'title-pos__top title-pos__r' => array(
			'label' => esc_html__( 'Upper right', 'DigiPress' ),
			'url'   => '%s/inc/admin/img/title-pos-upper-right.jpg'
			),
		'title-pos__btm title-pos__l' => array(
			'label' => esc_html__( 'Bottom left', 'DigiPress' ),
			'url'   => '%s/inc/admin/img/title-pos-bottom-left.jpg'
			),
		'title-pos__btm' => array(
			'label' => esc_html__( 'Bottom center', 'DigiPress' ),
			'url'   => '%s/inc/admin/img/title-pos-bottom-center.jpg'
			),
		'title-pos__btm title-pos__r' => array(
			'label' => esc_html__( 'Bottom right', 'DigiPress' ),
			'url'   => '%s/inc/admin/img/title-pos-bottom-right.jpg'
			),
	),
	'active_callback' => 'cb_show_top_under_content'
	)
));

/**
 * Magazine title background
 */
$id = 'top_magazine_title_back';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'sanitize_callback' => 'sanitize_text_field',
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control_Radio_Image(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	// 'label' => __('Site Colmuns Setting','DigiPress'),
	'separator' => true,
	'description' => __( 'Title background', 'DigiPress' ),
	'section' => 'dp_top_page_details_section',
	'column' => 2,
	'choices'  => array(
		'' => array(
			'label' => esc_html__( 'None', 'DigiPress' ),
			'url'   => '%s/inc/admin/img/title-frame-none.jpg'
			),
		'has-title-back' => array(
			'label' => esc_html__( 'Show', 'DigiPress' ),
			'url'   => '%s/inc/admin/img/title-frame.jpg'
			),
	),
	'active_callback' => 'cb_show_top_under_content'
	)
));

/**
 * Magazine title color
 */
$id = 'top_magazine_title_color';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage',
	'sanitize_callback' => 'sanitize_hex_color'
));
$wp_customize->add_control( new WP_Customize_Color_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	// 'label' => __('Background Design','DigiPress'),
	'description' => __('Title color', 'DigiPress'),
	'section' => 'dp_top_page_details_section',
	'active_callback' => 'cb_show_top_under_content'
	)
));

/**
 * Magazine title background color
 */
$id = 'top_magazine_title_back_color';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage',
	'sanitize_callback' => 'sanitize_hex_color'
));
$wp_customize->add_control( new WP_Customize_Color_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	// 'label' => __('Background Design','DigiPress'),
	'description' => __('Title background color', 'DigiPress'),
	'section' => 'dp_top_page_details_section',
	'active_callback' => 'cb_show_top_under_content'
	)
));

/**
 * Magazine title background color opacity
 */
$id = 'top_magazine_title_back_color_opacity';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'sanitize_callback' => 'absint',
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Range_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'before_text' => __('Title background opacity','DigiPress'),
	'section' => 'dp_top_page_details_section',
	'unit' => '%',
	'type' => 'custom_range',
	'input_attrs' => array(
		'min' => 1,
		'max' => 100,
		'step' => 1
		),
	'active_callback' => 'cb_show_top_under_content'
	)
));

/**
 * Magazine text background with border
 */
$id = 'top_magazine_title_back_border';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'sanitize_callback' => 'sanitize_text_field',
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control_Radio_Image(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	// 'label' => __('Site Colmuns Setting','DigiPress'),
	// 'separator' => true,
	'description' => __( 'Title background border', 'DigiPress' ),
	'section' => 'dp_top_page_details_section',
	'column' => 2,
	'choices'  => array(
		'' => array(
			'label' => __( 'None', 'DigiPress' ),
			'url'   => '%s/inc/admin/img/title-bg-bd-none.jpg'
			),
		'has-title-bd title-back-bd' => array(
			'label' => 'Solid border',
			'url'   => '%s/inc/admin/img/title-bg-bd-solid.jpg'
			),
		'has-title-bd title-back-bd__double' => array(
			'label' => 'Double border',
			'url'   => '%s/inc/admin/img/title-bg-bd-double.jpg'
			),
		'has-title-bd title-back-bd__dashed' => array(
			'label' => 'Dashed border',
			'url'   => '%s/inc/admin/img/title-bg-bd-dashed.jpg'
			),
		'has-title-bd title-back-bd__dot' => array(
			'label' => 'Dot border',
			'url'   => '%s/inc/admin/img/title-bg-bd-dot.jpg'
			),
		),
	'active_callback' => 'cb_show_top_under_content'
	)
));


/**
 * Magazine title shows as bold
 */
$id = 'top_magazine_title_by_bold';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'sanitize_callback' => 'sanitize_text_field',
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control_Radio_Image(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	// 'label' => __('Site Colmuns Setting','DigiPress'),
	'separator_top' => true,
	'separator' => true,
	'description' => __( 'Title font weight', 'DigiPress' ),
	'section' => 'dp_top_page_details_section',
	'column' => 2,
	'choices'  => array(
		'' => array(
			'label' => esc_html__( 'Bold weight', 'DigiPress' ),
			'url'   => '%s/inc/admin/img/title-bold-weight.jpg'
			),
		'title-normal-weight' => array(
			'label' => esc_html__( 'Normal weight', 'DigiPress' ),
			'url'   => '%s/inc/admin/img/title-normal-weight.jpg'
			),
	),
	'active_callback' => 'cb_show_top_under_content'
	)
));

/**
 * Magazine title tilt
 */
$id = 'top_magazine_title_tilt';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'sanitize_callback' => 'sanitize_text_field',
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control_Radio_Image(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	// 'label' => __('Site Colmuns Setting','DigiPress'),
	'separator' => true,
	'description' => __( 'Title tilt', 'DigiPress' ),
	'section' => 'dp_top_page_details_section',
	'column' => 3,
	'choices'  => array(
		'' => array(
			'label' => __( 'None', 'DigiPress' ),
			'url'   => '%s/inc/admin/img/title-tilt-none.jpg'
			),
		'title-tilt' => array(
			'label' => __( 'Upper to right', 'DigiPress' ),
			'url'   => '%s/inc/admin/img/title-tilt1.jpg'
			),
		'title-tilt down-to-r' => array(
			'label' => __( 'Downward to right', 'DigiPress' ),
			'url'   => '%s/inc/admin/img/title-tilt2.jpg'
			),
	),
	'active_callback' => 'cb_show_top_under_content'
	)
));

/**
 * Magazine title shows as serif font
 */
$id = 'top_magazine_text_by_serif';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'sanitize_callback' => 'sanitize_text_field',
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control_Radio_Image(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	// 'label' => __('Site Colmuns Setting','DigiPress'),
	'separator' => true,
	'description' => __( 'Gothic / Mincho', 'DigiPress' ),
	'section' => 'dp_top_page_details_section',
	'column' => 2,
	'choices'  => array(
		'' => array(
			'label' => esc_html__( 'Gothic', 'DigiPress' ),
			'url'   => '%s/inc/admin/img/text-gothic.jpg'
			),
		'serif' => array(
			'label' => esc_html__( 'Mincho', 'DigiPress' ),
			'url'   => '%s/inc/admin/img/text-mincho.jpg'
			),
	),
	'active_callback' => 'cb_show_top_under_content'
	)
));

/**
 * Magazine text vertically
 */
$id = 'top_magazine_text_vertically';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'sanitize_callback' => 'sanitize_text_field',
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control_Radio_Image(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	// 'label' => __('Site Colmuns Setting','DigiPress'),
	'separator' => true,
	'description' => __( 'Writing direction', 'DigiPress' ),
	'section' => 'dp_top_page_details_section',
	'column' => 2,
	'choices'  => array(
		'' => array(
			'label' => esc_html__( 'Horizontal writing', 'DigiPress' ),
			'url'   => '%s/inc/admin/img/text-horizontally.jpg'
			),
		'txt-vertical' => array(
			'label' => esc_html__( 'Vertical writing', 'DigiPress' ),
			'url'   => '%s/inc/admin/img/text-vertically.jpg'
			),
	),
	'active_callback' => 'cb_show_top_under_content'
	)
));


/**
 * Magazine date design
 */
$id = 'top_magazine_date_design';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'sanitize_callback' => 'sanitize_text_field',
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control_Radio_Image(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	// 'label' => __('Site Colmuns Setting','DigiPress'),
	'separator' => true,
	'description' => __( 'Date design', 'DigiPress' ),
	'section' => 'dp_top_page_details_section',
	'column' => 2,
	'choices'  => array(
		'date1' => array(
			'label' => '#1',
			'url'   => '%s/inc/admin/img/magazine-date1.jpg'
			),
		'date2' => array(
			'label' => '#2',
			'url'   => '%s/inc/admin/img/magazine-date2.jpg'
			),
		'date3' => array(
			'label' => '#3',
			'url'   => '%s/inc/admin/img/magazine-date3.jpg'
			),
		'date4' => array(
			'label' => '#4',
			'url'   => '%s/inc/admin/img/magazine-date4.jpg'
			),
		),
	'active_callback' => 'cb_show_top_under_content'
	)
));

/**
 * Magazine accent shape
 */
$id = 'top_magazine_accent_shape';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'sanitize_callback' => 'sanitize_text_field',
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control_Radio_Image(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	// 'label' => __('Site Colmuns Setting','DigiPress'),
	'description' => __( 'Accent shape', 'DigiPress' ),
	'section' => 'dp_top_page_details_section',
	'column' => 3,
	'choices'  => array(
		'' => array(
			'label' => __('None', 'DigiPress'),
			'url'   => '%s/inc/admin/img/magazine-accent-shape-none.png'
			),
		'has-acc-shape acc__shape1' => array(
			'label' => '#1',
			'url'   => '%s/inc/admin/img/magazine-accent-shape1.png'
			),
		'has-acc-shape acc__shape2' => array(
			'label' => '#2',
			'url'   => '%s/inc/admin/img/magazine-accent-shape2.png'
			),
		'has-acc-shape acc__shape3' => array(
			'label' => '#3',
			'url'   => '%s/inc/admin/img/magazine-accent-shape3.png'
			),
		'has-acc-shape acc__shape4' => array(
			'label' => '#4',
			'url'   => '%s/inc/admin/img/magazine-accent-shape4.png'
			),
		'has-acc-shape acc__shape5' => array(
			'label' => '#5',
			'url'   => '%s/inc/admin/img/magazine-accent-shape5.png'
			),
		'has-acc-shape acc__shape6' => array(
			'label' => '#6',
			'url'   => '%s/inc/admin/img/magazine-accent-shape6.png'
			),
		'has-acc-shape acc__shape7' => array(
			'label' => '#7',
			'url'   => '%s/inc/admin/img/magazine-accent-shape7.png'
			),
		'has-acc-shape acc__shape8' => array(
			'label' => '#8',
			'url'   => '%s/inc/admin/img/magazine-accent-shape8.png'
			),
		),
	'active_callback' => 'cb_show_top_under_content'
	)
));

/**
 * Magazine accent shape color
 */
$id = 'top_magazine_accent_shape_color';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage',
	'sanitize_callback' => 'sanitize_hex_color'
));
$wp_customize->add_control( new WP_Customize_Color_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	// 'label' => __('Background Design','DigiPress'),
	'description' => __('Accent shape color', 'DigiPress'),
	'section' => 'dp_top_page_details_section',
	'active_callback' => 'cb_show_top_under_content'
	)
));

/**
 * Magazine accent shape color opacity
 */
$id = 'top_magazine_accent_shape_opacity';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'sanitize_callback' => 'absint',
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Range_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'before_text' => __('Accent shape opacity','DigiPress'),
	'section' => 'dp_top_page_details_section',
	'unit' => '%',
	'type' => 'custom_range',
	'input_attrs' => array(
		'min' => 1,
		'max' => 100,
		'step' => 1
		),
	'active_callback' => 'cb_show_top_under_content'
	)
));


/**
 * Enable article filter
 */
$id = 'enable_loop_article_filter';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'refresh'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'fake_title' => __('Display filtering form','DigiPress'),
	'label' => __('Enable filtering by category','DigiPress'),
	'section' => 'dp_top_page_details_section',
	'type' => 'checkbox',
	'active_callback' => 'cb_show_top_under_content'
	)
));

/**
 * Exclude categories for filter
 */
$id = 'exclude_cats_filter';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'sanitize_callback' => 'sanitize_text_field',
	'transport' => 'refresh'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'before_text' => __('Excluded categories (ID) from filtering','DigiPress'),
	'note' => __('*Category ID must be a number.','DigiPress').'<br />'.__('*Use comma between category IDs to set multiple categories.', 'DigiPress'),
	'section' => 'dp_top_page_details_section',
	'type' => 'text',
	'input_attrs' => array(
		'placeholder' => $def_options[$id],
		),
	'active_callback' => 'cb_show_top_under_content'
	)
));


/**
 * Meta info
 */
$id = 'top_archive_list_date';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'refresh'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'fake_title' => __('Post meta info setting','DigiPress'),
	'label' => __('Show posted date','DigiPress'),
	'section' => 'dp_top_page_details_section',
	'type' => 'checkbox',
	'active_callback' => 'cb_show_top_under_content'
	)
));
$id = 'top_archive_list_author';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'refresh'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'label' => __('Show author name','DigiPress'),
	'section' => 'dp_top_page_details_section',
	'type' => 'checkbox',
	'active_callback' => 'cb_show_top_under_content'
	)
));
$id = 'top_archive_list_cat';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'refresh'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'label' => __('Show category','DigiPress'),
	'section' => 'dp_top_page_details_section',
	'type' => 'checkbox',
	'active_callback' => 'cb_show_top_under_content'
	)
));
$id = 'top_archive_list_views';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'refresh'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'label' => __('Show page views','DigiPress'),
	'section' => 'dp_top_page_details_section',
	'type' => 'checkbox',
	'active_callback' => 'cb_show_top_under_content'
	)
));
$id = 'likes_number_after_title_top';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'refresh'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'label' => __('Show Facebook likes','DigiPress'),
	'section' => 'dp_top_page_details_section',
	'type' => 'checkbox',
	'active_callback' => 'cb_show_top_under_content'
	)
));
$id = 'tweets_number_after_title_top';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'refresh'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'label' => __('Show tweeted counts','DigiPress').' (*)',
	'section' => 'dp_top_page_details_section',
	'type' => 'checkbox',
	'active_callback' => 'cb_show_top_under_content'
	)
));
$id = 'hatebu_number_after_title_top';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'refresh'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'label' => __('Show hatena bookmark counts','DigiPress'),
	'note' => __('*It is necessary to register the site in the following service in advance to acquire the number of tweets.','DigiPress').'<div><i class="dashicons-before dashicons-external"></i><a href="https://jsoon.digitiminimi.com/" target="_blank">count.jsoon</a></div>',
	'section' => 'dp_top_page_details_section',
	'type' => 'checkbox',
	'active_callback' => 'cb_show_top_under_content'
	)
));
$id = 'top_article_excerpt_length';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'sanitize_callback' => 'absint',
	'type' => 'option',
	'transport' => 'refresh'
));
$wp_customize->add_control( new DP_Customize_Range_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'label' => __('Excerpt length','DigiPress'),
	'section' => 'dp_top_page_details_section',
	'unit' => __('words','DigiPress'),
	'type' => 'custom_range',
	'input_attrs' => array(
		'min' => 0,
		'max' => 320,
		'step' => 1
		),
	'active_callback' => 'cb_show_top_under_content'
	)
));
// read more
$id = 'top_readmore_str';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'sanitize_callback' => 'dp_sanitize_html',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'label' => __('Read more label(Each posts)','DigiPress'),
	'section' => 'dp_top_page_details_section',
	'type' => 'text',
	'input_attrs' => array(
		'placeholder' => $def_options[$id],
		),
	'active_callback' => 'cb_show_top_under_content'
	)
));
// For Selective refresh
if (isset($wp_customize->selective_refresh)){
	$wp_customize->selective_refresh->add_partial('dp_theme_options['.$id.']', array(
		'selector' => '.loop-section.lp-top .more-link>a',
		'settings' => 'dp_theme_options['.$id.']',
		'container_inclusive' => false,
		'render_callback' => function(){
			$options = get_option('dp_theme_options');
			echo '<span>'.$options['top_readmore_str'].'</span>';
		}
	));
}

// Navigation text to next page
$id = 'navigation_text_to_2page_top';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'sanitize_callback' => 'dp_sanitize_html',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'label' => __('Label for second page','DigiPress'),
	'section' => 'dp_top_page_details_section',
	'type' => 'text',
	'input_attrs' => array(
		'placeholder' => $def_options[$id],
		),
	'active_callback' => 'cb_show_top_under_content'
	)
));
// For Selective refresh
if (isset($wp_customize->selective_refresh)){
	$wp_customize->selective_refresh->add_partial('dp_theme_options['.$id.']', array(
		'selector' => 'body.home .nav_to_paged>a',
		'settings' => 'dp_theme_options['.$id.']',
		'container_inclusive' => false,
		'render_callback' => function(){
			$options = get_option('dp_theme_options');
			echo '<span>'.$options['navigation_text_to_2page_top'].'</span>';
		}
	));
}

/**
 * Infeed Ads setting in top page
 */
$id = 'top_infeed_ads_code';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'refresh'
));
if ( version_compare( $wp_version, '4.9', '>=' ) ) {
	$wp_customize->add_control( new WP_Customize_Code_Editor_Control(
		$wp_customize,
		'dp_theme_options['.$id.']', array(
		'setting'=> 'dp_theme_options['.$id.']',
		'label' => __('Ads code(PC)','DigiPress'),
		'code_type' => 'text/x-scss',
		'section' => 'dp_top_page_infeed_ads_section'
		)
	));
} else {
	$wp_customize->add_control( new DP_Customize_Textarea_Control(
		$wp_customize,
		'dp_theme_options['.$id.']', array(
		'settings' => 'dp_theme_options['.$id.']',
		'label' => __('Ads code(PC)','DigiPress'),
		'other_class' => 'dp_code_textarea html-head code',
		'rows' => 10,
		'section' => 'dp_top_page_infeed_ads_section',
		'type' => 'textarea'
		)
	));
}
$id = 'top_infeed_ads_order';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'sanitize_callback' => 'sanitize_text_field',
	'transport' => 'refresh'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'before_text' => __('Numbers of insert ads order(PC)','DigiPress'),
	'note' => __('*Numbers should be specified as non multibyte.','DigiPress').'<br />'.__('*You need using comma with order number to set multiple order.','DigiPress'),
	'separator' => true,
	'section' => 'dp_top_page_infeed_ads_section',
	'type' => 'text',
	'input_attrs' => array(
		'placeholder' => '3,7',
		)
	)
));
// For Mobile
$id = 'top_infeed_ads_code_mobile';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'refresh'
));
if ( version_compare( $wp_version, '4.9', '>=' ) ) {
	$wp_customize->add_control( new WP_Customize_Code_Editor_Control(
		$wp_customize,
		'dp_theme_options['.$id.']', array(
		'setting'=> 'dp_theme_options['.$id.']',
		'label' => __('Ads code(Mobile)','DigiPress'),
		'code_type' => 'text/x-scss',
		'section' => 'dp_top_page_infeed_ads_section'
		)
	));
} else {
	$wp_customize->add_control( new DP_Customize_Textarea_Control(
		$wp_customize,
		'dp_theme_options['.$id.']', array(
		'settings' => 'dp_theme_options['.$id.']',
		'label' => __('Ads code(Mobile)','DigiPress'),
		'other_class' => 'dp_code_textarea html-head code',
		'rows' => 10,
		'section' => 'dp_top_page_infeed_ads_section',
		'type' => 'textarea'
		)
	));
}
$id = 'top_infeed_ads_order_mb';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'sanitize_callback' => 'sanitize_text_field',
	'transport' => 'refresh'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'before_text' => __('Numbers of insert ads order(Mobile)','DigiPress'),
	'note' => __('*Numbers should be specified as non multibyte.','DigiPress').'<br />'.__('*You need using comma with order number to set multiple order.','DigiPress'),
	'section' => 'dp_top_page_infeed_ads_section',
	'type' => 'text',
	'input_attrs' => array(
		'placeholder' => '3,6',
		)
	)
));

/**
 * Callback
 */
function cb_show_top_under_content($control) {
	$target = $control->manager->get_setting('dp_theme_options[top_page_main_content]')->value();
	$layout = $control->manager->get_setting('dp_theme_options[top_post_show_type]')->value();
	$text_vertically = $control->manager->get_setting('dp_theme_options[top_magazine_text_vertically]')->value();
	$title_back = $control->manager->get_setting('dp_theme_options[top_magazine_title_back]')->value();
	// $magazine_auto_design = $control->manager->get_setting('dp_theme_options[top_magazine_auto_design]')->value();
	$control_id = $control->id;

	$result = true;

	if (($target === 'none' || $target === 'page') && $control_id !== 'dp_theme_options[top_page_main_content]'){
		$result = false;
	}
	if ($target !== 'default' && (
		$control_id === 'dp_theme_options[enable_loop_article_filter]' ||
		$control_id === 'dp_theme_options[exclude_cats_filter]'
		)
	) $result = false;
	if ($target === 'custom' && (
		$control_id === 'dp_theme_options[top_post_show_type]' ||
		$control_id === 'dp_theme_options[top_overlay_color]' ||
		$control_id === 'dp_theme_options[top_loop_col]' ||
		$control_id === 'dp_theme_options[enable_loop_article_filter]' ||
		$control_id === 'dp_theme_options[exclude_cats_filter]' ||
		$control_id === 'dp_theme_options[top_fix_article_height]'
		)
	) $result = false;

	if ($layout === 'normal' && (
		$control_id === 'dp_theme_options[top_loop_col]' ||
		$control_id === 'dp_theme_options[enable_loop_article_filter]' ||
		$control_id === 'dp_theme_options[exclude_cats_filter]' ||
		$control_id === 'dp_theme_options[top_fix_article_height]' ||
		$control_id === 'dp_theme_options[top_magazine_cover_frame]' ||
		$control_id === 'dp_theme_options[top_magazine_cover_frame_color]' ||
		$control_id === 'dp_theme_options[top_magazine_title_position]' ||
		$control_id === 'dp_theme_options[top_magazine_title_tilt]' ||
		$control_id === 'dp_theme_options[top_magazine_text_by_serif]' ||
		$control_id === 'dp_theme_options[top_magazine_text_vertically]' ||
		$control_id === 'dp_theme_options[top_magazine_date_design]' ||
		$control_id === 'dp_theme_options[top_magazine_accent_shape]' ||
		$control_id === 'dp_theme_options[top_magazine_accent_shape_color]' ||
		$control_id === 'dp_theme_options[top_magazine_accent_shape_opacity]' ||
		$control_id === 'dp_theme_options[top_magazine_title_color]' ||
		$control_id === 'dp_theme_options[top_magazine_title_by_bold]' ||
		$control_id === 'dp_theme_options[top_magazine_title_back]' ||
		$control_id === 'dp_theme_options[top_magazine_title_back_color]' ||
		$control_id === 'dp_theme_options[top_magazine_title_back_border]' ||
		$control_id === 'dp_theme_options[top_magazine_title_back_color_opacity]'
		)
	) $result = false;
	if ($layout === 'portfolio' && (
		$control_id === 'dp_theme_options[top_article_excerpt_length]' ||
		$control_id === 'dp_theme_options[top_readmore_str]' ||
		$control_id === 'dp_theme_options[top_article_alternately]' ||
		$control_id === 'dp_theme_options[top_magazine_cover_frame]' ||
		$control_id === 'dp_theme_options[top_magazine_cover_frame_color]' ||
		$control_id === 'dp_theme_options[top_magazine_title_position]' ||
		$control_id === 'dp_theme_options[top_magazine_title_tilt]' ||
		$control_id === 'dp_theme_options[top_magazine_text_by_serif]' ||
		$control_id === 'dp_theme_options[top_magazine_text_vertically]' ||
		$control_id === 'dp_theme_options[top_magazine_date_design]' ||
		$control_id === 'dp_theme_options[top_magazine_accent_shape]' ||
		$control_id === 'dp_theme_options[top_magazine_accent_shape_color]' ||
		$control_id === 'dp_theme_options[top_magazine_accent_shape_opacity]' ||
		$control_id === 'dp_theme_options[top_magazine_title_color]' ||
		$control_id === 'dp_theme_options[top_magazine_title_by_bold]' ||
		$control_id === 'dp_theme_options[top_magazine_title_back]' ||
		$control_id === 'dp_theme_options[top_magazine_title_back_color]' ||
		$control_id === 'dp_theme_options[top_magazine_title_back_border]' ||
		$control_id === 'dp_theme_options[top_magazine_title_back_color_opacity]'
		)
	) $result = false;
	if ( $layout === 'magazine' && (
		$control_id === 'dp_theme_options[top_fix_article_height]' ||
		$control_id === 'dp_theme_options[top_overlay_color]' ||
		$control_id === 'dp_theme_options[top_article_round_corner]' ||
		$control_id === 'dp_theme_options[top_article_box_shadow]' ||
		$control_id === 'dp_theme_options[top_article_alternately]'
		)
	) $result = false;
	if ( ( $layout === 'news' ||  $layout === 'simple' ) && (
		$control_id === 'dp_theme_options[top_loop_col]' ||
		$control_id === 'dp_theme_options[top_article_round_corner]' ||
		$control_id === 'dp_theme_options[top_article_box_shadow]' ||
		$control_id === 'dp_theme_options[enable_loop_article_filter]' ||
		$control_id === 'dp_theme_options[exclude_cats_filter]' ||
		$control_id === 'dp_theme_options[top_fix_article_height]' ||
		$control_id === 'dp_theme_options[top_overlay_color]' ||
		$control_id === 'dp_theme_options[top_archive_list_views]' ||
		$control_id === 'dp_theme_options[likes_number_after_title_top]' ||
		$control_id === 'dp_theme_options[tweets_number_after_title_top]' ||
		$control_id === 'dp_theme_options[hatebu_number_after_title_top]' ||
		$control_id === 'dp_theme_options[top_article_excerpt_length]' ||
		$control_id === 'dp_theme_options[top_readmore_str]' ||
		$control_id === 'dp_theme_options[top_article_alternately]' ||
		$control_id === 'dp_theme_options[top_magazine_cover_frame]' ||
		$control_id === 'dp_theme_options[top_magazine_cover_frame_color]' ||
		$control_id === 'dp_theme_options[top_magazine_title_position]' ||
		$control_id === 'dp_theme_options[top_magazine_title_tilt]' ||
		$control_id === 'dp_theme_options[top_magazine_text_by_serif]' ||
		$control_id === 'dp_theme_options[top_magazine_text_vertically]' ||
		$control_id === 'dp_theme_options[top_magazine_date_design]' ||
		$control_id === 'dp_theme_options[top_magazine_accent_shape]' ||
		$control_id === 'dp_theme_options[top_magazine_accent_shape_color]' ||
		$control_id === 'dp_theme_options[top_magazine_accent_shape_opacity]' ||
		$control_id === 'dp_theme_options[top_magazine_title_color]' ||
		$control_id === 'dp_theme_options[top_magazine_title_by_bold]' ||
		$control_id === 'dp_theme_options[top_magazine_title_back]' ||
		$control_id === 'dp_theme_options[top_magazine_title_back_color]' ||
		$control_id === 'dp_theme_options[top_magazine_title_back_border]' ||
		$control_id === 'dp_theme_options[top_magazine_title_back_color_opacity]'
		)
	) $result = false;


	// if ( ( $layout == 'magazine' && !empty($magazine_auto_design) ) && (
	// 	$control_id === 'dp_theme_options[top_magazine_cover_frame]' ||
	// 	$control_id === 'dp_theme_options[top_magazine_cover_frame_color]' ||
	// 	$control_id === 'dp_theme_options[top_magazine_title_position]' ||
	// 	$control_id === 'dp_theme_options[top_magazine_title_tilt]' ||
	// 	$control_id === 'dp_theme_options[top_magazine_text_by_serif]' ||
	// 	$control_id === 'dp_theme_options[top_magazine_text_vertically]' ||
	// 	$control_id === 'dp_theme_options[top_magazine_date_design]' ||
	// 	$control_id === 'dp_theme_options[top_magazine_accent_shape]' ||
	// 	$control_id === 'dp_theme_options[top_magazine_accent_shape_color]' ||
	// 	$control_id === 'dp_theme_options[top_magazine_accent_shape_opacity]' ||
	// 	$control_id === 'dp_theme_options[top_magazine_title_color]' ||
	// 	$control_id === 'dp_theme_options[top_magazine_title_by_bold]' ||
	// 	$control_id === 'dp_theme_options[top_magazine_title_back]' ||
	// 	$control_id === 'dp_theme_options[top_magazine_title_back_color]' ||
	// 	$control_id === 'dp_theme_options[top_magazine_title_back_border]' ||
	// 	$control_id === 'dp_theme_options[top_magazine_title_back_color_opacity]'
	// ) ) $result = false;


	if ( ( $layout == 'magazine' && $text_vertically ) && (
		$control_id === 'dp_theme_options[top_magazine_title_position]'
		)
	) $result = false;

	if ( ( $layout == 'magazine' && empty( $title_back ) ) && (
		$control_id === 'dp_theme_options[top_magazine_title_back_color]' ||
		$control_id === 'dp_theme_options[top_magazine_title_back_color_opacity]' ||
		$control_id === 'dp_theme_options[top_magazine_title_back_border]'
		)
	) $result = false;

	return $result;
}