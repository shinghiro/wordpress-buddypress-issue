<?php
// **********************************************
// Single page section
// **********************************************
$wp_customize->add_panel(
	'dp_single_page_panel', array(
	'title' => __('Single Page Settings', 'DigiPress'),
	'description' => __('Settings for single page contents.', 'DigiPress'),
	'priority' => 66
));

/**
 * Eyecatch section
 */
$wp_customize->add_section(
	'dp_single_page_eyecatch_section', array(
	'title' => __('Eyecatch Setting', 'DigiPress'),
	'description' => '',
	'panel' => 'dp_single_page_panel',
	'priority' => 1
));
/**
 * Show eyecatch 
 */
$id = 'show_eyecatch_first';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'refresh'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'label' => __("Show eyecatch on top of single post",'DigiPress'),
	'note' => __('*You can select this option in every post options too.','DigiPress'),
	'section' => 'dp_single_page_eyecatch_section',
	'type' => 'checkbox'
	)
));

/**
 * Table of Contents section
 */
$wp_customize->add_section(
	'dp_single_page_toc_section', array(
	'title' => __('Table of Contents Setting', 'DigiPress'),
	'description' => __('Extract the headings (h1 to h6) in the text of the post page, and automatically create and display a table of contents (TOC) for the text.', 'DigiPress'),
	'panel' => 'dp_single_page_panel',
	'priority' => 10
));

// toc position or hide
$id = 'toc_position';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'refresh'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'label' => __('Display position', 'DigiPress'),
	'section' => 'dp_single_page_toc_section',
	'note' => __('*Note: Even if you use this option to automatically display the table of contents at the top of the article as a setting common to sites, you can hide the table of contents by article in the post option of each article.', 'DigiPress') . '<br />' . __('*Note: If you do not want to automatically display the table of contents as a common setting with this option, and you want to display the table of contents in any part of the text individually for each article, insert a short code ([dp_toc]) in the text You can view the table of contents manually.', 'DigiPress'),
	'type' => 'select',
	'choices' => array(
		'none' => __('Hide', 'DigiPress'),
		'top' => __('Head of the article','DigiPress'),
		'before_first_h' =>  __('Before first heading','DigiPress'),
		'right_float' => __('Fixed on right edge of screen','DigiPress')
		)
	)
));
// For Selective refresh
if (isset($wp_customize->selective_refresh)){
	$wp_customize->selective_refresh->add_partial('dp_theme_options['.$id.']', array(
		'selector' => '.dp_toc_container',
		'settings' => 'dp_theme_options['.$id.']'
	));
}

// toc position or hide
$id = 'toc_get_h_tag';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'refresh'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'label' => __('Display condition', 'DigiPress'),
	'description' => __('Target heading', 'DigiPress'),
	'section' => 'dp_single_page_toc_section',
	'type' => 'select',
	'choices' => array(
		'1' => sprintf(__('From h%s tag', 'DigiPress'), '1'),
		'2' => sprintf(__('From h%s tag', 'DigiPress'), '2'),
		'3' =>  sprintf(__('From h%s tag', 'DigiPress'), '3'),
		'4' => sprintf(__('From h%s tag', 'DigiPress'), '4'),
		'5' => sprintf(__('From h%s tag', 'DigiPress'), '5'),
		'6' => sprintf(__('From h%s tag', 'DigiPress'), '6')
		)
	)
));

// Minumum head count
$id = 'toc_min_h_count';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'sanitize_callback' => 'absint',
	'type' => 'option',
	'transport' => 'refresh'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'description' => __('Minumum heading count','DigiPress'),
	'unit' => __('headings over','DigiPress'),
	'section' => 'dp_single_page_toc_section',
	'type' => 'number',
	'input_attrs' => array('min' => 2,'max' => 500,'step' => 1)
	)
));

// Whether toc title show
$id = 'toc_show_main_title';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'refresh'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'fake_title' => __('TOC styles', 'DigiPress'),
	'label' => __('Show the title', 'DigiPress'),
	'section' => 'dp_single_page_toc_section',
	'type' => 'checkbox'
	)
));

// TOC title
$id = 'toc_main_title';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'sanitize_callback' => 'dp_sanitize_html',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'description' => __('TOC title','DigiPress'),
	'section' => 'dp_single_page_toc_section',
	'type' => 'text',
	'input_attrs' => array(
		'placeholder' => $def_options[$id],
		),
	'active_callback' => 'cb_single_post_toc'
	)
));
// For Selective refresh
if (isset($wp_customize->selective_refresh)){
	$wp_customize->selective_refresh->add_partial('dp_theme_options['.$id.']', array(
		'selector' => '.dp_toc_container .toc_title_block .toc_title',
		'settings' => 'dp_theme_options['.$id.']',
		'container_inclusive' => false,
		'render_callback' => function(){
			$options = get_option('dp_theme_options');
			echo $options['toc_main_title'];
		}
	));
}

// Allow user toggle
$id = 'toc_allow_user_toggle';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'refresh'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'label' => __('Allow visitors to show or hide the TOC', 'DigiPress'),
	'section' => 'dp_single_page_toc_section',
	'type' => 'checkbox',
	'active_callback' => 'cb_single_post_toc'
	)
));

// Close TOC as default
$id = 'toc_close_default';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'refresh'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'label' => __('Collapse the TOC when the page is displayed', 'DigiPress'),
	'section' => 'dp_single_page_toc_section',
	'type' => 'checkbox',
	'active_callback' => 'cb_single_post_toc'
	)
));

// Exclude categories in TOC
$id = 'toc_except_class';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'sanitize_callback' => 'sanitize_text_field',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'label' => __('Heading classes to exclude', 'DigiPress'),
	'note' => __('*Note:Use comma(,) to specify several classes.','DigiPress'),
	'section' => 'dp_single_page_toc_section',
	'type' => 'text',
	'input_attrs' => array(
		'placeholder' => 'no-toc,ignore' . __('...etc', 'DigiPress'),
		)
	)
));

// Scroll top padding (PC)
$id = 'toc_add_scroll_top';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'sanitize_callback' => 'absint',
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'label' => __('Scroll top padding adjustment', 'DigiPress'),
	'description' => __('Top padding', 'DigiPress') . ' (PC)',
	'unit' => 'px',
	'section' => 'dp_single_page_toc_section',
	'type' => 'number',
	'input_attrs' => array('min' => 0,'max' => 1000,'step' => 1)
	)
));

// Scroll top padding (Mobile)
$id = 'toc_add_scroll_top_mobile';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'sanitize_callback' => 'absint',
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'description' => __('Top padding','DigiPress') . ' ' . __('(Mobile)', 'DigiPress'),
	'unit' => 'px',
	'note' => __('*Note: If the header bar position is fixed, etc., and you do not want to cover the content at the top when scrolling from the table of contents to the heading, shift the scroll position at the top by the height specified here.', 'DigiPress'),
	'section' => 'dp_single_page_toc_section',
	'type' => 'number',
	'input_attrs' => array('min' => 0,'max' => 1000,'step' => 1)
	)
));

/**
 * TOC callback
 */
function cb_single_post_toc($control){
	$control_id = $control->id;
	$show_toc_title = $control->manager->get_setting('dp_theme_options[toc_show_main_title]')->value();
	$allow_user_toggle = $control->manager->get_setting('dp_theme_options[toc_allow_user_toggle]')->value();

	if ( (bool)$show_toc_title && ( 
		$control_id === 'dp_theme_options[toc_main_title]' ||
		$control_id === 'dp_theme_options[toc_allow_user_toggle]'
	) ) {
		return true;
	}

	if ( (bool)$show_toc_title && (bool)$allow_user_toggle && $control_id === 'dp_theme_options[toc_close_default]' ) {
		return true;
	}

	return false;
}


/**
 * Date section
 */
$wp_customize->add_section(
	'dp_single_page_posted_date_section', array(
	'title' => __('Posted Date Setting', 'DigiPress'),
	'description' => '',
	'panel' => 'dp_single_page_panel',
	'priority' => 20
));
/**
 * Show post date
 */
$id = 'show_pubdate_on_meta_post';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'refresh'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'label' => __('Single post', 'DigiPress'),
	'section' => 'dp_single_page_posted_date_section',
	'type' => 'select',
	'choices' => array(
		'hide' => __('Hide', 'DigiPress'),
		'meta_top' => __('Show top meta area','DigiPress'),
		'meta_bottom' =>  __('Show bottom meta area','DigiPress'),
		'meta_both' => __('Show both meta area','DigiPress')
		)
	)
));

$id = 'show_pubdate_on_meta_page';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'refresh'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'label' => __('Static page', 'DigiPress'),
	'section' => 'dp_single_page_posted_date_section',
	'type' => 'select',
	'choices' => array(
		'hide' => __('Hide', 'DigiPress'),
		'meta_top' => __('Show top meta area','DigiPress'),
		'meta_bottom' => __('Show bottom meta area','DigiPress'),
		'meta_both' => __('Show both meta area','DigiPress')
		)
	)
));

$id = 'date_reckon_mode';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'refresh'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'label' => __('Replace to counting from posted date', 'DigiPress'),
	'section' => 'dp_single_page_posted_date_section',
	'type' => 'checkbox'
	)
));

$id = 'show_last_update';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'refresh'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'label' => __('Show modified date', 'DigiPress'),
	'section' => 'dp_single_page_posted_date_section',
	'type' => 'checkbox'
	)
));

// Only updated
$id = 'show_only_last_update';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'refresh'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'label' => __('Hide post date and show only modified date', 'DigiPress'),
	'section' => 'dp_single_page_posted_date_section',
	'type' => 'checkbox',
	'active_callback' => 'cb_dp_post_meta'
	)
));
function cb_dp_post_meta($control){
	$control_id = $control->id;
	$show_last_update = $control->manager->get_setting('dp_theme_options[show_last_update]')->value();

	if ( $control_id === 'dp_theme_options[show_only_last_update]' && $show_last_update ){
		return true;
	}

	return false;
}

/**
 * Category tags section
 */
$wp_customize->add_section(
	'dp_single_page_category_tags_section', array(
	'title' => __('Display Category and Tag', 'DigiPress'),
	'description' => '',
	'panel' => 'dp_single_page_panel',
	'priority' => 30
));
/**
 * Show category
 */
$id = 'show_cat_in_single_post';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'refresh'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'label' => __('Display category','DigiPress'),
	'section' => 'dp_single_page_category_tags_section',
	'type' => 'select',
	'choices' => array(
		'hide' => __('Hide', 'DigiPress'),
		'meta_top' => __('Show top meta area','DigiPress'),
		'meta_bottom' =>  __('Show bottom meta area','DigiPress'),
		'meta_both' => __('Show both meta area','DigiPress')
		)
	)
));
/**
 * Show tags
 */
$id = 'show_tags';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'refresh'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'fake_title' => __('Display tag links', 'DigiPress'),
	'label' => __('Show tags in bottom meta area', 'DigiPress'),
	'section' => 'dp_single_page_category_tags_section',
	'type' => 'checkbox'
	)
));

/**
 * Other meta
 */
$wp_customize->add_section(
	'dp_single_page_other_meta_section', array(
	'title' => __('Display Views and Read Time', 'DigiPress'),
	'description' => '',
	'panel' => 'dp_single_page_panel',
	'priority' => 40
));
/**
 * Show page views
 */
$id = 'show_views_on_meta';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'refresh'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'label' => __('Display page views', 'DigiPress'),
	'section' => 'dp_single_page_other_meta_section',
	'type' => 'select',
	'choices' => array(
		'hide' => __('Hide', 'DigiPress'),
		'meta_top' => __('Show top meta area','DigiPress'),
		'meta_bottom' =>  __('Show bottom meta area','DigiPress'),
		'meta_both' => __('Show both meta area','DigiPress')
		)
	)
));

/**
 * Show the time for reading
 */
$id = 'time_for_reading';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'refresh'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'fake_title' => __('Display the time for reading', 'DigiPress'),
	'label' => __('Show the time for reading', 'DigiPress'),
	'section' => 'dp_single_page_other_meta_section',
	'type' => 'checkbox'
	)
));

/**
 * SNS share icon
 */
$wp_customize->add_section(
	'dp_single_page_sns_share_icon_section', array(
	'title' => __('Display SNS share buttons', 'DigiPress'),
	'description' => '',
	'panel' => 'dp_single_page_panel',
	'priority' => 50
));
/**
 * Show SNS share buttons for single page
 */
$id = 'show_sns_button_on_meta_post';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'refresh'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'fake_title' => __('Display target', 'DigiPress'),
	'label' => __('Display on single page','DigiPress'),
	'section' => 'dp_single_page_sns_share_icon_section',
	'type' => 'checkbox'
	)
));

/**
 * SNS share button for sitatic page
 */
$id = 'show_sns_button_on_meta_page';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'refresh'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'label' => __('Display on static page','DigiPress'),
	'section' => 'dp_single_page_sns_share_icon_section',
	'type' => 'checkbox'
	)
));

/**
 * Dummy option to navigte target
 */
$wp_customize->add_setting( 'dummy_field_single_sns_btn', array(
	'transport' => 'postMessage'
));
$wp_customize->add_control( 'dummy_field_single_sns_btn', array(
    'section' => 'dp_single_page_sns_share_icon_section'
));
// For Selective refresh
if (isset($wp_customize->selective_refresh)){
	$wp_customize->selective_refresh->add_partial('dummy_field_single_sns_btn', array(
		'selector' => '#single_float_div .inner'
	));
}
/**
 * Target SNS
 */
$id = 'show_sns_button_facebook';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'refresh'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'fake_title' => __('Target SNS services','DigiPress'),
	'label' => 'Facebook',
	'section' => 'dp_single_page_sns_share_icon_section',
	'type' => 'checkbox'
	)
));
$id = 'show_sns_button_twitter';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'refresh'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'label' => 'Twitter',
	'section' => 'dp_single_page_sns_share_icon_section',
	'type' => 'checkbox'
	)
));
$id = 'show_sns_button_hatena';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'refresh'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'label' => __('Hatena bookmark','DigiPress'),
	'section' => 'dp_single_page_sns_share_icon_section',
	'type' => 'checkbox'
	)
));
$id = 'show_sns_button_pinterest';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'refresh'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'label' => 'Pinterest',
	'section' => 'dp_single_page_sns_share_icon_section',
	'type' => 'checkbox'
	)
));
$id = 'show_sns_button_pocket';
$wp_customize->add_setting(
	'dp_theme_options[show_sns_button_pocket]', array(
	'default' => $def_options['show_sns_button_pocket'],
	'type' => 'option',
	'transport' => 'refresh'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options[show_sns_button_pocket]', array(
	'label' => 'Pocket',
	'section' => 'dp_single_page_sns_share_icon_section',
	'type' => 'checkbox'
	)
));
$id = 'show_sns_button_evernote';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'refresh'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'label' => 'Evernote',
	'section' => 'dp_single_page_sns_share_icon_section',
	'type' => 'checkbox'
	)
));
$id = 'show_sns_button_feedly';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'refresh'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'label' => 'Feedly',
	'section' => 'dp_single_page_sns_share_icon_section',
	'type' => 'checkbox'
	)
));
$id = 'show_sns_button_line';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'refresh'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'label' => 'LINE',
	'section' => 'dp_single_page_sns_share_icon_section',
	'type' => 'checkbox'
	)
));


/**
 * SNS follow box section
 */
$wp_customize->add_section(
	'dp_single_page_follow_box_section', array(
	'title' => __('SNS follow box Setting', 'DigiPress'),
	'description' => __('Display setting of SNS follow box displayed after the entry content.', 'DigiPress'),
	'panel' => 'dp_single_page_panel',
	'priority' => 55
));

// Show Facebook follow box
$id = 'follow_box_facebook';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'refresh'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'fake_title' => __('Facebook', 'DigiPress'),
	'label' => __('Show Facebook Like! button box', 'DigiPress'),
	'section' => 'dp_single_page_follow_box_section',
	'type' => 'checkbox'
	)
));
// For Selective refresh
if (isset($wp_customize->selective_refresh)){
	$wp_customize->selective_refresh->add_partial('dp_theme_options['.$id.']', array(
		'selector' => '.flw_box.fb .flw_box_col:first-of-type',
		'settings' => 'dp_theme_options['.$id.']'
	));
}

// Like target
$id = 'follow_box_facebook_like_target';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'refresh'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'description' => __('The URL for Like!', 'DigiPress'),
	'section' => 'dp_single_page_follow_box_section',
	'type' => 'select',
	'choices' => array(
		'home' => __('Home URL', 'DigiPress'),
		'post' => __('Each post URL', 'DigiPress'),
		'custom' =>  __('Custom URL (specified below)', 'DigiPress')
		),
	'active_callback' => 'cb_dp_follow_box'
	)
));

// Like! target URL
$id = 'follow_box_facebook_like_url';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => '',
	'type' => 'option',
	'sanitize_callback' => 'esc_url_raw',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'description' => __('Like! target URL','DigiPress'),
	'section' => 'dp_single_page_follow_box_section',
	'type' => 'text',
	'input_attrs' => array(
		'placeholder' => 'https://www.facebook.com/digipressthemes/',
	),
	'active_callback' => 'cb_dp_follow_box'
	)
));

// Show likes count
$id = 'follow_box_facebook_count';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'refresh'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'label' => __('Show Like! count', 'DigiPress'),
	'section' => 'dp_single_page_follow_box_section',
	'type' => 'checkbox',
	'active_callback' => 'cb_dp_follow_box'
	)
));

// Follow text
$id = 'follow_box_facebook_phrase';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'sanitize_callback' => 'dp_sanitize_html',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'description' => __('Follow phrase','DigiPress'),
	'section' => 'dp_single_page_follow_box_section',
	'type' => 'text',
	'input_attrs' => array(
		'placeholder' => __($def_options[$id], 'DigiPress'),
		),
	'active_callback' => 'cb_dp_follow_box'
	)
));
// For Selective refresh
if (isset($wp_customize->selective_refresh)){
	$wp_customize->selective_refresh->add_partial('dp_theme_options['.$id.']', array(
		'selector' => '.flw_box.fb .phrase',
		'settings' => 'dp_theme_options['.$id.']',
		'container_inclusive' => false,
		'render_callback' => function(){
			$options = get_option('dp_theme_options');
			echo $options['follow_box_facebook_phrase'];
		}
	));
}


// Like box background color
$id = 'follow_box_facebook_overlay_color';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'refresh',
	'sanitize_callback' => 'sanitize_hex_color'
));
$wp_customize->add_control( new WP_Customize_Color_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'settings' => 'dp_theme_options['.$id.']',
	'description' => __('Box background color','DigiPress'),
	'section' => 'dp_single_page_follow_box_section',
	'active_callback' => 'cb_dp_follow_box'
	)
));

// Enable blur filtered background image
$id = 'follow_box_facebook_bg_image';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'refresh'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'label' => __('Show blurred background image', 'DigiPress'),
	'section' => 'dp_single_page_follow_box_section',
	'type' => 'checkbox',
	'active_callback' => 'cb_dp_follow_box'
	)
));

// Show twitter follow box
$id = 'follow_box_twitter';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'refresh'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'fake_title' => __('Twitter', 'DigiPress'),
	'label' => __('Show Twitter follow button box', 'DigiPress'),
	'section' => 'dp_single_page_follow_box_section',
	'type' => 'checkbox'
	)
));
// For Selective refresh
if (isset($wp_customize->selective_refresh)){
	$wp_customize->selective_refresh->add_partial('dp_theme_options['.$id.']', array(
		'selector' => '.flw_box.tw',
		'settings' => 'dp_theme_options['.$id.']'
	));
}

// Twitter User ID
$id = 'twitter_user_id';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'sanitize_callback' => 'sanitize_text_field',
	'transport' => 'refresh'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'description' => __('Twitter user ID (*Exclude @ prefix)','DigiPress'),
	'section' => 'dp_single_page_follow_box_section',
	'type' => 'text',
	'input_attrs' => array(
		'placeholder' => $def_options[$id],
		),
	'active_callback' => 'cb_dp_follow_box'
	)
));

// Show follower count
$id = 'follow_box_twitter_count';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'refresh'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'label' => __('Show follower count', 'DigiPress'),
	'section' => 'dp_single_page_follow_box_section',
	'type' => 'checkbox',
	'active_callback' => 'cb_dp_follow_box'
	)
));
/**
 * SNS follow box callback
 */
function cb_dp_follow_box($control){
	$control_id = $control->id;
	$fb = $control->manager->get_setting('dp_theme_options[follow_box_facebook]')->value();
	$fb_target = $control->manager->get_setting('dp_theme_options[follow_box_facebook_like_target]')->value();
	$tw = $control->manager->get_setting('dp_theme_options[follow_box_twitter]')->value();

	if ( $fb &&(
		$control_id === 'dp_theme_options[follow_box_facebook_like_target]' ||
		$control_id === 'dp_theme_options[follow_box_facebook_count]' ||
		$control_id === 'dp_theme_options[follow_box_facebook_phrase]' ||
		$control_id === 'dp_theme_options[follow_box_facebook_overlay_color]' ||
		$control_id === 'dp_theme_options[follow_box_facebook_bg_image]'
		 ) ){
		return true;
	}

	if ( $fb && $fb_target === 'custom' && $control_id === 'dp_theme_options[follow_box_facebook_like_url]' ) {
		return true;
	}

	if ( $tw &&(
		$control_id === 'dp_theme_options[twitter_user_id]' ||
		$control_id === 'dp_theme_options[follow_box_twitter_count]'
		 ) ){
		return true;
	}

	return false;
}



/**
 * Author section
 */
$wp_customize->add_section(
	'dp_single_page_author_section', array(
	'title' => __('Display Author Name', 'DigiPress'),
	'description' => '',
	'panel' => 'dp_single_page_panel',
	'priority' => 60
));
/**
 * Show author
 */
$id = 'show_author_on_meta_post';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'refresh'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'label' => __('Single post', 'DigiPress'),
	'section' => 'dp_single_page_author_section',
	'type' => 'select',
	'choices' => array(
		'hide' => __('Hide', 'DigiPress'),
		'meta_top' => __('Show top meta area','DigiPress'),
		'meta_bottom' =>  __('Show bottom meta area','DigiPress'),
		'meta_both' => __('Show both meta area','DigiPress')
		)
	)
));

$id = 'show_author_on_meta_page';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'refresh'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'label' => __('Static page', 'DigiPress'),
	'section' => 'dp_single_page_author_section',
	'type' => 'select',
	'choices' => array(
		'hide' => __('Hide', 'DigiPress'),
		'meta_top' => __('Show top meta area','DigiPress'),
		'meta_bottom' => __('Show bottom meta area','DigiPress'),
		'meta_both' => __('Show both meta area','DigiPress')
		)
	)
));


/**
 * Author profile section
 */
$wp_customize->add_section(
	'dp_single_page_author_profile_section', array(
	'title' => __('Author Profile Setting', 'DigiPress'),
	'description' => '',
	'panel' => 'dp_single_page_panel',
	'priority' => 70
));
/**
 * Author profile
 */
$id = 'show_author_info';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'refresh'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'label' => __("Show author's profile",'DigiPress'),
	'section' => 'dp_single_page_author_profile_section',
	'separator' => true,
	'type' => 'checkbox'
	)
));
$id = 'author_info_title';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'sanitize_callback' => 'dp_sanitize_html',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'label' => __('Author Info Area Title','DigiPress'),
	'section' => 'dp_single_page_author_profile_section',
	'type' => 'text',
	'input_attrs' => array(
		'placeholder' => __('About The Author', 'DigiPress'),
		),
	'active_callback' => 'cb_single_post_settings'
	)
));
// For Selective refresh
if (isset($wp_customize->selective_refresh)){
	$wp_customize->selective_refresh->add_partial('dp_theme_options['.$id.']', array(
		'selector' => '.author_info > .inside-title',
		'settings' => 'dp_theme_options['.$id.']',
		'container_inclusive' => false,
		'render_callback' => function(){
			$options = get_option('dp_theme_options');
			echo '<span>'.$options['author_info_title'].'</span>';
		}
	));
}

/**
 * Recent posts title
 */
$id = 'author_recent_articles_title';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'sanitize_callback' => 'dp_sanitize_html',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'label' => __('Author\'s Recent Posts Title','DigiPress'),
	'section' => 'dp_single_page_author_profile_section',
	'type' => 'text',
	'separator' => true,
	'input_attrs' => array(
		'placeholder' => __('Recent Posted', 'DigiPress'),
		),
	'active_callback' => 'cb_single_post_settings'
	)
));
// For Selective refresh
if (isset($wp_customize->selective_refresh)){
	$wp_customize->selective_refresh->add_partial('dp_theme_options['.$id.']', array(
		'selector' => '.author_info .dp_related_posts .inside-title',
		'settings' => 'dp_theme_options['.$id.']',
		'container_inclusive' => false,
		'render_callback' => function(){
			$options = get_option('dp_theme_options');
			echo '<span>'.$options['author_recent_articles_title'].'</span>';
		}
	));
}

// Dummy navigate user pforile page
$wp_customize->add_setting(
	'dummy_field', array(
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dummy_field', array(
	'description' => __('*Access your profile page to edit your profile.', 'DigiPress'),
	'before_text' => '<a href="profile.php" class="button" target="_blank">'.__('Open your profile page','DigiPress').'</a>',
	'section' => 'dp_single_page_author_profile_section',
	'type' => 'text'
	)
));

/**
 * related posts section
 */
$wp_customize->add_section(
	'dp_single_page_related_posts_section', array(
	'title' => __('Related Posts Setting', 'DigiPress'),
	'description' => '',
	'panel' => 'dp_single_page_panel',
	'priority' => 80
));
/**
 * Related posts
 */
$id = 'show_related_posts';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'label' => __('Show related posts','DigiPress'),
	'section' => 'dp_single_page_related_posts_section',
	'separator' => true,
	'type' => 'checkbox'
	)
));

// Title
$id = 'related_posts_title';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'sanitize_callback' => 'dp_sanitize_html',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'label' => __('Section title','DigiPress'),
	'section' => 'dp_single_page_related_posts_section',
	'type' => 'text',
	'input_attrs' => array(
		'placeholder' => __('You Might Also Like', 'DigiPress'),
		),
	'active_callback' => 'cb_single_post_settings'
	)
));
// For Selective refresh
if (isset($wp_customize->selective_refresh)){
	$wp_customize->selective_refresh->add_partial('dp_theme_options['.$id.']', array(
		'selector' => 'aside.dp_related_posts .inside-title',
		'settings' => 'dp_theme_options['.$id.']',
		'container_inclusive' => false,
		'render_callback' => function(){
			$options = get_option('dp_theme_options');
			echo '<span>'.$options['related_posts_title'].'</span>';
		}
	));
}

// target
$id = 'related_posts_target';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'label' => __('Display target','DigiPress'),
	'section' => 'dp_single_page_related_posts_section',
	'type' => 'select',
	'choices' => array(
		'same_tag' => __('Same tag posts','DigiPress'),
		'same_cat' => __('Same category posts','DigiPress'),
		'same_cat_rand' => __('Same category posts(Random)','DigiPress'),
		),
	'active_callback' => 'cb_single_post_settings'
	)
));
// Horizontal or vertical
$id = 'related_posts_style';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'refresh'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'label' => __('Layout style','DigiPress'),
	'section' => 'dp_single_page_related_posts_section',
	'type' => 'radio',
	'choices' => array(
		'vertical' => __('Standard','DigiPress'),
		'horizontal' => __('Portfolio','DigiPress')
		),
	'active_callback' => 'cb_single_post_settings'
	)
));
// Post number
$id = 'number_related_posts';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'sanitize_callback' => 'absint',
	'type' => 'option',
	'transport' => 'refresh'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'label' => __('Display number','DigiPress'),
	'unit' => __('posts','DigiPress'),
	'section' => 'dp_single_page_related_posts_section',
	'type' => 'number',
	'input_attrs' => array('min' => 1,'max' => 100,'step' => 1),
	'active_callback' => 'cb_single_post_settings'
	)
));
// show category
$id = 'related_posts_category';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'label' => __('Show post category','DigiPress'),
	'section' => 'dp_single_page_related_posts_section',
	'type' => 'checkbox',
	'active_callback' => 'cb_single_post_settings'
	)
));

/**
 * Next Prev section
 */
$wp_customize->add_section(
	'dp_single_page_next_prev_section', array(
	'title' => __('Next / Prev Navigation', 'DigiPress'),
	'description' => '',
	'panel' => 'dp_single_page_panel',
	'priority' => 90
));
// Hide next /prev link
$id = 'hide_next_prev_post';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'label' => __('Hide links to next and previous articles','DigiPress'),
	'note' => __('*Settings for the links to next and previous articles in single post.','DigiPress'),
	'section' => 'dp_single_page_next_prev_section',
	'separator' => true,
	'type' => 'checkbox'
	)
));
// show same category?
$id = 'same_cat_next_prev_post';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'label' => __('Display only articles of the same category','DigiPress'),
	'section' => 'dp_single_page_next_prev_section',
	'type' => 'checkbox',
	'active_callback' => 'cb_single_post_settings'
	)
));
// Exclude category
$id = 'exclude_cats_next_prev_post';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'sanitize_callback' => 'dp_sanitize_html',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'description' => __('Exclude Category ID(s)','DigiPress'),
	'section' => 'dp_single_page_next_prev_section',
	'note' => __('*If there are categories to exclude from links of previous and next articles, specify that category ID.','DigiPress').'<br />'.__('*Use comma between category IDs to set multiple categories.','DigiPress'),
	'type' => 'text',
	'input_attrs' => array(
		'placeholder' => '12,30',
		),
	'active_callback' => 'cb_single_post_settings'
	)
));

/**
 * Comments section
 */
$wp_customize->add_section(
	'dp_single_page_comments_section', array(
	'title' => __('Comment Area Setting', 'DigiPress'),
	'description' => '',
	'panel' => 'dp_single_page_panel',
	'priority' => 100
));
/**
 * comment area
 */
$id = 'comments_main_title';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'sanitize_callback' => 'dp_sanitize_html',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'label' => __('Comment area titles', 'DigiPress'),
	'description' => __('The title of main comment area','DigiPress'),
	'section' => 'dp_single_page_comments_section',
	'type' => 'text',
	'input_attrs' => array(
		'placeholder' => __('Comments &amp; Trackbacks', 'DigiPress'),
		)
	)
));
// For Selective refresh
if (isset($wp_customize->selective_refresh)){
	$wp_customize->selective_refresh->add_partial('dp_theme_options['.$id.']', array(
		'selector' => '#comments',
		'settings' => 'dp_theme_options['.$id.']',
		'container_inclusive' => false,
		'render_callback' => function(){
			$options = get_option('dp_theme_options');
			echo '<span class="title">'.$options['comments_main_title'].'</span>';
		}
	));
}

/**
 * comment form title
 */
$id = 'comment_form_title';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'sanitize_callback' => 'dp_sanitize_html',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'description' => __('The title of comment form','DigiPress'),
	'section' => 'dp_single_page_comments_section',
	'type' => 'text',
	'input_attrs' => array(
		'placeholder' => __('Leave A Reply', 'DigiPress'),
		)
	)
));
// For Selective refresh
if (isset($wp_customize->selective_refresh)){
	$wp_customize->selective_refresh->add_partial('dp_theme_options['.$id.']', array(
		'selector' => '#reply-title',
		'settings' => 'dp_theme_options['.$id.']',
		'container_inclusive' => false,
		'render_callback' => function(){
			$options = get_option('dp_theme_options');
			echo '<span>'.$options['comment_form_title'].'</span>';
		}
	));
}
/**
 * Send button title
 */
$id = 'send_comment_text';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'sanitize_callback' => 'sanitize_text_field',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'description' => __('Send button text', 'DigiPress'),
	'note' => __('*Config the WordPress comments setting(Setting -> Discussion) to disable comment in single post.','DigiPress').'<div><i class="dashicons-before dashicons-external"></i><a href="options-discussion.php" target="_blank">'.__('Open Discussion Setting','DigiPress').'</a></div>',
	'section' => 'dp_single_page_comments_section',
	'separator' => true,
	'type' => 'text',
	'input_attrs' => array(
		'placeholder' => __('Send a comment', 'DigiPress'),
		)
	)
));
// Dummy navigate user pforile page
$wp_customize->add_setting(
	'dummy_field', array(
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dummy_field', array(
	'description' => __('*Access discussion page to display comments.', 'DigiPress'),
	'before_text' => '<a href="options-discussion.php" class="button" target="_blank">'.__('Open discussion page','DigiPress').'</a>',
	'section' => 'dp_single_page_comments_section',
	'type' => 'text'
	)
));

/**
 * Facebook Comments section
 */
$wp_customize->add_section(
	'dp_single_page_fb_comments_section', array(
	'title' => __('Facebook Comments Setting', 'DigiPress'),
	'description' => '',
	'panel' => 'dp_single_page_panel',
	'priority' => 110
));
/**
 * Facebook comment
 */
$id = 'facebookcomment_post';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'label' => __('Show in single post','DigiPress'),
	'section' => 'dp_single_page_fb_comments_section',
	'type' => 'checkbox'
	)
));
$id = 'facebookcomment_page';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'label' => __('Show in static page','DigiPress'),
	'section' => 'dp_single_page_fb_comments_section',
	'type' => 'checkbox'
	)
));
$id = 'fb_comments_title';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'type' => 'option',
	'sanitize_callback' => 'dp_sanitize_html',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'label' => __('Section title','DigiPress'),
	'section' => 'dp_single_page_fb_comments_section',
	'type' => 'text',
	'input_attrs' => array(
		'placeholder' => __('Comment On Facebook', 'DigiPress'),
		)
	)
));
$id = 'number_fb_comment';
$wp_customize->add_setting(
	'dp_theme_options['.$id.']', array(
	'default' => $def_options[$id],
	'sanitize_callback' => 'absint',
	'type' => 'option',
	'transport' => 'postMessage'
));
$wp_customize->add_control( new DP_Customize_Control(
	$wp_customize,
	'dp_theme_options['.$id.']', array(
	'label' => __('Display number','DigiPress'),
	'unit' => __('comments','DigiPress'),
	'note' => __('*If Ajax page loading option is enabled, Facebook comment on single page will not work.','DigiPress'),
	'section' => 'dp_single_page_fb_comments_section',
	'type' => 'number',
	'input_attrs' => array('min' => 1,'max' => 100,'step' => 1)
	)
));

/**
 * Callback
 */
function cb_single_post_settings($control){
	$show_author_info = $control->manager->get_setting('dp_theme_options[show_author_info]')->value();
	$show_related_posts = $control->manager->get_setting('dp_theme_options[show_related_posts]')->value();
	$hide_next_prev_post = $control->manager->get_setting('dp_theme_options[hide_next_prev_post]')->value();
	$control_id = $control->id;

	if ( (bool)$show_author_info && (
		$control_id === 'dp_theme_options[author_info_title]'||
		$control_id === 'dp_theme_options[author_recent_articles_title]'
		)
	) return true;
	if ( (bool)$show_author_info && $control_id === 'dp_theme_options[author_recent_articles_title]') return true;

	if ( (bool)$show_related_posts && (
		$control_id === 'dp_theme_options[related_posts_title]' ||
		$control_id === 'dp_theme_options[related_posts_target]' ||
		$control_id === 'dp_theme_options[related_posts_style]' ||
		$control_id === 'dp_theme_options[number_related_posts]' ||
		$control_id === 'dp_theme_options[related_posts_category]'
		)
	) return true;

	if ( !(bool)$hide_next_prev_post && (
		$control_id === 'dp_theme_options[same_cat_next_prev_post]' ||
		$control_id === 'dp_theme_options[exclude_cats_next_prev_post]'
		)
	) return true;

	return false;
}