<?php
/**
* DigiPress Theme Option Class
*/
class digipress_options {
	const OPTION_NAME	= 'digipress';
	const OPTION_ADD_ONS	= 'digipress_add_ons';
	const OPTION_TOOLS	= 'digipress_tools';

	/**
	* Backup / restore
	*/
	// Backup all settings
	static function dp_export_all_settings() {
		if (isset($_POST['dp_export']) && check_admin_referer('dp-export')) {
			global $def_options;
			$date = date("YmdHis");
			$json_name = DP_THEME_KEY."-".$date;
			// Get all options
			$options = get_option('dp_theme_options');
			$options = !empty($options) ? $options : $def_options;
			$all_options = array('dp_theme_options' => $options);

			foreach ($all_options as $key => $value) {
				$value = maybe_unserialize($value);
				$need_options[$key] = $value;
			}
			// Encode data into json data
			$json_file = json_encode($need_options);
			// Clear buffer
			ob_clean();
			header("Content-Type: text/json; charset=" . get_option('blog_charset'));
			header("Content-Disposition: attachment; filename=$json_name.json");
			echo $json_file;
			exit();
		}
	}
	// Restore
	static function dp_import_all_settings() {
		if (isset($_FILES['dp_import']) && check_admin_referer('dp-import')) {
			if ($_FILES['dp_import']['error'] > 0) {
				wp_die(__("Import Error : ", "DigiPress").$_FILES['dp_import']['error']);
			} else {
				$file_name = $_FILES['dp_import']['name']; // Get the name of file
				$tmp_exp = explode(".", $file_name);
				$file_ext = strtolower(end($tmp_exp)); // Get extension of file
				$file_size = $_FILES['dp_import']['size']; // Get size of file

				if ( $file_ext === "json" ) {
					if ( WP_Filesystem() ) {
						global $wp_filesystem;
						$encode_options = $wp_filesystem->get_contents($_FILES['dp_import']['tmp_name']);
						$all_options = json_decode($encode_options, true);
						if (is_array($all_options)) {
							foreach ($all_options as $key => $value) {
								update_option($key, $value);
							}
							// Export CSS
							dp_css_create();
							// Message
							$notice_msg = __('All options are restored successfully.','DigiPress');
							set_transient( 'dp-admin-option-notices', array($notice_msg), 10 );
							add_action( 'admin_notices', array('digipress_options', 'dp_show_admin_notice_message') );
						} else {
							set_transient( 'dp-admin-option-errors',__('Backup file is incorrect format.', 'DigiPress'), 10 );
							// Show error
							add_action( 'admin_notices', array('digipress_options', 'dp_show_admin_error_message') );
						}
					}
				} else {
					// Message
					$err_msg = __('Invalid file or file size too big.','DigiPress');
					$e = new WP_Error();
					$e->add( 'error', $err_msg );
					set_transient( 'dp-admin-option-errors',$e->get_error_messages(), 10 );
					// Show error
					add_action( 'admin_notices', array('digipress_options', 'dp_show_admin_error_message') );
				}
			}
		}
	}

	/**
	* Clear all cache
	*/
	static function clear_all_cache() {
		if ( isset($_POST['dp_clear_all_transient_cache']) && check_admin_referer('dp-clear-all-cache') ) {

			// Defined in control_cache.php
			dp_Delete_All_Cache();

			$notice_msg = __('Cache deleted successfully.','DigiPress');
			set_transient( 'dp-admin-option-notices', array($notice_msg), 10 );
			add_action( 'admin_notices', array('digipress_options', 'dp_show_admin_notice_message') );
		}
	}

	/**
	* Reset all settings
	*/
	static function reset_theme_options() {
		//Reset control settings
		if ( isset($_POST['dp_reset_all_settings']) && check_admin_referer('dp-reset') ) {
			global $def_options;
			//Reset
			update_option('dp_theme_options', $def_options);
			//Rewrite Style.css
			if (!dp_css_create()) return;
			$notice_msg = __('Successfully reseted parameters.','DigiPress');
			set_transient( 'dp-admin-option-notices', array($notice_msg), 10 );
			add_action( 'admin_notices', array('digipress_options', 'dp_show_admin_notice_message') );
		}
	}

	/**
	* Show visual option interface
	* Include And Display Theme Option Panel.
	*/
	static function display_settings() {
		$options = get_option('dp_theme_options');
		include_once(DP_THEME_DIR . "/inc/admin/page_settings.php");
	}

	/**
	* Add-ons panel
	*/
	static function display_add_ons() {
		include_once(DP_THEME_DIR . "/inc/admin/page_add_ons.php");
	}

	/**
	* Tools panel
	*/
	static function display_tools() {
		require_once(DP_THEME_DIR . "/inc/admin/page_tools.php");
	}

	/**
	*  Insert CSS and javascript to header of DigiPress option panel.
	*/
	static function enqueue_css_js() {
		if (!is_admin()) return;
		//CSS
		wp_enqueue_style('dp_admin', DP_THEME_URI . '/inc/css/dp_admin.css', array());
	}
	static function enqueue_css_js_add_ons() {
		if (!is_admin()) return;
		//CSS
		wp_enqueue_style('dp_admin', DP_THEME_URI . '/inc/css/dp_admin.css', array());
		// Register Color picker
		wp_enqueue_style('wp-color-picker');
		wp_enqueue_script('wp-color-picker');
		// Javascript
		wp_enqueue_script('dp_setting_page', DP_THEME_URI . '/inc/js/dp_setting_page.min.js', array('jquery', 'wp-color-picker'), DP_OPTION_SPT_VERSION, true);
	}

	/**
	 *  Add menu page into Admin interface.
	 *
	 * @param	none
	 * @return	none
	 */
	public static function add_menu() {
		//Main
		$hook_sf = add_menu_page(
			__('DigiPress Theme Options', 'DigiPress'),
			__('DigiPress', 'DigiPress'),
			'manage_options',
			digipress_options::OPTION_NAME,
			array('digipress_options', 'display_settings'),
			'dashicons-admin-settings'
		);

		// Settings
		$hook_sf_backup_restore = add_submenu_page(
			digipress_options::OPTION_NAME,
			__('Settings'),
			__('Settings'),
			'manage_options',
			digipress_options::OPTION_NAME,
			array('digipress_options', 'display_settings')
		);

		// Add-ons
		$hook_sf_add_ons = add_submenu_page(
			digipress_options::OPTION_NAME,
			__('Add-Ons', 'DigiPress'),
			__('Add-Ons', 'DigiPress'),
			'manage_options',
			digipress_options::OPTION_ADD_ONS,
			array('digipress_options', 'display_add_ons')
		);

		// Tools
		$hook_sf_tools = add_submenu_page(
			digipress_options::OPTION_NAME,
			__('Tools', 'DigiPress'),
			__('Tools', 'DigiPress'),
			'manage_options',
			digipress_options::OPTION_TOOLS,
			array('digipress_options', 'display_tools')
		);

		// Add CSS and Javascript into header only
		add_action('admin_print_scripts-'.$hook_sf, array('digipress_options', 'enqueue_css_js'));
		add_action('admin_print_scripts-'.$hook_sf_backup_restore, array('digipress_options','enqueue_css_js'));
		add_action('admin_print_scripts-'.$hook_sf_add_ons, array('digipress_options','enqueue_css_js_add_ons'));
		add_action('admin_print_scripts-'.$hook_sf_tools, array('digipress_options','enqueue_css_js'));
	}

	/**
	* Notice messages
	*/
	public function dp_update_msg() {
		echo "<div class=\"updated\"><p>".__('Successfully updated.','DigiPress')."</p></div>";
	}
	public function dp_delete_msg() {
		echo "<div class=\"updated\"><p>".__('Successfully deleted.','DigiPress')."</p></div>";
	}
	public function dp_del_fail_msg() {
		echo "<div class=\"error\"><p>".__('Failed to delete a file.','DigiPress')."</p></div>";
	}
	public function dp_no_file_msg() {
		echo "<div class=\"error\"><p>".__('Target file does not found.','DigiPress')."</p></div>";
	}
	public function dp_reset_options() {
		echo "<div class=\"updated\"><p>".__('Successfully reseted parameters.','DigiPress')."</p></div>";
	}
	public function not_rewrite_msg($filePath) {
		echo "<div class=\"error\"><p>" . $filePath .' : '.__('The file is not writable. Please change the permission to 666 or 606.','DigiPress')."</p></div>";
	}
	public function file_in_use_msg($filePath) {
		echo "<div class=\"error\"><p>" . $filePath .' : '.__('The file may be in use by other program. Please identify the conflict process.','DigiPress')."</p></div>";
	}
	public function not_open_file_msg($filePath) {
		echo "<div class=\"error\"><p>" . $filePath . ' : '.__('The file can not be opened. Please identify the conflict process.','DigiPress')."</p></div>";
	}
	public function not_write_dir_msg($filePath) {
		echo "<div class=\"error\"><p>" . $filePath . ' : '.__('The files in this folder is not rewritable. Please change the permission to 777.','DigiPress')."</p></div>";
	}

	// **
	// Show admin message from transient data
	static function dp_show_admin_error_message() {
		if ( $messages = get_transient( 'dp-admin-option-errors' ) ) : ?>
<div class="error"><ul><?php
foreach( (array)$messages as $message ): ?>
<li><?php echo $message; ?></li><?php
endforeach; ?>
</ul></div><?php
		endif;
	}
	static function dp_show_admin_notice_message() {
		if ( $messages = get_transient( 'dp-admin-option-notices' ) ) : ?>
<div class="updated"><ul><?php
foreach( (array)$messages as $message ): ?>
<li><?php echo $message; ?></li><?php
endforeach; ?>
</ul></div><?php
		endif;
	}
}