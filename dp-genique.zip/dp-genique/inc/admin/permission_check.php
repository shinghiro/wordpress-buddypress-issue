<?php
/**
* Check and create Upload directory
*/
function dp_permission_check() {
	if ( phpversion() < 5 ) {
		echo '<div class="error"><p>PHP ver. ' . phpversion() . __(' : WordPress and DigiPress couldn\'t run as normal on this PHP version. Please update php ASAP!', 'DigiPress').'</p></div>';
		return;
	}
	$css_dir			= DP_UPLOAD_DIR . "/css";

	$arr_uoload_dir = array($css_dir);
	$err_msg = '';

	// Check and create upload dir
	foreach ($arr_uoload_dir as $current_dir) {
		if ( !file_exists($current_dir) ) {
			if ( !mkdir($current_dir, 0777, true) ) {
				$err_msg .= '<li>' . $current_dir . __(' directory couldn\'t be created.' ,'DigiPress').'</li>';
			}
		}
		if ( !is_writable( $current_dir ) ) {
			$err_msg .= '<li>' . $current_dir . __(' : Please change the permission of this directory to 777 or 757.', 'DigiPress').'</li>';
		}
	}
	if (!empty($err_msg)) {
		echo '<div class="error"><ul>'.$err_msg.'</ul></div>';
	}


}