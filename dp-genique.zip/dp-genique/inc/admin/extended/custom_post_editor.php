<?php
/**
 * Customize editor panel
 */
// Enable original CSS in editor panel
function dp_theme_add_editor_styles() {
    add_editor_style( 'inc/css/editor_style.css' );
}
add_action( 'after_setup_theme', 'dp_theme_add_editor_styles' );

/**
 * Add inline CSS in Visual Editor (Classic)
 */
function dp_tiny_mce_editor_inline_css( $settings ){
	// Target selectors
	$selector = array(
		'.mce-content-body.editor-area',	// Clasic Editor
		'div.editor-styles-wrapper .wp-block-freeform.block-library-rich-text__tinymce' // So do gutenberg
	);
	$inline_css = dp_generate_editor_inline_css( $selector );

	$settings['content_style'] = $inline_css;
	return $settings;
}
add_filter( 'tiny_mce_before_init', 'dp_tiny_mce_editor_inline_css' );

/**
 * Enable style sheet for Gutenberg
 */
function dp_theme_enqueue_for_gutenberg() {

	$font_color_selector = array(
		'.editor-post-title__block .editor-post-title__input'
	);
	// Inline CSS
	$inline_css = dp_override_gutenberg_font_color( $font_color_selector );

	$wrapper_selector = array(
		'div.editor-styles-wrapper'
	);
	$inline_css .= dp_generate_editor_inline_css( $wrapper_selector );


	// Register inline CSS
	wp_register_style( 'dp-editor-insert', false );
	wp_enqueue_style( 'dp-editor-insert' );
	wp_add_inline_style( 'dp-editor-insert', $inline_css );
}
add_action( 'enqueue_block_editor_assets', 'dp_theme_enqueue_for_gutenberg' );

/**
 * Override gutenberg default font color
 */
function dp_override_gutenberg_font_color( $arr_selector ){
	if ( !( isset($arr_selector) && is_array($arr_selector) ) ) return;
	global $options;

	$selector = implode( ',', $arr_selector );
	$inline_css = $selector."{color:".$options['base_font_color'].";}";

	return $inline_css;
}

/**
 * Generate inline CSS for editor
 */
function dp_generate_editor_inline_css( $arr_selector ){

	if ( !( isset($arr_selector) && is_array($arr_selector) ) ) return;

	global $def_options, $options;

	extract( $options );

	$variant_css = $typography_css = '';
	$selector = implode( ',', $arr_selector );

	// RGB
	$rgb_container_bg_color = dp_hex_to_rgb( $container_bg_color );
	$rgb_lighten_container_bg_color = dp_color_luminance($container_bg_color, 0.04 );
	$rgb_darken_container_bg_color = dp_color_luminance($container_bg_color, -0.03 );
	$rgb_base_font_color = dp_hex_to_rgb( $base_font_color );
	$rgb_base_link_color = dp_hex_to_rgb( $base_link_color );
	$rgb_primary_color = dp_hex_to_rgb( $primary_color );
	$rgb_secondary_color = dp_hex_to_rgb( $secondary_color );
	$rgb_darken_primary_color = dp_color_luminance( $primary_color, -0.4 );

	$variant_css =
		$selector . "{
		--container-bg-color:" . $container_bg_color . ";
		--container-bg-color-76p:rgba(" . $rgb_container_bg_color[0] . "," . $rgb_container_bg_color[1] . "," . $rgb_container_bg_color[2] . ",.76);
		--container-bg-color-62p:rgba(" . $rgb_container_bg_color[0] . "," . $rgb_container_bg_color[1] . "," . $rgb_container_bg_color[2] . ",.62);
		--container-bg-opacity:" . (int)$container_bg_opacity / 100 . ";
		--container-top-gradient:linear-gradient(180deg," . $container_bg_color . ",transparent);
		--base-letter-spacing:" . $base_letter_spacing . "em;
		--base-font-color:" . $base_font_color . ";
		--base-link-color:" . $base_link_color . ";
		--base-link-hover-color:" . $base_link_hover_color . ";
		--base-font-color-76p:rgba(" . $rgb_base_font_color[0] . "," . $rgb_base_font_color[1] . "," . $rgb_base_font_color[2] . ",.76);
		--base-font-color-62p:rgba(" . $rgb_base_font_color[0] . "," . $rgb_base_font_color[1] . "," . $rgb_base_font_color[2] . ",.62);
		--base-font-color-48p:rgba(" . $rgb_base_font_color[0] . "," . $rgb_base_font_color[1] . "," . $rgb_base_font_color[2] . ",.48);
		--base-font-color-40p:rgba(" . $rgb_base_font_color[0] . "," . $rgb_base_font_color[1] . "," . $rgb_base_font_color[2] . ",.40);
		--base-font-color-34p:rgba(" . $rgb_base_font_color[0] . "," . $rgb_base_font_color[1] . "," . $rgb_base_font_color[2] . ",.34);
		--base-font-color-28p:rgba(" . $rgb_base_font_color[0] . "," . $rgb_base_font_color[1] . "," . $rgb_base_font_color[2] . ",.28);
		--base-font-color-24p:rgba(" . $rgb_base_font_color[0] . "," . $rgb_base_font_color[1] . "," . $rgb_base_font_color[2] . ",.24);
		--base-font-color-20p:rgba(" . $rgb_base_font_color[0] . "," . $rgb_base_font_color[1] . "," . $rgb_base_font_color[2] . ",.2);
		--base-font-color-16p:rgba(" . $rgb_base_font_color[0] . "," . $rgb_base_font_color[1] . "," . $rgb_base_font_color[2] . ",.16);
		--base-font-color-12p:rgba(" . $rgb_base_font_color[0] . "," . $rgb_base_font_color[1] . "," . $rgb_base_font_color[2] . ",.12);
		--base-font-color-8p:rgba(" . $rgb_base_font_color[0] . "," . $rgb_base_font_color[1] . "," . $rgb_base_font_color[2] . ",.08);
		--base-font-color-8p:rgba(" . $rgb_base_font_color[0] . "," . $rgb_base_font_color[1] . "," . $rgb_base_font_color[2] . ",.06);
		--base-font-color-4p:rgba(" . $rgb_base_font_color[0] . "," . $rgb_base_font_color[1] . "," . $rgb_base_font_color[2] . ",.04);
		--common-title-spacing:" . $title_letter_spacing . "em;
		--term-color:" . $primary_color . ";
		--primary-color:" . $primary_color . ";
		--primary-color-6p:rgba(" . $rgb_primary_color[0] . "," . $rgb_primary_color[1] . "," . $rgb_primary_color[2] . ",.06);
		--primary-color-10p:rgba(" . $rgb_primary_color[0] . "," . $rgb_primary_color[1] . "," . $rgb_primary_color[2] . ",.1);
		--primary-color-14p:rgba(" . $rgb_primary_color[0] . "," . $rgb_primary_color[1] . "," . $rgb_primary_color[2] . ",.14);
		--secondary-color:" . $secondary_color . ";
		--accent-color-gradient:linear-gradient(135deg, " . $primary_color . " 0%," . $secondary_color . " 100%);
	";

	/**
	 * Background image
	 */
	if ( isset($background_img) && !empty($background_img) ) {
		$background_img = is_ssl() ? str_replace('http:', 'https:', $background_img) : $background_img;
		if ($background_repeat === 'no-repeat'){
			$variant_css .=
			"--site-bg-size:cover;
			--site-bg-position:center;";
		} else {
			$variant_css .=
			"--site-bg-repeat:" . $background_repeat . ";
			--site-bg-position:left top;";
		}

		$variant_css .=
			"--site-bg-image:url(" . $background_img . ");";
	}


	/**
	 * Primary color base
	 */
	if (isset($options['enable_primary_color_gradient'] ) && !empty($options['enable_primary_color_gradient'] )) {
		$variant_css .= "--primary-color-gradient:linear-gradient(135deg," . $primary_color." 0%,rgba(" . $rgb_darken_primary_color[0] . "," . $rgb_darken_primary_color[1] . "," . $rgb_darken_primary_color[2] . ",1) 100%);";
	}

	/**
	 * Font size
	 */
	if ( empty($base_font_size) ) {
		$variant_css .= "--base-font-size:" . $original_font_size_px . "px;";
	} else {
		$variant_css .= "--base-font-size:" . $base_font_size . "px;";
	}

	/**
	 * Link style
	 */
	if ( $base_link_bold ) {
		$variant_css .= "--entry-link-weight:700;";
	}
	if ( $base_link_underline === 'not_mouseover' ) {

		$variant_css .=
			"--entry-link-decoration:underline;
			--entry-link-decoration-hover:none;";

	} else if ( $base_link_underline === 'none' ) {
		$variant_css .= "--entry-link-decoration-hover:none;";
	}

	/**
	 * Head tag styling
	 */
	// Head tag font size
	if (isset($base_font_size_h1) && !empty($base_font_size_h1)) {
		if ( $base_font_size_h1 != $def_options['base_font_size_h1'] ) {
			$variant_css .= "--base-h1-size:" . $base_font_size_h1 . "%;";
		}
	}

	if (isset($base_font_size_h2) && !empty($base_font_size_h2)) {
		if ( $base_font_size_h2 != $def_options['base_font_size_h2'] ) {
			$variant_css .= "--base-h2-size:" . $base_font_size_h2 . "%;";
		}
	}

	if (isset($base_font_size_h3) && !empty($base_font_size_h3)) {
		if ( $base_font_size_h3 != $def_options['base_font_size_h3'] ) {
			$variant_css .= "--base-h3-size:" . $base_font_size_h3 . "%;";
		}
	}

	if (isset($base_font_size_h4) && !empty($base_font_size_h4)) {
		if ( $base_font_size_h4 != $def_options['base_font_size_h4'] ) {
			$variant_css .= "--base-h4-size:" . $base_font_size_h4 . "%;";
		}
	}

	if (isset($base_font_size_h5) && !empty($base_font_size_h5)) {
		if ( $base_font_size_h5 != $def_options['base_font_size_h5'] ) {
			$variant_css .= "--base-h5-size:" . $base_font_size_h5 . "%;";
		}
	}

	if (isset($base_font_size_h6) && !empty($base_font_size_h6)) {
		if ( $base_font_size_h6 != $def_options['base_font_size_h6'] ) {
			$variant_css .= "--base-h6-size:" . $base_font_size_h6 . "%;";
		}
	}

	/**
	 * Italic and bold for major titles
	 */
	if ( $title_font_bold ) {
		$variant_css .= '--major-title-font-weight:700;';
	}

	if ( $title_font_style_italic ) {
		$variant_css .= '--major-title-font-style:italic;';
	}


	/**
	 * Base font family
	 */
	if ( strpos( $base_font_family, 'mincho' ) !== false || $base_font_family == 'serif-all' ) {
		$typography_css = "'HiraMinProN-W3','Hiragino Mincho ProN','YuMincho','Yu Mincho','HG明朝E',serif;";
	} else {
		$typography_css = "'Hiragino Sans', 'Hiragino Kaku Gothic ProN', Meiryo, YuGothic, 'Yu Gothic', sans-serif";
	}
	if ( isset($custom_font_only_title) && !empty($custom_font_only_title) ) {
		$variant_css .= '--major-title-font-family:' . $typography_css;

	} else {
		$variant_css .= "--base-font-family:" . $typography_css;
	}

	// Closure
	$variant_css .= '}';
	$variant_css = str_replace( array("\r\n","\r","\n","\t"), '', $variant_css );

	return $variant_css;
}


// Add custom button on Tiny MCE (Classic)
if ( !function_exists( 'dp_tiny_mce_before_init' ) ):
	function dp_tiny_mce_before_init( $init_array ){
		$init_array['body_class'] = 'editor-area';

		// Default block formats
		$init_array['block_formats'] = __('Paragraph', 'DigiPress') . '=p;' . sprintf(__('Heading %s', 'DigiPress'), '1') . '=h1;' . sprintf(__('Heading %s', 'DigiPress'), '2') . '=h2;' . sprintf(__('Heading %s', 'DigiPress'), '3') . '=h3;' . sprintf(__('Heading %s', 'DigiPress'), '4') . '=h4;' . sprintf(__('Heading %s', 'DigiPress'), '5') . '=h5;' . sprintf(__('Heading %s', 'DigiPress'), '6') . '=h6;' . __('Address tag', 'DigiPress') . '=address;' . __('Preformatted text', 'DigiPress') . '=pre;' . __('Source code', 'DigiPress') . '=code';

		// Font size
		$init_array['fontsize_formats'] = '8px 9px 10px 11px 12px 13px 14px 15px 16px 17px 18px 19px 20px 21px 22px 23px 24px 25px 26px 27px 28px 29px 30px 31px 32px 33px 34px 35px 36px 37px 38px 39px 40px 110% 120% 130% 140% 150% 160% 170% 180% 190% 200% 210% 220% 230% 240% 250% 260% 270% 280% 290% 300%';


		// Overwrite default formats
		$default_formats = array(
			'alignleft' => array(
				'selector' =>'p,h1,h2,h3,h4,h5,h6,table,td,th,div,ul,ol,li,dl,dt,dd',
				'classes' => 'al-l',
				'styles' => ''
			),
			'alignright' => array(
				'selector' =>'p,h1,h2,h3,h4,h5,h6,table,td,th,div,ul,ol,li,dl,dt,dd',
				'classes' => 'al-r',
				'styles' => ''
			),
			'aligncenter' => array(
				'selector' =>'p,h1,h2,h3,h4,h5,h6,table,td,th,div,ul,ol,li,dl,dt,dd',
				'classes' => 'al-c',
				'styles' => ''
			)
		);
		$init_array['formats'] = json_encode($default_formats);


		// Original style code
		$style_formats = array(
			array(
				'title' => __('Bold', 'DigiPress'),
				'inline' => 'span',
				'icon' => 'bold',
				'classes' => 'b'
			),
			array(
				'title' => __('Italic', 'DigiPress'),
				'inline' => 'span',
				'icon' => 'italic',
				'classes' => 'i'
			),
			array(
				'title' => __('Serif style', 'DigiPress'),
				'inline' => 'span',
				'classes' => 'serif'
			),
			array(
				'title' => __('Font sizes', 'DigiPress'),
				'items' => array(
					array(
						'title' => '10px',
						'inline' => 'span',
						'classes' => 'ft10px'
					),
					array(
						'title' => '11px',
						'inline' => 'span',
						'classes' => 'ft11px'
					),
					array(
						'title' => '12px',
						'inline' => 'span',
						'classes' => 'ft12px'
					),
					array(
						'title' => '13px',
						'inline' => 'span',
						'classes' => 'ft13px'
					),
					array(
						'title' => '14px',
						'inline' => 'span',
						'classes' => 'ft14px'
					),
					array(
						'title' => '15px',
						'inline' => 'span',
						'classes' => 'ft15px'
					),
					array(
						'title' => '16px',
						'inline' => 'span',
						'classes' => 'ft16px'
					),
					array(
						'title' => '17px',
						'inline' => 'span',
						'classes' => 'ft17px'
					),
					array(
						'title' => '18px',
						'inline' => 'span',
						'classes' => 'ft18px'
					),
					array(
						'title' => '19px',
						'inline' => 'span',
						'classes' => 'ft19px'
					),
					array(
						'title' => '20px',
						'inline' => 'span',
						'classes' => 'ft20px'
					),
					array(
						'title' => '21px',
						'inline' => 'span',
						'classes' => 'ft21px'
					),
					array(
						'title' => '22px',
						'inline' => 'span',
						'classes' => 'ft22px'
					),
					array(
						'title' => '23px',
						'inline' => 'span',
						'classes' => 'ft23px'
					),
					array(
						'title' => '24px',
						'inline' => 'span',
						'classes' => 'ft24px'
					),
					array(
						'title' => '25px',
						'inline' => 'span',
						'classes' => 'ft25px'
					),
					array(
						'title' => '26px',
						'inline' => 'span',
						'classes' => 'ft26px'
					),
					array(
						'title' => '27px',
						'inline' => 'span',
						'classes' => 'ft27px'
					),
					array(
						'title' => '28px',
						'inline' => 'span',
						'classes' => 'ft28px'
					),
					array(
						'title' => '29px',
						'inline' => 'span',
						'classes' => 'ft29px'
					),
					array(
						'title' => '30px',
						'inline' => 'span',
						'classes' => 'ft30px'
					),
					array(
						'title' => '31px',
						'inline' => 'span',
						'classes' => 'ft31px'
					),
					array(
						'title' => '32px',
						'inline' => 'span',
						'classes' => 'ft32px'
					),
					array(
						'title' => '33px',
						'inline' => 'span',
						'classes' => 'ft33px'
					),
					array(
						'title' => '34px',
						'inline' => 'span',
						'classes' => 'ft34px'
					),
					array(
						'title' => '35px',
						'inline' => 'span',
						'classes' => 'ft35px'
					),
					array(
						'title' => '40px',
						'inline' => 'span',
						'classes' => 'ft40px'
					),
					array(
						'title' => '45px',
						'inline' => 'span',
						'classes' => 'ft45px'
					),
					array(
						'title' => '50px',
						'inline' => 'span',
						'classes' => 'ft50px'
					)
				)
			),
			array(
				'title' => __('Font color', 'DigiPress'),
				'icon' => 'forecolor',
				'items' => array(
					array(
						'title' => __('red', 'DigiPress'),
						'inline' => 'span',
						'classes' => 'red'
					),
					array(
						'title' => __('blue', 'DigiPress'),
						'inline' => 'span',
						'classes' => 'blue'
					),
					array(
						'title' => __('light blue', 'DigiPress'),
						'inline' => 'span',
						'classes' => 'lightblue'
					),
					array(
						'title' => __('green', 'DigiPress'),
						'inline' => 'span',
						'classes' => 'green'
					),
					array(
						'title' => __('yellow', 'DigiPress'),
						'inline' => 'span',
						'classes' => 'yellow'
					),
					array(
						'title' => __('orange', 'DigiPress'),
						'inline' => 'span',
						'classes' => 'orange'
					),
					array(
						'title' => __('pink', 'DigiPress'),
						'inline' => 'span',
						'classes' => 'pink'
					)
				)
			),
			array(
				'title' => sprintf(__('Line marker %s', 'DigiPress'), ''),
				'items' => array(
					array(
						'title' => __('red', 'DigiPress'),
						'inline' => 'span',
						'classes' => 'mk-red'
					),
					array(
						'title' => __('blue', 'DigiPress'),
						'inline' => 'span',
						'classes' => 'mk-blue'
					),
					array(
						'title' => __('light blue', 'DigiPress'),
						'inline' => 'span',
						'classes' => 'mk-lightblue'
					),
					array(
						'title' => __('green', 'DigiPress'),
						'inline' => 'span',
						'classes' => 'mk-green'
					),
					array(
						'title' => __('yellow', 'DigiPress'),
						'inline' => 'span',
						'classes' => 'mk-yellow'
					),
					array(
						'title' => __('orange', 'DigiPress'),
						'inline' => 'span',
						'classes' => 'mk-orange'
					),
					array(
						'title' => __('pink', 'DigiPress'),
						'inline' => 'span',
						'classes' => 'mk-pink'
					)
				)
			),
			array(
				'title' => sprintf(__('Underline %s', 'DigiPress'), ''),
				'icon' => 'underline',
				'items' => array(
					array(
						'title' => __('default', 'DigiPress'),
						'inline' => 'span',
						'classes' => 'bd'
					),
					array(
						'title' => __('red', 'DigiPress'),
						'inline' => 'span',
						'classes' => 'bd-red'
					),
					array(
						'title' => __('blue', 'DigiPress'),
						'inline' => 'span',
						'classes' => 'bd-blue'
					),
					array(
						'title' => __('light blue', 'DigiPress'),
						'inline' => 'span',
						'classes' => 'bd-lightblue'
					),
					array(
						'title' => __('green', 'DigiPress'),
						'inline' => 'span',
						'classes' => 'bd-green'
					),
					array(
						'title' => __('yellow', 'DigiPress'),
						'inline' => 'span',
						'classes' => 'bd-yellow'
					),
					array(
						'title' => __('orange', 'DigiPress'),
						'inline' => 'span',
						'classes' => 'bd-orange'
					),
					array(
						'title' => __('pink', 'DigiPress'),
						'inline' => 'span',
						'classes' => 'bd-pink'
					)
				)
			),
			array(
				'title' => sprintf(__('Box %s', 'DigiPress'), ''),
				'items' => array(
					array(
						'title' => __('default', 'DigiPress'),
						'block' => 'div',
						'classes' => 'box'
					),
					array(
						'title' => __('red', 'DigiPress'),
						'block' => 'div',
						'classes' => 'box-red'
					),
					array(
						'title' => __('blue', 'DigiPress'),
						'block' => 'div',
						'classes' => 'box-blue'
					),
					array(
						'title' => __('green', 'DigiPress'),
						'block' => 'div',
						'classes' => 'box-green'
					),
					array(
						'title' => __('yellow', 'DigiPress'),
						'block' => 'div',
						'classes' => 'box-yellow'
					),
					array(
						'title' => __('orange', 'DigiPress'),
						'block' => 'div',
						'classes' => 'box-orange'
					),
					array(
						'title' => __('pink', 'DigiPress'),
						'block' => 'div',
						'classes' => 'box-pink'
					)
				)
			),
			array(
				'title' => __('Label', 'DigiPress'),
				'items' => array(
					array(
						'title' => __('default', 'DigiPress'),
						'inline' => 'span',
						'classes' => 'label'
					),
					array(
						'title' => __('red', 'DigiPress'),
						'inline' => 'span',
						'classes' => 'label label-red'
					),
					array(
						'title' => __('blue', 'DigiPress'),
						'inline' => 'span',
						'classes' => 'label label-blue'
					),
					array(
						'title' => __('light blue', 'DigiPress'),
						'inline' => 'span',
						'classes' => 'label label-lightblue'
					),
					array(
						'title' => __('green', 'DigiPress'),
						'inline' => 'span',
						'classes' => 'label label-green'
					),
					array(
						'title' => __('yellow', 'DigiPress'),
						'inline' => 'span',
						'classes' => 'label label-yellow'
					),
					array(
						'title' => __('orange', 'DigiPress'),
						'inline' => 'span',
						'classes' => 'label label-orange'
					),
					array(
						'title' => __('pink', 'DigiPress'),
						'inline' => 'span',
						'classes' => 'label label-pink'
					),
					array(
						'title' => __('black', 'DigiPress'),
						'inline' => 'span',
						'classes' => 'label label-black'
					)
				)
			),
			array(
				'title' => __('Button', 'DigiPress'),
				'icon' => 'link',
				'items' => array(
					array(
						'title' => __('default', 'DigiPress'),
						'inline' => 'a',
						'attributes' => array(
							'href' => 'https://'
						),
						'classes' => 'btn',
						'onclick' => 'function(){
							editor.windowManager.open();
						}'
					),
					array(
						'title' => __('red', 'DigiPress'),
						'inline' => 'a',
						'attributes' => array(
							'href' => 'https://'
						),
						'classes' => 'btn btn-red',
						'onclick' => 'function(){
							editor.windowManager.open();
						}'
					),
					array(
						'title' => __('blue', 'DigiPress'),
						'inline' => 'a',
						'attributes' => array(
							'href' => 'https://'
						),
						'classes' => 'btn btn-blue',
						'onclick' => 'function(){
							editor.windowManager.open();
						}'
					),
					array(
						'title' => __('light blue', 'DigiPress'),
						'inline' => 'a',
						'attributes' => array(
							'href' => 'https://'
						),
						'classes' => 'btn btn-lightblue',
						'onclick' => 'function(){
							editor.windowManager.open();
						}'
					),
					array(
						'title' => __('green', 'DigiPress'),
						'inline' => 'a',
						'attributes' => array(
							'href' => 'https://'
						),
						'classes' => 'btn btn-green',
						'onclick' => 'function(){
							editor.windowManager.open();
						}'
					),
					array(
						'title' => __('yellow', 'DigiPress'),
						'inline' => 'a',
						'attributes' => array(
							'href' => 'https://'
						),
						'classes' => 'btn btn-yellow',
						'onclick' => 'function(){
							editor.windowManager.open();
						}'
					),
					array(
						'title' => __('orange', 'DigiPress'),
						'inline' => 'a',
						'attributes' => array(
							'href' => 'https://'
						),
						'classes' => 'btn btn-orange',
						'onclick' => 'function(){
							editor.windowManager.open();
						}'
					),
					array(
						'title' => __('pink', 'DigiPress'),
						'inline' => 'a',
						'attributes' => array(
							'href' => 'https://'
						),
						'classes' => 'btn btn-pink',
						'onclick' => 'function(){
							editor.windowManager.open();
						}'
					),
					array(
						'title' => __('black', 'DigiPress'),
						'inline' => 'a',
						'attributes' => array(
							'href' => 'https://'
						),
						'classes' => 'btn btn-black',
						'onclick' => 'function(){
							editor.windowManager.open();
						}'
					)
				)
			),
			array(
				'title' => __('Background color', 'DigiPress'),
				'icon' => 'backcolor',
				'items' => array(
					array(
						'title' => __('red', 'DigiPress'),
						'block' => 'div',
						'classes' => 'bg-red'
					),
					array(
						'title' => __('blue', 'DigiPress'),
						'block' => 'div',
						'classes' => 'bg-blue'
					),
					array(
						'title' => __('light blue', 'DigiPress'),
						'block' => 'div',
						'classes' => 'bg-lightblue'
					),
					array(
						'title' => __('green', 'DigiPress'),
						'block' => 'div',
						'classes' => 'bg-green'
					),
					array(
						'title' => __('yellow', 'DigiPress'),
						'block' => 'div',
						'classes' => 'bg-yellow'
					),
					array(
						'title' => __('orange', 'DigiPress'),
						'block' => 'div',
						'classes' => 'bg-orange'
					),
					array(
						'title' => __('pink', 'DigiPress'),
						'block' => 'div',
						'classes' => 'bg-pink'
					)
				)
			),
			array(
				'title' => __('Box padding', 'DigiPress'),
				'items' => array(
					array(
						'title' => __('top', 'DigiPress') . ' 10px',
						'block' => 'div',
						'classes' => 'pd10px-top'
					),
					array(
						'title' => __('top', 'DigiPress') . ' 15px',
						'block' => 'div',
						'classes' => 'pd15px-top'
					),
					array(
						'title' => __('top', 'DigiPress') . ' 20px',
						'block' => 'div',
						'classes' => 'pd20px-top'
					),
					array(
						'title' => __('top', 'DigiPress') . ' 25px',
						'block' => 'div',
						'classes' => 'pd25px-top'
					),
					array(
						'title' => __('top', 'DigiPress') . ' 30px',
						'block' => 'div',
						'classes' => 'pd30px-top'
					),
					array(
						'title' => __('top', 'DigiPress') . ' 35px',
						'block' => 'div',
						'classes' => 'pd35px-top'
					),
					array(
						'title' => __('top', 'DigiPress') . ' 40px',
						'block' => 'div',
						'classes' => 'pd40px-top'
					),
					array(
						'title' => __('top', 'DigiPress') . ' 45px',
						'block' => 'div',
						'classes' => 'pd45px-top'
					),
					array(
						'title' => __('top', 'DigiPress') . ' 50px',
						'block' => 'div',
						'classes' => 'pd50px-top'
					),
					array(
						'title' => __('top', 'DigiPress') . ' 10px',
						'block' => 'div',
						'classes' => 'pd10px-top'
					),
					array(
						'title' => __('top', 'DigiPress') . ' 15px',
						'block' => 'div',
						'classes' => 'pd15px-top'
					),
					array(
						'title' => __('top', 'DigiPress') . ' 20px',
						'block' => 'div',
						'classes' => 'pd20px-top'
					),
					array(
						'title' => __('bottom', 'DigiPress') . ' 25px',
						'block' => 'div',
						'classes' => 'pd25px-btm'
					),
					array(
						'title' => __('bottom', 'DigiPress') . ' 30px',
						'block' => 'div',
						'classes' => 'pd30px-btm'
					),
					array(
						'title' => __('bottom', 'DigiPress') . ' 35px',
						'block' => 'div',
						'classes' => 'pd35px-btm'
					),
					array(
						'title' => __('bottom', 'DigiPress') . ' 40px',
						'block' => 'div',
						'classes' => 'pd40px-btm'
					),
					array(
						'title' => __('bottom', 'DigiPress') . ' 45px',
						'block' => 'div',
						'classes' => 'pd45px-btm'
					),
					array(
						'title' => __('bottom', 'DigiPress') . ' 50px',
						'block' => 'div',
						'classes' => 'pd50px-btm'
					),
					array(
						'title' => __('left', 'DigiPress') . ' 10px',
						'block' => 'div',
						'classes' => 'pd10px-l'
					),
					array(
						'title' => __('left', 'DigiPress') . ' 15px',
						'block' => 'div',
						'classes' => 'pd15px-l'
					),
					array(
						'title' => __('left', 'DigiPress') . ' 20px',
						'block' => 'div',
						'classes' => 'pd20px-l'
					),
					array(
						'title' => __('left', 'DigiPress') . ' 25px',
						'block' => 'div',
						'classes' => 'pd25px-l'
					),
					array(
						'title' => __('left', 'DigiPress') . ' 30px',
						'block' => 'div',
						'classes' => 'pd30px-l'
					),
					array(
						'title' => __('left', 'DigiPress') . ' 35px',
						'block' => 'div',
						'classes' => 'pd35px-l'
					),
					array(
						'title' => __('left', 'DigiPress') . ' 40px',
						'block' => 'div',
						'classes' => 'pd40px-l'
					),
					array(
						'title' => __('left', 'DigiPress') . ' 45px',
						'block' => 'div',
						'classes' => 'pd45px-l'
					),
					array(
						'title' => __('left', 'DigiPress') . ' 50px',
						'block' => 'div',
						'classes' => 'pd50px-l'
					),
					array(
						'title' => __('right', 'DigiPress') . ' 10px',
						'block' => 'div',
						'classes' => 'pd10px-r'
					),
					array(
						'title' => __('right', 'DigiPress') . ' 15px',
						'block' => 'div',
						'classes' => 'pd15px-r'
					),
					array(
						'title' => __('right', 'DigiPress') . ' 20px',
						'block' => 'div',
						'classes' => 'pd20px-r'
					),
					array(
						'title' => __('right', 'DigiPress') . ' 25px',
						'block' => 'div',
						'classes' => 'pd25px-r'
					),
					array(
						'title' => __('right', 'DigiPress') . ' 30px',
						'block' => 'div',
						'classes' => 'pd30px-r'
					),
					array(
						'title' => __('right', 'DigiPress') . ' 35px',
						'block' => 'div',
						'classes' => 'pd35px-r'
					),
					array(
						'title' => __('right', 'DigiPress') . ' 40px',
						'block' => 'div',
						'classes' => 'pd40px-r'
					),
					array(
						'title' => __('right', 'DigiPress') . ' 45px',
						'block' => 'div',
						'classes' => 'pd45px-r'
					),
					array(
						'title' => __('right', 'DigiPress') . ' 50px',
						'block' => 'div',
						'classes' => 'pd50px-r'
					),
					array(
						'title' => __('all around', 'DigiPress') . ' 10px',
						'block' => 'div',
						'classes' => 'pd10px'
					),
					array(
						'title' => __('all around', 'DigiPress') . ' 15px',
						'block' => 'div',
						'classes' => 'pd15px'
					),
					array(
						'title' => __('all around', 'DigiPress') . ' 20px',
						'block' => 'div',
						'classes' => 'pd20px'
					),
					array(
						'title' => __('all around', 'DigiPress') . ' 25px',
						'block' => 'div',
						'classes' => 'pd25px'
					),
					array(
						'title' => __('all around', 'DigiPress') . ' 30px',
						'block' => 'div',
						'classes' => 'pd30px'
					),
					array(
						'title' => __('all around', 'DigiPress') . ' 35px',
						'block' => 'div',
						'classes' => 'pd35px'
					),
					array(
						'title' => __('all around', 'DigiPress') . ' 40px',
						'block' => 'div',
						'classes' => 'pd40px'
					),
					array(
						'title' => __('all around', 'DigiPress') . ' 45px',
						'block' => 'div',
						'classes' => 'pd45px'
					),
					array(
						'title' => __('all around', 'DigiPress') . ' 50px',
						'block' => 'div',
						'classes' => 'pd50px'
					)
				)
			),
			array(
				'title' => __('Box margin', 'DigiPress'),
				'items' => array(
					array(
						'title' => __('top', 'DigiPress') . ' 10px',
						'block' => 'div',
						'classes' => 'mg10px-top'
					),
					array(
						'title' => __('top', 'DigiPress') . ' 15px',
						'block' => 'div',
						'classes' => 'mg15px-top'
					),
					array(
						'title' => __('top', 'DigiPress') . ' 20px',
						'block' => 'div',
						'classes' => 'mg20px-top'
					),
					array(
						'title' => __('top', 'DigiPress') . ' 25px',
						'block' => 'div',
						'classes' => 'mg25px-top'
					),
					array(
						'title' => __('top', 'DigiPress') . ' 30px',
						'block' => 'div',
						'classes' => 'mg30px-top'
					),
					array(
						'title' => __('top', 'DigiPress') . ' 35px',
						'block' => 'div',
						'classes' => 'mg35px-top'
					),
					array(
						'title' => __('top', 'DigiPress') . ' 40px',
						'block' => 'div',
						'classes' => 'mg40px-top'
					),
					array(
						'title' => __('top', 'DigiPress') . ' 45px',
						'block' => 'div',
						'classes' => 'mg45px-top'
					),
					array(
						'title' => __('top', 'DigiPress') . ' 50px',
						'block' => 'div',
						'classes' => 'mg50px-top'
					),
					array(
						'title' => __('top', 'DigiPress') . ' 10px',
						'block' => 'div',
						'classes' => 'mg10px-top'
					),
					array(
						'title' => __('top', 'DigiPress') . ' 15px',
						'block' => 'div',
						'classes' => 'mg15px-top'
					),
					array(
						'title' => __('top', 'DigiPress') . ' 20px',
						'block' => 'div',
						'classes' => 'mg20px-top'
					),
					array(
						'title' => __('bottom', 'DigiPress') . ' 25px',
						'block' => 'div',
						'classes' => 'mg25px-btm'
					),
					array(
						'title' => __('bottom', 'DigiPress') . ' 30px',
						'block' => 'div',
						'classes' => 'mg30px-btm'
					),
					array(
						'title' => __('bottom', 'DigiPress') . ' 35px',
						'block' => 'div',
						'classes' => 'mg35px-btm'
					),
					array(
						'title' => __('bottom', 'DigiPress') . ' 40px',
						'block' => 'div',
						'classes' => 'mg40px-btm'
					),
					array(
						'title' => __('bottom', 'DigiPress') . ' 45px',
						'block' => 'div',
						'classes' => 'mg45px-btm'
					),
					array(
						'title' => __('bottom', 'DigiPress') . ' 50px',
						'block' => 'div',
						'classes' => 'mg50px-btm'
					),
					array(
						'title' => __('left', 'DigiPress') . ' 10px',
						'block' => 'div',
						'classes' => 'mg10px-l'
					),
					array(
						'title' => __('left', 'DigiPress') . ' 15px',
						'block' => 'div',
						'classes' => 'mg15px-l'
					),
					array(
						'title' => __('left', 'DigiPress') . ' 20px',
						'block' => 'div',
						'classes' => 'mg20px-l'
					),
					array(
						'title' => __('left', 'DigiPress') . ' 25px',
						'block' => 'div',
						'classes' => 'mg25px-l'
					),
					array(
						'title' => __('left', 'DigiPress') . ' 30px',
						'block' => 'div',
						'classes' => 'mg30px-l'
					),
					array(
						'title' => __('left', 'DigiPress') . ' 35px',
						'block' => 'div',
						'classes' => 'mg35px-l'
					),
					array(
						'title' => __('left', 'DigiPress') . ' 40px',
						'block' => 'div',
						'classes' => 'mg40px-l'
					),
					array(
						'title' => __('left', 'DigiPress') . ' 45px',
						'block' => 'div',
						'classes' => 'mg45px-l'
					),
					array(
						'title' => __('left', 'DigiPress') . ' 50px',
						'block' => 'div',
						'classes' => 'mg50px-l'
					),
					array(
						'title' => __('right', 'DigiPress') . ' 10px',
						'block' => 'div',
						'classes' => 'mg10px-r'
					),
					array(
						'title' => __('right', 'DigiPress') . ' 15px',
						'block' => 'div',
						'classes' => 'mg15px-r'
					),
					array(
						'title' => __('right', 'DigiPress') . ' 20px',
						'block' => 'div',
						'classes' => 'mg20px-r'
					),
					array(
						'title' => __('right', 'DigiPress') . ' 25px',
						'block' => 'div',
						'classes' => 'mg25px-r'
					),
					array(
						'title' => __('right', 'DigiPress') . ' 30px',
						'block' => 'div',
						'classes' => 'mg30px-r'
					),
					array(
						'title' => __('right', 'DigiPress') . ' 35px',
						'block' => 'div',
						'classes' => 'mg35px-r'
					),
					array(
						'title' => __('right', 'DigiPress') . ' 40px',
						'block' => 'div',
						'classes' => 'mg40px-r'
					),
					array(
						'title' => __('right', 'DigiPress') . ' 45px',
						'block' => 'div',
						'classes' => 'mg45px-r'
					),
					array(
						'title' => __('right', 'DigiPress') . ' 50px',
						'block' => 'div',
						'classes' => 'mg50px-r'
					),
					array(
						'title' => __('all around', 'DigiPress') . ' 10px',
						'block' => 'div',
						'classes' => 'mg10px'
					),
					array(
						'title' => __('all around', 'DigiPress') . ' 15px',
						'block' => 'div',
						'classes' => 'mg15px'
					),
					array(
						'title' => __('all around', 'DigiPress') . ' 20px',
						'block' => 'div',
						'classes' => 'mg20px'
					),
					array(
						'title' => __('all around', 'DigiPress') . ' 25px',
						'block' => 'div',
						'classes' => 'mg25px'
					),
					array(
						'title' => __('all around', 'DigiPress') . ' 30px',
						'block' => 'div',
						'classes' => 'mg30px'
					),
					array(
						'title' => __('all around', 'DigiPress') . ' 35px',
						'block' => 'div',
						'classes' => 'mg35px'
					),
					array(
						'title' => __('all around', 'DigiPress') . ' 40px',
						'block' => 'div',
						'classes' => 'mg40px'
					),
					array(
						'title' => __('all around', 'DigiPress') . ' 45px',
						'block' => 'div',
						'classes' => 'mg45px'
					),
					array(
						'title' => __('all around', 'DigiPress') . ' 50px',
						'block' => 'div',
						'classes' => 'mg50px'
					)
				)
			),
			array(
				'title' => __('Keyboard shortcut', 'DigiPress'),
				'inline' => 'span',
				'classes' => 'keyboard'
			),
			array(
				'title' => __('Formatted text', 'DigiPress'),
				'block' => 'pre',
				'classes' => ''
			),
			array(
				'title' => __('Code tag', 'DigiPress'),
				'block' => 'code',
				'classes' => ''
			)
		);
		//Parse to json
		$init_array['style_formats'] = json_encode($style_formats);
		$init_array['style_formats_merge'] = true;

		return $init_array;
	}
endif;
add_filter( 'tiny_mce_before_init', 'dp_tiny_mce_before_init' );


// Add the quick tags on text editor mode
if ( !function_exists( 'add_dp_custom_quicktags' ) ):
	function add_dp_custom_quicktags() {
		global $options;

		// Disable inserting quick tags
		if ( isset($options['disable_add_quick_tags']) && !empty($options['disable_add_quick_tags']) ) return;

		// Tags
		if ( wp_script_is('quicktags') ){
			$quicktags = "<script>
QTags.addButton('p','" . __('p (Paragraph)', 'DigiPress') . "','<p>','</p>');
QTags.addButton('br','" . __('br (Break)', 'DigiPress') . "','','<br />');
QTags.addButton('qt-dldtdd','" . __('Definition list', 'DigiPress') . "','<dl>\\r\\n<dt></dt>\\r\\n<dd>\\r\\n\\r\\n</dd>\\r\\n</dl>','');
QTags.addButton('qt-dl','" . __('dl', 'DigiPress') . "','<dl>','</dl>');
QTags.addButton('qt-dt','" . __('dt', 'DigiPress') . "','<dt>','</dt>');
QTags.addButton('qt-dd','" . __('dd', 'DigiPress') . "','<dd>','</dd>');
QTags.addButton('qt-table','" . __('table', 'DigiPress') . "','<table>\\r\\n<tbody>\\r\\n\\r\\n</tbody>\\r\\n</table>', '');
QTags.addButton('qt-tr','" . __('tr (Table row)', 'DigiPress') . "','<tr>','</tr>');
QTags.addButton('qt-th','" . __('th (Head cell)', 'DigiPress') . "','<th>','</th>');
QTags.addButton('qt-td','" . __('td  (cell)', 'DigiPress') . "','<td>','</td>');
QTags.addButton('qt-al-l-p','" . sprintf(__('Alignment %s : %s', 'DigiPress'), '(p)', __('left', 'DigiPress') ) . "','<p class=\"al-l\">','</p>');
QTags.addButton('qt-al-c-p','" . sprintf(__('Alignment %s : %s', 'DigiPress'), '(p)', __('center', 'DigiPress') ) . "','<p class=\"al-c\">','</p>');
QTags.addButton('qt-al-r-p','" . sprintf(__('Alignment %s : %s', 'DigiPress'), '(p)', __('right', 'DigiPress') ) . "','<p class=\"al-r\">','</p>');
QTags.addButton('qt-al-l-div','" . sprintf(__('Alignment %s : %s', 'DigiPress'), '(div)', __('left', 'DigiPress') ) . "','<div class=\"al-l\">','</div>');
QTags.addButton('qt-al-c-div','" . sprintf(__('Alignment %s : %s', 'DigiPress'), '(div)', __('center', 'DigiPress') ) . "','<div class=\"al-c\">','</div>');
QTags.addButton('qt-al-r-div','" . sprintf(__('Alignment %s : %s', 'DigiPress'), '(div)', __('right', 'DigiPress') ) . "','<div class=\"al-r\">','</div>');
QTags.addButton('qt-h1','" . __('h1', 'DigiPress') . "','<h1>','</h1>');
QTags.addButton('qt-h2','" . __('h2', 'DigiPress') . "','<h2>','</h2>');
QTags.addButton('qt-h3','" . __('h3', 'DigiPress') . "','<h3>','</h3>');
QTags.addButton('qt-h4','" . __('h4', 'DigiPress') . "','<h4>','</h4>');
QTags.addButton('qt-h5','" . __('h5', 'DigiPress') . "','<h5>','</h5>');
QTags.addButton('qt-h6','" . __('h6', 'DigiPress') . "','<h6>','</h6>');
QTags.addButton('qt-bold','" . __('Bold', 'DigiPress') . "','<span class=\"b\">','</span>');
QTags.addButton('qt-italic','" . __('Italic', 'DigiPress') . "','<span class=\"i\">','</span>');
QTags.addButton('qt-serif','" . __('Serif style', 'DigiPress') . "','<span class=\"serif\">','</span>');
QTags.addButton('qt-red','" . sprintf(__('Font %s', 'DigiPress'), __('red', 'DigiPress')) . "','<span class=\"red\">','</span>');
QTags.addButton('qt-blue','" . sprintf(__('Font %s', 'DigiPress'), __('blue', 'DigiPress')) . "','<span class=\"blue\">','</span>');
QTags.addButton('qt-green','" . sprintf(__('Font %s', 'DigiPress'), __('green', 'DigiPress')) . "','<span class=\"green\">','</span>');
QTags.addButton('qt-yellow','" . sprintf(__('Font %s', 'DigiPress'), __('yellow', 'DigiPress')) . "','<span class=\"yellow\">','</span>');
QTags.addButton('qt-orange','" . sprintf(__('Font %s', 'DigiPress'), __('orange', 'DigiPress')) . "','<span class=\"orange\">','</span>');
QTags.addButton('qt-pink','" . sprintf(__('Font %s', 'DigiPress'), __('pink', 'DigiPress')) . "','<span class=\"pink\">','</span>');
QTags.addButton('qt-mk-red','" . sprintf(__('Line marker %s', 'DigiPress'), __('red', 'DigiPress')) . "','<span class=\"mk-red\">','</span>');
QTags.addButton('qt-mk-blue','" . sprintf(__('Line marker %s', 'DigiPress'), __('blue', 'DigiPress')) . "','<span class=\"mk-blue\">','</span>');
QTags.addButton('qt-mk-green','" . sprintf(__('Line marker %s', 'DigiPress'), __('green', 'DigiPress')) . "','<span class=\"mk-green\">','</span>');
QTags.addButton('qt-mk-yellow','" . sprintf(__('Line marker %s', 'DigiPress'), __('yellow', 'DigiPress')) . "','<span class=\"mk-yellow\">','</span>');
QTags.addButton('qt-mk-orange','" . sprintf(__('Line marker %s', 'DigiPress'), __('orange', 'DigiPress')) . "','<span class=\"mk-orange\">','</span>');
QTags.addButton('qt-mk-pink','" . sprintf(__('Line marker %s', 'DigiPress'), __('pink', 'DigiPress')) . "','<span class=\"mk-pink\">','</span>');
QTags.addButton('qt-bd','" . sprintf(__('Underline %s', 'DigiPress'), '') . "','<span class=\"bd\">','</span>');
QTags.addButton('qt-bd-red','" . sprintf(__('Underline %s', 'DigiPress'), __('red', 'DigiPress')) . "','<span class=\"bd-red\">','</span>');
QTags.addButton('qt-bd-blue','" . sprintf(__('Underline %s', 'DigiPress'), __('blue', 'DigiPress')) . "','<span class=\"bd-blue\">','</span>');
QTags.addButton('qt-bd-green','" . sprintf(__('Underline %s', 'DigiPress'), __('green', 'DigiPress')) . "','<span class=\"bd-green\">','</span>');
QTags.addButton('qt-bd-yellow','" . sprintf(__('Underline %s', 'DigiPress'), __('yellow', 'DigiPress')) . "','<span class=\"bd-yellow\">','</span>');
QTags.addButton('qt-bd-orange','" . sprintf(__('Underline %s', 'DigiPress'), __('orange', 'DigiPress')) . "','<span class=\"bd-orange\">','</span>');
QTags.addButton('qt-bd-pink','" . sprintf(__('Underline %s', 'DigiPress'), __('pink', 'DigiPress')) . "','<span class=\"bd-pink\">','</span>');
QTags.addButton('qt-label','" . __('Label', 'DigiPress') . "','<span class=\"label\">','</span>');
QTags.addButton('qt-label-red','" . __('Label', 'DigiPress') . " " . __('red', 'DigiPress'). "','<span class=\"label label-red\">','</span>');
QTags.addButton('qt-label-blue','" . __('Label', 'DigiPress') . " " . __('blue', 'DigiPress'). "','<span class=\"label label-blue\">','</span>');
QTags.addButton('qt-label-green','" . __('Label', 'DigiPress') . " " . __('green', 'DigiPress'). "','<span class=\"label label-green\">','</span>');
QTags.addButton('qt-label-yellow','" . __('Label', 'DigiPress') . " " . __('yellow', 'DigiPress'). "','<span class=\"label label-yellow\">','</span>');
QTags.addButton('qt-label-orange','" . __('Label', 'DigiPress') . " " . __('orange', 'DigiPress'). "','<span class=\"label label-orange\">','</span>');
QTags.addButton('qt-label-pink','" . __('Label', 'DigiPress') . " " . __('pink', 'DigiPress'). "','<span class=\"label label-pink\">','</span>');
QTags.addButton('qt-button','" . __('Button', 'DigiPress') . "','<a href=\"\" class=\"btn\">','</a>');
QTags.addButton('qt-button-red','" . __('Button', 'DigiPress') . " " . __('red', 'DigiPress'). "','<a href=\"\" class=\"btn btn-red\">','</a>');
QTags.addButton('qt-button-blue','" . __('Button', 'DigiPress') . " " . __('blue', 'DigiPress'). "','<a href=\"\" class=\"btn btn-blue\">','</a>');
QTags.addButton('qt-button-green','" . __('Button', 'DigiPress') . " " . __('green', 'DigiPress'). "','<a href=\"\" class=\"btn btn-green\">','</a>');
QTags.addButton('qt-button-yellow','" . __('Button', 'DigiPress') . " " . __('yellow', 'DigiPress'). "','<a href=\"\" class=\"btn btn-yellow\">','</a>');
QTags.addButton('qt-button-orange','" . __('Button', 'DigiPress') . " " . __('orange', 'DigiPress'). "','<a href=\"\" class=\"btn btn-orange\">','</a>');
QTags.addButton('qt-button-pink','" . __('Button', 'DigiPress') . " " . __('pink', 'DigiPress'). "','<a href=\"\" class=\"btn btn-pink\">','</a>');
QTags.addButton('qt-box','" . sprintf(__('Box %s', 'DigiPress'), '') . "','<div class=\"box\">','</div>');
QTags.addButton('qt-box-red','" . sprintf(__('Box %s', 'DigiPress'), __('red', 'DigiPress')) . "','<div class=\"box-red\">','</div>');
QTags.addButton('qt-box-blue','" . sprintf(__('Box %s', 'DigiPress'), __('blue', 'DigiPress')) . "','<div class=\"box-blue\">','</div>');
QTags.addButton('qt-box-green','" . sprintf(__('Box %s', 'DigiPress'), __('green', 'DigiPress')) . "','<div class=\"box-green\">','</div>');
QTags.addButton('qt-box-yellow','" . sprintf(__('Box %s', 'DigiPress'), __('yellow', 'DigiPress')) . "','<div class=\"box-yellow\">','</div>');
QTags.addButton('qt-box-orange','" . sprintf(__('Box %s', 'DigiPress'), __('orange', 'DigiPress')) . "','<div class=\"box-orange\">','</div>');
QTags.addButton('qt-box-pink','" . sprintf(__('Box %s', 'DigiPress'), __('pink', 'DigiPress')) . "','<div class=\"box-pink\">','</div>');
QTags.addButton('keyboard','" . __('Keyboard shortcut', 'DigiPress') . "','<span class=\"keyboard\">','</span>');
QTags.addButton('pre','" . __('Formatted text', 'DigiPress') . "','<pre>','</pre>');
</script>";
			$quicktags = str_replace(array("\r\n","\r","\n","\t"), '', $quicktags);
			echo $quicktags;
		}
	}
endif;
add_action( 'admin_print_footer_scripts', 'add_dp_custom_quicktags', 99 );


// Add Tiny MCE buttons first row
if ( !function_exists( 'dp_mce_buttons' ) ):
	function dp_mce_buttons($buttons){
		// Remove buttons
		$remove = array('italic');
		// Add buttons
		array_push($buttons, "backcolor", "copy", "cut", "paste", "fontsizeselect", "fontselect", "cleanup");
		return array_diff($buttons,$remove);
	}
endif;
add_filter("mce_buttons", "dp_mce_buttons");

// Add original style box on Tiny MCE second row
if ( !function_exists( 'dp_mce_buttons_2' ) ):
	function dp_mce_buttons_2($buttons) {
		// Get the default select box
		$temp = array_shift($buttons);
		// Push the original styles
		array_unshift($buttons, 'styleselect');
		// Restore the select box
		array_unshift($buttons, $temp);

		return $buttons;
	}
endif;
add_filter('mce_buttons_2','dp_mce_buttons_2');

// Enable AddQuicktag in custom post type
function dp_addquicktag_set_custom_post_type($post_types) {
	global $options;
	array_push($post_types, $options['news_cpt_slug_id']);
	return $post_types;
}
add_filter('addquicktag_post_types', 'dp_addquicktag_set_custom_post_type');


/**
 * Insert img tag to editor with resized image sizes for retina.
 * @param  string $html inserting img tag from media
 * @return string       New img tag with resized half attribute.
 */
function dp_image_send_to_editor_for_retina( $html ) {
	global $options;

	if ( !isset($options['retina_img_tag_to_editor']) || empty($options['retina_img_tag_to_editor'])) return $html;

	$html = preg_replace_callback( '/(width|height)="(\d*)"\s/',
		function($m){
			return $m[1] . '="' . round($m[2] / 2) . '" ';
		},
		$html
	);
	return $html;
}
add_filter( 'image_send_to_editor', 'dp_image_send_to_editor_for_retina' );