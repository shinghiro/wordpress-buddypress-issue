<?php
/**
* Add custom fields to menu item
*
* This will allow us to play nicely with any other plugin that is adding the same hook
*
* @param $item_id: the menu item ID (integer)
* @param $item: the menu item data object (object)
* @param $depth: the depth of the menu item (integer)
* @param $args: an object of menu item arguments (object)
* @param $id: the Navigation Menu ID (integer)
*/
function dp_add_custom_menu_fields( $item_id, $item ) {

	/**
	 * Second label
	 */
	$custom_menu_item_second_label = get_post_meta( $item_id, '_custom_menu_item_second_label', true );
?>
<p class="field-second-label description" style="clear:both;margin-bottom:18px;"><?php
	wp_nonce_field( 'custom_menu_item_second_label_nonce', '_custom_menu_item_second_label_nonce_name' ); ?>
	<label for="edit-menu-item-second-label-<?php echo $item_id ;?>">
		<?php _e( 'Secondary label', 'DigiPress' ); ?><br />
		<input type="hidden" class="nav-menu-id" value="<?php echo $item_id ;?>" />
			<input type="text" id="edit-menu-item-second-label-<?php echo $item_id ;?>" class="widefat code edit-menu-item-second-label" name="custom_menu_item_second_label[<?php echo $item_id ;?>]" value="<?php echo esc_attr( $custom_menu_item_second_label ); ?>" /><br />
			<span class="description">
				<?php _e( 'The second label replaces the navigation label when the menu is hovered.', 'DigiPress' ); ?><br />
			</span>
	</label>
</p><?php

	/**
	 * Icon
	 */
	$custom_menu_item_icon = get_post_meta( $item_id, '_custom_menu_item_icon', true );
?>
<p class="field-icon description" style="clear:both;margin-bottom:18px;"><?php
	wp_nonce_field( 'custom_menu_item_icon_nonce', '_custom_menu_item_icon_nonce_name' ); ?>
	<label for="edit-menu-item-icon-<?php echo $item_id ;?>">
		<?php _e( 'Icon class', 'DigiPress' ); ?><br />
		<input type="hidden" class="nav-menu-id" value="<?php echo $item_id ;?>" />
			<input type="text" id="edit-menu-item-icon-<?php echo $item_id ;?>" class="widefat code edit-menu-item-icon" name="custom_menu_item_icon[<?php echo $item_id ;?>]" value="<?php echo esc_attr( $custom_menu_item_icon ); ?>" /><br />
			<span class="description">
				<?php _e( 'If you want an icon to appear next to the label, enter the icon class.', 'DigiPress' ); ?><br />
				<a href="https://DigiPress.info/manual/icon-font-map/" class="button button-small" target="_blank"><?php _e( 'See the icon class list', 'DigiPress' ); ?></a>
			</span>
	</label>
</p><?php


	/**
	 * Icon position
	 */
	$custom_menu_item_icon_position = get_post_meta( $item_id, '_custom_menu_item_icon_position', true );
?>
<p class="field-icon-position description" style="margin-bottom:18px;"><?php
	wp_nonce_field( 'custom_menu_item_icon_position_nonce', '_custom_menu_item_icon_position_nonce_name' ); ?>
	<?php _e( 'Icon position', 'DigiPress' ); ?><br />
		<label for="edit-menu-item-icon-position-<?php echo $item_id ;?>-1" class="selected-menu">
			<input type="radio" id="edit-menu-item-icon-position-<?php echo $item_id ;?>-1" name="custom_menu_item_icon_position[<?php echo $item_id ;?>]" value="left" <?php
	if ( isset( $custom_menu_item_icon_position ) && $custom_menu_item_icon_position == 'left' ) echo 'checked'; ?> /> <?php
	_e( 'Left', 'DigiPress' );
	?>
		</label>
		<label for="edit-menu-item-icon-position-<?php echo $item_id ;?>-2" class="selected-menu">
			<input type="radio" id="edit-menu-item-icon-position-<?php echo $item_id ;?>-2" name="custom_menu_item_icon_position[<?php echo $item_id ;?>]" value="right" <?php
	if ( isset( $custom_menu_item_icon_position ) && $custom_menu_item_icon_position == 'right' ) echo 'checked'; ?> /> <?php
	_e( 'Right', 'DigiPress' );
	?>
		</label>
</p><?php



	/**
	 * Mega menu flag
	 */
	$custom_menu_item_mega_menu = get_post_meta( $item_id, '_custom_menu_item_mega_menu', true );
?>
<p class="field-mega-menu description" style="margin-bottom:18px;"><?php
	wp_nonce_field( 'custom_menu_item_mega_menu_nonce', '_custom_menu_item_mega_menu_nonce_name' ); ?>
	<label for="edit-menu-item-mega-menu-<?php echo $item_id ;?>">
		<input type="checkbox" id="edit-menu-item-mega-menu-<?php echo $item_id ;?>" name="custom_menu_item_mega_menu[<?php echo $item_id ;?>]" value="1" <?php
	if ( isset( $custom_menu_item_mega_menu ) && !empty( $custom_menu_item_mega_menu ) ) echo 'checked'; ?> /> <?php
	_e( 'Show as a mega menu', 'DigiPress' );
	?>
	</label><br />
	<span class="description">
		<?php _e( 'This option is available for the parent menu only.', 'DigiPress' ); ?>
	</span>
</p><?php


	/**
	 * Featured Image
	 */
	$custom_menu_item_image = get_post_meta( $item_id, '_custom_menu_item_image', true );
?>
<p class="field-image description" style="clear:both;margin-bottom:18px;"><?php
	wp_nonce_field( 'custom_menu_item_image_nonce', '_custom_menu_item_image_nonce_name' ); ?>
	<label for="edit-menu-item-image-<?php echo $item_id ;?>">
		<?php _e( 'Image URL', 'DigiPress' ); ?><br />
		<input type="hidden" class="nav-menu-id" value="<?php echo $item_id ;?>" />
			<input type="url" id="edit-menu-item-image-<?php echo $item_id ;?>" class="widefat code edit-menu-item-image img_url with-add-btn" size="36" name="custom_menu_item_image[<?php echo $item_id ;?>]" value="<?php echo esc_attr( $custom_menu_item_image ); ?>" /><button class="dp_upload_image_button button"><?php _e('Add / Change','DigiPress'); ?></button>
			<span class="preview-img">
			<?php if ( ! empty( $custom_menu_item_image ) ) {
				echo '<img src="' . $custom_menu_item_image . '" />';
			} ?>
			</span>
			<span class="description">
				<?php _e( 'You can set the featured image of this menu item.', 'DigiPress' ); ?>
			</span>
	</label>
</p><?php

}
add_action( 'wp_nav_menu_item_custom_fields', 'dp_add_custom_menu_fields', 10, 2 );


/**
* Save the menu item meta
*
* @param int $menu_id
* @param int $menu_item_db_id
*/
function dp_save_custom_menu_fields( $menu_id, $menu_item_db_id ) {

	/**
	 * Second label
	 */
	if ( isset( $_POST['_custom_menu_item_second_label_nonce_name'] ) && wp_verify_nonce( $_POST['_custom_menu_item_second_label_nonce_name'], 'custom_menu_item_second_label_nonce' ) ) {
		if ( isset( $_POST['custom_menu_item_second_label'][$menu_item_db_id]  ) ) {

			$sanitized_data = sanitize_text_field( $_POST['custom_menu_item_second_label'][$menu_item_db_id] );
			update_post_meta( $menu_item_db_id, '_custom_menu_item_second_label', $sanitized_data );

		} else {

			delete_post_meta( $menu_item_db_id, '_custom_menu_item_second_label' );

		}
	}

	/**
	 * Icon
	 */
	if ( isset( $_POST['_custom_menu_item_icon_nonce_name'] ) && wp_verify_nonce( $_POST['_custom_menu_item_icon_nonce_name'], 'custom_menu_item_icon_nonce' ) ) {
		if ( isset( $_POST['custom_menu_item_icon'][$menu_item_db_id]  ) ) {

			$sanitized_data = sanitize_text_field( $_POST['custom_menu_item_icon'][$menu_item_db_id] );
			update_post_meta( $menu_item_db_id, '_custom_menu_item_icon', $sanitized_data );

		} else {

			delete_post_meta( $menu_item_db_id, '_custom_menu_item_icon' );

		}
	}


	/**
	 * Icon position
	 */
	if ( isset( $_POST['_custom_menu_item_icon_position_nonce_name'] ) && wp_verify_nonce( $_POST['_custom_menu_item_icon_position_nonce_name'], 'custom_menu_item_icon_position_nonce' ) ) {
		if ( isset( $_POST['custom_menu_item_icon_position'][$menu_item_db_id]  ) ) {

			update_post_meta( $menu_item_db_id, '_custom_menu_item_icon_position', $_POST['custom_menu_item_icon_position'][$menu_item_db_id] );

		} else {

			delete_post_meta( $menu_item_db_id, '_custom_menu_item_icon_position' );

		}
	}


	/**
	 * Mega menu flag
	 */
	if ( isset( $_POST['_custom_menu_item_mega_menu_nonce_name'] ) && wp_verify_nonce( $_POST['_custom_menu_item_mega_menu_nonce_name'], 'custom_menu_item_mega_menu_nonce' ) ) {
		if ( isset( $_POST['custom_menu_item_mega_menu'][$menu_item_db_id]  ) ) {

			update_post_meta( $menu_item_db_id, '_custom_menu_item_mega_menu', $_POST['custom_menu_item_mega_menu'][$menu_item_db_id] );

		} else {

			delete_post_meta( $menu_item_db_id, '_custom_menu_item_mega_menu' );

		}
	}


	/**
	 * Featured Image
	 */
	if ( isset( $_POST['_custom_menu_item_image_nonce_name'] ) && wp_verify_nonce( $_POST['_custom_menu_item_image_nonce_name'], 'custom_menu_item_image_nonce' ) ) {
		if ( isset( $_POST['custom_menu_item_image'][$menu_item_db_id]  ) ) {

			$sanitized_data = sanitize_text_field( $_POST['custom_menu_item_image'][$menu_item_db_id] );
			update_post_meta( $menu_item_db_id, '_custom_menu_item_image', $sanitized_data );

		} else {

			delete_post_meta( $menu_item_db_id, '_custom_menu_item_image' );

		}
	}
}
add_action( 'wp_update_nav_menu_item', 'dp_save_custom_menu_fields', 10, 2 );