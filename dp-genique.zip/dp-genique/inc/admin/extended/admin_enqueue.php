<?php
/**
 * Import original CSS and javascript in admin panel
 * @param  [type] $hook_suffix [description]
 * @return [type]              [description]
 */
function dp_admin_enqueue($hook_suffix) {
	switch ($hook_suffix) {
		case 'post-new.php':
		case 'post.php':	// post edit
			wp_enqueue_media();
			wp_enqueue_style('wp-color-picker');
			wp_enqueue_script('wp-color-picker');
			wp_enqueue_style( 'dp_admin', DP_THEME_URI . '/inc/css/dp_admin.css', null);
			wp_enqueue_style( 'magazibne_preview', DP_THEME_URI . '/inc/css/post_option_magazine_preview.css', null);
			wp_enqueue_script( 'dp_post_page', DP_THEME_URI . '/inc/js/dp_post_page.min.js', array('jquery', 'wp-color-picker'), DP_OPTION_SPT_VERSION, true );
			break;

		case 'widgets.php':
			// jQuery
		    wp_enqueue_script('jquery',array(),false);
			// Color picker
			wp_enqueue_style('wp-color-picker');
			wp_enqueue_script('wp-color-picker');
			// widgets
			wp_enqueue_style( 'dp_widgets_page', DP_THEME_URI . '/inc/css/dp_widgets_page.css', null);
			wp_enqueue_script( 'dp_widgets_page', DP_THEME_URI."/inc/js/dp_widgets_page.min.js", array('jquery', 'wp-color-picker'), DP_OPTION_SPT_VERSION, true );
			break;

		case 'edit.php':	// Post list
			wp_enqueue_script( 'dp_admin_edit', DP_THEME_URI . '/inc/js/dp_admin_edit.min.js', array('jquery'), DP_OPTION_SPT_VERSION, true );
			break;

		case 'edit-tags.php': // Category, tag add
		case 'term.php':	// Category, tag edit
			wp_enqueue_media();
			wp_enqueue_script('thickbox');
			wp_enqueue_style('thickbox');
		    wp_enqueue_style('wp-color-picker');
		    wp_enqueue_script('wp-color-picker');
			wp_enqueue_script( 'dp_term', DP_THEME_URI . '/inc/js/dp_term.min.js', array('jquery'), DP_OPTION_SPT_VERSION, true );
			wp_enqueue_style( 'dp_term', DP_THEME_URI . '/inc/css/dp_term.css', null );
			break;

		case 'themes.php':	// Theme list
			wp_enqueue_style('theme_update_details', DP_THEME_URI . '/inc/css/theme_update_details.css', null);
			break;

		case 'nav-menus.php': // Menu
			wp_enqueue_media();
			wp_enqueue_script( 'dp_menu_page', DP_THEME_URI . '/inc/js/dp_menu_page.min.js', array('jquery'), DP_OPTION_SPT_VERSION, true );
			wp_enqueue_style( 'dp_menu_page', DP_THEME_URI . '/inc/css/dp_menu_page.css', null );
			break;
	}
}
add_action( 'admin_enqueue_scripts', 'dp_admin_enqueue' );