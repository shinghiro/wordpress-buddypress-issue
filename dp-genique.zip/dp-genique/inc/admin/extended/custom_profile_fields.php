<?php
/**
 * Hide or add profile items
 */
function dp_custom_profile_fields( $fields ) {
	// Remove fields
	unset($fields['aim']);     // AIM
	unset($fields['yim']);     // Yahoo IM
	unset($fields['jabber']);  // Jabber / Google Talk

	// Add new fields
	$fields['site_name']= __('Your site name', 'DigiPress');
	$fields['org']		= __('Organization', 'DigiPress');
	$fields['title']	= __('Role', 'DigiPress');
	$fields['twitter']	= __('Twitter URL', 'DigiPress');
	$fields['facebook'] = __('Facebook URL', 'DigiPress');
	$fields['youtube'] 	= __('YouTube URL', 'DigiPress');
	$fields['flickr'] 	= __('Flickr URL', 'DigiPress');
	$fields['instagram'] 	= __('Instagram URL', 'DigiPress');
	$fields['pinterest'] 	= __('Pinterest URL', 'DigiPress');
	$fields['bg_img']	= __('Prof background image URL', 'DigiPress');

	return $fields;
}
add_filter('user_contactmethods','dp_custom_profile_fields',10, 1);

/**
 * Custom field for user profile
 */
function dp_add_original_profile_fields($bool) {
	global $wp_version;

	$current_profile_user = [];

	if ( version_compare( $wp_version, '6.0', '<' ) ) {
		global $profileuser;
		$current_profile_user = $profileuser;
	} else {
		global $profile_user;
		$current_profile_user = $profile_user;
	}

	if ( preg_match('/^(profile\.php|user-edit\.php)/', basename($_SERVER['REQUEST_URI'])) ) {

		echo '<tr><th scope="row" rowspan="2">' . __('Authors list page config', 'DigiPress') . '</th>';
		echo '<td><input type="text" name="ref_url" id="ref_url" value="' . esc_html($current_profile_user->ref_url) . '" class="regular-text" placeholder="' . __('Reference URL in authors list page', 'DigiPress') .'" />
		<p class="description">' . __('URL to refer to when the profile image is clicked on the authors list page.', 'DigiPress') . '</p></td>';
		echo '</tr>';

		echo '<tr><td>';
		echo '<label><input type="checkbox" name="open_new_tab_ref_url" value="1"' . ( ( isset($current_profile_user->open_new_tab_ref_url) && !empty($current_profile_user->open_new_tab_ref_url) ) ? ' checked' : '' ) .' />' . __('Open URL in new tab', 'DigiPress') .'</label>';
		echo '</td></tr>';
	}

	return $bool;
}
add_action( 'show_password_fields', 'dp_add_original_profile_fields' );

function dp_update_original_profile_data($user_id, $old_user_data){
	if ( isset($_POST['ref_url']) && $old_user_data->ref_url != $_POST['ref_url'] ){
		// Reference URL
		$ref_url = esc_url_raw($_POST['ref_url']);
		update_user_meta( $user_id, 'ref_url', $ref_url );
	}

	if ( isset($_POST['open_new_tab_ref_url']) && $old_user_data->open_new_tab_ref_url != $_POST['open_new_tab_ref_url'] ){
		// Open in new tab
		update_user_meta( $user_id, 'open_new_tab_ref_url', $_POST['open_new_tab_ref_url'] );
	} else {
		update_user_meta( $user_id, 'open_new_tab_ref_url', null );
	}
}
add_action( 'profile_update', 'dp_update_original_profile_data', 10, 2 );