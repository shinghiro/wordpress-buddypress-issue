<?php
/*******************************************************
* Custom Field Contents
*******************************************************/
// Array for custom field
$dp_cf_arr = array(
	'is_slideshow',
	'slideshow_image_url',
	// 'is_headline',
	'hide_sns_icon',
	'dp_disable_breadcrumb',
	'dp_hide_title',
	'dp_hide_date',
	'dp_hide_author',
	'dp_hide_cat',
	'dp_hide_tag',
	'dp_hide_views',
	'dp_hide_fb_comment',
	'dp_hide_next_prev',
	'dp_hide_follow_box',
	'dp_meta_keyword',
	'dp_meta_desc',
	'dp_hide_time_for_reading',
	'dp_noindex',
	'dp_nofollow',
	'dp_noarchive',
	'dp_hide_toc',
	'item_taxonomy',
	'item_image_url',
	'item_video_id',
	'video_service',
	'disable_sidebar',
	'one_col_narrow',
	'disable_wpautop',
	'replace_p_to_br',
	'dp_hide_header_menu',
	'dp_hide_footer',
	'dp_show_eyecatch_force',
	'dp_eyecatch_on_container',
	'dp_post_tag',
	'dp_post_tag_color',
	'dp_hide_related_posts',
	'dp_related_posts_title',
	'dp_archive_slider_img1',
	'dp_archive_slider_img2',
	'dp_archive_slider_img3',
	'dp_hide_author_prof',
	'dp_eyecatch_to_bg',
	'dp_free_meta_title',
	'dp_free_meta1_key',
	'dp_free_meta1_val',
	'dp_free_meta2_key',
	'dp_free_meta2_val',
	'dp_free_meta3_key',
	'dp_free_meta3_val',
	'dp_free_meta4_key',
	'dp_free_meta4_val',
	'dp_free_meta5_key',
	'dp_free_meta5_val',
	'nextpage_text',
	'magazine_custom_design',
	'magazine_cover_frame',
	'magazine_cover_frame_color',
	'magazine_title',
	'magazine_title_position',
	'magazine_title_by_bold',
	'magazine_text_by_serif',
	'magazine_text_vertically',
	'magazine_caption',
	'magazine_title_tilt',
	'magazine_title_back',
	'magazine_title_color',
	'magazine_title_back_color',
	'magazine_title_back_color_opacity',
	'magazine_title_back_border',
	'magazine_date_design',
	'magazine_accent_shape',
	'magazine_accent_shape_color',
	'magazine_accent_shape_opacity',
	'magazine_image',
);

// Add custom fields
function add_custom_field() {
	if ( !function_exists('add_meta_box') ) return;
	global $options, $dp_cf_arr;
	// Add to single
	add_meta_box(
		'dp_custom_fields_single', 
		__('Post options','DigiPress'), 
		'html_source_for_custom_box_single', 
		'post', 
		'normal', 
		'high'
	);
	// Add to page
	add_meta_box(
		'dp_custom_fields_page', 
		__('Post options','DigiPress'), 
		'html_source_for_custom_box_page', 
		'page', 
		'normal', 
		'high'
	);
	// Add to custom type
	add_meta_box(
		'dp_custom_fields_page', 
		__('Post options','DigiPress'), 
		'html_source_for_custom_box_page', 
		$options['news_cpt_slug_id'], 
		'normal', 
		'high'
	);
}

// Save custom fields...
function save_custom_field($post_id) {
	// Throw auto save 
	if ( defined('DOING_AUTOSAVE') && DOING_AUTOSAVE ) return $post_id;

	global $pagenow, $typenow, $post, $dp_cf_arr;
	//Throw if current saving is under quick edit(admin-ajax.php) or bulk edit(edit.php)
	if ( $pagenow === 'admin-ajax.php' || $pagenow === 'edit.php' || $pagenow === 'wp-cron.php') return;

	// Add array from extensions
	$additional_params = apply_filters( 'dp_custom_field_add_params', $post_id );
	if ( $additional_params != $post_id ) {
		array_push($dp_cf_arr, $additional_params);
	}

	if (!isset($post_id)) $post_id = $_REQUEST['post_ID'];

	// Save
	$dp_cf_val = '';
	foreach($dp_cf_arr as $dp_cf) {
 		// Get Current item
		$dp_cf_current 	= get_post_meta($post_id, $dp_cf);
		// Get value
		$dp_cf_val 	= isset($_POST[$dp_cf]) ? $_POST[$dp_cf] : '';
 		// Save, update or delete
		if( empty($dp_cf_current) ) {
			add_post_meta($post_id, $dp_cf, $dp_cf_val, true);
		} elseif ( $dp_cf_current != $dp_cf_val ) {
			update_post_meta($post_id, $dp_cf, $dp_cf_val);
		} elseif ( empty($dp_cf_val) ) {
			delete_post_meta( $post_id, $dp_cf );
		}
	}
}

/*---------------------------------------
 * For Single
 *--------------------------------------*/
/* HTML form */
function html_source_for_custom_box_single() {
	global $post;

	$is_slideshow = get_post_meta( $post->ID, 'is_slideshow', true);
	$slideshow_image_url = get_post_meta( $post->ID, 'slideshow_image_url', true);
	// $is_headline	= get_post_meta( $post->ID, 'is_headline', true);
	$disable_sidebar = get_post_meta( $post->ID, 'disable_sidebar', true);
	$one_col_narrow = get_post_meta( $post->ID, 'one_col_narrow' , true);
	$hide_sns_icon	= get_post_meta( $post->ID, 'hide_sns_icon', true);
	$dp_disable_breadcrumb	= get_post_meta( $post->ID, 'dp_disable_breadcrumb', true);
	$dp_hide_date	= get_post_meta( $post->ID, 'dp_hide_date', true);
	$dp_hide_title = get_post_meta( $post->ID, 'dp_hide_title', true);
	$dp_hide_author	= get_post_meta( $post->ID, 'dp_hide_author', true);
	$dp_hide_cat	= get_post_meta( $post->ID, 'dp_hide_cat', true);
	$dp_hide_tag	= get_post_meta( $post->ID, 'dp_hide_tag', true);
	$dp_hide_views	= get_post_meta( $post->ID, 'dp_hide_views', true);
	$dp_hide_fb_comment = get_post_meta( $post->ID, 'dp_hide_fb_comment', true);
	$dp_hide_next_prev = get_post_meta( $post->ID, 'dp_hide_next_prev', true);
	$dp_hide_follow_box = get_post_meta( $post->ID, 'dp_hide_follow_box', true);
	$dp_hide_time_for_reading = get_post_meta( $post->ID, 'dp_hide_time_for_reading', true);
	$dp_meta_keyword= get_post_meta( $post->ID, 'dp_meta_keyword', true);
	$dp_noindex		= get_post_meta( $post->ID, 'dp_noindex', true);
	$dp_nofollow	= get_post_meta( $post->ID, 'dp_nofollow', true);
	$dp_noarchive	= get_post_meta( $post->ID, 'dp_noarchive', true);
	$dp_hide_toc	= get_post_meta( $post->ID, 'dp_hide_toc', true);
	$item_video_id 	= get_post_meta( $post->ID, 'item_video_id', true);
	$video_service	= get_post_meta( $post->ID, 'video_service', true);
	$dp_show_eyecatch_force	= get_post_meta( $post->ID, 'dp_show_eyecatch_force', true);
	$dp_eyecatch_on_container= get_post_meta( $post->ID, 'dp_eyecatch_on_container', true);
	$dp_eyecatch_to_bg= get_post_meta( $post->ID, 'dp_eyecatch_to_bg', true);
	$disable_wpautop = get_post_meta( $post->ID, 'disable_wpautop', true);
	$replace_p_to_br = get_post_meta( $post->ID, 'replace_p_to_br', true);
	$dp_post_tag 	= get_post_meta( $post->ID, 'dp_post_tag', true);
	$dp_post_tag_color= get_post_meta( $post->ID, 'dp_post_tag_color', true);
	$dp_hide_related_posts= get_post_meta( $post->ID, 'dp_hide_related_posts', true);
	$dp_related_posts_title= get_post_meta( $post->ID, 'dp_related_posts_title', true);
	$dp_archive_slider_img1= get_post_meta( $post->ID, 'dp_archive_slider_img1', true);
	$dp_archive_slider_img2= get_post_meta( $post->ID, 'dp_archive_slider_img2', true);
	$dp_archive_slider_img3= get_post_meta( $post->ID, 'dp_archive_slider_img3', true);
	$dp_hide_author_prof	= get_post_meta( $post->ID, 'dp_hide_author_prof', true);
	$dp_free_meta_title	= get_post_meta( $post->ID, 'dp_free_meta_title', true);
	$dp_free_meta1_key	= get_post_meta( $post->ID, 'dp_free_meta1_key', true);
	$dp_free_meta1_val	= get_post_meta( $post->ID, 'dp_free_meta1_val', true);
	$dp_free_meta2_key	= get_post_meta( $post->ID, 'dp_free_meta2_key', true);
	$dp_free_meta2_val	= get_post_meta( $post->ID, 'dp_free_meta2_val', true);
	$dp_free_meta3_key	= get_post_meta( $post->ID, 'dp_free_meta3_key', true);
	$dp_free_meta3_val	= get_post_meta( $post->ID, 'dp_free_meta3_val', true);
	$dp_free_meta4_key	= get_post_meta( $post->ID, 'dp_free_meta4_key', true);
	$dp_free_meta4_val	= get_post_meta( $post->ID, 'dp_free_meta4_val', true);
	$dp_free_meta5_key	= get_post_meta( $post->ID, 'dp_free_meta5_key', true);
	$dp_free_meta5_val	= get_post_meta( $post->ID, 'dp_free_meta5_val', true);
	$nextpage_text	= get_post_meta( $post->ID, 'nextpage_text', true);
	$magazine_custom_design	= get_post_meta( $post->ID, 'magazine_custom_design', true);
	$magazine_cover_frame	= get_post_meta( $post->ID, 'magazine_cover_frame', true);
	$magazine_cover_frame_color	= get_post_meta( $post->ID, 'magazine_cover_frame_color', true);
	$magazine_title_position	= get_post_meta( $post->ID, 'magazine_title_position', true);
	$magazine_title	= get_post_meta( $post->ID, 'magazine_title', true);
	$magazine_caption	= get_post_meta( $post->ID, 'magazine_caption', true);
	$magazine_image	= get_post_meta( $post->ID, 'magazine_image', true);
	$magazine_title_by_bold	= get_post_meta( $post->ID, 'magazine_title_by_bold', true);
	$magazine_text_by_serif	= get_post_meta( $post->ID, 'magazine_text_by_serif', true);
	$magazine_text_vertically	= get_post_meta( $post->ID, 'magazine_text_vertically', true);
	$magazine_title_tilt	= get_post_meta( $post->ID, 'magazine_title_tilt', true);
	$magazine_title_color	= get_post_meta( $post->ID, 'magazine_title_color', true);
	$magazine_title_back	= get_post_meta( $post->ID, 'magazine_title_back', true);
	$magazine_title_back_color	= get_post_meta( $post->ID, 'magazine_title_back_color', true);
	$magazine_title_back_color_opacity	= get_post_meta( $post->ID, 'magazine_title_back_color_opacity', true);
	$magazine_title_back_border	= get_post_meta( $post->ID, 'magazine_title_back_border', true);
	$magazine_date_design	= get_post_meta( $post->ID, 'magazine_date_design', true);
	$magazine_accent_shape	= get_post_meta( $post->ID, 'magazine_accent_shape', true);
	$magazine_accent_shape_color	= get_post_meta( $post->ID, 'magazine_accent_shape_color', true);
	$magazine_accent_shape_opacity	= get_post_meta( $post->ID, 'magazine_accent_shape_opacity', true);


	// For magazine design
	$cat = get_the_category( $post->ID );
	if ( isset( $cat ) && !empty( $cat ) && is_array( $cat ) ) {
		$cat = $cat[0]->cat_name;
	} else {
		$cat = '';
	}

	$eyecatch = DP_Post_Thumbnail::get_post_thumbnail(
		array(
			'width' => 460,
			'height' => 320,
			'size' => 'dp-archive-thumb',
			'if_img_tag' => false
		)
	);
	if ( !isset( $magazine_image ) || empty( $magazine_image ) ) {
		$magazine_image = $eyecatch;
	}
	$article_style = '';
	$article_class = 'loop-article ' . $magazine_cover_frame . ' ' . $magazine_title_position . ' ' . $magazine_title_by_bold . ' ' . $magazine_text_by_serif . ' ' . $magazine_text_vertically . ' ' . $magazine_title_tilt . ' ' . $magazine_date_design . ' ' . $magazine_accent_shape;
	if ( isset( $magazine_title_back ) && $magazine_title_back == 'has-title-back' ){
		$article_class .= ' ' . $magazine_title_back . ' ' . $magazine_title_back_border;

		$article_style .= isset( $magazine_title_back_color ) && !empty( $magazine_title_back_color ) ? '--mgz-title-bg-color:' . $magazine_title_back_color . ';' : '';
		$article_style .= isset( $magazine_title_back_color_opacity ) && !empty( $magazine_title_back_color_opacity ) ? '--mgz-title-bg-opacity:' . (int)$magazine_title_back_color_opacity / 100 . ';' : '';
	}
	$article_style .= isset( $magazine_cover_frame_color ) && !empty( $magazine_cover_frame_color ) ? '--mgz-frame-color:' . $magazine_cover_frame_color . ';' : '';
	$article_style .= isset( $magazine_title_color ) && !empty( $magazine_title_color ) ? '--mgz-title-color:' . $magazine_title_color . ';' : '';
	$article_style .= isset( $magazine_accent_shape_color ) && !empty( $magazine_accent_shape_color ) ? '--acc-shape-color:' . $magazine_accent_shape_color . ';' : '';
	$article_style .= isset( $magazine_accent_shape_opacity ) && !empty( $magazine_accent_shape_opacity ) ? '--acc-shape-opacity:' . (int)$magazine_accent_shape_opacity / 100 . ';' : '';
	$article_style = !empty( $article_style ) ? ' style="' . $article_style . '"' : '';


	// Additional settings
	$additional_setting = '';
	$preview_tag = '';
	if ( !empty($slideshow_image_url) ) {
		$preview_tag = '<img src="' . $slideshow_image_url . '" id="exist_slide_image" />';
	}

	$css_code = <<<_EOD_
<style type="text/css"><!--
.dp_cf_item_box {
	border:1px solid #ddd;
	padding:16px;
	margin-bottom:10px;
}
.dp_cf_item_box p {
	margin:6px 0 12px 0;
}
.dp_cf_inner_box {
	margin:10px;
}
--></style>
_EOD_;
	$css_code = str_replace(array("\r\n","\r","\n","\t","/^\s(?=\s)/"), '', $css_code);
	echo $css_code;

	// Featured tag
	echo '<div class="dp_cf_item_box">
		 <p class="b">'.__('Featured tag :','DigiPress').'</p>
		 <p>'.__("Enter the label that featured this post. This tag uses as a label in each archive page.", "DigiPress").'</p>
		 <label for="dp_post_tag">'.__('Label strings : ', 'DigiPress').'</label><input name="dp_post_tag" id="dp_post_tag" type="text" size=20 value="'.htmlspecialchars(stripslashes($dp_post_tag)).'" /> '.__('Label background color','DigiPress').' : 
		 <input type="text" name="dp_post_tag_color" value="'.$dp_post_tag_color.'" class="dp-color-field" /></div>';

	// Video ID
	echo '<div class="dp_cf_item_box">
		<p class="b">'.__('Embed video ID:','DigiPress').'</p>
		 <p>'.__('Enter the video ID to play video in archive page.', 'DigiPress').'</p>
		 <div class="mg10px-btm">
		 <label for="video_service"> '.__("Service : ","DigiPress").'</label>
		 <select name="video_service" id="video_service" size=1 class="mg10px-r">
		  <option value="YouTube" ' .( (!$video_service || $video_service) === 'YouTube' ? ' selected="selected"' : '').'>YouTube</option>
		  <option value="Vimeo" ' .(isset($video_service) && $video_service === 'Vimeo' ? ' selected="selected"' : '').'>Vimeo</option></select> 
		 <label for="item_video_id"> '.__("Video ID : ","DigiPress").'</label>
		 <input type="text" name="item_video_id" id="item_video_id" size="15" value="'.$item_video_id.'" /></div></div>';

	// Archive slider image
	echo '<div class="dp_cf_item_box"><p class="b">'.__('Archive slider images:','DigiPress').'</p>
		 <p>'.__('Enter the image URL to display the slide show in archgive page.', 'DigiPress').'</p>
		 <div class="mg10px-btm">'.__('Image ','DigiPress').'1 : <input type="text" name="dp_archive_slider_img1" id="dp_archive_slider_img1" class="img_url" size="50" style="width:70%;" value="'.$dp_archive_slider_img1.'" /><button class="dp_upload_image_button button">'.__('Add / Change','DigiPress').'</button></div>
		 <div class="mg10px-btm">'.__('Image ','DigiPress').'2 : <input type="text" name="dp_archive_slider_img2" id="dp_archive_slider_img2" class="img_url" size="50" style="width:70%;" value="'.$dp_archive_slider_img2.'" /><button class="dp_upload_image_button button">'.__('Add / Change','DigiPress').'</button></div>
		 <div class="mg10px-btm">'.__('Image ','DigiPress').'3 : <input type="text" name="dp_archive_slider_img3" id="dp_archive_slider_img3" class="img_url" size="50" style="width:70%;" value="'.$dp_archive_slider_img3.'" /><button class="dp_upload_image_button button">'.__('Add / Change','DigiPress').'</button></div>';
	echo '</div>';

	// Free meta
	echo '<div class="dp_cf_item_box"><p class="b">'.__('Free Meta Data:','DigiPress').'</p>
		 <p>'.__('Enter these custom meta info if you want to show them in archive and single page.', 'DigiPress').'</p>
		 <div class="mg10px-btm">'.__('Heading Text','DigiPress').' : <input type="text" name="dp_free_meta_title" id="dp_free_meta_title" size="80" style="width:60%;" value="'.htmlspecialchars(stripslashes($dp_free_meta_title)).'" placeholder="' . __('Product name, full name, etc.', 'DigiPress') . '" />
		 	<p> '.__('*If you input the heading phrase, it will appear at the beginning of this metatable on a single page.', 'DigiPress').'</p></div>
		 <div class="mg10px-btm">'.__('Title ','DigiPress').'1 : <input type="text" name="dp_free_meta1_key" id="dp_free_meta1_key" size="20" style="width:15%;" value="'.htmlspecialchars(stripslashes($dp_free_meta1_key)).'" placeholder="' . __('Price', 'DigiPress') . '" /> '.__('Value ','DigiPress').' : <input type="text" name="dp_free_meta1_val" id="dp_free_meta1_val" size="20" style="width:50%;" value="'.htmlspecialchars(stripslashes($dp_free_meta1_val)).'" placeholder="¥12,800" /></div>
		 <div class="mg10px-btm">'.__('Title ','DigiPress').'2 : <input type="text" name="dp_free_meta2_key" id="dp_free_meta2_key" size="20" style="width:15%;" value="'.htmlspecialchars(stripslashes($dp_free_meta2_key)).'" placeholder="' . __('Price', 'DigiPress') . '" /> '.__('Value ','DigiPress').' : <input type="text" name="dp_free_meta2_val" id="dp_free_meta2_val" size="20" style="width:50%;" value="'.htmlspecialchars(stripslashes($dp_free_meta2_val)).'" placeholder="¥12,800" /></div>
		 <div class="mg10px-btm">'.__('Title ','DigiPress').'3 : <input type="text" name="dp_free_meta3_key" id="dp_free_meta3_key" size="20" style="width:15%;" value="'.htmlspecialchars(stripslashes($dp_free_meta3_key)).'" placeholder="' . __('Price', 'DigiPress') . '" /> '.__('Value ','DigiPress').' : <input type="text" name="dp_free_meta3_val" id="dp_free_meta3_val" size="20" style="width:50%;" value="'.htmlspecialchars(stripslashes($dp_free_meta3_val)).'" placeholder="¥12,800" /></div>
		 <div class="mg10px-btm">'.__('Title ','DigiPress').'4 : <input type="text" name="dp_free_meta4_key" id="dp_free_meta4_key" size="20" style="width:15%;" value="'.htmlspecialchars(stripslashes($dp_free_meta4_key)).'" placeholder="' . __('Price', 'DigiPress') . '" /> '.__('Value ','DigiPress').' : <input type="text" name="dp_free_meta4_val" id="dp_free_meta4_val" size="20" style="width:50%;" value="'.htmlspecialchars(stripslashes($dp_free_meta4_val)).'" placeholder="¥12,800" /></div>
		 <div class="mg10px-btm">'.__('Title ','DigiPress').'5 : <input type="text" name="dp_free_meta5_key" id="dp_free_meta5_key" size="20" style="width:15%;" value="'.htmlspecialchars(stripslashes($dp_free_meta5_key)).'" placeholder="' . __('Price', 'DigiPress') . '" /> '.__('Value ','DigiPress').' : <input type="text" name="dp_free_meta5_val" id="dp_free_meta5_val" size="20" style="width:50%;" value="'.htmlspecialchars(stripslashes($dp_free_meta5_val)).'" placeholder="¥12,800" /></div>';
	echo '</div>';

	// Magazine style
	echo '<div class="dp_cf_item_box">
		<p class="b">' . __( 'Custom Magazine style','DigiPress' ) . '</p>
		<p>' . __( 'When the article list is displayed in magazine style, modify this option if you want to change the design for this article instead of the common setting design.', 'DigiPress' ) . '</p>
		<input type="checkbox" name="magazine_custom_design" id="magazine_custom_design" value="1" class="toggle_ele"' . ( isset( $magazine_custom_design ) && !empty( $magazine_custom_design ) ? ' checked="checked"' : '' ) . ' />
		<label for="magazine_custom_design">' . __( 'Customize to original design', 'DigiPress' ) . '</label>

		<div class="toggle_content">
			<div class="box-c">
				<div class="grid-box">
					<div class="grid-item">

					 	<div class="flex-box">
						 	<div class="flex-item">
								<label for="magazine_cover_frame" class="disp-blk"> ' . __( 'Frame design', 'DigiPress' ) . '</label>
								<select name="magazine_cover_frame" id="magazine_cover_frame" size=1>
									<option value="" ' . ( !isset( $magazine_cover_frame ) || empty( $magazine_cover_frame ) ? ' selected="selected"' : '' ) . '>' . __( 'None', 'DigiPress' ) . '</option>
									<option value="has-frame line-frame __solid" ' . ( isset( $magazine_cover_frame ) && $magazine_cover_frame == 'has-frame line-frame __solid' ? ' selected="selected"' : '' ) . '>' . __( 'Solid line', 'DigiPress' ) . '</option>
									<option value="has-frame line-frame __double" ' . ( isset( $magazine_cover_frame ) && $magazine_cover_frame == 'has-frame line-frame __double' ? ' selected="selected"' : '' ) . '>' . __( 'Double line', 'DigiPress' ) . '</option>
									<option value="has-frame line-frame __dashed" ' . ( isset( $magazine_cover_frame ) && $magazine_cover_frame == 'has-frame line-frame __dashed' ? ' selected="selected"' : '' ) . '>' . __( 'Dashed line', 'DigiPress' ) . '</option>
									<option value="has-frame line-frame __dot" ' . ( isset( $magazine_cover_frame ) && $magazine_cover_frame == 'has-frame line-frame __dot' ? ' selected="selected"' : '' ) . '>' . __( 'Dot line', 'DigiPress' ) . '</option>
									<option value="has-frame thick-bd" ' . ( isset( $magazine_cover_frame ) && $magazine_cover_frame == 'has-frame thick-bd' ? ' selected="selected"' : '' ) . '>' . __( 'Thick border', 'DigiPress' ) . '</option>
									<option value="has-frame thick-bd no-r no-btm" ' . ( isset( $magazine_cover_frame ) && $magazine_cover_frame == 'has-frame thick-bd no-r no-btm' ? ' selected="selected"' : '' ) . '>' . __( 'Thick border', 'DigiPress' ) . __('(top, left)', 'DigiPress') . '</option>
									<option value="has-frame thick-bd no-l no-btm" ' . ( isset( $magazine_cover_frame ) && $magazine_cover_frame == 'has-frame thick-bd no-l no-btm' ? ' selected="selected"' : '' ) . '>' . __( 'Thick border', 'DigiPress' ) . __('(top, right)', 'DigiPress') . '</option>
									<option value="has-frame thick-bd no-r no-top" ' . ( isset( $magazine_cover_frame ) && $magazine_cover_frame == 'has-frame thick-bd no-r no-top' ? ' selected="selected"' : '' ) . '>' . __( 'Thick border', 'DigiPress' ) . __('(bottom, left)', 'DigiPress') . '</option>
									<option value="has-frame thick-bd no-l no-top" ' . ( isset( $magazine_cover_frame ) && $magazine_cover_frame == 'has-frame thick-bd no-l no-top' ? ' selected="selected"' : '' ) . '>' . __( 'Thick border', 'DigiPress' ) . __('(bottom, right)', 'DigiPress') . '</option>
									<option value="has-frame thick-bd no-l no-r no-btm" ' . ( isset( $magazine_cover_frame ) && $magazine_cover_frame == 'has-frame thick-bd no-l no-r no-btm' ? ' selected="selected"' : '' ) . '>' . __( 'Thick border', 'DigiPress' ) . __('(top)', 'DigiPress') . '</option>
									<option value="has-frame thick-bd no-l no-r no-top" ' . ( isset( $magazine_cover_frame ) && $magazine_cover_frame == 'has-frame thick-bd no-l no-r no-top' ? ' selected="selected"' : '' ) . '>' . __( 'Thick border', 'DigiPress' ) . __('(bottom)', 'DigiPress') . '</option>
								</select>
							</div>
							<div class="flex-item">
								<label for="magazine_cover_frame_color" class="disp-blk">' . __( 'Frame color', 'DigiPress' ) . '</label>
				 				<input type="text" name="magazine_cover_frame_color" id="magazine_cover_frame_color" value="' . ( !isset( $magazine_cover_frame_color ) || empty( $magazine_cover_frame_color ) ? '#ffffff' : $magazine_cover_frame_color ) . '" class="dp-color-field" data-default-color="#ffffff" />
							</div>
						</div>

						<hr />

						<div class="flex-box">
							<div class="flex-item">
								<label for="magazine_title_position" class="disp-blk"> ' . __( 'Title position', 'DigiPress' ) . '</label>
								<select name="magazine_title_position" id="magazine_title_position" size=1>
									<option value="" ' . ( !isset( $magazine_title_position ) || empty( $magazine_title_position ) ? ' selected="selected"' : '' ) . '>' . __( 'Center', 'DigiPress' ) . '</option>
									<option value="title-pos__top title-pos__l" ' . ( isset( $magazine_title_position ) && $magazine_title_position == 'title-pos__top title-pos__l' ? ' selected="selected"' : '' ) . '>' . __( 'Upper left', 'DigiPress' ). '</option>
									<option value="title-pos__top" ' . ( isset( $magazine_title_position ) && $magazine_title_position == 'title-pos__top' ? ' selected="selected"' : '' ) . '>' . __( 'Upper center', 'DigiPress' ). '</option>
									<option value="title-pos__top title-pos__r" ' . ( isset( $magazine_title_position ) && $magazine_title_position == 'title-pos__top title-pos__r' ? ' selected="selected"' : '' ) . '>' . __( 'Upper right', 'DigiPress' ) . '</option>
									<option value="title-pos__btm title-pos__l" ' . ( isset( $magazine_title_position ) && $magazine_title_position == 'title-pos__btm title-pos__l' ? ' selected="selected"' : '' ) . '>' . __( 'Bottom left', 'DigiPress' ) . '</option>
									<option value="title-pos__btm" ' . ( isset( $magazine_title_position ) && $magazine_title_position == 'title-pos__btm' ? ' selected="selected"' : '' ) . '>' . __( 'Bottom center', 'DigiPress' ) . '</option>
									<option value="title-pos__btm title-pos__r" ' . ( isset( $magazine_title_position ) && $magazine_title_position == 'title-pos__btm title-pos__r' ? ' selected="selected"' : '' ) . '>' . __( 'Bottom right', 'DigiPress' ) . '</option>
								</select>
							</div>
							<div class="flex-item">
								<label for="magazine_title_color" class="disp-blk">' . __( 'Title color', 'DigiPress' ) . '</label>
				 				<input type="text" name="magazine_title_color" id="magazine_title_color" value="' . ( !isset( $magazine_title_color ) || empty( $magazine_title_color ) ? '#ffffff' : $magazine_title_color ) . '" class="dp-color-field" data-default-color="#ffffff" />
							</div>
						</div>

						<div class="flex-box dir-col">
							<div class="flex-item">
								<input type="checkbox" name="magazine_title_back" id="magazine_title_back" class="toggle_ele" value="has-title-back"' . ( isset( $magazine_title_back ) && $magazine_title_back == 'has-title-back' ? ' checked="checked"' : '' ) . ' />
								<label for="magazine_title_back">' . __( 'Show the title background color', 'DigiPress' ) . '</label>
								<div class="toggle_content mg20px-l box-c">
									<div class="flex-box">
										<div class="flex-item">
											<label for="magazine_title_back_color" class="disp-blk">' . __( 'Title background color', 'DigiPress' ) . '</label>
							 				<input type="text" name="magazine_title_back_color" id="magazine_title_back_color" value="' . ( !isset( $magazine_title_back_color ) || empty( $magazine_title_back_color ) ? '#000000' : $magazine_title_back_color ) . '" class="dp-color-field" data-default-color="#000000" />
										</div>
										<div class="flex-item">
											<label for="magazine_title_back_color_opacity" class="disp-blk">' . __( 'Title background opacity', 'DigiPress' ) . '</label>
							 				<input type="number" name="magazine_title_back_color_opacity" id="magazine_title_back_color_opacity" value="' . ( !isset( $magazine_title_back_color_opacity ) || empty( $magazine_title_back_color_opacity ) ? 50 : $magazine_title_back_color_opacity ) . '" min="1" max="100" step="1" /> %
										</div>
									</div>
									<div class="flex-box">
										<div class="flex-item">
											<label for="magazine_title_back_border" class="disp-blk"> ' . __( 'Title background border', 'DigiPress' ) . '</label>
											<select name="magazine_title_back_border" id="magazine_title_back_border" size=1>
												<option value="" ' . ( !isset( $magazine_title_back_border ) || empty( $magazine_title_back_border ) ? ' selected="selected"' : '' ) . '>' . __( 'None', 'DigiPress' ) . '</option>
												<option value="has-title-bd title-back-bd" ' . ( isset( $magazine_title_back_border ) && $magazine_title_back_border == 'has-title-bd title-back-bd' ? ' selected="selected"' : '' ) . '>' . __( 'Solid line', 'DigiPress' ). '</option>
												<option value="has-title-bd title-back-bd__double" ' . ( isset( $magazine_title_back_border ) && $magazine_title_back_border == 'has-title-bd title-back-bd__double' ? ' selected="selected"' : '' ) . '>' . __( 'Double line', 'DigiPress' ). '</option>
												<option value="has-title-bd title-back-bd__dashed" ' . ( isset( $magazine_title_back_border ) && $magazine_title_back_border == 'has-title-bd title-back-bd__dashed' ? ' selected="selected"' : '' ) . '>' . __( 'Dashed line', 'DigiPress' ). '</option>
												<option value="has-title-bd title-back-bd__dot" ' . ( isset( $magazine_title_back_border ) && $magazine_title_back_border == 'has-title-bd title-back-bd__dot' ? ' selected="selected"' : '' ) . '>' . __( 'Dot line', 'DigiPress' ). '</option>
											</select>
										</div>
									</div>
								</div>
							</div>

							<div class="flex-item">
								<input type="checkbox" name="magazine_title_by_bold" id="magazine_title_by_bold" value="title-normal-weight"' . ( isset( $magazine_title_by_bold ) && $magazine_title_by_bold == 'title-normal-weight' ? ' checked="checked"' : '' ) . ' />
								<label for="magazine_title_by_bold">' . __( 'Disable bold title', 'DigiPress' ) . '</label>
							</div>

							<div class="flex-item">
								<label for="magazine_title_tilt" class="disp-blk"> ' . __( 'Title tilt', 'DigiPress' ) . '</label>
								<select name="magazine_title_tilt" id="magazine_title_tilt" size=1>
									<option value="" ' . ( !isset( $magazine_title_tilt ) || empty( $magazine_title_tilt ) ? ' selected="selected"' : '' ) . '>' . __( 'None', 'DigiPress' ) . '</option>
									<option value="title-tilt" ' . ( isset( $magazine_title_tilt ) && $magazine_title_tilt == 'title-tilt' ? ' selected="selected"' : '' ) . '>' . __( 'Upper to right', 'DigiPress' ). '</option>
									<option value="title-tilt down-to-r" ' . ( isset( $magazine_title_tilt ) && $magazine_title_tilt == 'title-tilt down-to-r' ? ' selected="selected"' : '' ) . '>' . __( 'Downward to right', 'DigiPress' ). '</option>
								</select>
							</div>

							<div class="flex-item">
								<input type="checkbox" name="magazine_text_by_serif" id="magazine_text_by_serif" value="serif"' . ( isset( $magazine_text_by_serif ) && $magazine_text_by_serif == 'serif' ? ' checked="checked"' : '' ) . ' />
								<label for="magazine_text_by_serif">' . __( 'Display the text in serif font', 'DigiPress' ) . '</label>
							</div>

							<div class="flex-item">
								<input type="checkbox" name="magazine_text_vertically" id="magazine_text_vertically" value="txt-vertical"' . ( isset( $magazine_text_vertically ) && $magazine_text_vertically == 'txt-vertical' ? ' checked="checked"' : '' ) . ' />
								<label for="magazine_text_vertically">' . __( 'Display the text vertically', 'DigiPress' ) . '</label>
								<p class="description">' . __( '*In vertical writing mode, the title position is disabled.', 'DigiPress' ) . '</p>
							</div>
						</div>

						<hr />

						<div class="flex-box">
							<div class="flex-item">
								<label for="magazine_date_design" class="disp-blk"> ' . __( 'Date design', 'DigiPress' ) . '</label>
								<select name="magazine_date_design" id="magazine_date_design" size=1>
									<option value="date1" ' . ( !isset( $magazine_date_design ) || $magazine_date_design == 'date1' ? ' selected="selected"' : '' ) . '>' . __( 'Default', 'DigiPress' ) . '</option>
									<option value="date2" ' . ( isset( $magazine_date_design ) && $magazine_date_design == 'date2' ? ' selected="selected"' : '' ) . '>' . __( 'Vertically', 'DigiPress' ). '</option>
									<option value="date3" ' . ( isset( $magazine_date_design ) && $magazine_date_design == 'date3' ? ' selected="selected"' : '' ) . '>' . __( 'Line square', 'DigiPress' ). '</option>
									<option value="date4" ' . ( isset( $magazine_date_design ) && $magazine_date_design == 'date4' ? ' selected="selected"' : '' ) . '>' . __( 'Round shape', 'DigiPress' ). '</option>
								</select>
							</div>
						</div>

						<hr />

						<div class="flex-box">
							<div class="flex-item">
								<label for="magazine_accent_shape" class="disp-blk"> ' . __( 'Accent shape', 'DigiPress' ) . '</label>
								<select name="magazine_accent_shape" id="magazine_accent_shape" size=1>
									<option value="" ' . ( !isset( $magazine_accent_shape ) || empty( $magazine_accent_shape ) ? ' selected="selected"' : '' ) . '>' . __( 'None', 'DigiPress' ) . '</option>
									<option value="has-acc-shape acc__shape1" ' . ( isset( $magazine_accent_shape ) && $magazine_accent_shape == 'has-acc-shape acc__shape1' ? ' selected="selected"' : '' ) . '>' . __( 'Square', 'DigiPress' ). '</option>
									<option value="has-acc-shape acc__shape2" ' . ( isset( $magazine_accent_shape ) && $magazine_accent_shape == 'has-acc-shape acc__shape2' ? ' selected="selected"' : '' ) . '>' . __( 'Rhombus', 'DigiPress' ). '</option>
									<option value="has-acc-shape acc__shape3" ' . ( isset( $magazine_accent_shape ) && $magazine_accent_shape == 'has-acc-shape acc__shape3' ? ' selected="selected"' : '' ) . '>' . __( 'Circle', 'DigiPress' ). '</option>
									<option value="has-acc-shape acc__shape4" ' . ( isset( $magazine_accent_shape ) && $magazine_accent_shape == 'has-acc-shape acc__shape4' ? ' selected="selected"' : '' ) . '>' . __( 'Right triangle', 'DigiPress' ) . ' #1' . '</option>
									<option value="has-acc-shape acc__shape5" ' . ( isset( $magazine_accent_shape ) && $magazine_accent_shape == 'has-acc-shape acc__shape5' ? ' selected="selected"' : '' ) . '>' . __( 'Right triangle', 'DigiPress' ) . ' #2' . '</option>
									<option value="has-acc-shape acc__shape6" ' . ( isset( $magazine_accent_shape ) && $magazine_accent_shape == 'has-acc-shape acc__shape6' ? ' selected="selected"' : '' ) . '>' . __( 'Parallelogram', 'DigiPress' ) . ' #1' . '</option>
									<option value="has-acc-shape acc__shape7" ' . ( isset( $magazine_accent_shape ) && $magazine_accent_shape == 'has-acc-shape acc__shape7' ? ' selected="selected"' : '' ) . '>' . __( 'Parallelogram', 'DigiPress' ) . ' #2' . '</option>
									<option value="has-acc-shape acc__shape8" ' . ( isset( $magazine_accent_shape ) && $magazine_accent_shape == 'has-acc-shape acc__shape8' ? ' selected="selected"' : '' ) . '>' . __( 'Pentagon', 'DigiPress' ) . '</option>
								</select>
							</div>
						</div>

						<div class="flex-box">
							<div class="flex-item">
								<label for="magazine_accent_shape_color" class="disp-blk">' . __( 'Accent shape color', 'DigiPress' ) . '</label>
				 				<input type="text" name="magazine_accent_shape_color" id="magazine_accent_shape_color" value="' . ( !isset( $magazine_accent_shape_color ) || empty( $magazine_accent_shape_color ) ? '#ffffff' : $magazine_accent_shape_color ) . '" class="dp-color-field" data-default-color="#ffffff" />
							</div>
							<div class="flex-item">
								<label for="magazine_accent_shape_opacity" class="disp-blk">' . __( 'Accent shape opacity', 'DigiPress' ) . '</label>
				 				<input type="number" name="magazine_accent_shape_opacity" id="magazine_accent_shape_opacity" value="' . ( !isset( $magazine_accent_shape_opacity ) || empty( $magazine_accent_shape_opacity ) ? 30 : $magazine_accent_shape_opacity ) . '" min="1" max="100" step="1" /> %
							</div>
						</div>

					</div>

					<div class="grid-item">
						<div class="b ft16px mg50px-top mg20px-btm">' . __( 'Preview', 'DigiPress' ) . '</div>
						<div id="dp-magazine-preview" class="' . $article_class . '"' . $article_style . '>
							<div class="loop-article-content">
								<div class="loop-post-thumb">
									<figure class="loop-figure">
										<img src="' . $magazine_image . '" class="figure-img" id="dp-magazine-preview-image" data-eyecatch-url="' . $eyecatch . '" width="460" height="320">
									</figure>
								</div>
								<div class="loop-c-block">
									<div class="title-area">
										<h2 class="loop-title"><span class="title-inner" id="dp-magazine-preview-title">' . ( isset($magazine_title) && !empty( $magazine_title ) ? strip_tags( $magazine_title ) : strip_tags( get_the_title() ) ) . '</span></h2>
										<div class="loop-excerpt entry-summary" id="dp-magazine-preview-excerpt">' . ( isset($magazine_caption) && !empty( $magazine_caption ) ? strip_tags( $magazine_caption ) : mb_substr( strip_tags( get_the_excerpt() ), 0, 68 ) ) . '</div>
									</div>
									<div class="loop-date eng">
										<span class="date_year">' . get_post_time('Y') . '</span> <span class="mon-day"><span class="date_month">' . get_post_time('n') . '</span><span class="date_day">' . get_post_time('j') . '</span></span>
									</div>
									<div class="meta-cat in-loop">
										<span class="cat-name">' . $cat . '</span>
									</div>
								</div>
							</div>
						</div>
					</div>

				</div>
			</div>
		</div>

		<div class="flex-box dir-col mg20px-top">
			<div class="flex-item">
				<label for="magazine_title" class="disp-blk"> ' . __( 'Alternative title', 'DigiPress' ) . '</label>
				<input type="text" name="magazine_title" id="magazine_title" size="50" value="' . strip_tags( $magazine_title ) . '" placeholder="' . strip_tags( get_the_title() ) . '" />
			</div>

			<div class="flex-item">
				<label for="magazine_caption" class="disp-blk"> ' . __( 'Alternative caption', 'DigiPress' ) . '</label>
				<textarea name="magazine_caption" id="magazine_caption" rows="2" cols="49" placeholder="' . strip_tags( get_the_excerpt() ) . '" />' . strip_tags( $magazine_caption ) . '</textarea>
			</div>

			<div class="flex-item">
				<label for="magazine_caption" class="disp-blk"> ' . __( 'Cover image', 'DigiPress' ) . '</label>
				<input type="text" name="magazine_image" id="magazine_image" class="img_url" size="50" style="width:70%;" value="' . $magazine_image . '" /><button class="dp_upload_image_button button">'.__('Add / Change','DigiPress').'</button>
				<p class="description">' . __( '*In the magazine style, if you want to display another image as a thumbnail instead of the eyecatch image of the article, enter the url here.', 'DigiPress' ) . '</p>
			</div>
		</div>
		</div>';

	// Nextpage text
	echo '<div class="dp_cf_item_box">
		 <p class="b">' . __('Every next page text','DigiPress') . '</p>
		 <p>' . __("Enter the link text to the next page for each page. Enter one line for each page break.", "DigiPress") . '</p>
		 <textarea name="nextpage_text" id="nextpage_text" rows="4" cols="80">' . htmlspecialchars( $nextpage_text ) . '</textarea></div>';

	// Show eyecatch
	echo '<div class="dp_cf_item_box">
		 <input name="dp_show_eyecatch_force" id="dp_show_eyecatch_force" type="checkbox" value="1"';
	if( isset($dp_show_eyecatch_force) && !empty($dp_show_eyecatch_force) ) echo ' checked="checked"';
	echo ' /><label for="dp_show_eyecatch_force" class="b"> '.__("Check to show eyecatch image at first","DigiPress").'</label>';
	echo '<div class="mg10px-top mg20px-l mg15px-btm"><input name="dp_eyecatch_on_container" id="dp_eyecatch_on_container" type="checkbox" value="1"';
		if( $dp_eyecatch_on_container ) echo ' checked="checked"';
	echo ' /><label for="dp_eyecatch_on_container"> '.__("Eyecatch shows on container","DigiPress").'</label></div>';
	echo '<p>'.__('You can show the eyecatch image at first of this post when you check this option.','DigiPress').'</p></div>';

	// Eyecatch to background image
	echo '<div class="dp_cf_item_box">
		 <input name="dp_eyecatch_to_bg" id="dp_eyecatch_to_bg" type="checkbox" value="1"';
	if( isset($dp_eyecatch_to_bg) && !empty($dp_eyecatch_to_bg) ) echo ' checked="checked"';
	echo ' /><label for="dp_eyecatch_to_bg" class="b"> '.__("Check to set the eyecatch as background image","DigiPress").'</label>';
	echo '<p>'.__('You can show the eyecatch image as the background when you check this option.','DigiPress').'</p></div>';

	// Hide title
	echo '<div class="dp_cf_item_box">
		 <input name="dp_hide_title" id="dp_hide_title" type="checkbox" value="1"';
	if( $dp_hide_title ) echo ' checked="checked"';
	echo ' /><label for="dp_hide_title" class="b"> '.__("Check to hide post title","DigiPress").'</label>';
	echo '<p>'.__('You can hide the title of this post page when you check this option.','DigiPress').'</p></div>';

	// Hide date
	echo '<div class="dp_cf_item_box">
		 <input name="dp_hide_date" id="dp_hide_date" type="checkbox" value="1"';
	if( $dp_hide_date ) echo ' checked="checked"';
	echo ' /><label for="dp_hide_date" class="b"> '.__("Check to hide published date","DigiPress").'</label>';
	echo '<p>'.__('You can hide the date of this post page when you check this option.','DigiPress').'</p></div>';

	// Hide author
	echo '<div class="dp_cf_item_box">
		 <input name="dp_hide_author" id="dp_hide_author" type="checkbox" value="1"';
	if( $dp_hide_author ) echo ' checked="checked"';
	echo ' /><label for="dp_hide_author" class="b"> '.__("Check to hide author","DigiPress").'</label>';
	echo '<p>'.__('You can hide the author of this post page when you check this option.','DigiPress').'</p></div>';

	// Hide author profile
	echo '<div class="dp_cf_item_box">
		 <input name="dp_hide_author_prof" id="dp_hide_author_prof" type="checkbox" value="1"';
	if( $dp_hide_author_prof ) echo ' checked="checked"';
	echo ' /><label for="dp_hide_author_prof" class="b"> '.__("Check to hide author profile","DigiPress").'</label>';
	echo '<p>'.__('You can hide the author profile of this post page when you check this option.','DigiPress').'</p></div>';

	// Hide category
	echo '<div class="dp_cf_item_box">
		 <input name="dp_hide_cat" id="dp_hide_cat" type="checkbox" value="1"';
	if( $dp_hide_cat ) echo ' checked="checked"';
	echo ' /><label for="dp_hide_cat" class="b"> '.__("Check to hide category links","DigiPress").'</label>';
	echo '<p>'.__('You can hide category links of this post page when you check this option.','DigiPress').'</p></div>';

	// Hide tags
	echo '<div class="dp_cf_item_box">
		 <input name="dp_hide_tag" id="dp_hide_tag" type="checkbox" value="1"';
	if( $dp_hide_tag ) echo ' checked="checked"';
	echo ' /><label for="dp_hide_tag" class="b"> '.__("Check to hide tag links","DigiPress").'</label>';
	echo '<p>'.__('You can hide tag links of this post page when you check this option.','DigiPress').'</p></div>';

	// Hide views
	echo '<div class="dp_cf_item_box">
		 <input name="dp_hide_views" id="dp_hide_views" type="checkbox" value="1"';
	if( $dp_hide_views ) echo ' checked="checked"';
	echo ' /><label for="dp_hide_views" class="b"> '.__("Check to hide views","DigiPress").'</label>';
	echo '<p>'.__('You can hide viewed count of this post page when you check this option.','DigiPress').'</p></div>';

	// Hide time for reading
	echo '<div class="dp_cf_item_box">
		 <input name="dp_hide_time_for_reading" id="dp_hide_time_for_reading" type="checkbox" value="1"';
	if( $dp_hide_time_for_reading ) echo ' checked="checked"';
	echo ' /><label for="dp_hide_time_for_reading" class="b"> '.__("Check to hide reading time","DigiPress").'</label>';
	echo '<p>'.__('You can hide the time for readin of this post page when you check this option.','DigiPress').'</p></div>';

	// Hide SNS Icons
	echo '<div class="dp_cf_item_box">
		 <input name="hide_sns_icon" id="hide_sns_icon" type="checkbox" value="1"';
	if( $hide_sns_icon ) echo ' checked="checked"';
	echo ' /><label for="hide_sns_icon" class="b"> '.__("Check to hide SNS buttons","DigiPress").'</label>';
	echo '<p>'.__('You can hide SNS buttons of this post page when you check this option.','DigiPress').'</p></div>';

	// Hide SNS Follow Box
	echo '<div class="dp_cf_item_box"><label class="b"><input name="dp_hide_follow_box" id="dp_hide_follow_box" type="checkbox" value="1"';
	if( $dp_hide_follow_box ) echo ' checked="checked"';
	echo ' /> '.__("Check to hide SNS follow box", "DigiPress").'</label>';
	echo '<p>'.__('Check this option to hide SNS follow box in this page.', 'DigiPress').'</p></div>';

	// Hide TOC
	echo '<div class="dp_cf_item_box">
		 <input name="dp_hide_toc" id="dp_hide_toc" type="checkbox" value="1"';
	if( $dp_hide_toc ) echo ' checked="checked"';
	echo ' /><label for="dp_hide_toc" class="b"> '.__("Check to hide Table of Contents","DigiPress").'</label>';
	echo '<p>'.__('You can hide table of Contents of this post page when you check this option.','DigiPress').'<br /><a href="'.admin_url().'customize.php" target="_blank">'.__('Settings for Table of Contents','DigiPress').'</a></p></div>';

	// Hide Breadcrumb
	echo '<div class="dp_cf_item_box">
		 <input name="dp_disable_breadcrumb" id="dp_disable_breadcrumb" type="checkbox" value="1"';
	if( $dp_disable_breadcrumb ) echo ' checked="checked"';
	echo ' /><label for="dp_disable_breadcrumb" class="b"> '.__("Check to hide the breadcrumb list","DigiPress").'</label>';
	echo '<p>'.__('You can hide the breadcrumb list when you check this option.','DigiPress').'</p></div>';

	// Hide Facebook Comment
	echo '<div class="dp_cf_item_box">
		 <input name="dp_hide_fb_comment" id="dp_hide_fb_comment" type="checkbox" value="1"';
	if( $dp_hide_fb_comment ) echo ' checked="checked"';
	echo ' /><label for="dp_hide_fb_comment" class="b"> '.__("Check to hide Facebook comment box","DigiPress").'</label>';
	echo '<p>'.__('You can hide Facebook comment box of this post page when you check this option.','DigiPress').'</p></div>';

	// hide sidebar
	echo '<div class="dp_cf_item_box">
		 <input name="disable_sidebar" id="disable_sidebar" type="checkbox" value="1"';
	if( $disable_sidebar ) echo ' checked="checked"';
	echo ' /><label for="disable_sidebar" class="b"> '.__("Check to disable sidebar(1 column)","DigiPress").'</label>';
	echo '<div class="mg15px-l mg8px-top"><input name="one_col_narrow" id="one_col_narrow" type="checkbox" value="1"';
	if( $one_col_narrow ) echo ' checked="checked"';
	echo ' /><label for="one_col_narrow" > '.__("Check to resize narrow width","DigiPress").'</label></div><p>'.__('You can hide the sidebar of this post page when you check this option.','DigiPress').'</p></div>';

	// Disable wpautop
	echo '<div class="dp_cf_item_box">
		 <input name="disable_wpautop" id="disable_wpautop_dp" type="checkbox" value="1"';
	if( $disable_wpautop ) echo ' checked="checked"';
	echo ' /><label for="disable_wpautop_dp" class="b"> '.__("Check to disable auto format of WordPress","DigiPress").'</label><div class="mg15px-l mg8px-top"><input name="replace_p_to_br" id="replace_p_to_br" type="checkbox" value="1"';
	if ($replace_p_to_br) echo ' checked="checked"'; 
	echo ' ><label for="replace_p_to_br">'.__('Check to replace line breaks to br tag in this post.', 'DigiPress').'</label></div>';
	echo '<p>'.__('Check this option to disable auto format function of WordPress of this post.','DigiPress').'</p></div>';


	// Whether include headline 
	// echo '<div class="dp_cf_item_box">
	// 	 <input name="is_headline" id="is_headline_dp" type="checkbox" value="1"';
	// if( $is_headline ) echo ' checked="checked"';
	// echo ' /><label for="is_headline_dp" class="b"> '.__("Check to Include Headline Slider","DigiPress").'</label>';
	// echo '<p>'.__('You can show this post to the headline in top page when you check this option.','DigiPress').'</p></div>';

	// Whether include Slideshow 
	echo '<div class="dp_cf_item_box">
		 <input name="is_slideshow" id="is_slideshow_dp" type="checkbox" value="1"';
	if( $is_slideshow ) echo ' checked="checked"';
	echo ' /><label for="is_slideshow_dp" class="b"> '.__("Check to Include Slideshow","DigiPress").'</label>';
	echo '<p>'.__('You can show this post to the slideshow of DigiPress header area when you check this option.','DigiPress').'</p></div>';

	// URL
	echo '<div class="dp_cf_item_box">
		<p class="b">'.__('Header Slider Image URL(Optional):','DigiPress').'</p><p>'.__('Enter the URL to your slideshow image below, if you want to customize default image of slideshow.', 'DigiPress').'</p>
		 <input type="text" name="slideshow_image_url" id="slideshow_image_url" class="img_url" size="60" style="width:80%;" value="'.$slideshow_image_url.'" />
		 <button class="dp_upload_image_button button">'.__('Add / Change','DigiPress').'</button><br />* '
		 .__("When you save as a blank, DigiPress displays the random image to the slideshow.",'DigiPress');
	echo '<p class="pd8px-top b grey">'.__("Current Slideshow image", "DigiPress").':</p><div id="uploadedImageView" class="clearfix">'. $preview_tag.'</div>';
	echo '</div>';

	// Related posts main title
	echo '<div class="dp_cf_item_box">
		 <p class="b">'.__('Related articles area title','DigiPress').'</p>
		 <p>'.__("You can change the title of the related articles area on this post page.", "DigiPress").'</p>
		 <input name="dp_related_posts_title" id="dp_related_posts_title" type="text" style="width:100%;" value="'.$dp_related_posts_title.'" /></div>';

	// Hide related posts
	echo '<div class="dp_cf_item_box"><label class="b"><input name="dp_hide_related_posts" id="dp_hide_related_posts" type="checkbox" value="1"';
	if( $dp_hide_related_posts ) echo ' checked="checked"';
	echo ' /> ' . __( 'Hide related articles', 'DigiPress' ) . '</label>';
	echo '<p>' . __( 'Check this option to hide the related articles of this post page.', 'DigiPress' ) . '</p></div>';

	// Hide Next prev navi link
	echo '<div class="dp_cf_item_box"><label class="b"><input name="dp_hide_next_prev" id="dp_hide_next_prev" type="checkbox" value="1"';
	if( $dp_hide_next_prev ) echo ' checked="checked"';
	echo ' /> '.__("Check to hide next and prev navigation","DigiPress").'</label>';
	echo '<p>'.__('Check this option to hide links to previous and next posted articles.','DigiPress').'</p></div>';

	// Meta keyword
	echo '<div class="dp_cf_item_box">
		 <p class="b">'.__('HTML meta keyword (Optional):','DigiPress').'</p>
		 <p>'.__("Enter meta keywords of this post. If you don't specifiy the keyword, post tags are used for meta keywords.", "DigiPress").'</p>
		 <input name="dp_meta_keyword" id="dp_meta_keyword" type="text" style="width:100%;" value="'.$dp_meta_keyword.'" />';
	echo '<p>'.__('* Please use comma for separate each keyword.','DigiPress').'</p></div>';


	// No index
	echo '<div class="dp_cf_item_box">
		<p class="b">'.__('HTML meta information settings', 'DigiPress').'</p>
		 <div class="mg8px-btm"><input name="dp_noindex" id="dp_noindex" type="checkbox" value="1"';
	if( $dp_noindex ) echo ' checked="checked"';
	echo ' /><label for="dp_noindex"> '.__("Check to set meta no index attribute to this page.","DigiPress").'</label></div>';
	// No follow
	echo '<div class="mg8px-btm"><input name="dp_nofollow" id="dp_nofollow" type="checkbox" value="1"';
	if( $dp_nofollow ) echo ' checked="checked"';
	echo ' /><label for="dp_nofollow"> '.__("Check to set meta no follow attribute to this page.","DigiPress").'</label></div>';
	// No archive
	echo '<div class="mg8px-btm"><input name="dp_noarchive" id="dp_noarchive" type="checkbox" value="1"';
	if( $dp_noarchive ) echo ' checked="checked"';
	echo ' /><label for="dp_noarchive"> '.__("Check to set meta no archive attribute to this page.","DigiPress").'</label></div></div>';

	// Show additional params from extensions
	$additional_setting = apply_filters('dp_custom_field_single_form', $post->ID);
	if (is_string($additional_setting) && $additional_setting != $post->ID) {
		echo $additional_setting;
	}
}
 
/*---------------------------------------
 * For Page
 *--------------------------------------*/
/* HTML form */
function html_source_for_custom_box_page() {

	global $post;

	$is_slideshow = get_post_meta( $post->ID, 'is_slideshow', true);
	$slideshow_image_url = get_post_meta( $post->ID, 'slideshow_image_url', true);
	$disable_sidebar = get_post_meta( $post->ID, 'disable_sidebar', true);
	$one_col_narrow = get_post_meta( $post->ID, 'one_col_narrow' , true);
	$hide_sns_icon = get_post_meta( $post->ID, 'hide_sns_icon', true);
	$dp_disable_breadcrumb = get_post_meta( $post->ID, 'dp_disable_breadcrumb', true);
	$dp_hide_date = get_post_meta( $post->ID, 'dp_hide_date', true);
	$dp_hide_author = get_post_meta( $post->ID, 'dp_hide_author', true);
	$dp_meta_keyword = get_post_meta( $post->ID, 'dp_meta_keyword', true);
	$dp_noindex	= get_post_meta( $post->ID, 'dp_noindex', true);
	$dp_nofollow = get_post_meta( $post->ID, 'dp_nofollow', true);
	$dp_noarchive = get_post_meta( $post->ID, 'dp_noarchive', true);
	$dp_hide_header_menu = get_post_meta( $post->ID, 'dp_hide_header_menu', true);
	$dp_hide_footer = get_post_meta( $post->ID, 'dp_hide_footer', true);
	$dp_hide_title = get_post_meta( $post->ID, 'dp_hide_title', true);
	$dp_show_eyecatch_force	= get_post_meta( $post->ID, 'dp_show_eyecatch_force', true);
	$dp_eyecatch_on_container = get_post_meta( $post->ID, 'dp_eyecatch_on_container', true);
	$dp_eyecatch_to_bg = get_post_meta( $post->ID, 'dp_eyecatch_to_bg', true);
	$disable_wpautop = get_post_meta( $post->ID, 'disable_wpautop', true);
	$replace_p_to_br = get_post_meta( $post->ID, 'replace_p_to_br', true);
	$nextpage_text = get_post_meta( $post->ID, 'nextpage_text', true);

	$additional_setting = '';
	$preview_tag = '';
	if ( !empty($slideshow_image_url) ) {
		$preview_tag = '<img src="' . $slideshow_image_url . '" id="exist_slide_image" />';
	}

	$css_code = <<<_EOD_
<style type="text/css"><!--
.dp_cf_item_box {
	border:1px solid #ddd;
	padding:10px;
	margin-bottom:10px;
}
.dp_cf_item_box p {
	margin:6px 0 12px 0;
}
.dp_cf_inner_box {
	margin:10px;
}
--></style>
_EOD_;
	$css_code = str_replace(array("\r\n","\r","\n","\t","/^\s(?=\s)/"), '', $css_code);
	echo $css_code;


	// Nextpage text
	echo '<div class="dp_cf_item_box">
		 <p class="b">' . __('Every next page text','DigiPress') . '</p>
		 <p>' . __("Enter the link text to the next page for each page. Enter one line for each page break.", "DigiPress") . '</p>
		 <textarea name="nextpage_text" id="nextpage_text" rows="4" cols="80">' . htmlspecialchars( $nextpage_text ) . '</textarea></div>';

	// Show eyecatch
	echo '<div class="dp_cf_item_box">
		 <input name="dp_show_eyecatch_force" id="dp_show_eyecatch_force" type="checkbox" value="1"';
	if( isset($dp_show_eyecatch_force) && !empty($dp_show_eyecatch_force) ) echo ' checked="checked"';
	echo ' /><label for="dp_show_eyecatch_force" class="b"> '.__("Check to show eyecatch image at first","DigiPress").'</label>';
	echo '<div class="mg10px-top mg20px-l mg15px-btm"><input name="dp_eyecatch_on_container" id="dp_eyecatch_on_container" type="checkbox" value="1"';
		if( $dp_eyecatch_on_container ) echo ' checked="checked"';
	echo ' /><label for="dp_eyecatch_on_container"> '.__("Eyecatch shows on container","DigiPress").'</label></div>';
	echo '<p>'.__('You can show the eyecatch image at first of this post when you check this option.','DigiPress').'</p></div>';

	// Eyecatch to background image
	echo '<div class="dp_cf_item_box">
		 <input name="dp_eyecatch_to_bg" id="dp_eyecatch_to_bg" type="checkbox" value="1"';
	if( isset($dp_eyecatch_to_bg) && !empty($dp_eyecatch_to_bg) ) echo ' checked="checked"';
	echo ' /><label for="dp_eyecatch_to_bg" class="b"> '.__("Check to set the eyecatch as background image","DigiPress").'</label>';
	echo '<p>'.__('You can show the eyecatch image as the background when you check this option.','DigiPress').'</p></div>';

	// Hide title
	echo '<div class="dp_cf_item_box">
		 <input name="dp_hide_title" id="dp_hide_title" type="checkbox" value="1"';
	if( $dp_hide_title ) echo ' checked="checked"';
	echo ' /><label for="dp_hide_title" class="b"> '.__("Check to hide post title","DigiPress").'</label>';
	echo '<p>'.__('You can hide the title of this post page when you check this option.','DigiPress').'</p></div>';

	// Hide date
	echo '<div class="dp_cf_item_box">
		 <input name="dp_hide_date" id="dp_hide_date" type="checkbox" value="1"';
	if( $dp_hide_date ) echo ' checked="checked"';
	echo ' /><label for="dp_hide_date" class="b"> '.__("Check to hide published date","DigiPress").'</label>';
	echo '<p>'.__('You can hide the date of this post page when you check this option.','DigiPress').'</p></div>';

	// Hide author
	echo '<div class="dp_cf_item_box">
		 <input name="dp_hide_author" id="dp_hide_author" type="checkbox" value="1"';
	if( $dp_hide_author ) echo ' checked="checked"';
	echo ' /><label for="dp_hide_author" class="b"> '.__("Check to hide author","DigiPress").'</label>';
	echo '<p>'.__('You can hide the author of this post page when you check this option.','DigiPress').'</p></div>';

	// Hide SNS Icons
	echo '<div class="dp_cf_item_box">
		 <input name="hide_sns_icon" id="hide_sns_icon" type="checkbox" value="1"';
	if( $hide_sns_icon ) echo ' checked="checked"';
	echo ' /><input type="hidden" name="dp_post_option_update" value="true" /><label for="hide_sns_icon" class="b"> '.__("Check to hide SNS buttons","DigiPress").'</label>';
	echo '<p>'.__('You can hide SNS buttons of this post page when you check this option.','DigiPress').'</p></div>';

	// Hide Breadcrumb
	echo '<div class="dp_cf_item_box">
		 <input name="dp_disable_breadcrumb" id="dp_disable_breadcrumb" type="checkbox" value="1"';
	if( $dp_disable_breadcrumb ) echo ' checked="checked"';
	echo ' /><label for="dp_disable_breadcrumb" class="b"> '.__("Check to hide the breadcrumb list","DigiPress").'</label>';
	echo '<p>'.__('You can hide the breadcrumb list when you check this option.','DigiPress').'</p></div>';

	// hide sidebar
	echo '<div class="dp_cf_item_box">
		 <input name="disable_sidebar" id="disable_sidebar" type="checkbox" value="1"';
	if( $disable_sidebar ) echo ' checked="checked"';
	echo ' /><label for="disable_sidebar" class="b"> '.__("Check to disable sidebar(1 column)","DigiPress").'</label>';
	echo '<div class="mg15px-l mg8px-top"><input name="one_col_narrow" id="one_col_narrow" type="checkbox" value="1"';
	if( $one_col_narrow ) echo ' checked="checked"';
	echo ' /><label for="one_col_narrow" > '.__("Check to resize narrow width","DigiPress").'</label></div><p>'.__('You can hide the sidebar of this post page when you check this option.','DigiPress').'</p></div>';

	// Disable wpautop
	echo '<div class="dp_cf_item_box">
		 <input name="disable_wpautop" id="disable_wpautop_dp" type="checkbox" value="1"';
	if( $disable_wpautop ) echo ' checked="checked"';
	echo ' /><label for="disable_wpautop_dp" class="b"> '.__("Check to disable auto format of WordPress","DigiPress").'</label><div class="mg15px-l mg8px-top"><input name="replace_p_to_br" id="replace_p_to_br" type="checkbox" value="1"';
	if ($replace_p_to_br) echo ' checked="checked"'; 
	echo ' ><label for="replace_p_to_br">'.__('Check to replace line breaks to br tag in this post.', 'DigiPress').'</label></div>';
	echo '<p>'.__('Check this option to disable auto format function of WordPress of this post.','DigiPress').'</p></div>';

	// Whether include Slideshow 
	echo '<div class="dp_cf_item_box">
		 <input name="is_slideshow" id="is_slideshow_dp" type="checkbox" value="1"';
	if( $is_slideshow ) echo ' checked="checked"';
	echo ' /><label for="is_slideshow_dp" class="b"> '.__("Check to Include Slideshow","DigiPress").'</label>';
	echo '<p>'.__('You can show this post to the slideshow of DigiPress header area when you check this option.','DigiPress').'</p></div>';

	// URL
	echo '<div class="dp_cf_item_box">
		<p class="b">'.__('Header Slider Image URL(Optional):','DigiPress').'</p><p>'.__('Enter the URL to your slideshow image below, if you want to customize default image of slideshow.', 'DigiPress').'</p>
		 <input type="text" name="slideshow_image_url" id="slideshow_image_url" class="img_url" size="60" style="width:80%;" value="'.$slideshow_image_url.'" />
		 <button class="dp_upload_image_button button">'.__('Add / Change','DigiPress').'</button><br />* '
		 .__("When you save as a blank, DigiPress displays the random image to the slideshow.",'DigiPress');
	echo '<p class="pd8px-top b grey">'.__("Current Slideshow image", "DigiPress").':</p><div id="uploadedImageView" class="clearfix">'. $preview_tag.'</div>';
	echo '</div>';

	// No index
	echo '<div class="dp_cf_item_box">
		<p class="b">'.__('HTML meta information settings', 'DigiPress').'</p>
		 <div class="mg8px-btm"><input name="dp_noindex" id="dp_noindex" type="checkbox" value="1"';
	if( $dp_noindex ) echo ' checked="checked"';
	echo ' /><label for="dp_noindex"> '.__("Check to set meta no index attribute to this page.","DigiPress").'</label></div>';
	// No follow
	echo '<div class="mg8px-btm"><input name="dp_nofollow" id="dp_nofollow" type="checkbox" value="1"';
	if( $dp_nofollow ) echo ' checked="checked"';
	echo ' /><label for="dp_nofollow"> '.__("Check to set meta no follow attribute to this page.","DigiPress").'</label></div>';
	// No archive
	echo '<div class="mg8px-btm"><input name="dp_noarchive" id="dp_noarchive" type="checkbox" value="1"';
	if( $dp_noarchive ) echo ' checked="checked"';
	echo ' /><label for="dp_noarchive"> '.__("Check to set meta no archive attribute to this page.","DigiPress").'</label></div></div>';


	// Meta keyword
	echo '<div class="dp_cf_item_box">
		 <p class="b">'.__('HTML meta keyword (Optional):','DigiPress').'</p>
		 <p>'.__("Enter meta keywords of this post. If you don't specifiy the keyword, post tags are used for meta keywords.", "DigiPress").'</p>
		 <input name="dp_meta_keyword" id="dp_meta_keyword" type="text" style="width:100%;" value="'.$dp_meta_keyword.'" />';
	echo '<p>'.__('* Please use comma for separate each keyword.','DigiPress').'</p></div>';

	// Show additional params from extensions
	$additional_setting = apply_filters('dp_custom_field_page_form', $post->ID);
	if (is_string($additional_setting) && $additional_setting != $post->ID) {
		echo $additional_setting;
	}
}
/****************************************************************
* Insert custom field to editing post window.
****************************************************************/
// Add custom fields
add_action('admin_menu', 'add_custom_field');
add_action('save_post', 'save_custom_field');