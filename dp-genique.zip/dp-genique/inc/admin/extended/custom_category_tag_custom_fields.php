<?php
/**
 * Add custom field in adding a new category
 */
function dp_term_add_form_fields() {

	global $options;

	// Current screen info
	$current_screen = get_current_screen();


	/**
	 * Sub title
	 */
	// Description
	$description = __('You can set the sub title of this archive page.', 'DigiPress');
	// Form code
	$form_code =
'<div class="form-field">
<label for="ex_term_meta_sub_title">' . __('Sub Title', 'DigiPress') . '</label>
<input type="text" name="ex_term_meta[sub_title]" id="ex_term_meta_sub_title" size="25" value="" />
<p class="description">' . $description . '</p>
</div>';


	/**
	 * Image color
	 */
	// Description
	$description = __('You can set the featured color of this archive page.', 'DigiPress');
	// Form code
	$form_code .=
'<div class="form-field">
<label for="ex_term_meta_color">'.__('Featured color', 'DigiPress').'</label>
<input type="text" name="ex_term_meta[color]" value="" class="dp-color-field" />
<p class="description">' . $description . '</p>
</div>';


	/**
	 * Featured image
	 */
	// Description
	$description = __('You can set the featured image of this archive page.', 'DigiPress');
	// Form code
	$form_code .=
'<div class="form-field">
<label for="ex_term_meta_img">'.__('Image URL', 'DigiPress').'</label>
<input type="url" id="ex_term_meta_img" class="img_url with-add-btn" size="36" name="ex_term_meta[img]" value="" /><button class="dp_upload_image_button button">'.__('Add / Change','DigiPress').'</button>
<p class="description">' . $description . '</p>
</div>';


	/**
	 * Sort option
	 */
	$arr_order = array(
		'date' => __('Order by newest', 'DigiPress'),
		'modified' => __('Order by modified', 'DigiPress'),
		'post_views_count' => __('Order by views', 'DigiPress'),
		'comment_count' => __('Order by comment count', 'DigiPress'),
		'title' => __('Order by title', 'DigiPress'),
		'name' => __('Order by slug', 'DigiPress'),
		'author' => __('Order by author', 'DigiPress'),
		'rand' => __('Random order', 'DigiPress')
	);
	$select_form = '<select name="ex_term_meta[orderby]" id="ex_term_meta_orderby" class="postform">';
	foreach ($arr_order as $key => $value) {
		$select_form .= '<option class="level-0" value="' . $key . '">' .$value . '</option>';
	}
	$select_form .= '</select>';

	// Form code
	$form_code .= '<div class="form-field"><label for="ex_term_meta_orderby">' . __('Sort order', 'DigiPress') . '</label>' . $select_form . '<p class="description">' . __('You can change the order of articles in this archive page.', 'DigiPress') . '</p></div>';


	/**
	 * Number of posts per page
	 */
	$number_posts = get_option('posts_per_page');
	$number_posts_mobile = get_option('posts_per_page');
	if ( $current_screen->taxonomy === 'category' ){
		$number_posts = $options['number_posts_category'];
		$number_posts_mobile = $options['number_posts_category_mobile'];
	} else if ( $current_screen->taxonomy === 'post_tag' ){
		$number_posts = $options['number_posts_tag'];
		$number_posts_mobile = $options['number_posts_tag_mobile'];
	}
	$form_code .= '<div class="form-field"><label for="ex_term_meta_number_posts">' . __('Number of display per page', 'DigiPress') . '</label>
<table>
<tbody>
<tr>
<td>' . __('PC theme', 'DigiPress') . '</td>
<td> : <input type="number" name="ex_term_meta[number_posts]" id="ex_term_meta_number_posts" class="small-text small-width" min="1" value="' . $number_posts . '" />' . __('posts', 'DigiPress') . '</td>
</tr>
<tr>
<td>' . __('Mobile theme', 'DigiPress') . '</td>
<td> : <input type="number" name="ex_term_meta[number_posts_mobile]" id="ex_term_meta_number_posts_mobile" class="small-text small-width" min="1" value="' . $number_posts_mobile . '" />' . __('posts', 'DigiPress') . '</td>
</tr>
</tbody></table>
<p class="description">' . __( 'You can set the number of articles per page when this archive page is displayed.', 'DigiPress' ) . '</p></div>';


	/**
	 * Archive layout
	 */
	$arr_layout = array(
		'' => __( 'Same as archive settings', 'DigiPress' ),
		'normal' => __('Standard layout', 'DigiPress'),
		'portfolio' => __('Portfolio', 'DigiPress'),
		'magazine' => __('Magazine layout', 'DigiPress'),
		'news' => __('Simple list layout', 'DigiPress'),
		'simple' => __('Simple list layout','DigiPress') . ' (' . __('with thumbnail', 'DigiPress') . ')'
	);
	$select_form = '<select name="ex_term_meta[layout]" id="ex_term_meta_layout" class="postform">';
	foreach ($arr_layout as $key => $value) {
		$select_form .= '<option class="level-0" value="' . $key . '">' .$value . '</option>';
	}
	$select_form .= '</select>';

	// Description
	$description = 'You can set the archive page layout for each %s.';
	if ( $current_screen->taxonomy === 'category' ){
		$description = sprintf( __( $description, 'DigiPress' ), __( 'category', 'DigiPress' ) );
	} else if ( $current_screen->taxonomy === 'post_tag' ){
		$description = sprintf( __( $description, 'DigiPress' ), __( 'tag', 'DigiPress' ) );
	}

	// Form code
	$form_code .= '<div class="form-field"><label for="ex_term_meta_layout">' . __('Archive layout', 'DigiPress') . '</label>' . $select_form . '<p class="description">' . $description . '</p></div>';


	/**
	 * 1 column
	 */
	// Description
	$description = __('You can set this archive page to 1 column (without sidebar).', 'DigiPress');
	// Form code
	$form_code .=
'<div class="form-field">
<label for="ex_term_meta_no_sidebar">' . __('Column setting', 'DigiPress') . '</label>
<label><input type="checkbox" value="1" name="ex_term_meta[no_sidebar]" id="ex_term_meta_no_sidebar" />' . __('Display in 1 column (without sidebar)', 'DigiPress') . '</label>
<p class="description">' . $description . '</p>
</div>';


	/**
	 * Disable related posts
	 */
	// Description
	$description = __('Check this if you hide related articles for articles page that belong to this category.', 'DigiPress');
	// Form code
	$form_code .=
'<div class="form-field">
<label for="ex_term_meta_hide_rel_posts">' . __('Post meta setting', 'DigiPress') . '</label>
<label><input type="checkbox" value="1" name="ex_term_meta[hide_rel_posts]" id="ex_term_meta_hide_rel_posts" />' . __('Hide related articles', 'DigiPress') . '</label>
<p class="description">' . $description . '</p></div>';


	/**
	 * Show sub categories if this category has children
	 */
	if ( $current_screen->taxonomy === 'category' ){

		// Main Description
		$description = __('Show sub categories instead of articles if this category has children.', 'DigiPress');

		/**
		 * Form code
		 */
		$form_code .= '<div class="form-field"><p><label>' . __('Switch to subcategory view', 'DigiPress') . '</label></p>';

		$form_code .=
'<input type="checkbox" value="1" name="ex_term_meta[show_only_sub_terms]" id="ex_term_meta_show_only_sub_terms" class="toggle_ele" />
<label for="ex_term_meta_show_only_sub_terms" class="toggle_lbl">' . __('Show only sub categories', 'DigiPress') . '</label>
<p class="description">' . $description . '</p>';

		// Toggle content
		$form_code .= '<div class="toggle_content box-c mg15px-top">';

		// Sub category layout
		$description = __('For thumbnail image, the image URL stored in each sub category is displayed.', 'DigiPress');
		$arr_layout = array(
			'thumb_big' => __('Big thumbnail', 'DigiPress'),
			'thumb_small' => __('Small thumbnail','DigiPress'),
			'simple_list' => __('Simple list layout', 'DigiPress'),
		);
		$select_form = '<div class="mg15px-btm"><label for="ex_term_meta_sub_terms_layout">' . __('Layout', 'DigiPress') . '</label><select name="ex_term_meta[sub_terms_layout]" id="ex_term_meta_sub_terms_layout" class="postform">';
		foreach ($arr_layout as $key => $value) {
			$select_form .= '<option class="level-0" value="' . $key . '">' .$value . '</option>';
		}
		$select_form .=
'</select><p class="description">' . $description . '</p></div>';
		$form_code .= $select_form;

		// Mouseover effect
		$description = __('Set the animation effect for thumbnail images when hovering sub category items.', 'DigiPress');
		$arr_effect = array(
			'' => __('None', 'DigiPress'),
			'hover-move-up' => __('Move Up','DigiPress'),
			'hover-tilt-top' => __('Tilt Top Front', 'DigiPress'),
			'hover-tilt-bottom' => __('Tilt Bottom Front', 'DigiPress'),
			'hover-tilt-left' => __('Tilt Left Front', 'DigiPress'),
			'hover-tilt-right' => __('Tilt Right Front', 'DigiPress'),
		);
		$select_form = '<div class="mg15px-btm"><label for="ex_term_meta_sub_terms_hover_fx">' . __('Thumbnail hover effect', 'DigiPress') . '</label><select name="ex_term_meta[sub_terms_hover_fx]" id="ex_term_meta_sub_terms_hover_fx" class="postform">';
		foreach ($arr_effect as $key => $value) {
			$select_form .= '<option class="level-0" value="' . $key . '">' .$value . '</option>';
		}
		$select_form .=
'</select><p class="description">' . $description . '</p></div>';
		$form_code .= $select_form;

		// Crop image to circle
		$form_code .=
'<div class="mg15px-btm">
<label for="ex_term_meta_sub_terms_crop_circle_image">
<input type="checkbox" value="1" name="ex_term_meta[sub_terms_crop_circle_image]" id="ex_term_meta_sub_terms_crop_circle_image" />' . __('Crop thumbnail to circle', 'DigiPress') . '
</label>
</div>';

		// No Image URL
		$description = __('You can set a thumbnail image to be displayed as an alternative when the image URL is not saved in the sub category.', 'DigiPress');
		$form_code .=
'<div class="mg15px-btm">
<label for="ex_term_meta_sub_terms_no_image">'.__('"NO IMAGE" image(Alternate thumbnail)', 'DigiPress').'</label>
<input type="url" class="img_url with-add-btn" size="36" name="ex_term_meta[sub_terms_no_image]" value="" /><button class="dp_upload_image_button button">'.__('Add / Change','DigiPress').'</button>
<p class="description">' . $description . '</p>
</div>';

		// Exclude empty
		$description = __('Check to exclude a category that has no published posts from the list of sub categories.', 'DigiPress');
		$form_code .=
'<div class="mg15px-btm">
<label for="ex_term_meta_sub_terms_exclude_empty">
<input type="checkbox" value="1" name="ex_term_meta[sub_terms_exclude_empty]" id="ex_term_meta_sub_terms_exclude_empty" />' . __('Exclude empty sub categories', 'DigiPress') . '
</label>
<p class="description">' . $description . '</p>
</div>';

		// Close
		$form_code .= '</div></div>';
	}


	// Show
	echo $form_code;
}
add_action( 'category_add_form_fields', 'dp_term_add_form_fields' );
add_action( 'post_tag_add_form_fields', 'dp_term_add_form_fields' );



/**
 * Add custom field into category page
 */
function dp_add_extra_term_fields( $term ) {

	global $options;

	$t_id = $term->term_id;
	$ex_term_meta = get_option("ex_term_meta_$t_id");

	// Current screen info
	$current_screen = get_current_screen();


	/**
	 * Sub title
	 */
	$sub_title = '';
	if ( isset($ex_term_meta['sub_title']) ) {
		$sub_title = esc_attr($ex_term_meta['sub_title']);
	}
	$form_code =
'<tr class="form-field">
<th><label for="ex_term_meta_sub_title">'.__('Sub Title', 'DigiPress').'</label></th>
<td><input type="text" name="ex_term_meta[sub_title]" id="ex_term_meta_sub_title" size="25" value="'.$sub_title.'" />
<p class="description">' . __('You can set the sub title of this archive page.', 'DigiPress') . '</p></td>
</tr>';


	/**
	 * Image color
	 */
	$color = '';
	if ( isset($ex_term_meta['color']) ) {
		$color = esc_attr($ex_term_meta['color']);
	}
	$form_code .=
'<tr class="form-field">
<th><label for="ex_term_meta_color">'.__('Featured color', 'DigiPress').'</label></th>
<td><input type="text" name="ex_term_meta[color]" value="'.$color.'" class="dp-color-field" id="ex_term_meta_color" />
<p class="description">' . __('You can set the featured color of this archive page.', 'DigiPress') . '</p></td>
</tr>';


	/**
	 * Featured image
	 */
	$img_url = '';
	if ( isset($ex_term_meta['img']) ) {
		$img_url = esc_attr($ex_term_meta['img']);
	}
	$form_code .=
'<tr class="form-field">
<th><label for="ex_term_meta_img">'.__('Image URL', 'DigiPress').'</label></th>
<td><input type="text" class="img_url with-add-btn" size="36" name="ex_term_meta[img]" value="'.$img_url.'" id="ex_term_meta_img" /><button class="dp_upload_image_button button">'.__('Add / Change','DigiPress').'</button>
<p class="description">'.__('You can set the featured image of this archive page.', 'DigiPress').'</p></td>
</tr>';

	/**
	 * Featured video
	 */
// 	$video_id = '';
// 	if ( isset($ex_term_meta['video_id']) ) {
// 		$video_id = esc_attr($ex_term_meta['video_id']);
// 	}

// 	$form_code .=
// '<tr style="display:none;" class="form-field">
// <th><label for="video_id">'.__('Video ID(YouTube or Vimeo)', 'DigiPress').'</label></th>
// <td><input type="text" name="ex_term_meta[video_id]" id="video_id" size="25" value="'.$video_id.'" /><p class="description">'.__('Enter the video ID or URL to play the background video in category page.', 'DigiPress').'</p></td>
// </tr>';


	/**
	 * Sort option
	 */
	$arr_order = array(
		'date' => __('Order by newest', 'DigiPress'),
		'modified' => __('Order by modified', 'DigiPress'),
		'post_views_count' => __('Order by views', 'DigiPress'),
		'comment_count' => __('Order by comment count', 'DigiPress'),
		'title' => __('Order by title', 'DigiPress'),
		'name' => __('Order by slug', 'DigiPress'),
		'author' => __('Order by author', 'DigiPress'),
		'rand' => __('Random order', 'DigiPress')
	);

	// custom field value
	$orderby = isset($ex_term_meta['orderby']) ? esc_attr($ex_term_meta['orderby']) : 'date';

	$select_form = '<select name="ex_term_meta[orderby]" id="ex_term_meta_orderby" class="postform">';
	foreach ($arr_order as $key => $value) {
		if ( $orderby === $key ){
			$select_form .= '<option class="level-0" value="' . $key . '" selected>' .$value . '</option>';
		} else {
			$select_form .= '<option class="level-0" value="' . $key . '">' .$value . '</option>';
		}
	}
	$select_form .= '</select>';

	// Form code
	$form_code .=
'<tr class="form-field">
<th scope="row"><label for="ex_term_meta_orderby">' . __('Sort order', 'DigiPress') . '</label></th>
<td>' . $select_form . '<p class="description">' . __('You can change the order of articles in this archive page.', 'DigiPress') . '</p>
</td>
</tr>';


	/**
	 * Number of posts per page
	 */
	$number_posts = get_option('posts_per_page');
	$number_posts_mobile = get_option('posts_per_page');
	// PC
	if ( isset($ex_term_meta['number_posts']) ) {
		$number_posts = $ex_term_meta['number_posts'];
	} else {
		if ( $current_screen->taxonomy === 'category' ){
			$number_posts = $options['number_posts_category'];
		} else if ( $current_screen->taxonomy === 'post_tag' ){
			$number_posts = $options['number_posts_tag'];
		}
	}
	// Mobile
	if ( isset($ex_term_meta['number_posts_mobile']) ) {
		$number_posts_mobile = $ex_term_meta['number_posts_mobile'];
	} else {
		if ( $current_screen->taxonomy === 'category' ){
			$number_posts_mobile = $options['number_posts_category_mobile'];
		} else if ( $current_screen->taxonomy === 'post_tag' ){
			$number_posts_mobile = $options['number_posts_tag_mobile'];
		}
	}

	$form_code .=
'<tr class="form-field">
<th scope="row"><label for="ex_term_meta_number_posts">' . __('Number of display per page', 'DigiPress') . '</label></th>
<td>
	<table>
	<tbody>
	<tr>
	<td>' . __('PC theme', 'DigiPress') . '</td>
	<td>: <input type="number" name="ex_term_meta[number_posts]" id="ex_term_meta_number_posts" class="small-text small-width" min="1" value="' . $number_posts . '" />' . __('posts', 'DigiPress') . '</td>
	</tr>
	<tr>
	<td>' . __('Mobile theme', 'DigiPress') . '</td>
	<td>: <input type="number" name="ex_term_meta[number_posts_mobile]" id="ex_term_meta_number_posts_mobile" class="small-text small-width" min="1" value="' . $number_posts_mobile . '" />' . __('posts', 'DigiPress') . '</td>
	</tr>
	</tbody>
	</table>
	<p class="description">' . __( 'You can set the number of articles per page when this archive page is displayed.', 'DigiPress' ) . '</p>
</td>
</tr>';


	/**
	 * Archive layout
	 */
	$arr_layout = array(
		'' => __( 'Same as archive settings', 'DigiPress' ),
		'normal' => __('Standard layout', 'DigiPress'),
		'portfolio' => __('Portfolio', 'DigiPress'),
		'magazine' => __('Magazine layout', 'DigiPress'),
		'news' => __('Simple list layout', 'DigiPress'),
		'simple' => __('Simple list layout','DigiPress') . ' (' . __('with thumbnail', 'DigiPress') . ')'
	);

	// custom field value
	$layout = isset($ex_term_meta['layout']) ? $ex_term_meta['layout'] : $options['archive_post_show_type'];

	$select_form = '<select name="ex_term_meta[layout]" id="ex_term_meta_layout" class="postform">';
	foreach ($arr_layout as $key => $value) {
		if ( $layout === $key ){
			$select_form .= '<option class="level-0" value="' . $key . '" selected>' .$value . '</option>';
		} else {
			$select_form .= '<option class="level-0" value="' . $key . '">' .$value . '</option>';
		}
	}
	$select_form .= '</select>';

	// Description
	$description = 'You can set the archive page layout for each %s.';
	if ( $current_screen->taxonomy === 'category' ){
		$description = sprintf( __( $description, 'DigiPress' ), __( 'category', 'DigiPress' ) );
	} else if ( $current_screen->taxonomy === 'post_tag' ){
		$description = sprintf( __( $description, 'DigiPress' ), __( 'tag', 'DigiPress' ) );
	}

	// Form code
	$form_code .=
'<tr class="form-field">
<th scope="row"><label for="ex_term_meta_layout">' . __('Archive layout', 'DigiPress') . '</label></th>
<td>' . $select_form . '<p class="description">' . $description . '</p></td>
</tr>';


	/**
	 * 1 column
	 */
	// custom field value
	$check_state = '';
	if ( isset($ex_term_meta['no_sidebar']) && !empty($ex_term_meta['no_sidebar']) ){
		$check_state = ' checked';
	}

	// Description
	$description = __('You can set this archive page to 1 column (without sidebar).', 'DigiPress');
	// Form code
	$form_code .=
'<tr class="form-field">
<th scope="row"><label for="ex_term_meta_no_sidebar">' . __('Column setting', 'DigiPress') . '</label></th>
<td><label><input type="checkbox" value="1" name="ex_term_meta[no_sidebar]" id="ex_term_meta_no_sidebar"' . $check_state . ' />' . __('Display in 1 column (without sidebar)', 'DigiPress') . '</label><p class="description">' . $description . '</p></td>
</tr>';


	/**
	 * Disable related posts
	 */
	// custom field value
	$check_state = '';
	if ( isset($ex_term_meta['hide_rel_posts']) && !empty($ex_term_meta['hide_rel_posts']) ){
		$check_state = ' checked';
	}
	// Description
	$description = __('Check this if you hide related articles for articles page that belong to this category.', 'DigiPress');
	// Form code
	$form_code .=
'<tr class="form-field">
<th scope="row"><label for="ex_term_meta_hide_rel_posts">' . __('Post meta setting', 'DigiPress') . '</label></th>
<td><label><input type="checkbox" value="1" name="ex_term_meta[hide_rel_posts]" id="ex_term_meta_hide_rel_posts"' . $check_state . ' />' . __('Hide related articles', 'DigiPress') . '</label><p class="description">' . $description . '</p></td>
</tr>';



	/**
	 * Show sub categories if this category has children
	 */
	if ( $current_screen->taxonomy === 'category' ){

		$check_state = '';

		/**
		 * Form code
		 */
		$form_code .=
'<tr class="form-field">
<th scope="row"><label>' . __('Switch to subcategory view', 'DigiPress') . '</label></th>';

		// Main Description
		$description = __('Show sub categories instead of articles if this category has children.', 'DigiPress');

		// Show sub categories
		$check_state = '';
		if ( isset($ex_term_meta['show_only_sub_terms']) && !empty($ex_term_meta['show_only_sub_terms']) ){
			$check_state = ' checked';
		}
		$form_code .=
'<td><input type="checkbox" value="1" name="ex_term_meta[show_only_sub_terms]" id="ex_term_meta_show_only_sub_terms" class="toggle_ele"' . $check_state . ' />
<label for="ex_term_meta_show_only_sub_terms" class="toggle_lbl">' . __('Show only sub categories', 'DigiPress') . '</label>
<p class="description">' . $description . '</p>';

		// Toggle content
		$form_code .= '<div class="toggle_content box-c mg15px-top">';

		// Sub category layout
		$description = __('For thumbnail image, the image URL stored in each sub category is displayed.', 'DigiPress');
		$arr_layout = array(
			'thumb_big' => __('Big thumbnail', 'DigiPress'),
			'thumb_small' => __('Small thumbnail','DigiPress'),
			'simple_list' => __('Simple list layout', 'DigiPress'),
		);
		// custom field value
		$layout = isset($ex_term_meta['sub_terms_layout']) ? $ex_term_meta['sub_terms_layout'] : 'thumb big';
		$select_form =
'<p><label for="ex_term_meta_sub_terms_layout">' . __('Layout', 'DigiPress') . '</label></p>
<div class="mg20px-btm">
<select name="ex_term_meta[sub_terms_layout]" id="ex_term_meta_sub_terms_layout" class="postform">';

		foreach ($arr_layout as $key => $value) {
			if ( $layout === $key ){
				$select_form .= '<option class="level-0" value="' . $key . '" selected>' . $value . '</option>';
			} else {
				$select_form .= '<option class="level-0" value="' . $key . '">' .$value . '</option>';
			}
		}

		$select_form .=
'</select><p class="description">' . $description . '</p></div>';
		$form_code .= $select_form;


		// Mouseover effect
		$description = __('Set the animation effect for thumbnail images when hovering sub category items.', 'DigiPress');
		$arr_effect = array(
			'' => __('None', 'DigiPress'),
			'hover-move-up' => __('Move Up','DigiPress'),
			'hover-tilt-top' => __('Tilt Top Front', 'DigiPress'),
			'hover-tilt-bottom' => __('Tilt Bottom Front', 'DigiPress'),
			'hover-tilt-left' => __('Tilt Left Front', 'DigiPress'),
			'hover-tilt-right' => __('Tilt Right Front', 'DigiPress'),
		);
		// custom field value
		$hover_fx = isset($ex_term_meta['sub_terms_hover_fx']) ? $ex_term_meta['sub_terms_hover_fx'] : 'hover-move-up';
		$select_form =
'<p><label for="ex_term_meta_sub_terms_hover_fx">' . __('Thumbnail hover effect', 'DigiPress') . '</label></p>
<div class="mg20px-btm">
<select name="ex_term_meta[sub_terms_hover_fx]" id="ex_term_meta_sub_terms_hover_fx" class="postform">';

		foreach ($arr_effect as $key => $value) {
			if ( $hover_fx === $key ){
				$select_form .= '<option class="level-0" value="' . $key . '" selected>' . $value . '</option>';
			} else {
				$select_form .= '<option class="level-0" value="' . $key . '">' .$value . '</option>';
			}
		}

		$select_form .=
'</select><p class="description">' . $description . '</p></div>';
		$form_code .= $select_form;


		// Crop image to circle
		$check_state = '';
		if ( isset($ex_term_meta['sub_terms_crop_circle_image']) && !empty($ex_term_meta['sub_terms_crop_circle_image']) ){
			$check_state = ' checked';
		}
		$form_code .=
'<div class="mg20px-btm">
<label for="ex_term_meta_sub_terms_crop_circle_image">
<input type="checkbox" value="1" name="ex_term_meta[sub_terms_crop_circle_image]" id="ex_term_meta_sub_terms_crop_circle_image"' . $check_state . ' />' . __('Crop thumbnail to circle', 'DigiPress') . '
</label>
</div>';


		// No Image URL
		$img_url = '';
		if ( isset($ex_term_meta['sub_terms_no_image']) ) {
			$img_url = esc_attr($ex_term_meta['sub_terms_no_image']);
		}
		$description = __('You can set a thumbnail image to be displayed as an alternative when the image URL is not saved in the sub category.', 'DigiPress');
		$form_code .=
'<div class="mg20px-btm">
<label for="ex_term_meta_sub_terms_no_image">'.__('"NO IMAGE" image(Alternate thumbnail)', 'DigiPress').'</label>
<input type="url" class="img_url with-add-btn" size="36" name="ex_term_meta[sub_terms_no_image]" value="' . $img_url . '" id="ex_term_meta_sub_terms_no_image" /><button class="dp_upload_image_button button">'.__('Add / Change','DigiPress').'</button>
<p class="description">' . $description . '</p>
</div>';

		// Exclude empty
		$description = __('Check to exclude a category that has no published posts from the list of sub categories.', 'DigiPress');
		$check_state = '';
		if ( isset($ex_term_meta['sub_terms_exclude_empty']) && !empty($ex_term_meta['sub_terms_exclude_empty']) ){
			$check_state = ' checked';
		}

		$form_code .=
'<div class="mg20px-btm">
<label for="ex_term_meta_sub_terms_exclude_empty">
<input type="checkbox" value="1" name="ex_term_meta[sub_terms_exclude_empty]" id="ex_term_meta_sub_terms_exclude_empty"' . $check_state . ' />' . __('Exclude empty sub categories', 'DigiPress') . '
</label>
<p class="description">' . $description . '</p>
</div>';

		// Close
		$form_code .= '</td></tr>';
	}


	echo $form_code;
}
add_action ( 'category_edit_form_fields', 'dp_add_extra_term_fields' );
add_action ( 'post_tag_edit_form_fields', 'dp_add_extra_term_fields' );


/**
 * Save the category meta data
 */
function dp_save_extra_term_fileds( $term_id ) {
	if ( isset( $_POST['ex_term_meta'] ) ) {
		// Re-make CSS flag
		// $exp_css = false;

		// ID
		$t_id = $term_id;
		// meta
		$ex_term_meta = get_option("ex_term_meta_$t_id");
		// Get POST data
		$term_keys = array_keys($_POST['ex_term_meta']);

		// Checkbox state only
		if ( !isset($_POST['ex_term_meta']['no_sidebar']) ) {
			$ex_term_meta['no_sidebar'] = NULL;
		}
		if ( !isset($_POST['ex_term_meta']['show_only_sub_terms']) ) {
			$ex_term_meta['show_only_sub_terms'] = NULL;
		}
		if ( !isset($_POST['ex_term_meta']['sub_terms_exclude_empty']) ) {
			$ex_term_meta['sub_terms_exclude_empty'] = NULL;
		}
		if ( !isset($_POST['ex_term_meta']['sub_terms_crop_circle_image']) ) {
			$ex_term_meta['sub_terms_crop_circle_image'] = NULL;
		}
		if ( !isset($_POST['ex_term_meta']['hide_rel_posts']) ) {
			$ex_term_meta['hide_rel_posts'] = NULL;
		}

		// Each POST data
		foreach ($term_keys as $key){
			if ( isset($_POST['ex_term_meta'][$key]) ){
				$ex_term_meta[$key] = $_POST['ex_term_meta'][$key];
			}
		}

		// Update
		update_option( "ex_term_meta_$t_id", $ex_term_meta );

		// Re-create CSS
		dp_css_create();
	}
}
add_action( 'create_term', 'dp_save_extra_term_fileds' );
add_action( 'edited_term', 'dp_save_extra_term_fileds' );