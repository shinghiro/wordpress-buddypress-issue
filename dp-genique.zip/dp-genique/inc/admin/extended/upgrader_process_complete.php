<?php
/**
 * Fired on theme update completed
 */
function dp_upgrader_process_complete( $upgrader_object, $options ) {
	$current_theme = get_template();
	if ( $options['action'] === 'update' && $options['type'] === 'theme' ){

		dp_css_create();

		// foreach( (array)$options['themes'] as $theme ){
		// 	if ( $theme === $current_theme ){
		// 		// re-generate custom CSS
		// 		dp_css_create();
		// 	}
		// }
	}
}
add_action( 'upgrader_process_complete', 'dp_upgrader_process_complete', 10, 2 );