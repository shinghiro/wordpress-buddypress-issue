<?php
/**
 * Show taxonomy archive ID
 */
function dp_admin_tax_id_add_col( $columns ){
	return $columns + array ( 'tax_id' => 'ID' );
}
function dp_admin_tax_id_show( $v, $name, $id ){
	return 'tax_id' === $name ? $id : $v;
}
foreach ( get_taxonomies() as $taxonomy ) {
	add_action( "manage_edit-{$taxonomy}_columns", 'dp_admin_tax_id_add_col' );
	add_filter( "manage_edit-{$taxonomy}_sortable_columns", 'dp_admin_tax_id_add_col' );
	add_filter( "manage_{$taxonomy}_custom_column", 'dp_admin_tax_id_show', 10, 3 );
}
/**
 * Inline CSS for taxonomy page
 */
function dp_admin_tax_inline_style(){
	echo '<style>#tax_id{width:60px}</style>';
}
add_action( 'admin_print_styles-edit-tags.php', 'dp_admin_tax_inline_style' );


/**
 * Inline CSS for article list page
 */
function dp_admin_post_list_inline_style(){
	$style =
'<style>#thumbnail{width:90px;}
#revealid_id{width:60px}
#post_views{width:80px}
th.column-dp_hide_date,
td.column-dp_hide_date,
th.column-dp_hide_author,
td.column-dp_hide_author,
th.column-dp_hide_author_prof,
td.column-dp_hide_author_prof,
th.column-dp_hide_cat,
td.column-dp_hide_cat,
th.column-dp_hide_tag,
td.column-dp_hide_tag,
th.column-dp_hide_views,
td.column-dp_hide_views,
th.column-dp_hide_fb_comment,
td.column-dp_hide_fb_comment,
th.column-dp_hide_time_for_reading,
td.column-dp_hide_time_for_reading,
th.column-dp_disable_breadcrumb,
td.column-dp_disable_breadcrumb,
th.column-disable_sidebar,
td.column-disable_sidebar,
th.column-dp_show_eyecatch_force,
td.column-dp_show_eyecatch_force,
th.column-dp_hide_related_posts,
td.column-dp_hide_related_posts,
th.column-dp_eyecatch_to_bg,
td.column-dp_eyecatch_to_bg,
th.column-is_slideshow,
td.column-is_slideshow,
th.column-is_headline,
td.column-is_headline,
th.column-hide_sns_icon,
td.column-hide_sns_icon,
th.column-dp_hide_toc,
td.column-dp_hide_toc,
th.column-dp_hide_follow_box,
td.column-dp_hide_follow_box,
th.column-dp_hide_next_prev,
td.column-dp_hide_next_prev{
display:none;
}</style>';

	echo $style;
}
add_action( 'admin_print_styles-edit.php', 'dp_admin_post_list_inline_style' );


/**
 * Sortable columns
 */
function dp_sortable_post_list_column( $sortable_columns )    {
	$sortable_columns['revealid_id'] = 'ID';
	$sortable_columns['post_views'] = 'post_views';

	return $sortable_columns;
}
add_filter( 'manage_edit-post_sortable_columns', 'dp_sortable_post_list_column' );
add_filter( 'manage_edit-page_sortable_columns', 'dp_sortable_post_list_column' );
// Set the sortable custom fields
function dp_sort_by_custom_field( $query ) {
	if ( $query->is_main_query() && ( $orderby = $query->get( 'orderby' ) ) ) {
		switch( $orderby ) {
			case 'post_views':
				$query->set( 'meta_key', 'post_views_count' );
				$query->set( 'orderby', 'meta_value_num' );
				break;
		}
	}
}
add_action( 'pre_get_posts', 'dp_sort_by_custom_field', 1 );


/**
 * Add Column in posted list page
 */
function dp_add_posts_columns($columns) {
	$arr_fields = array(
		'thumbnail' => __('Thumbnail', 'default'),
		'revealid_id' => 'ID',
		'is_slideshow' => '',
		'dp_hide_date' => '',
		'dp_hide_author' => '',
		'dp_hide_author_prof' => '',
		'dp_hide_cat' => '',
		'dp_hide_tag' => '',
		'dp_hide_views' => '',
		'dp_hide_fb_comment' => '',
		'dp_hide_time_for_reading' => '',
		'hide_sns_icon' => '',
		'dp_hide_toc' => '',
		'dp_hide_follow_box' => '',
		'dp_hide_next_prev' => '',
		'dp_disable_breadcrumb' => '',
		'disable_sidebar' => '',
		'dp_show_eyecatch_force' => '',
		'dp_hide_related_posts' => '',
		'dp_eyecatch_to_bg' => ''
	);
	foreach ($arr_fields as $key => $field) {
		$columns[$key] = $field;
	}
	return $columns;
}
function dp_show_posts_custom_column($column_slug, $post_id) {
	global $options;

	$arr_post_type 	= array('post', 'page', $options['news_cpt_slug_id']);
	$pattern 		= '/'.implode('|', $arr_post_type).'/i';
	$match_type 	= preg_match($pattern, get_post_type($post_id));
	if (!$match_type) return;

	// Thumbnail column
	if ($column_slug === 'thumbnail') {
		$thumb = get_the_post_thumbnail($post_id, array(90,90), 'thumbnail');
		// Display
		if ( isset($thumb) && $thumb ) {
			echo $thumb;
		} else {
			_e('No Thumbnail', 'DigiPress');
		}
	}

	// Post ID
	if( 'revealid_id' == $column_slug ) {
		echo $post_id;
	}

	// Hidden columns
	// Check box items
	$arr_fields = array(
		'is_slideshow', 
		// 'is_headline',
		'dp_hide_date',
		'dp_hide_author',
		'dp_hide_author_prof',
		'dp_hide_cat',
		'dp_hide_tag',
		'dp_hide_views',
		'dp_hide_fb_comment',
		'dp_hide_time_for_reading',
		'hide_sns_icon',
		'dp_hide_toc',
		'dp_hide_follow_box',
		'dp_hide_next_prev',
		'dp_disable_breadcrumb',
		'disable_sidebar',
		'dp_show_eyecatch_force',
		'dp_hide_related_posts',
		'dp_eyecatch_to_bg'
	);

	// Only hidden check box
	foreach ($arr_fields as $key => $field) {
		if ( $column_slug === $field ) {
			$val = (bool)get_post_meta( $post_id , $field , true );
			if ( $val ) {
				$checked = 'checked';
			} else {
				$checked = '';
			}
			echo "<input type='checkbox' readonly $checked />";
		}
	}
}
add_filter( 'manage_posts_columns', 'dp_add_posts_columns' );
add_action( 'manage_posts_custom_column', 'dp_show_posts_custom_column', 10, 2 );
add_filter( 'manage_pages_columns', 'dp_add_posts_columns' );
add_action( 'manage_pages_custom_column', 'dp_show_posts_custom_column', 10, 2 );

/**
 * Add custom field option into quick edit
 * @param [type] $column_name [description]
 * @param [type] $post_type   [description]
 */
function dp_add_custom_field_into_quick_edit( $column_name, $post_type ) {
	global $options;

	$arr_post_type 	= array('post', 'page', $options['news_cpt_slug_id']);
	$pattern 		= '/'.implode('|', $arr_post_type).'/i';
	$match_type 	= preg_match($pattern, $post_type);
	if (!$match_type) return;

	static $print_nonce = true;
	if ( $print_nonce ) {
		$print_nonce = false;
		wp_nonce_field( 'quick_edit_action', $post_type . '_edit_nonce' ); // For CSRF
	}

	// Check box items
	$arr_fields = array(
		'is_slideshow' 	=> 'Include slideshow', 
		// 'is_headline'	=> 'Include headline',
		'dp_hide_date'	=> 'Hide post date',
		'dp_hide_author'=> 'Hide post author',
		'dp_hide_author_prof' => 'Hide post author prof',
		'dp_hide_cat' => 'Hide post categories',
		'dp_hide_tag' => 'Hide post tags',
		'dp_hide_views'	=> 'Hide post views',
		'dp_hide_fb_comment'	=> 'Disable Facebook comments',
		'dp_hide_time_for_reading' => 'Hide time for reading',
		'hide_sns_icon' => 'Hide SNS buttons',
		'dp_hide_toc' => 'Hide Table of Contents',
		'dp_hide_follow_box' => 'Hide SNS follow box',
		'dp_hide_next_prev' => 'Hide next / prev navigation',
		'dp_disable_breadcrumb' => 'Check to hide the breadcrumb list',
		'disable_sidebar' => 'Set to 1 column',
		'dp_show_eyecatch_force'=> 'Show eyecatch under the title',
		'dp_hide_related_posts'=> 'Hide related articles',
		'dp_eyecatch_to_bg'=> 'Set the eyecatch as background image',
	);

	// HTML
	$field_code = '';
	foreach ($arr_fields as $key => $field) {
		if ( $column_name === $key ) {
			$field_code = '<fieldset class="inline-edit-col-center inline-custom-meta"><div class="inline-edit-col column-'.$key.'"><label class="inline-edit-group">';
			$field_code .= '<input type="checkbox" name="'.$key.'" /><span class="checkbox-title">'.__($field, 'DigiPress').'</span>';
			$field_code .= '</label></div></fieldset>';
		}
	}

	echo $field_code;
}
add_action( 'quick_edit_custom_box', 'dp_add_custom_field_into_quick_edit', 10, 2 );


/**
 * Save the custom field from quick edit
 * @param  [type] $post_id [description]
 * @return [type]          [description]
 */
function dp_save_custom_field_from_quick_edit( $post_id ) {
	global $options;

	$arr_post_type 	= array('post', 'page', $options['news_cpt_slug_id']);
	$pattern 		= '/'.implode('|', $arr_post_type).'/i';
	$match_type 	= preg_match($pattern, get_post_type($post_id));
	if (!$match_type) return;

	if ( !current_user_can( 'edit_post', $post_id ) ) return;
	$slug = get_post_type( $post_id ); // Target post type
	$_POST += array("{$slug}_edit_nonce" => '');
	if ( !wp_verify_nonce( $_POST["{$slug}_edit_nonce"], 'quick_edit_action' ) ) return;

	$arr_fields = array(
		'is_slideshow', 
		// 'is_headline',
		'dp_hide_date',
		'dp_hide_author',
		'dp_hide_author_prof',
		'dp_hide_cat',
		'dp_hide_tag',
		'dp_hide_views',
		'dp_hide_fb_comment',
		'dp_hide_time_for_reading',
		'hide_sns_icon',
		'dp_hide_toc',
		'dp_hide_follow_box',
		'dp_hide_next_prev',
		'dp_disable_breadcrumb',
		'disable_sidebar',
		'dp_show_eyecatch_force',
		'dp_hide_related_posts',
		'dp_eyecatch_to_bg');

	// If check box
	foreach ($arr_fields as $key => $field) {
		if ( isset( $_REQUEST[$field] ) ) {
			update_post_meta($post_id, $field, true);
		} else {
			update_post_meta($post_id, $field, false);
		}
	}
}
add_action( 'save_post', 'dp_save_custom_field_from_quick_edit' );