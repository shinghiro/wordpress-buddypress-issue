<?php
// require_once ABSPATH . 'wp-includes/class-wp-customize-control.php';
/**
 * Theme customizer class
 *
 * @link http://codex.wordpress.org/Theme_Customization_API
 * @since DigiPress 1.0
 */
class DP_Theme_Customizer{
	/**
	 * Add to theme customizer
	 *
	 * @since       1.0.0.0
	 * @return      void
	 */
	public static function register($wp_customize){
		global $wp_version, $options, $def_options;
		$theme_path = trailingslashit( get_template_directory() );
		// ***********************
		// add_section
		// ***********************
		// Default section : themes, title_tagline, colors, header_image, background_image, static_front_page
		// ***********************
		// add_setting
		// ***********************
		// type : 'option' or 'theme_mod' (defaults to 'theme_mod')
		// transport : 'refresh' (default) or 'postMessage'.
		// ***********************
		// add_control
		// ***********************
		//  proority : themes (0), title_tagline (20), colors (40), header_image (60), background_image (80), static_front_page (120)
	 	//  type : text, checkbox, radio, select, textarea, dropdown-pages, email, url, number, hidden, range, and date
	 	//  section : themes, title_tagline, colors, header_image (only when enabled), background_image (only when enabled), static_front_page

		// Register custom control classes
		require_once( $theme_path . 'inc/admin/customizer/dp_customizer_control.php' );
		require_once( $theme_path . 'inc/admin/customizer/dp_customizer_textarea_control.php' );
		require_once( $theme_path . 'inc/admin/customizer/dp_customizer_range_control.php' );
		require_once( $theme_path . 'inc/admin/customizer/dp_customizer_custom_css_control.php' );
		require_once( $theme_path . 'inc/admin/customizer/dp_customizer_control_radio_image.php' );
		$wp_customize->register_control_type( 'DP_Customize_Control_Radio_Image' );
		// if ( version_compare( $wp_version, '4.9', '>=' ) ) {
		// 	require_once( $theme_path . 'inc/admin/customizer/dp_customizer_code_editor_control.php' );
		// 	$wp_customize->register_control_type( 'DP_Customize_Code_Editor_Control' );
		// }

		// ***********************
		// Remove default section
		// ***********************
		$wp_customize->remove_section('header_image');
		$wp_customize->remove_section('static_front_page');
		$wp_customize->remove_section('colors');
		$wp_customize->remove_section('background_image');
		$wp_customize->remove_section('custom_css');
		// ***********************
		// Customize default section
		// ***********************
		$wp_customize->get_section('title_tagline')->title = __('HTML Header and Meta', 'DigiPress');
		$wp_customize->get_section('title_tagline')->description = __('Customize the head section.', 'DigiPress');

		if ( get_option( DP_THEME_SLUG . '_license_key_status' ) !== 'valid' ){
			$wp_customize->add_section(
				'dp_activate_section', array(
				'priority' => 1,
				'title' => __('License Activation', 'DigiPress'),
				'description' => __('Please go to the license option and activate to customize this theme.', 'DigiPress'),
			));
			$wp_customize->add_setting(
				'activate_theme_license', array(
				'transport' => 'postMessage'
			));
			$wp_customize->add_control( new DP_Customize_Control(
				$wp_customize,
				'activate_theme_license', array(
				'before_text' => '<a href="themes.php?page='.DP_THEME_SLUG.'-license" class="button">'.__('Activate your license','DigiPress').'</a>',
				'section' => 'dp_activate_section',
				'type' => 'text'
				)
			));
			return;
		}
		/**
		 * Main Customizer Panels
		 */
		include_once( $theme_path . 'inc/admin/customizer/setting_general.php' );
		include_once( $theme_path . 'inc/admin/customizer/setting_mobile_theme.php' );
		include_once( $theme_path . 'inc/admin/customizer/setting_site_layout.php' );
		include_once( $theme_path . 'inc/admin/customizer/setting_html_header.php' );
		include_once( $theme_path . 'inc/admin/customizer/setting_header_bar_area.php' );
		include_once( $theme_path . 'inc/admin/customizer/setting_offcanvas_menu_area.php' );
		include_once( $theme_path . 'inc/admin/customizer/setting_header_area.php' );
		include_once( $theme_path . 'inc/admin/customizer/setting_top_page.php' );
		include_once( $theme_path . 'inc/admin/customizer/setting_archive_page.php' );
		include_once( $theme_path . 'inc/admin/customizer/setting_single_page.php' );
		include_once( $theme_path . 'inc/admin/customizer/setting_footer_area.php' );
		include_once( $theme_path . 'inc/admin/customizer/setting_sort.php' );
		include_once( $theme_path . 'inc/admin/customizer/setting_base_text.php' );
		include_once( $theme_path . 'inc/admin/customizer/setting_site_background.php' );
		include_once( $theme_path . 'inc/admin/customizer/setting_custom_css.php' );
		include_once( $theme_path . 'inc/admin/customizer/setting_backup_restore.php' );

		// Sanitize for HTML code value
		function dp_sanitize_html( $html ) {
			return stripslashes(wp_filter_post_kses( $html ));
		}

		// Sanitize float
		function dp_sanitize_float( $input ) {
			return filter_var($input, FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION);
		}
	}

	/**
     * Loads the jQuery UI Button script and custom scripts/styles.
     *
     * @since  1.0.0
     * @access public
     * @return void
     */
    public static function enqueue() {
    	// For widgets
    	wp_enqueue_style( 'wp-color-picker' );
		wp_enqueue_script( 'wp-color-picker' );
		wp_enqueue_style( 'dp_widgets_page', get_template_directory_uri() . '/inc/css/dp_widgets_page.css' );
		wp_enqueue_script( 'dp_widgets_page', get_template_directory_uri()."/inc/js/dp_widgets_page.min.js", array('jquery', 'wp-color-picker'), DP_OPTION_SPT_VERSION, true );
	    // For theme customizer
		wp_enqueue_style( 'dp_theme_customizer', get_template_directory_uri() . '/inc/css/dp_theme_customizer.css' );
		wp_enqueue_script( 'dp_theme_customizer', get_template_directory_uri() . '/inc/js/dp_theme_customizer.min.js', array('jquery'), DP_OPTION_SPT_VERSION, true );
		wp_enqueue_script( 'dp-customizer-controls', get_template_directory_uri() . '/inc/js/customizer-controls.min.js', array( 'jquery' ), DP_OPTION_SPT_VERSION, true );
	}

	/**
	* Hook: 'customize_preview_init'
	*
	* @see add_action('customize_preview_init',$func)
	*/
	public static function live_preview() {
		// Retrieve theme options for refreshing live preview
		dp_get_option();
		// CSS and js
		wp_enqueue_style( 'customizer_live_preview', get_template_directory_uri() . '/inc/css/live_preview.css' );
		wp_enqueue_script( 'customizer_live_preview', get_template_directory_uri() . '/inc/js/customizer_live_preview.min.js', array( 'jquery' ), DP_OPTION_SPT_VERSION, true );
	}

	/**
	 * Hook 'customize_save_after'
	 */
	public static function save($wp_customize){
		// Make directory if necessary
		dp_permission_check();
		// Export css file
		dp_css_create();

		// Clear all cache
		dp_Delete_All_Cache();
	}
}
// Queuing css and script
add_action('customize_controls_enqueue_scripts',array('DP_Theme_Customizer', 'enqueue'));
// Register customizer
add_action('customize_register',array('DP_Theme_Customizer', 'register'));
// Realtime preview in live preview
add_action('customize_preview_init', array('DP_Theme_Customizer', 'live_preview'));
// Customizer saving
add_action('customize_save_after', array('DP_Theme_Customizer', 'save'));