<?php
/**
 * Include each customize functions
 */
include_once(DP_THEME_DIR . "/inc/admin/extended/admin_enqueue.php");
include_once(DP_THEME_DIR . "/inc/admin/extended/custom_profile_fields.php");
include_once(DP_THEME_DIR . "/inc/admin/extended/custom_post_editor.php");
include_once(DP_THEME_DIR . "/inc/admin/extended/custom_post_list_fields.php");
include_once(DP_THEME_DIR . "/inc/admin/extended/custom_fields.php");
include_once(DP_THEME_DIR . "/inc/admin/extended/custom_fields_on_menu.php");
include_once(DP_THEME_DIR . "/inc/admin/extended/custom_category_tag_custom_fields.php");
include_once(DP_THEME_DIR . "/inc/admin/extended/upgrader_process_complete.php");