<div class="wrap">
<div id="dp_custom">
	<h1 class="icon-cogs"> <?php _e( 'Settings' ); ?></h1>
	<p class="ft12px"><?php echo DP_THEME_NAME . ' Ver.' . DP_OPTION_SPT_VERSION; ?></p><?php

	// if ( get_option( DP_THEME_SLUG . '_license_key_status' ) !== 'valid' ) return;?>
	<div class="mg30px-top mg40px-btm">
		<p class="description"><?php _e("To customize the theme, go to [ Appearance ] -> [ Customize ].", "DigiPress"); ?></p>
		<a href="customize.php?return=%2Fwp-admin%2Fadmin.php%3Fpage%3Ddigipress" class="button-primary"><?php _e( 'Open the customizer', 'DigiPress' ); ?></a>
	</div>

	<div class="dp_export_import mg30px-btm">
		<h2 class="icon-download"><?php _e("Backup / Restore", "DigiPress"); ?></h2>
		<p class="description"><?php _e("You can backup or restore all theme options in this function.", "DigiPress"); ?></p>
		<table class="form-table">
			<tbody>
			<tr>
			<th><?php _e("Backup :", "DigiPress"); ?></th>
			<td>
				<div class="dp_export_button">
				<form method='post'><?php
				wp_nonce_field('dp-export');
				submit_button(__('Backup all settings', 'DigiPress'), 'secondary', 'dp_export', false); ?>
				</form>
				</div>
			</td>
			</tr>
			<tr>
			<th><?php _e("Restore :", "DigiPress"); ?></th>
			<td>
				<form method='post' enctype='multipart/form-data'>
				<div class="dp_import_button mg10px-r"><?php
				wp_nonce_field('dp-import');
				_e("Select Upload File", "DigiPress"); ?>
				<input type='file' name='dp_import' onchange="dpuv.style.display='inline-block'; dpuv.value=this.value;" />
				<input type="text" id="dpuv" class="dp_import_btn_text" disabled />
				</div>
				<?php submit_button(__('Restore settings', 'DigiPress'), 'secondary', 'dp_import_submit', false); ?>
				</form>
			</td>
			</tr>
			</tbody>
		</table>
	</div>

	<div class="mg40px-btm">
		<h2 class="icon-trash-full"><?php _e( 'Clear the cache', 'DigiPress' ); ?></h2>
		<form method='post' class="mg15px-btm"><?php
		wp_nonce_field( 'dp-clear-all-cache' );
		$other_attributes = array( 'onclick' => "return confirm('".__('Clear all cache. Are you sure?','DigiPress')."')" );
		submit_button(__('Clear all cache', 'DigiPress'), 'delete', 'dp_clear_all_transient_cache', false, $other_attributes);?>
		</form>
		<p class="description"><?php _e("Delete all cache stored in the database created by the cache function.", "DigiPress"); ?></p>
	</div>

	<div class="mg40px-btm">
		<h2 class="icon-ccw"><?php _e('Reset all settings', 'DigiPress'); ?></h2>
		<form method='post'><?php
		wp_nonce_field('dp-reset');
		$other_attributes = array( 'onclick' => "return confirm('".__('Reset current all settings. Are you sure?','DigiPress')."')" );
		submit_button(__('Reset all settings', 'DigiPress'), 'delete', 'dp_reset_all_settings', false, $other_attributes);?>
		</form>
	</div>

</div>
<hr />
</div><?php // .wrap