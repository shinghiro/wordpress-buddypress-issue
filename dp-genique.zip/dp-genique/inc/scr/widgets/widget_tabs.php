<?php
/*******************************************************
* Tab widget
*******************************************************/
class DP_Tab_Widget extends WP_Widget {
	public function __construct() {
		$widget_opts = array('classname' => 'dp_tab_widget', 
							 'description' => __('Multi tab widget by DigiPress', 'DigiPress') );
		$control_opts = array('width' => 200, 'height' => 300);
		parent::__construct('DPTabWidget', __('Tab Widget', 'DigiPress'), $widget_opts, $control_opts);
	}

	// Input widget form in Admin panel.
	public function form($instance) {
		// default value
		$instance = wp_parse_args(
			(array)$instance,
			array(
				'title_new_post' => __('Recent Posts','DigiPress'),
				'title_most_viewed' => __('Popular Posts','DigiPress'),
				'title_random' => __('Random Posts','DigiPress'),
				'title_most_commented' => __('Most Commented Posts','DigiPress'),
				'title_category' => __('Category','DigiPress'),
				'title_tag_cloud' => __('Tag Cloud','DigiPress'),
				'title_recent_comment' => __('Recent Comment','DigiPress'),
				'title_archive' => __('Archive','DigiPress'),
				'wd_new_post' => true,
				'wd_category' => true,
				'wd_tag_cloud' => true,
				'wd_recent_comment' => false,
				'wd_archive' => false,
				'wd_most_viewed'=> false,
				'wd_most_commented'	=> false,
				'wd_random'	=> false,
				'first_open_tab' => 'recent',
				'ins_category_count' => 0,
				'ins_archive_count' => 0,
				'number' => 5,
				'title_length'=> 35,
				'cat'=> null,
				'target' => 'post_views_count',
				'thumbnail' => true,
				'rounded_thumb' => false,
				'comment'=> false,
				'views'=> false,
				'pub_date'	=> 'show',
				'last_update' => false,
				'hatebu_number' => false,
				'tweets_number' => false,
				'likes_number' => false,
				'disable_cache' => false,
		));

		$form_code = $term_code = $first_open_tab_code = '';

		// get values
		$title_new_post		= strip_tags($instance['title_new_post']);
		$title_category		= strip_tags($instance['title_category']);
		$title_tag_cloud		= strip_tags($instance['title_tag_cloud']);
		$title_most_viewed	= strip_tags($instance['title_most_viewed']);
		$title_recent_comment	= strip_tags($instance['title_recent_comment']);
		$title_most_commented	= strip_tags($instance['title_most_commented']);
		$title_random		= strip_tags($instance['title_random']);
		$title_archive		= strip_tags($instance['title_archive']);

		$wd_new_post			= $instance['wd_new_post'];
		$wd_category		= $instance['wd_category'];
		$wd_tag_cloud		= $instance['wd_tag_cloud'];
		$wd_most_viewed		= $instance['wd_most_viewed'];
		$wd_recent_comment	= $instance['wd_recent_comment'];
		$wd_most_commented		= $instance['wd_most_commented'];
		$wd_random			= $instance['wd_random'];
		$wd_archive			= $instance['wd_archive'];

		$number		= $instance['number'];
		$title_length		= $instance['title_length'];
		$thumbnail	= $instance['thumbnail'];
		$rounded_thumb	= $instance['rounded_thumb'];
		$comment	= $instance['comment'];
		$views		= $instance['views'];
		$pub_date 	= $instance['pub_date'];
		$last_update = $instance['last_update'];
		$hatebu_number = $instance['hatebu_number'];
		$tweets_number = $instance['tweets_number'];
		$likes_number = $instance['likes_number'];
		$cat		= $instance['cat'];
		$target 	 = $instance['target'];
		$first_open_tab 	= $instance['first_open_tab'];

		$disable_cache 	= $instance['disable_cache'];

		// instance
		$ins_category_count		= $instance['ins_category_count'];
		$ins_archive_count		= $instance['ins_archive_count'];

		// Get fields name and id
		$wd_new_post_name		= $this->get_field_name('wd_new_post');
		$wd_new_post_id			= $this->get_field_id('wd_new_post');
		$wd_category_name		= $this->get_field_name('wd_category');
		$wd_category_id			= $this->get_field_id('wd_category');
		$wd_tag_cloud_name		= $this->get_field_name('wd_tag_cloud');
		$wd_tag_cloud_id		= $this->get_field_id('wd_tag_cloud');
		$wd_most_viewed_name	= $this->get_field_name('wd_most_viewed');
		$wd_most_viewed_id		= $this->get_field_id('wd_most_viewed');
		$wd_most_commented_name	= $this->get_field_name('wd_most_commented');
		$wd_most_commented_id	= $this->get_field_id('wd_most_commented');
		$wd_random_name			= $this->get_field_name('wd_random');
		$wd_random_id			= $this->get_field_id('wd_random');
		$wd_recent_comment_name	= $this->get_field_name('wd_recent_comment');
		$wd_recent_comment_id	= $this->get_field_id('wd_recent_comment');
		$wd_archive_name		= $this->get_field_name('wd_archive');
		$wd_archive_id			= $this->get_field_id('wd_archive');

		$title_new_post_name		= $this->get_field_name('title_new_post');
		$title_new_post_id		= $this->get_field_id('title_new_post');
		$title_category_name	= $this->get_field_name('title_category');
		$title_category_id		= $this->get_field_id('title_category');
		$title_tag_cloud_name	= $this->get_field_name('title_tag_cloud');
		$title_tag_cloud_id		= $this->get_field_id('title_tag_cloud');
		$title_most_viewed_name	= $this->get_field_name('title_most_viewed');
		$title_most_viewed_id	= $this->get_field_id('title_most_viewed');
		$title_most_commented_name	= $this->get_field_name('title_most_commented');
		$title_most_commented_id	= $this->get_field_id('title_most_commented');
		$title_random_name		= $this->get_field_name('title_random');
		$title_random_id		= $this->get_field_id('title_random');
		$title_recent_comment_name	= $this->get_field_name('title_recent_comment');
		$title_recent_comment_id		= $this->get_field_id('title_recent_comment');
		$title_archive_name		= $this->get_field_name('title_archive');
		$title_archive_id		= $this->get_field_id('title_archive');

		$ins_category_count_name	= $this->get_field_name('ins_category_count');
		$ins_category_count_id		= $this->get_field_id('ins_category_count');
		$ins_archive_count_name		= $this->get_field_name('ins_archive_count');
		$ins_archive_count_id		= $this->get_field_id('ins_archive_count');

		$number_name	= $this->get_field_name('number');
		$number_id	= $this->get_field_id('number');
		$title_length_name	= $this->get_field_name('title_length');
		$title_length_id	= $this->get_field_id('title_length');
		$thumbnail_name	= $this->get_field_name('thumbnail');
		$thumbnail_id	= $this->get_field_id('thumbnail');
		$rounded_thumb_name	= $this->get_field_name('rounded_thumb');
		$rounded_thumb_id	= $this->get_field_id('rounded_thumb');
		$comment_name	= $this->get_field_name('comment');
		$comment_id		= $this->get_field_id('comment');
		$views_name		= $this->get_field_name('views');
		$views_id		= $this->get_field_id('views');
		$pub_date_name	= $this->get_field_name('pub_date');
		$pub_date_id	= $this->get_field_id('pub_date');
		$last_update_name	= $this->get_field_name('last_update');
		$last_update_id	= $this->get_field_id('last_update');
		$hatebu_number_name	= $this->get_field_name('hatebu_number');
		$tweets_number_name	= $this->get_field_name('tweets_number');
		$likes_number_name	= $this->get_field_name('likes_number');
		$hatebu_number_id = $this->get_field_id('hatebu_number');
		$tweets_number_id = $this->get_field_id('tweets_number');
		$likes_number_id = $this->get_field_id('likes_number');
		$cat_name		= $this->get_field_name('cat');
		$cat_id			= $this->get_field_id('cat');
		$target_name	= $this->get_field_name('target');
		$target_id		= $this->get_field_id('target');
		$first_open_tab_name	= $this->get_field_name('first_open_tab');
		$first_open_tab_id		= $this->get_field_id('first_open_tab');

		$disable_cache_name	= $this->get_field_name('disable_cache');
		$disable_cache_id		= $this->get_field_id('disable_cache');

		$wd_new_post_check = '';
		if ($wd_new_post) $wd_new_post_check = ' checked';
		$wd_category_check = '';
		if ($wd_category) $wd_category_check = ' checked';
		$wd_tag_cloud_check = '';
		if ($wd_tag_cloud) $wd_tag_cloud_check = ' checked';
		$wd_most_viewedCheck = '';
		if ($wd_most_viewed) $wd_most_viewedCheck = ' checked';
		$wd_most_commentedCheck = '';
		if ($wd_most_commented) $wd_most_commentedCheck = ' checked';
		$wd_random_check = '';
		if ($wd_random) $wd_random_check = ' checked';
		$wd_recent_commentCheck = '';
		if ($wd_recent_comment) $wd_recent_commentCheck = ' checked';
		$wd_archiveCheck = '';
		if ($wd_archive) $wd_archiveCheck = ' checked';
		$ins_category_countCheck = '';
		if ($ins_category_count == 1) $ins_category_countCheck = ' checked';
		$ins_archive_countCheck = '';
		if ($ins_archive_count == 1) $ins_archive_countCheck = ' checked';

		$thumb_check = '';
		if ($thumbnail) $thumb_check = ' checked';
		$comment_check = '';
		if ($comment) $comment_check = ' checked';
		$views_check = '';
		if ($views) $views_check = ' checked';
		$rounded_thumb_check = '';
		if ($rounded_thumb) $rounded_thumb_check = ' checked';
		$pub_date_check = '';
		if ($pub_date) $pub_date_check = ' checked';
		$last_update_check = '';
		if ($last_update) $last_update_check = ' checked';
		$hatebu_number_check = '';
		if ($hatebu_number) $hatebu_number_check = ' checked';

		$tweets_number_check = '';
		if ($tweets_number) $tweets_number_check = ' checked';

		$likes_number_check = '';
		if ($likes_number) $likes_number_check = ' checked';

		$disable_cache_check = '';
		if ( $disable_cache ) $disable_cache_check = ' checked';

		// First open tab
		$arr_open_tab = array(
			'recent' => __('Recent posts tab','DigiPress'),
			'most_viewed' => __('Most viewed posts tab','DigiPress'),
			'recent_comments' => __('Recent comments tab','DigiPress'),
			'most_commented' => __('Most commented tab','DigiPress'),
			'random_posts' => __('Random posts tab','DigiPress'),
			'category' => __('Categories tab','DigiPress'),
			'tags' => __('Tag cloud tab','DigiPress'),
			'archive' => __('Monthly archive tab','DigiPress')
		);
		foreach ($arr_open_tab as $key => $value) {
			if ($first_open_tab === $key) {
				$first_open_tab_code .= '<option value="'.$key.'" selected>'.__($value, 'DigiPress').'</option>';
			} else {
				$first_open_tab_code .= '<option value="'.$key.'">'.__($value, 'DigiPress').'</option>';
			}
		}
		$first_open_tab_code = '<div class="mg20px-btm"><div class="b mg5px-btm"><label for="'.$first_open_tab_id.'">'.__('First open tab', 'DigiPress').':</label></div><div class="mg15px-l"><select name="'.$first_open_tab_name.'" id="'.$first_open_tab_id.'">'.$first_open_tab_code.'</select></div></div>';

		// Show form
		$form_code = '<div class="pd20px-btm">';
		$form_code .= '<div class="mg20px-btm mg20px-top"><input name="'.$wd_new_post_name.'" id="'.$wd_new_post_id.'" type="checkbox" value="show" '.$wd_new_post_check.' /><label for="'.$wd_new_post_id.'" style="font-weight:bold;">'.__('Show recent posts.', 'DigiPress').'</label>';
		$form_code .= '<div style="margin:6px 0 0 15px;"><label for="'.$title_new_post_id.'">'.__('Title','DigiPress').':</label><br /><input type="text" name="'.$title_new_post_name.'" id="'.$title_new_post_id.'" value="'.$title_new_post.'" style="width:100%;" />
			 </div></div>';

		$form_code .= '<div class="mg20px-btm"><input name="'.$wd_most_viewed_name.'" id="'.$wd_most_viewed_id.'" type="checkbox" value="show" '.$wd_most_viewedCheck.' /><label for="'.$wd_most_viewed_id.'" style="font-weight:bold;">'.__('Show most viewed posts.', 'DigiPress').'</label>
			 <div style="margin:6px 0 6px 15px;"><label for="'.$title_most_viewed_id.'">'.__('Title','DigiPress').':</label><br /><input type="text" name="'.$title_most_viewed_name.'" id="'.$title_most_viewed_id.'" value="'.$title_most_viewed.'" style="width:100%;" />
			 </div>';

		// Do the custom function
		$term_code = apply_filters( 'dp_tab_widget_most_viewed_form', 
			array(
				'post',
				$target, 
				$target_name, 
				$target_id)
			);
		if (is_string($term_code)) {
			$form_code .= '<div style="margin-left:15px;">'.$term_code.'</div>';
		}

		$form_code .= '</div>';

		$form_code .= '<div class="mg20px-btm"><input name="'.$wd_recent_comment_name.'" id="'.$wd_recent_comment_id.'" type="checkbox" value="show" '.$wd_recent_commentCheck.' /><label for="'.$wd_recent_comment_id.'" style="font-weight:bold;">'.__('Show recent comments.', 'DigiPress').'</label>
			 <div style="margin:6px 0 6px 15px;"><label for="'.$title_recent_comment_id.'">'.__('Title','DigiPress').':</label><br /><input type="text" name="'.$title_recent_comment_name.'" id="'.$title_recent_comment_id.'" value="'.$title_recent_comment.'" style="width:100%;" />
			 </div></div>';

		$form_code .= '<div class="mg20px-btm"><input name="'.$wd_most_commented_name.'" id="'.$wd_most_commented_id.'" type="checkbox" value="show" '.$wd_most_commentedCheck.' /><label for="'.$wd_most_commented_id.'" style="font-weight:bold;">'.__('Show most commented posts.', 'DigiPress').'</label>
			 <div style="margin:6px 0 6px 15px;"><label for="'.$title_most_commented_id.'">'.__('Title','DigiPress').':</label><br /><input type="text" name="'.$title_most_commented_name.'" id="'.$title_most_commented_id.'" value="'.$title_most_commented.'" style="width:100%;" />
			 </div></div>';

		$form_code .= '<div class="mg20px-btm"><input name="'.$wd_random_name.'" id="'.$wd_random_id.'" type="checkbox" value="show"'.$wd_random_check.' /><label for="'.$wd_random_id.'" style="font-weight:bold;">'.__('Show random posts.', 'DigiPress').'</label>
			 <div style="margin:6px 0 6px 15px;"><label for="'.$title_random_id.'">'.__('Title','DigiPress').':</label><br /><input type="text" name="'.$title_random_name.'" id="'.$title_random_id.'" value="'.$title_random.'" style="width:100%;" />
			 </div></div>';

		$form_code .= '<div style="border:1px solid #ddd;margin:2px 0 2px 15px;padding:4px;-moz-border-radius:4px;-webkit-border-radius:4px;border-radius:4px;"><p style="font-weight:bold;">'.__('Display Option:', 'DigiPress').'</p>';
		$form_code .= '<p><label for="'.$number_id.'">'.__('Number to display','DigiPress').':</label>
			 <input type="number" name="'.$number_name.'" id="'.$number_id.'" min=1 value="'.$number.'" style="width:80px;" /></p>';
		$form_code .= '<p><label for="'.$title_length_id.'">'.__('Max title length','DigiPress').':</label>
			 <input type="number" name="'.$title_length_name.'" id="'.$title_length_id.'" min=1 value="'.$title_length.'" style="width:80px;" /></p>';
		$form_code .=  '<p><input name="'.$pub_date_name.'" id="'.$pub_date_id.'" type="checkbox" value="on"'.$pub_date_check.' /><label for="'.$pub_date_id.'">'.__('Show date','DigiPress').'</label></p>';
		$form_code .=  '<p><input name="'.$last_update_name.'" id="'.$last_update_id.'" type="checkbox" value="on"'.$last_update_check.' />
			 <label for="'.$last_update_id.'">'.__('Show last updated','DigiPress').'</label></p>';
		$form_code .=  '<p><input name="'.$thumbnail_name.'" id="'.$thumbnail_id.'" type="checkbox" value="on"'.$thumb_check.' /><label for="'.$thumbnail_id.'">'.__('Show Thumbnail','DigiPress').'</label></p>';
		$form_code .= '<p style="margin-left:15px;"><input name="'.$rounded_thumb_name.'" id="'.$rounded_thumb_id.'" type="checkbox" value="on" '.$rounded_thumb_check.' /><label for="'.$rounded_thumb_id.'">'.__('Rounded Thumbnail','DigiPress').'</label></p>';
		$form_code .= '<p><input name="'.$comment_name.'" id="'.$comment_id.'" type="checkbox" value="on"'.$comment_check.' /><label for="'.$comment_id.'">'.__('Show the comment number', 'DigiPress').'</label></p>';
		$form_code .= '<p><input name="'.$views_name.'" id="'.$views_id.'" type="checkbox" value="on"'.$views_check.' /><label for="'.$views_id.'">'.__('Show views.', 'DigiPress').'</label></p>';
		$form_code .= '<p><input name="'.$hatebu_number_name.'" id="'.$hatebu_number_id.'" type="checkbox" value="on"'.$hatebu_number_check.' /><label for="'.$hatebu_number_id.'">'.__('Show hatena bookmarked count', 'DigiPress').'</label></p>';
		$form_code .= '<p><input name="'.$tweets_number_name.'" id="'.$tweets_number_id.'" type="checkbox" value="on"'.$tweets_number_check.' /><label for="'.$tweets_number_id.'">'.__('Show tweeted count', 'DigiPress').'</label></p>';
		$form_code .= '<p><input name="'.$likes_number_name.'" id="'.$likes_number_id.'" type="checkbox" value="on"'.$likes_number_check.' /><label for="'.$likes_number_id.'">'.__('Show FB likes count', 'DigiPress').'</label></p>';
		$form_code .= '<p><label for="'.$cat_id.'">'.__('Target Category(Optional)','DigiPress').':</label><br />
			 <input type="text" name="'.$cat_name.'" id="'.$cat_id.'" value="'.$cat.'" style="width:100%;" /><br />
			 <span class="ft12px">'.__('*Note: Multiple categories are available.(ex. 2,4,12)', 'DigiPress').'</span></p>';
		$form_code .= '</div></div>';


		$form_code .= '<div style="margin-bottom:26px;"><input name="'.$wd_category_name.'" id="'.$wd_category_id.'" type="checkbox" value="show" '.$wd_category_check.' /><label for="'.$wd_category_id.'" style="font-weight:bold;">'.__('Show category.', 'DigiPress').'</label>
			 <div style="margin:6px 0 6px 15px;"><label for="'.$title_category_id.'">'.__('Title','DigiPress').':</label><br /><input type="text" name="'.$title_category_name.'" id="'.$title_category_id.'" value="'.$title_category.'" style="width:100%;" />';
		$form_code .= '<p style="padding-top:6px;"><input name="'.$ins_category_count_name.'" id="'.$ins_category_count_id.'" type="checkbox" value=1 '.$ins_category_countCheck.' /><label for="'.$ins_category_count_id.'">'.__('Show counts.', 'DigiPress').'</label></p></div></div>';

		$form_code .= '<div class="mg20px-btm"><input name="'.$wd_tag_cloud_name.'" id="'.$wd_tag_cloud_id.'" type="checkbox" value="show" '.$wd_tag_cloud_check.' /><label for="'.$wd_tag_cloud_id.'" style="font-weight:bold;">'.__('Show tag cloud.', 'DigiPress').'</label>
			 <div style="margin:6px 0 6px 15px;"><label for="'.$title_tag_cloud_id.'">'.__('Title','DigiPress').':</label><br /><input type="text" name="'.$title_tag_cloud_name.'" id="'.$title_tag_cloud_id.'" value="'.$title_tag_cloud.'" style="width:100%;" /></div></div>';

		$form_code .= '<div class="mg20px-btm"><input name="'.$wd_archive_name.'" id="'.$wd_archive_id.'" type="checkbox" value="show" '.$wd_archiveCheck.' /><label for="'.$wd_archive_id.'" style="font-weight:bold;">'.__('Show monthly archives.', 'DigiPress').'</label>
			 <div style="margin:6px 0 6px 15px;"><label for="'.$title_archive_id.'">'.__('Title','DigiPress').':</label><br /><input type="text" name="'.$title_archive_name.'" id="'.$title_archive_id.'" value="'.$title_archive.'" style="width:100%;" />';
		$form_code .= '<p style="padding-top:6px;"><input name="'.$ins_archive_count_name.'" id="'.$ins_archive_count_id.'" type="checkbox" value=1 '.$ins_archive_countCheck.' /><label for="'.$ins_archive_count_id.'">'.__('Show counts.', 'DigiPress').'</label></p></div></div>';
		$form_code .= $first_open_tab_code;

		$form_code .= '<hr /><p><input name="'.$disable_cache_name.'" id="'.$disable_cache_id.'" type="checkbox" value="on"'.$disable_cache_check.' /><label for="'.$disable_cache_id.'" class="b">'.__('Disable cache', 'DigiPress').'</label><br />
			<span class="ft12px">'.__('*Note: If the theme option cache function is enabled, check to not cache this widget.', 'DigiPress').'</span></p><hr />';

		// Display
		echo $form_code;
	}

	// Save Function
	// $new_instance : Input value
	// $old_instance : Exist value
	// Return : New values
	public function update($new_instance, $old_instance) {
		$instance['title_new_post']		= strip_tags($new_instance['title_new_post']);
		$instance['title_category']		= strip_tags($new_instance['title_category']);
		$instance['title_tag_cloud']		= strip_tags($new_instance['title_tag_cloud']);
		$instance['title_recent_comment']= strip_tags($new_instance['title_recent_comment']);
		$instance['title_archive']		= strip_tags($new_instance['title_archive']);
		$instance['title_most_viewed']		= strip_tags($new_instance['title_most_viewed']);
		$instance['title_most_commented']	= strip_tags($new_instance['title_most_commented']);
		$instance['title_random']			= strip_tags($new_instance['title_random']);
		$instance['wd_new_post']			= $new_instance['wd_new_post'];
		$instance['wd_category']		= $new_instance['wd_category'];
		$instance['wd_tag_cloud']		= $new_instance['wd_tag_cloud'];
		$instance['wd_recent_comment']	= $new_instance['wd_recent_comment'];
		$instance['wd_archive']			= $new_instance['wd_archive'];
		$instance['wd_most_viewed']		= $new_instance['wd_most_viewed'];
		$instance['wd_most_commented']	= $new_instance['wd_most_commented'];
		$instance['wd_random']			= $new_instance['wd_random'];
		$instance['ins_category_count']		= $new_instance['ins_category_count'];
		$instance['ins_archive_count']		= $new_instance['ins_archive_count'];
		$instance['number']		= $new_instance['number'];
		$instance['title_length']		= $new_instance['title_length'];
		$instance['thumbnail']	= $new_instance['thumbnail'];
		$instance['rounded_thumb']	= $new_instance['rounded_thumb'];
		$instance['comment']	= $new_instance['comment'];
		$instance['views']		= $new_instance['views'];
		$instance['pub_date']		= $new_instance['pub_date'];
		$instance['last_update']	= $new_instance['last_update'];
		$instance['hatebu_number']	= $new_instance['hatebu_number'];
		$instance['tweets_number']	= $new_instance['tweets_number'];
		$instance['likes_number']	= $new_instance['likes_number'];
		$instance['cat']		= $new_instance['cat'];
		$instance['target']			= $new_instance['target'];
		$instance['first_open_tab']		= $new_instance['first_open_tab'];
		$instance['disable_cache']		= $new_instance['disable_cache'];

		return $instance;
	}

	// Display to theme
	// $args : output array
	// $instance : exist array
	public function widget($args, $instance) {
		$instance = wp_parse_args(
			(array)$instance,
			array(
				'title_new_post' 		=> __('Recent Posts', 'DigiPress'),
				'title_category' 		=> __('Category', 'DigiPress'),
				'title_tag_cloud' 		=> __('Tag Cloud', 'DigiPress'),
				'title_recent_comment' => __('Recent Comments', 'DigiPress'),
				'title_archive' 		=> __('Archive', 'DigiPress'),
				'title_most_viewed' 	=> __('Popular Posts','DigiPress'),
				'title_random' 		=> __('Random Posts','DigiPress'),
				'title_most_commented'=> __('Most Commented Posts','DigiPress'), 
				'wd_new_post'		=> true,
				'wd_category'		=> true,
				'wd_tag_cloud'		=> true,
				'wd_recent_comment'=> false,
				'wd_archive'		=> false,
				'wd_most_viewed'	=> false,
				'wd_most_commented'	=> false,
				'wd_random'	=> false,
				'ins_category_count'	=> 0,
				'ins_archive_count'	=> 0,
				'number' => 5,
				'title_length' => 38,
				'target' => 'post_views_count',
				'first_open_tab'	=> 'recent',
				'thumbnail' => true,
				'rounded_thumb' => false,
				'cat'		=> null,
				'comment'	=> false,
				'views'	=> false,
				'pub_date'	=> true,
				'last_update'	=> false,
				'hatebu_number' => false,
				'tweets_number' => true,
				'likes_number' => true,
				'disable_cache' => false,
		));



		/**
		 * Check the transient data and return the cache if cache is exists
		 */
		if ( dp_is_enable_cache( array( 'target' => 'tab_widget' ) ) && !$instance['disable_cache'] ){
			$cache = get_transient( 'dp_wdt_' . $this->id );
			if ( $cache !== false ) {
				echo $cache;
				return;
			}
		}



		extract($args);

		$title_new_post = $instance['title_new_post'];
		$title_new_post = apply_filters('title_new_post', $title_new_post);
		$title_category = $instance['title_category'];
		$title_category = apply_filters('title_category', $title_category);
		$title_tag_cloud = $instance['title_tag_cloud'];
		$title_tag_cloud = apply_filters('title_tag_cloud', $title_tag_cloud);
		$title_recent_comment = $instance['title_recent_comment'];
		$title_recent_comment = apply_filters('title_recent_comment', $title_recent_comment);
		$title_archive = $instance['title_archive'];
		$title_archive = apply_filters('title_archive', $title_archive);
		$title_most_viewed = $instance['title_most_viewed'];
		$title_most_viewed = apply_filters('title_most_viewed', $title_most_viewed);
		$title_most_commented = $instance['title_most_commented'];
		$title_most_commented = apply_filters('title_most_commented', $title_most_commented);
		$title_random = $instance['title_random'];
		$title_random = apply_filters('title_random', $title_random);

		$wd_new_post 		= $instance['wd_new_post'];
		$wd_category 		= $instance['wd_category'];
		$wd_tag_cloud 		= $instance['wd_tag_cloud'];
		$wd_recent_comment 	= $instance['wd_recent_comment'];
		$wd_archive 		= $instance['wd_archive'];
		$wd_most_viewed 		= $instance['wd_most_viewed'];
		$wd_most_commented 		= $instance['wd_most_commented'];
		$wd_random 		= $instance['wd_random'];

		$ins_category_count		= $instance['ins_category_count'];
		$ins_archive_count		= $instance['ins_archive_count'];

		$number = $instance['number'];
		$title_length = $instance['title_length'];
		$thumbnail	= $instance['thumbnail'];
		$rounded_thumb	= $instance['rounded_thumb'];
		$comment	= $instance['comment'];
		$views		= $instance['views'];
		$pub_date	= $instance['pub_date'];
		$last_update = $instance['last_update'];
		$hatebu_number = $instance['hatebu_number'];
		$tweets_number = $instance['tweets_number'];
		$likes_number = $instance['likes_number'];
		$cat = $instance['cat'];
		$target = $instance['target'] ? $instance['target'] : 'post_views_count';
		$first_open_tab 	= $instance['first_open_tab'];


		$flag_first_tab 	= true;
		$first_tab			= 1;


		// classes
		$li_class = 'dp_tab_wd__title dp_role_tab_list__item';
		$btn_class = 'dp_tab_wd__btn dp_role_tab_list__btn';
		$panel_item_class = 'dp_role_tab_panels__item';

		// sprintf format
		$li_format = '<li class="%s" role="presentation"><button type="button" class="%s" role="tab" aria-controls="%s" aria-selected="';
		$panel_format = '<div class="%s" id="%s" aria-hidden="';


		// Widget params
		$ins_category_count = ($ins_category_count == 1) ? 1 : 0;
		$ins_archive_count = ($ins_archive_count == 1) ? 1 : 0; 

		$args = array(
			'before_title'	=> '',
			'after_title'	=> ''
			);
		$instanceCategory = array(
			'title'			=> ' ',
			'count'			=> $ins_category_count,
			'hierarchical'	=> 1,
			'dropdown'		=> 0
			);
		$instanceRecentComment = array(
			'title' 		=> ' ',
			'number' 		=> $number
			);
		$instanceTagCloud = array(
			'title'			=> ' ',
			'count'			=> 1
			);
		$instanceArchive = array(
			'title'			=> ' ',
			'count'			=> $ins_archive_count,
			'dropdown'		=> 1
			);


		// First open tab check
		if ($first_open_tab === 'most_viewed' && $wd_most_viewed) {
			$flag_first_tab = false;
			$first_tab = 2;
		} else if ($first_open_tab === 'recent_comments' && $wd_recent_comment) {
			$flag_first_tab = false;
			$first_tab = 3;
		} else if ($first_open_tab === 'most_commented' && $wd_most_commented) {
			$flag_first_tab = false;
			$first_tab = 4;
		} else if ($first_open_tab === 'random_posts' && $wd_random) {
			$flag_first_tab = false;
			$first_tab = 5;
		} else if ($first_open_tab === 'category' && $wd_category) {
			$flag_first_tab = false;
			$first_tab = 6;
		} else if ($first_open_tab === 'tags' && $wd_tag_cloud) {
			$flag_first_tab = false;
			$first_tab = 7;
		} else if ($first_open_tab === 'archive' && $wd_archive) {
			$flag_first_tab = false;
			$first_tab = 8;
		}

		// Display code
		$widget_code = $before_widget;

		// Tab list
		$widget_code .= '<div class="dp_tab_widget_ul_wrapper dp_role_tab_list_area"><ul class="dp_tab_widget_ul dp_role_tab_list" role="tablist">';
		if ( $wd_new_post ) {

			$widget_code .= sprintf(
				$li_format,
				$li_class,
				$btn_class,
				'new-' . $this->id
			);

			if ( $flag_first_tab ) {
				$widget_code .= 'true';
				$flag_first_tab = false;
				$first_tab = 1;
			} else {
				if ( $first_tab === 1 ){
					$widget_code .= 'true';
				} else {
					$widget_code .= 'false';
				}
			}

			$widget_code .= '"><span>';

			if ( $instance['title_new_post'] ) {
				$widget_code .= $title_new_post;
			} else {
				$widget_code .= __( 'Recent Posts', 'DigiPress' );
			}

			$widget_code .= '</span></button></li>';
		}

		if ( $wd_most_viewed ) {

			$widget_code .= sprintf(
				$li_format,
				$li_class,
				$btn_class,
				'popular-' . $this->id
			);

			if ( $flag_first_tab ) {
				$widget_code .= 'true';
				$flag_first_tab = false;
				$first_tab = 2;
			} else {
				if ( $first_tab === 2 ){
					$widget_code .= 'true';
				} else {
					$widget_code .= 'false';
				}
			}

			$widget_code .= '"><span>';

			if ( $instance['title_most_viewed'] ) {
				$widget_code .= $title_most_viewed;
			} else {
				$widget_code .= __( 'Popular Posts', 'DigiPress' );
			}

			$widget_code .= '</span></button></li>';
		}

		if ($wd_recent_comment) {

			$widget_code .= sprintf(
				$li_format,
				$li_class,
				$btn_class,
				'comment-' . $this->id
			);

			if ( $flag_first_tab ) {
				$widget_code .= 'true';
				$flag_first_tab = false;
				$first_tab = 3;
			} else {
				if ( $first_tab === 3 ){
					$widget_code .= 'true';
				} else {
					$widget_code .= 'false';
				}
			}

			$widget_code .= '"><span>';

			if ( $instance['title_recent_comment'] ) {
				$widget_code .= $title_recent_comment;
			} else {
				$widget_code .= __( 'Recent Comments', 'DigiPress' );
			}

			$widget_code .= '</span></button></li>';
		}

		if ($wd_most_commented) {

			$widget_code .= sprintf(
				$li_format,
				$li_class,
				$btn_class,
				'commented-' . $this->id
			);

			if ( $flag_first_tab ) {
				$widget_code .= 'true';
				$flag_first_tab = false;
				$first_tab = 4;
			} else {
				if ( $first_tab === 4 ){
					$widget_code .= 'true';
				} else {
					$widget_code .= 'false';
				}
			}

			$widget_code .= '"><span>';

			if ( $instance['title_most_commented'] ) {
				$widget_code .= $title_most_commented;
			} else {
				$widget_code .= __( 'Most Commented', 'DigiPress' );
			}

			$widget_code .= '</span></button></li>';
		}

		if ($wd_random) {

			$widget_code .= sprintf(
				$li_format,
				$li_class,
				$btn_class,
				'random-' . $this->id
			);

			if ( $flag_first_tab ) {
				$widget_code .= 'true';
				$flag_first_tab = false;
				$first_tab = 5;
			} else {
				if ( $first_tab === 5 ){
					$widget_code .= 'true';
				} else {
					$widget_code .= 'false';
				}
			}

			$widget_code .= '"><span>';

			if ( $instance['title_random'] ) {
				$widget_code .= $title_random;
			} else {
				$widget_code .= __( 'Pickup', 'DigiPress' );
			}

			$widget_code .= '</span></button></li>';
		}

		if ($wd_category) {

			$widget_code .= sprintf(
				$li_format,
				$li_class,
				$btn_class,
				'category-' . $this->id
			);

			if ( $flag_first_tab ) {
				$widget_code .= 'true';
				$flag_first_tab = false;
				$first_tab = 6;
			} else {
				if ( $first_tab === 6 ){
					$widget_code .= 'true';
				} else {
					$widget_code .= 'false';
				}
			}

			$widget_code .= '"><span>';

			if ( $instance['title_category'] ) {
				$widget_code .= $title_category;
			} else {
				$widget_code .= __( 'Category', 'DigiPress' );
			}

			$widget_code .= '</span></button></li>';
		}

		if ($wd_tag_cloud) {

			$widget_code .= sprintf(
				$li_format,
				$li_class,
				$btn_class,
				'tag-' . $this->id
			);

			if ( $flag_first_tab ) {
				$widget_code .= 'true';
				$flag_first_tab = false;
				$first_tab = 7;
			} else {
				if ( $first_tab === 7 ){
					$widget_code .= 'true';
				} else {
					$widget_code .= 'false';
				}
			}

			$widget_code .= '"><span>';

			if ( $instance['title_tag_cloud'] ) {
				$widget_code .= $title_tag_cloud;
			} else {
				$widget_code .= __( 'Tag Cloud', 'DigiPress' );
			}

			$widget_code .= '</span></button></li>';
		}

		if ($wd_archive) {

			$widget_code .= sprintf(
				$li_format,
				$li_class,
				$btn_class,
				'archive-' . $this->id
			);

			if ( $flag_first_tab ) {
				$widget_code .= 'true';
				$flag_first_tab = false;
				$first_tab = 8;
			} else {
				if ( $first_tab === 8 ){
					$widget_code .= 'true';
				} else {
					$widget_code .= 'false';
				}
			}

			$widget_code .= '"><span>';

			if ( $instance['title_archive'] ) {
				$widget_code .= $title_archive;
			} else {
				$widget_code .= __( 'Archive', 'DigiPress' );
			}

			$widget_code .= '</span></button></li>';
		}

		$widget_code .= '</ul><span class="dp_tab_sline"></span></div>';



		// Show Tab content
		$widget_code .= '<div class="dp_tab_contents dp_role_tab_panels">';

		// Recent Posts
		if ( $wd_new_post ) {

			$widget_code .= sprintf(
				$panel_format,
				$panel_item_class,
				'new-' . $this->id
			);

			if ( $first_tab === 1 ) {
				$widget_code .= 'false';
			} else {
				$widget_code .= 'true';
			}

			$widget_code .= '">';

			$order_by = 'post_date';
			$widget_code .= DP_GET_POSTS_BY_QUERY(array(
						'number'	=> $number,
						'title_length'	=> $title_length,
						'comment'	=> $comment,
						'views' 	=> $views,
						'pub_date'	=> $pub_date,
						'last_update' => $last_update,
						'thumbnail'	=> $thumbnail,
						'rounded_thumb' => $rounded_thumb,
						'hatebu_number'	=> $hatebu_number,
						'tweets_number'	=> $tweets_number,
						'likes_number'	=> $likes_number,
						'cat_id'	=> str_replace("\s", "", $cat),
						'order_by'	=> $order_by,
						'type'		=> 'tab',
						'return' => true
						)
			);
			$widget_code .= '</div>';
		}

		// Most viewed Posts
		if ($wd_most_viewed) {

			$widget_code .= sprintf(
				$panel_format,
				$panel_item_class,
				'popular-' . $this->id
			);

			if ( $first_tab === 2 ) {
				$widget_code .= 'false';
			} else {
				$widget_code .= 'true';
			}

			$widget_code .= '">';

			$order_by = 'meta_value_num';
			$widget_code .= DP_GET_POSTS_BY_QUERY(array(
					'number'	=> $number,
					'title_length'	=> $title_length,
					'comment'	=> $comment,
					'views' 	=> $views,
					'pub_date' 	=> $pub_date,
					'last_update' => $last_update,
					'thumbnail'	=> $thumbnail,
					'rounded_thumb' => $rounded_thumb,
					'hatebu_number'	=> $hatebu_number,
					'tweets_number'	=> $tweets_number,
					'likes_number'	=> $likes_number,
					'cat_id'	=> str_replace("\s", "", $cat),
					'meta_key'	=> $target,
					'order_by'	=> $order_by,
					'type'		=> 'tab',
					'return' => true
					)
		);
			$widget_code .= '</div>';
		}
		// Recent comment
		if ($wd_recent_comment) {

			$widget_code .= sprintf(
				$panel_format,
				$panel_item_class,
				'comment-' . $this->id
			);

			if ( $first_tab === 3 ) {
				$widget_code .= 'false';
			} else {
				$widget_code .= 'true';
			}

			$widget_code .= '">';

			ob_start();
			the_widget('DP_Widget_Recent_Comments', $instanceRecentComment, $args);
			$widget_code .= ob_get_contents();
		    ob_end_clean();

			$widget_code .= '</div>';
		}

		// Most Commented Posts
		if ($wd_most_commented) {

			$widget_code .= sprintf(
				$panel_format,
				$panel_item_class,
				'commented-' . $this->id
			);

			if ( $first_tab === 4 ) {
				$widget_code .= 'false';
			} else {
				$widget_code .= 'true';
			}

			$widget_code .= '">';

			$order_by = 'comment_count';
			$widget_code .= DP_GET_POSTS_BY_QUERY(array(
					'number'	=> $number,
					'title_length'	=> $title_length,
					'comment'	=> $comment,
					'views' 	=> $views,
					'pub_date' 	=> $pub_date,
					'last_update' => $last_update,
					'thumbnail'	=> $thumbnail,
					'rounded_thumb' => $rounded_thumb,
					'hatebu_number'	=> $hatebu_number,
					'tweets_number'	=> $tweets_number,
					'likes_number'	=> $likes_number,
					'cat_id'	=> str_replace("\s", "", $cat),
					'order_by'	=> $order_by,
					'type'		=> 'tab',
					'return' => true
					)
		);
			$widget_code .= '</div>';
		}

		// Random Posts
		if ($wd_random) {

			$widget_code .= sprintf(
				$panel_format,
				$panel_item_class,
				'random-' . $this->id
			);

			if ( $first_tab === 5 ) {
				$widget_code .= 'false';
			} else {
				$widget_code .= 'true';
			}

			$widget_code .= '">';

			$order_by = 'rand';
			$widget_code .= DP_GET_POSTS_BY_QUERY(array(
						'number'	=> $number,
						'title_length'	=> $title_length,
						'comment'	=> $comment,
						'views' 	=> $views,
						'pub_date' 	=> $pub_date,
						'last_update' => $last_update,
						'thumbnail'	=> $thumbnail,
						'rounded_thumb' => $rounded_thumb,
						'hatebu_number'	=> $hatebu_number,
						'tweets_number'	=> $tweets_number,
						'likes_number'	=> $likes_number,
						'cat_id'	=> str_replace("\s", "", $cat),
						'order_by'	=> $order_by,
						'type'		=> 'tab',
						'return' => true
						)
			);
			$widget_code .= '</div>';
		}

		if ($wd_category) {

			$cat_has_count = '';
			if ( $ins_category_count ) {
				$cat_has_count = ' cat-has-num';
			}

			$widget_code .= sprintf(
				$panel_format,
				$panel_item_class . $cat_has_count,
				'category-' . $this->id
			);

			if ( $first_tab === 6 ) {
				$widget_code .= 'false';
			} else {
				$widget_code .= 'true';
			}

			$widget_code .= '">';


			// Use extended original widget categories
			ob_start();
			the_widget('DP_Widget_Categories', $instanceCategory, $args);
			$widget_code .= ob_get_contents();
		    ob_end_clean();
			$widget_code .= '</div>';
		}

		if ($wd_tag_cloud) {

			$widget_code .= sprintf(
				$panel_format,
				$panel_item_class,
				'tag-' . $this->id
			);

			if ( $first_tab === 7 ) {
				$widget_code .= 'false';
			} else {
				$widget_code .= 'true';
			}

			$widget_code .= '">';


			ob_start();
			the_widget('DP_Widget_Tag_cloud', $instanceTagCloud, $args);
			$widget_code .= ob_get_contents();
		    ob_end_clean();

			$widget_code .= '</div>';
		}

		if ($wd_archive) {

			$widget_code .= sprintf(
				$panel_format,
				$panel_item_class,
				'archive-' . $this->id
			);

			if ( $first_tab === 8 ) {
				$widget_code .= 'false';
			} else {
				$widget_code .= 'true';
			}

			$widget_code .= '">';


			ob_start();
			the_widget('WP_Widget_Archives', $instanceArchive, $args);
			$widget_code .= ob_get_contents();
		    ob_end_clean();

			$widget_code .= '</div>';
		}
		$widget_code .= '</div>'.$after_widget;

		echo $widget_code;


		/**
		 * Save to cache
		 */
		if ( dp_is_enable_cache( array( 'target' => 'tab_widget' ) ) && !$instance['disable_cache'] ){
			set_transient( 'dp_wdt_' . $this->id, $widget_code, 0 );
		}
	}
}
// widgets_init
add_action('widgets_init', function(){register_widget('DP_Tab_Widget');});