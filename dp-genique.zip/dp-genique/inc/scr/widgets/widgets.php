<?php
/*******************************************************
* Sidebar widget
*******************************************************/
function dp_register_widget_area(){
	global $options;

	$wow_title_css 	= '';
	$wow_ft_title_css	= '';
	$mb_suffix			= '';
	if ((bool)is_mobile_dp()) {
		$mb_suffix = '_mobile';
	}
	if ( isset($options['disable_wow_js' . $mb_suffix] ) && !$options['disable_wow_js' . $mb_suffix] ){
		$wow_title_css 		= ' wow fadeInDown';
		$wow_ft_title_css	= ' wow fadeInDown';
	}

	$ft_col_num = isset( $options['footer_col_number'] ) && !empty( $options['footer_col_number'] ) ? $options['footer_col_number'] : 3;

	$slider_css = isset($options['disable_li_widget_acc']) && !empty($options['disable_li_widget_acc']) ? '' : ' slider_fx';

	register_sidebar(array(
			'name'		=> __('Sidebar', 'DigiPress'),
			'id'		=> 'sidebar',
			'before_widget'	=> '<div id="%1$s" class="widget-box %2$s' . $wow_title_css . $slider_css . '">',
			'after_widget'	=> '</div>',
			'before_title'	=> '<h2 class="wd-title"><span>',
			'after_title'	=> '</span></h2>'));

	// Sidebar 2
	if ($options['site_layout'] === 'sb-content-sb') {
		register_sidebar(array(
				'name'		=> __('Sidebar2', 'DigiPress'),
				'id'		=> 'sidebar2',
				'description'	=> __('Second sidebar for 3column.', 'DigiPress'),
				'before_widget'	=> '<div id="%1$s" class="widget-box %2$s' . $wow_title_css . $slider_css . '">',
				'after_widget'	=> '</div>',
				'before_title'	=> '<h2 class="wd-title"><span>',
				'after_title'	=> '</span></h2>'));
	}

	// Header banner
	register_sidebar(array(
			'name'		=> __('Top background image', 'DigiPress'),
			'id'		=> 'widget-on-top-banner',
			'description'	=> __('Widget area on background screen of front page.', 'DigiPress'),
			'before_widget'	=> '<div id="%1$s" class="widget-box %2$s' . $slider_css . '">',
			'after_widget'	=> '</div>',
			'before_title'	=> '<h3 class="inside-title"><span>',
			'after_title'	=> '</span></h3>'));

	// Top page container
	register_sidebar(array(
			'name'		=> __('Container top area', 'DigiPress'),
			'id'		=> 'widget-container-top',
			'description'	=> __('Between under header area and main content.', 'DigiPress'),
			'before_widget'	=> '<div id="%1$s" class="widget-box %2$s' . $slider_css . '">',
			'after_widget'	=> '</div>',
			'before_title'	=> '<h3 class="inside-title' . $wow_title_css . '"><span>',
			'after_title'	=> '</span></h3>'));

	// Top page content area
	register_sidebar(array(
			'name'		=> __('Content top area', 'DigiPress'),
			'id'		=> 'widget-content-top',
			'description'	=> __('Top area in main content.', 'DigiPress'),
			'before_widget'	=> '<div id="%1$s" class="widget-box %2$s' . $slider_css . '">',
			'after_widget'	=> '</div>',
			'before_title'	=> '<h3 class="inside-title' . $wow_title_css . '"><span>',
			'after_title'	=> '</span></h3>'));

	// Under post title
	register_sidebar(array(
			'name'		=> __('Under the post title', 'DigiPress'),
			'id'		=> 'widget-post-top',
			'before_widget'	=> '<div id="%1$s" class="widget-box %2$s' . $slider_css . '">',
			'after_widget'	=> '</div>',
			'before_title'	=> '<h3 class="inside-title' . $wow_title_css . '"><span>',
			'after_title'	=> '</span></h3>'));

	// Middle post
	register_sidebar(array(
			'name'		=> __('Middle of the post', 'DigiPress'),
			'id'		=> 'widget-post-middle',
			'before_widget'	=> '<div id="%1$s" class="widget-box %2$s">',
			'after_widget'	=> '</div>',
			'before_title'	=> '<h3 class="inside-title' . $wow_title_css . '"><span>',
			'after_title'	=> '</span></h3>'));

	// Last article content
	register_sidebar(array(
			'name'		=> __('Bottom of the post', 'DigiPress'),
			'id'		=> 'widget-post-bottom',
			'before_widget'	=> '<div id="%1$s" class="widget-box %2$s' . $slider_css . '">',
			'after_widget'	=> '</div>',
			'before_title'	=> '<h3 class="inside-title' . $wow_title_css . '"><span>',
			'after_title'	=> '</span></h3>'));

	// Top page content botom area
	register_sidebar(array(
			'name'		=> __('Content bottom area', 'DigiPress'),
			'id'		=> 'widget-content-bottom',
			'description'	=> __('Last area in main content.', 'DigiPress'),
			'before_widget'	=> '<div id="%1$s" class="widget-box %2$s' . $slider_css . '">',
			'after_widget'	=> '</div>',
			'before_title'	=> '<h3 class="inside-title' . $wow_title_css . '"><span>',
			'after_title'	=> '</span></h3>'));

	// Top page container botom area
	register_sidebar(array(
			'name'		=> __('Container footer area', 'DigiPress'),
			'id'		=> 'widget-container-bottom',
			'description'	=> __('Between under main content and footer area.', 'DigiPress'),
			'before_widget'	=> '<div id="%1$s" class="widget-box %2$s' . $slider_css . '">',
			'after_widget'	=> '</div>',
			'before_title'	=> '<h3 class="inside-title' . $wow_title_css . '"><span>',
			'after_title'	=> '</span></h3>'));

	register_sidebar(array(
			'name'		=> __('Footer Widget1', 'DigiPress'),
			'id'		=> 'footer-widget1',
			'before_widget'	=> '<div id="%1$s" class="widget-box %2$s' . $slider_css . '">',
			'after_widget'	=> '</div>',
			'before_title'	=> '<h2 class="wd-title' . $wow_ft_title_css . '"><span>',
			'after_title'	=> '</span></h2>'));

	if ( $ft_col_num != 1 ) {
		register_sidebar(array(
				'name'		=> __('Footer Widget2', 'DigiPress'),
				'id'		=> 'footer-widget2',
				'before_widget'	=> '<div id="%1$s" class="widget-box %2$s' . $slider_css . '">',
				'after_widget'	=> '</div>',
				'before_title'	=> '<h2 class="wd-title' . $wow_ft_title_css . '"><span>',
				'after_title'	=> '</span></h2>'));
	}

	if ( $ft_col_num == 4 || $ft_col_num == 3 ) {
		register_sidebar(array(
				'name'		=> __('Footer Widget3', 'DigiPress'),
				'id'		=> 'footer-widget3',
				'before_widget'	=> '<div id="%1$s" class="widget-box %2$s' . $slider_css . '">',
				'after_widget'	=> '</div>',
				'before_title'	=> '<h2 class="wd-title' . $wow_ft_title_css . '"><span>',
				'after_title'	=> '</span></h2>'));
	}

	if ( $ft_col_num == 4 ) {
		register_sidebar(array(
				'name'		=> __('Footer Widget4', 'DigiPress'),
				'id'		=> 'footer-widget4',
				'before_widget'	=> '<div id="%1$s" class="widget-box %2$s' . $slider_css . '">',
				'after_widget'	=> '</div>',
				'before_title'	=> '<h2 class="wd-title' . $wow_ft_title_css . '"><span>',
				'after_title'	=> '</span></h2>'));
	}

	// Top page container for mobile
	register_sidebar(array(
			'name'		=> __('Container top area(mobile)', 'DigiPress'),
			'id'		=> 'widget-container-top-mb',
			'description'	=> __('Between under header area and main content.', 'DigiPress'),
			'before_widget'	=> '<div id="%1$s" class="widget-box %2$s' . $slider_css . '">',
			'after_widget'	=> '</div>',
			'before_title'	=> '<h3 class="inside-title' . $wow_title_css . '"><span>',
			'after_title'	=> '</span></h3>'));

	// Under the post title space for mobile
	register_sidebar(array(
			'name'		=> __('Under the post title(mobile)', 'DigiPress'),
			'id'		=> 'widget-post-top-mb',
			'before_widget'	=> '<div id="%1$s" class="widget-box %2$s' . $slider_css . '">',
			'after_widget'	=> '</div>',
			'before_title'	=> '<h3 class="inside-title' . $wow_title_css . '"><span>',
			'after_title'	=> '</span></h3>'));

	// Middle post
	register_sidebar(array(
			'name'		=> __('Middle of the post(mobile)', 'DigiPress'),
			'id'		=> 'widget-post-middle-mb',
			'before_widget'	=> '<div id="%1$s" class="widget-box %2$s">',
			'after_widget'	=> '</div>',
			'before_title'	=> '<h3 class="inside-title' . $wow_title_css . '"><span>',
			'after_title'	=> '</span></h3>'));

	// Last post content for mobile
	register_sidebar(array(
			'name'		=> __('Bottom of the post(mobile)', 'DigiPress'),
			'id'		=> 'widget-post-bottom-mb',
			'before_widget'	=> '<div id="%1$s" class="widget-box %2$s' . $slider_css . '">',
			'after_widget'	=> '</div>',
			'before_title'	=> '<h3 class="inside-title' . $wow_title_css . '"><span>',
			'after_title'	=> '</span></h3>'));

	// Container footer widget for mobile
	register_sidebar(array(
			'name'		=> __('Container bottom(mobile)', 'DigiPress'),
			'id'		=> 'widget-container-bottom-mb',
			'description'	=> __('After main content area for mobile.', 'DigiPress'),
			'before_widget'	=> '<div id="%1$s" class="widget-box %2$s' . $slider_css . '">',
			'after_widget'	=> '</div>',
			'before_title'	=> '<h3 class="inside-title' . $wow_title_css . '"><span>',
			'after_title'	=> '</span></h3>'));

	// Site footer widget for mobile
	register_sidebar(array(
			'name'		=> __('Footer Widget(mobile)', 'DigiPress'),
			'id'		=> 'widget-footer-mb',
			'description'	=> __('Footer widget for mobile.', 'DigiPress'),
			'before_widget'	=> '<div id="%1$s" class="widget-box %2$s' . $slider_css . '">',
			'after_widget'	=> '</div>',
			'before_title'	=> '<h3 class="wd-title' . $wow_ft_title_css . '"><span>',
			'after_title'	=> '</span></h3>'));
}
add_action( 'widgets_init', 'dp_register_widget_area' );


/*******************************************************
* Get posts by get_posts Query
*******************************************************/
function DP_GET_POSTS_BY_QUERY( $args ) {

	global $options, $post, $IS_MOBILE_DP;

	// Defauls and parse params
	$args = wp_parse_args(
			(array)$args,
			array(
				'number' 	=> 5,
				'thumbnail'	=> true,
				'rounded_thumb' => false,
				'views'		=> false,
				'comment'	=> false,
				'order_by'	=> 'date',
				'order'		=> 'DESC',
				'hatebu_number'	=> false,
				'tweets_number'	=> false,
				'likes_number'	=> false,
				'cat_id'	=> '',
				'authors_id'=> '',
				'tag_slug' => '',
				'keyword' => '',
				'meta_key'	=> '',
				'meta_value' => '',
				'post_type'	=> 'post',
				'term'		=> '',
				'pub_date'	=> false,
				'last_update' => false,
				'type'		=> '',
				'more_text'	=> 'More',
				'more_url'	=> '',
				'voted_icon' => '',
				'voted_count' => false,
				'return'	=> false,
				'title_length' => 48,
				'month'		=> 0,
				'year'		=> 0,
	) );

	extract($args);

	// Params
	$meta_key = isset($meta_key) && !empty($meta_key) && $order_by === 'meta_value_num' ? $meta_key : '';

	$return_code = '';
	$counter = 0;
	$views_code = '';
	$thumb_class = '';
	$item_link_class = 'item-link';
	$thumb_link_class = 'thumb-link';


	// *********************
	// Date query
	// *********************
	$date_query = '';
	switch ( $term ) {
		case 'this week':
			$date_query = array(
				'before' => 'today +1 days',
				'after' => 'monday this week'
			);
			break;
		case 'last week':
			$date_query = array(
				'before' => 'monday this week',
				'after' => 'monday last week'
			);
			break;
		case 'last 7 days':
			$date_query = array(
				'before' => 'today +1 days',
				'after' => '-6 days'
			);
			break;
		case 'this month':
			$date_query = array(
				'before' => 'today +1 days',
				'after' => 'first day of this month'
			);
			break;
		case 'last month':
			$date_query = array(
				'before' => 'first day of this month',
				'after' => 'first day of previous month'
			);
			break;
		case 'last 30 days':
			$date_query = array(
				'before' => 'today +1 days',
				'after' => '-29 days'
			);
			break;
		case 'this year':
			$date_query = array(
				'before' => 'today +1 days',
				'after' => 'first day of January this year'
			);
			break;
		case 'last year':
			$date_query = array(
				'before' => 'first day of January this year',
				'after' => 'first day of January this year -1 years'
			);
			break;
	}

	// *********************
	// Category ID
	// *********************
	if ( !empty($post_type) && $post_type !== 'post' && $post_type !== 'page' ) {
		$cat_id = null;
	}

	// *********************
	// More link
	// *********************
	if ( !empty($more_text) ) {
		if ( empty($more_url) && ($type === 'recent' || $type === 'custom') ) {
			if ( $post_type === 'post' ) {
				if ($cat_id) {
					$arr_cat_id 	= explode(",", $cat_id);
					$more_url = get_category_link($arr_cat_id[0]);
				} else {
					if (is_home()) {
						$more_url = esc_url(get_pagenum_link(2));
					} else {
						// All posts and not home
						$more_url = home_url('/');
					}
				}
			} else {
				$more_url = get_post_type_archive_link($post_type);
			}
		}

		if ( !empty($more_url) ) {
			$more_url = '<div class="more-entry-link"><a href="' . $more_url . '"><span>' . $more_text . '</span></a></div>';
		}
	}

	// *********************
	// Main Query
	// *********************
	$posts = get_posts(array(
		'numberposts' => $number,
		'category' => $cat_id,
		'tag' => $tag_slug,
		'author' => $authors_id,
		's'	=> $keyword,
		'post_type' => $post_type,
		'meta_key' => $meta_key,
		'meta_value' => $meta_value,
		'orderby' => $order_by,
		'date_query' => array( $date_query ),
		'order' => $order,
		'monthnum' => $month,
		'year' => $year,
		)
	);

	$mobile_class = $IS_MOBILE_DP ? ' mobile': '';

	// Thumb check
	$width = null;
	$height = null;
	$if_img_tag = false;
	$thumb_class = ' no_thumb';
	$arg = null;
	if ((bool)$thumbnail) {
		$width = 120;
		$height = 80;
		$thumb_class = ' has_thumb';
		$arg = array("width"=>$width, "height"=>$height, "size"=>"dp-widget-thumb", "if_img_tag"=>$if_img_tag);
	}

	// ranking
	$rank_label_class = (bool)$voted_count ? ' has_rank' : '';

	// Rounded thumbnail
	$rounded_thumb = (bool)$rounded_thumb ? ' rounded' : '';

	// *****************
	// Display
	foreach( $posts as $post ) : setup_postdata($post);
		// reset
		$comment_code = '';
		$thumb_url = '';
		$thumb_code = '';
		$listStartCode = '';
		$ranking_code = '';
		$date_code = '';
		$sns_share_code = '';
		$item_list_code = '';
		$widget_meta_code = '';
		$voted_code = '';
		$voted_icon_class = '';

		// Anchor
		$post_url = get_the_permalink();

		// Ranking tag
		if (strpos($meta_key, 'post_views_count') !== false || $voted_count) {
			$counter++;
			$ranking_code = '<span class="rank_label ' . $thumb_class . '"> ' . $counter . '</span>';
		}

		// Voted count
		if ( $voted_count ) {
			$voted_icon = !empty($voted_icon) ? $voted_icon : 'icon-heart';
			$voted_code = get_post_meta(get_the_ID(), 'dp_ex_sr_votes_like_count', true);
			$voted_code = '<div class="voted"><i class="' . $voted_icon . '"></i><span class="share-num"> ' . $voted_code . '</span></div>';
		}


		// Post title
		$post_title =  the_title('', '', false) ? the_title('', '', false) : __('No Title', 'DigiPress');
		$post_title = (mb_strlen($post_title, 'utf-8') > $title_length) ? mb_substr($post_title, 0, $title_length, 'utf-8') . '...' : $post_title;
		$post_title = '<div class="excerpt_title_wid" role="heading"> ' . $post_title . '</div>';

		// Publish date
		if ( (bool)$pub_date && !get_post_meta(get_the_ID(), 'dp_hide_date', true) ) {
			if (isset($options['date_eng_mode']) && (bool)$options['date_eng_mode']) {
				$date_code = '<time datetime="' . get_the_date('c') . '">' . get_post_time('M' ) . ' ' . get_post_time('j' ) . ', ' . get_post_time('Y' ) . '</time>';
			} else {
				$date_code = '<time datetime="' . get_the_date('c') . '">' . get_the_date() . '</time>';
			}
		}
		// Last updated
		if ( (bool)$last_update && !get_post_meta(get_the_ID(), 'dp_hide_date', true) ) {
			if ( ( get_the_modified_date( 'U' ) > get_the_date( 'U' ) ) && get_the_modified_date() != get_the_date() ) {
				$date_code .=  '<span class="updated icon-update" content="' . get_the_modified_date('c') . '">' . get_the_modified_date() . '</span>';
			}
		}
		// Whole date code
		if (!empty($date_code)) {
			$date_code = '<div class="widget-time"> ' . $date_code . '</div>';
		}

		// Thumbnail
		if ($thumbnail) {
			$thumb_code = DP_Post_Thumbnail::get_post_thumbnail($arg);
			$thumb_code = '<div class="widget-post-thumb ' . $thumb_class.$rounded_thumb . '"><figure class="post-thumb"><img src="' . $thumb_code . '" alt="Thumbnail" width="120" height="80" class="thumb-img" /></figure></div>';
		}

		// Views
		if ( (bool)$views && function_exists('dp_get_post_views')) {
			$views_code = '<div class="meta-views widget-views">'.dp_get_post_views(get_the_ID(), $meta_key). ' views</div>';
		}

		// SNS share count
		if ($post_type === 'post') {
			if ( ! (isset($options['disable_sns_share_count']) && !empty($options['disable_sns_share_count'])) ){
				// Count Facebook Like
				if ( (bool)$likes_number ) {
					$sns_share_code = '<div class="bg-likes ct-fb"><i class="icon-facebook"></i><span class="share-num"></span></div>';
				}
				// Tweets
				if ( (bool)$tweets_number ) {
					$sns_share_code .= '<div class="bg-tweets ct-tw"><i class="icon-twitter"></i><span class="share-num"></span></div>';
				}
				// hatebu
				if ( (bool)$hatebu_number ) {
					$sns_share_code .= '<div class="bg-hatebu ct-hb"><i class="icon-hatebu"></i><span class="share-num"></span></div>';
				}
			}
			// Comments
			if ( ($post_type === 'post') && $comment && comments_open() ) {
				$sns_share_code .= '<div class="meta-comment"><i class="icon-comment"></i><span class="share-num">' . get_comments_number() . '</span></div>';
			}
			if (!empty($sns_share_code) || $voted_count) {
				$sns_share_code = '<div class="loop-share-num ct-shares" data-url="' . $post_url . '"> ' . $sns_share_code.$voted_code . '</div>';
			}
		}
		// Combine
		$item_list_code .=  '<li class="aitem ' . $rank_label_class . '"><a href="' . $post_url . '" class="' . $item_link_class . '"> ' . $thumb_code . '<div class="excerpt_div ' . $thumb_class . $rounded_thumb . '"> ' . $post_title.$date_code.$views_code . '</div> ' . $sns_share_code . $ranking_code . '</a></li>';

		$return_code .= $item_list_code;
	endforeach;
	// Reset Query
	wp_reset_postdata();

	// Code
	$return_code = '<ul class="recent_entries ' . $thumb_class . $mobile_class . '"> ' . $return_code . '</ul> ' . $more_url;

	if ((bool)$return) {
		return $return_code;
	} else {
		echo $return_code;
	}
}


/*******************************************************
* Search form widget
*******************************************************/
class DP_Widget_Search extends WP_Widget {
	public function __construct() {
		// widget actual processes
		$widget_ops = array(
						'classname' => 'dp_search_form',
						'description' => __( "A search form for your site.", 'DigiPress') );
		parent::__construct('DPWidgetSearch', __('Search Box for DigiPress', 'DigiPress'), $widget_ops);
	}
	public function form($instance) {
		// outputs the options form on admin
		$instance	= wp_parse_args( (array) $instance, array(
									'title'	=> '',
									'mode'		=> 'default',
									'param_cat' => false,
									'exclude_cat' => '',
									'exclude_tag' => '',
									'exclude_type' => '',
									'target_type' => '',
									'param_tag' => false,
									'param_type' => false,
									'param_range' => false,
									'param_word_area_title' => __('Search words', 'DigiPress'),
									'param_cat_area_title' => __('Category', 'DigiPress'),
									'param_tag_area_title' => __('Post tag', 'DigiPress'),
									'param_type_area_title' => __('Post type', 'DigiPress'),
									'param_range_area_title' => __('Date range', 'DigiPress'),
									'preset_phrase' => '',
									'preset_words' => ''
									  ) );

		$title		= $instance['title'];
		$mode		= $instance['mode'];
		$param_cat	= $instance['param_cat'];
		$exclude_cat= $instance['exclude_cat'];
		$exclude_tag= $instance['exclude_tag'];
		$exclude_type= $instance['exclude_type'];
		$target_type= $instance['target_type'];
		$param_tag	= $instance['param_tag'];
		$param_type	= $instance['param_type'];
		$param_range= $instance['param_range'];
		$preset_phrase	= $instance['preset_phrase'];
		$preset_words	= $instance['preset_words'];
		$param_word_area_title = $instance['param_word_area_title'];
		$param_cat_area_title = $instance['param_cat_area_title'];
		$param_tag_area_title = $instance['param_tag_area_title'];
		$param_type_area_title = $instance['param_type_area_title'];
		$param_range_area_title = $instance['param_range_area_title'];

		$title_name	= $this->get_field_name('title');
		$title_id	= $this->get_field_id('title');
		$mode_name	= $this->get_field_name('mode');
		$mode_id	= $this->get_field_id('mode');
		$param_cat_name	= $this->get_field_name('param_cat');
		$param_cat_id	= $this->get_field_id('param_cat');
		$exclude_cat_name	= $this->get_field_name('exclude_cat');
		$exclude_cat_id	= $this->get_field_id('exclude_cat');
		$exclude_tag_name	= $this->get_field_name('exclude_tag');
		$exclude_tag_id	= $this->get_field_id('exclude_tag');
		$exclude_type_name	= $this->get_field_name('exclude_type');
		$exclude_type_id	= $this->get_field_id('exclude_type');
		$target_type_name	= $this->get_field_name('target_type');
		$target_type_id	= $this->get_field_id('target_type');
		$param_tag_name	= $this->get_field_name('param_tag');
		$param_tag_id	= $this->get_field_id('param_tag');
		$param_type_name= $this->get_field_name('param_type');
		$param_type_id	= $this->get_field_id('param_type');
		$param_range_name= $this->get_field_name('param_range');
		$param_range_id	= $this->get_field_id('param_range');
		$preset_phrase_name= $this->get_field_name('preset_phrase');
		$preset_phrase_id	= $this->get_field_id('preset_phrase');
		$preset_words_name= $this->get_field_name('preset_words');
		$preset_words_id	= $this->get_field_id('preset_words');

		$param_word_area_title_name= $this->get_field_name('param_word_area_title');
		$param_word_area_title_id	= $this->get_field_id('param_word_area_title');
		$param_cat_area_title_name= $this->get_field_name('param_cat_area_title');
		$param_cat_area_title_id	= $this->get_field_id('param_cat_area_title');
		$param_tag_area_title_name= $this->get_field_name('param_tag_area_title');
		$param_tag_area_title_id	= $this->get_field_id('param_tag_area_title');
		$param_type_area_title_name= $this->get_field_name('param_type_area_title');
		$param_type_area_title_id	= $this->get_field_id('param_type_area_title');
		$param_range_area_title_name= $this->get_field_name('param_range_area_title');
		$param_range_area_title_id	= $this->get_field_id('param_range_area_title');

		$param_cat_check = $param_cat ? ' checked' : '';
		$param_tag_check = $param_tag ? ' checked' : '';
		$param_type_check = $param_type ? ' checked' : '';
		$param_range_check = $param_range ? ' checked' : '';

		$mode_check = ($mode === 'gcs') ? ' checked' : '';

		/**
		 * Config form
		 */
		$form = '<p><label for="' . $title_id . '">' . __('Title:', 'DigiPress' ) . '</label><input class="widefat" id="' . $title_id . '" name="' . $title_name . '" type="text" value="' . esc_attr($title) . '" /></p>';

		// defaut or google custom search?
		$form .= '<input name="' . $mode_name. '" id="' . $mode_id . '" type="checkbox" value="gcs" ' . $mode_check.' class="toggle_ele rev" /><label for="' . $mode_id . '">' . __('Use Google Custom Search', 'DigiPress' ) . '</label><p><span class="ft12px">' . __('You need access [General Settings]->[Google API Setting] panel to use Google Custom Search.','DigiPress') . '</span></p>';


		// Start toggle content
		$form .= '<div class="toggle_content"><hr />';


		// Target post type
		$form .= '<p><label for="' . $target_type_id . '">' . __('Search target', 'DigiPress' ) . ':</label>
<select id="' . $target_type_id . '" name="' . $target_type_name . '" class="widefat">
	<option value="any">' . __( 'All', 'DigiPress' ) . '</option>';

		if ( $target_type === 'post' ){
			$form .= '<option value="post" selected>' . __( 'Posts', 'DigiPress' ) . '</option>';
		} else {
			$form .= '<option value="post">' . __( 'Posts', 'DigiPress' ) . '</option>';
		}

		if ( $target_type === 'page' ){
			$form .= '<option value="page" selected>' . __( 'WordPress pages', 'DigiPress' ) . '</option>';
		} else {
			$form .= '<option value="page">' . __( 'WordPress pages', 'DigiPress' ) . '</option>';
		}

		// Custom post types
		$types = get_post_types(
			array(
				'public'	=> true,
				'_builtin'	=> false
			), 'objects');
		foreach ($types as $key => $cpt ) {
			if ( $target_type === $cpt->name ) {
				$form .= '<option value="' . $cpt->name . '" selected>' . esc_html($cpt->label) . '</option>';
			} else {
				$form .= '<option value="' . $cpt->name . '">' . esc_html($cpt->label) . '</option>';
			}
		}
		$form .=
'</select>
<span class="ft12px">' . __( '*You can filter the search to content of specific post type.', 'DigiPress' ) . __('If you allow the selection of target post types, those post types other than "All" take precedence.', 'DigiPress') . '</span></p>';

		// Search word area title
		$form .=
'<p><label for="' . $param_word_area_title_id . '">'.sprintf( __('%s area title', 'DigiPress'), __('Search words', 'DigiPress') ) . ':</label>
	<input class="widefat" id="' . $param_word_area_title_id . '" name="' . $param_word_area_title_name . '" type="text" value="' . esc_attr($param_word_area_title) . '" placeholder="' . __('Search words','DigiPress') . '" />
	<span class="ft12px">' . __( '*This title is not displayed when displaying only the search word text box.', 'DigiPress' ) . '</span></p>';

		// Preset area title
		$form .=
'<p><label for="' . $preset_phrase_id . '">'.sprintf( __('%s area title', 'DigiPress'), __('Preset search', 'DigiPress') ) . ':</label><input class="widefat" id="' . $preset_phrase_id . '" name="' . $preset_phrase_name . '" type="text" value="' . esc_attr($preset_phrase) . '" placeholder="' . __('Featured words','DigiPress') . '" /></p>';

		// Preset search words
		$form .=
'<p><label for="' . $preset_words_id . '">' . __('Preset search words', 'DigiPress' ) . ':</label>
	<input class="widefat" id="' . $preset_words_id . '" name="' . $preset_words_name . '" type="text" value="' . esc_attr($preset_words) . '" placeholder="' . __('WordPress,CSS','DigiPress') . '" /><br />
	<span class="ft12px">' . __( '* Please use comma for separate each keyword.', 'DigiPress' ) . '</span>
</p>';

		// post type
		$form .=
'<p><input name="' . $param_type_name. '" id="' . $param_type_id . '" class="toggle_ele" type="checkbox" value="true" ' . $param_type_check.' />
	<label for="' . $param_type_id . '">' . __('Allow users to select post type', 'DigiPress' ) . '</label>
	<span class="toggle_content pd5px-top pd10px-l">
		<label for="' . $param_type_area_title_id . '">'.sprintf( __('%s area title', 'DigiPress'), __('Post type', 'DigiPress') ) . '</label>
		<input class="widefat" id="' . $param_type_area_title_id . '" name="' . $param_type_area_title_name . '" type="text" value="' . esc_attr($param_type_area_title) . '" placeholder="'.sprintf( __('Target %s', 'DigiPress'), __('Post type', 'DigiPress') ) . '" />
		<label for="' . $exclude_type_id . '">'.sprintf( __('Exclude %s %s', 'DigiPress'), __('post type', 'DigiPress'), __('slug', 'DigiPress') ) . '</label>
		<input class="widefat" id="' . $exclude_type_id . '" name="' . $exclude_type_name . '" type="text" value="' . esc_attr($exclude_type) . '" placeholder="news,product,forum,review" /><br />
		<span class="ft12px">' .sprintf( __( '*If you set multiple %s, please separate the %s with comma.', 'DigiPress' ), __('post type', 'DigiPress'), __('slug', 'DigiPress') ) . '</span>
	</span>
</p>';

		// Category
		$form .=
'<p><input name="' . $param_cat_name. '" id="' . $param_cat_id . '" class="toggle_ele" type="checkbox" value="true" ' . $param_cat_check.' />
	<label for="' . $param_cat_id . '">' . __('Allow users to select a category', 'DigiPress' ) . '</label>
	<span class="toggle_content pd5px-top pd10px-l">
		<label for="' . $param_cat_area_title_id . '">'.sprintf( __('%s area title', 'DigiPress'), __('Category', 'DigiPress') ) . '</label>
		<input class="widefat" id="' . $param_cat_area_title_id . '" name="' . $param_cat_area_title_name . '" type="text" value="' . esc_attr($param_cat_area_title) . '" placeholder="'.sprintf( __('Target %s', 'DigiPress'), __('category', 'DigiPress') ) . '" />
		<label for="' . $exclude_cat_id . '">'.sprintf( __('Exclude %s %s', 'DigiPress'), __('category', 'DigiPress'), 'ID' ) . '</label>
		<input class="widefat" id="' . $exclude_cat_id . '" name="' . $exclude_cat_name . '" type="text" value="' . esc_attr($exclude_cat) . '" placeholder="1,10,24" /><br />
		<span class="ft12px">' .sprintf( __( '*If you set multiple %s, please separate the %s with comma.', 'DigiPress' ), __('categories', 'DigiPress'), 'ID' ) . '</span>
	</span>
</p>';

		// Tag
		$form .=
'<p><input name="' . $param_tag_name. '" id="' . $param_tag_id . '" class="toggle_ele" type="checkbox" value="true" ' . $param_tag_check.' />
	<label for="' . $param_tag_id . '">' . __('Allow users to select tags', 'DigiPress' ) . '</label>
	<span class="toggle_content pd5px-top pd10px-l">
		<label for="' . $param_tag_area_title_id . '">'.sprintf( __('%s area title', 'DigiPress'), __('Post tag', 'DigiPress') ) . '</label>
		<input class="widefat" id="' . $param_tag_area_title_id . '" name="' . $param_tag_area_title_name . '" type="text" value="' . esc_attr($param_tag_area_title) . '" placeholder="'.sprintf( __('Target %s', 'DigiPress'), __('post tag', 'DigiPress') ) . '" />
		<label for="' . $exclude_tag_id . '">'.sprintf( __('Exclude %s %s', 'DigiPress'), __('post tag', 'DigiPress'), 'ID' ) . '</label>
		<input class="widefat" id="' . $exclude_tag_id . '" name="' . $exclude_tag_name . '" type="text" value="' . esc_attr($exclude_tag) . '" placeholder="1,10,24" /><br />
		<span class="ft12px">' .sprintf( __( '*If you set multiple %s, please separate the %s with comma.', 'DigiPress' ), __('post tags', 'DigiPress'), 'ID' ) . '</span>
	</span>
</p>';

		// Search range
		$form .=
'<p><input name="' . $param_range_name. '" id="' . $param_range_id . '" class="toggle_ele" type="checkbox" value="true" ' . $param_range_check.' />
	<label for="' . $param_range_id . '">' . __('Allow users to select date range', 'DigiPress' ) . '</label>
	<span class="toggle_content pd5px-top pd10px-l">
		<label for="' . $param_range_area_title_id . '">'.sprintf( __('%s area title', 'DigiPress'), __('Search range', 'DigiPress') ) . '</label>
		<input class="widefat" id="' . $param_range_area_title_id . '" name="' . $param_range_area_title_name . '" type="text" value="' . esc_attr($param_range_area_title) . '" placeholder="'.sprintf( __('Target %s', 'DigiPress'), __('Date range', 'DigiPress') ) . '" />
	</span>
</p>';

		// End of toggle content
		$form .= '</div>';

		echo $form;
	}

	public function update($new_instance, $old_instance) {
		// processes widget options to be saved
		$instance = $old_instance;
		$new_instance = wp_parse_args((array) $new_instance, array( 'title' => ''));
		$instance['mode']	= $new_instance['mode'];
		$instance['param_cat']	= $new_instance['param_cat'];
		$instance['exclude_cat']= $new_instance['exclude_cat'];
		$instance['exclude_tag']= $new_instance['exclude_tag'];
		$instance['exclude_type']= $new_instance['exclude_type'];
		$instance['target_type']	= $new_instance['target_type'];
		$instance['param_tag']	= $new_instance['param_tag'];
		$instance['param_type']	= $new_instance['param_type'];
		$instance['param_range']	= $new_instance['param_range'];
		$instance['param_word_area_title']	= $new_instance['param_word_area_title'];
		$instance['param_cat_area_title']	= $new_instance['param_cat_area_title'];
		$instance['param_tag_area_title']	= $new_instance['param_tag_area_title'];
		$instance['param_type_area_title']	= $new_instance['param_type_area_title'];
		$instance['param_range_area_title']	= $new_instance['param_range_area_title'];
		$instance['title']	= htmlspecialchars(stripslashes($new_instance['title']));
		$instance['preset_phrase']	= htmlspecialchars(stripslashes($new_instance['preset_phrase']));
		$instance['preset_words']	= htmlspecialchars(stripslashes($new_instance['preset_words']));
		return $instance;
	}

	public function widget($args, $instance) {
		// outputs the content of the widget
		extract($args);
		$instance = wp_parse_args((array)$instance, array(
			'title' => '',
			'mode' => '',
			'param_cat' => false,
			'exclude_cat' => '',
			'exclude_tag' => '',
			'exclude_type' => '',
			'target_type' => false,
			'param_tag' => false,
			'param_type' => false,
			'param_range' => false,
			'param_word_area_title' => __('Search words', 'DigiPress'),
			'param_cat_area_title' => __('Category', 'DigiPress'),
			'param_tag_area_title' => __('Post tag', 'DigiPress'),
			'param_type_area_title' => __('Post type', 'DigiPress'),
			'param_range_area_title' => __('Date range', 'DigiPress'),
			'preset_phrase' => '',
			'preset_words' => ''
		));

		// $form = $preset_form = $kw_title = $kw_submit_btn = $current_post_type = $current_cat = $current_range = '';
		// $current_tags = array();
		// $form_class = 'search-form';

		$form = '';

		$title = apply_filters('widget_title', $instance['title'], $instance, $this->id_base);
		$title = htmlspecialchars_decode($title);

		/**
		 * Search form
		 */
		if ( $instance['mode'] !== 'gcs' ) {
			// Original form
			$form = dp_custom_search_form(false, array(
					'param_cat' => $instance['param_cat'],
					'exclude_cat' => $instance['exclude_cat'],
					'exclude_tag' => $instance['exclude_tag'],
					'exclude_type' => $instance['exclude_type'],
					'target_type' => $instance['target_type'],
					'param_tag' => $instance['param_tag'],
					'param_type' => $instance['param_type'],
					'param_range' => $instance['param_range'],
					'param_word_area_title' => $instance['param_word_area_title'],
					'param_cat_area_title' => $instance['param_cat_area_title'],
					'param_tag_area_title' => $instance['param_tag_area_title'],
					'param_type_area_title' => $instance['param_type_area_title'],
					'param_range_area_title' => $instance['param_range_area_title'],
					'preset_phrase' => $instance['preset_phrase'],
					'preset_words' => $instance['preset_words'],
					'show_input_title' => true )
				);
		}

		// Show form
		echo $before_widget;
		if ( $title ) echo $before_title . $title . $after_title;

		if ( $instance['mode'] === 'gcs' ) {
			echo "<gcse:searchbox-only></gcse:searchbox-only>";
		} else {
			echo $form;
		}
		echo $after_widget;
	}
}
// register DP_Widget_Search widget
add_action('widgets_init', function(){register_widget('DP_Widget_Search');});


/*******************************************************
* Recent Posts widget
*******************************************************/
class DP_RecentPosts_Widget extends WP_Widget {
	public function __construct() {
		$widget_opts = array('classname' => 'dp_recent_posts_widget', 
							 'description' => __('Enhanced Recent Posts widget provided by DigiPress', 'DigiPress') );
		$control_opts = array('width' => 200, 'height' => 300);
		parent::__construct('DPRecentPostsWidget', __('Custom Recent Posts', 'DigiPress'), $widget_opts, $control_opts);
	}

	// Input widget form in Admin panel.
	public function form($instance) {
		$orderby_form = '';
		$arr_orderby = array(
				'date',
				'modified',
				'comment_count',
				'ID',
				'rand',
				'author');

		// default value
		$instance = wp_parse_args(
			(array)$instance,
			array(
				'title' => __('Recent Posts','DigiPress'), 
				'number' => 5,
				'title_length' => 48,
				'post_type' => 'post',
				'cat'		=> null,
				'tag' => null,
				'authors' => null,
				'keyword' => null,
				'thumbnail' => true,
				'rounded_thumb' => false,
				'comment'	=> false,
				'views'	=> false,
				'order_by'	=> 'date',
				'pub_date'	=> 'show',
				'last_update' => false,
				'hatebu_number' => false,
				'tweets_number' => false,
				'likes_number' => false,
				'more_text'	=> 'More',
				'more_url'	=> '',
				'disable_cache' => false,
			));

		// get values
		$title		= strip_tags($instance['title']);
		$number		= $instance['number'];
		$title_length= $instance['title_length'];
		$post_type		= $instance['post_type'];
		$thumbnail	= $instance['thumbnail'];
		$rounded_thumb	= $instance['rounded_thumb'];
		$comment	= $instance['comment'];
		$views		= $instance['views'];
		$hatebu_number = $instance['hatebu_number'];
		$tweets_number = $instance['tweets_number'];
		$likes_number = $instance['likes_number'];
		$cat		= $instance['cat'];
		$tag	= $instance['tag'];
		$authors	= $instance['authors'];
		$keyword	= $instance['keyword'];
		$orderby 	= $instance['order_by'];
		$pub_date 	= $instance['pub_date'];
		$last_update = $instance['last_update'];
		$more_text 	= $instance['more_text'];
		$more_url 	= $instance['more_url'];
		$disable_cache 	= $instance['disable_cache'];

		$title_name	= $this->get_field_name('title');
		$title_id	= $this->get_field_id('title');
		$number_name	= $this->get_field_name('number');
		$number_id	= $this->get_field_id('number');
		$title_length_name	= $this->get_field_name('title_length');
		$title_length_id	= $this->get_field_id('title_length');
		$post_type_name	= $this->get_field_name('post_type');
		$post_type_id	= $this->get_field_id('post_type');
		$thumbnail_name	= $this->get_field_name('thumbnail');
		$thumbnail_id	= $this->get_field_id('thumbnail');
		$rounded_thumb_name	= $this->get_field_name('rounded_thumb');
		$rounded_thumb_id	= $this->get_field_id('rounded_thumb');
		$comment_name	= $this->get_field_name('comment');
		$comment_id		= $this->get_field_id('comment');
		$views_name		= $this->get_field_name('views');
		$views_id		= $this->get_field_id('views');
		$cat_name		= $this->get_field_name('cat');
		$cat_id			= $this->get_field_id('cat');
		$authors_name	= $this->get_field_name('authors');
		$authors_id		= $this->get_field_id('authors');
		$tag_name	= $this->get_field_name('tag');
		$tag_id		= $this->get_field_id('tag');
		$keyword_name	= $this->get_field_name('keyword');
		$keyword_id		= $this->get_field_id('keyword');
		$orderby_name	= $this->get_field_name('order_by');
		$orderby_id = $this->get_field_id('order_by');
		$hatebu_number_name	= $this->get_field_name('hatebu_number');
		$tweets_number_name	= $this->get_field_name('tweets_number');
		$likes_number_name	= $this->get_field_name('likes_number');
		$hatebu_number_id = $this->get_field_id('hatebu_number');
		$tweets_number_id = $this->get_field_id('tweets_number');
		$likes_number_id = $this->get_field_id('likes_number');
		$pub_date_name	= $this->get_field_name('pub_date');
		$pub_date_id	= $this->get_field_id('pub_date');
		$last_update_name	= $this->get_field_name('last_update');
		$last_update_id	= $this->get_field_id('last_update');
		$more_text_name	= $this->get_field_name('more_text');
		$more_text_id	= $this->get_field_id('more_text');
		$more_url_name	= $this->get_field_name('more_url');
		$more_url_id	= $this->get_field_id('more_url');
		$disable_cache_name	= $this->get_field_name('disable_cache');
		$disable_cache_id	= $this->get_field_id('disable_cache');


		$thumb_check = '';
		if ($thumbnail) $thumb_check = ' checked';

		$comment_check = '';
		if ($comment) $comment_check = ' checked';

		$views_check = '';
		if ($views) $views_check = ' checked';

		$rounded_thumb_check = '';
		if ($rounded_thumb) $rounded_thumb_check = ' checked';

		$hatebu_number_check = '';
		if ($hatebu_number) $hatebu_number_check = ' checked';

		$tweets_number_check = '';
		if ($tweets_number) $tweets_number_check = ' checked';

		$likes_number_check = '';
		if ($likes_number) $likes_number_check = ' checked';

		$pub_date_check = '';
		if ($pub_date === 'show') $pub_date_check = ' checked';

		$last_update_check = '';
		if ($last_update) $last_update_check = ' checked';

		$disable_cache_check = '';
		if ($disable_cache) $disable_cache_check = ' checked';

		// Order by
		foreach ($arr_orderby as $val) {
			if ($val === $orderby) {
				$orderby_form .= '<option value="' . $val . '" selected>' . __($val,'DigiPress' ) . '</option>';
			} else {
				$orderby_form .= '<option value="' . $val . '">' . __($val,'DigiPress' ) . '</option>';
			}
		}

		// Custom Post type
		$all_custom_post_types = get_post_types(
					array(
						'public'	=> true,
						'_builtin'	=> false
					), 'objects');
		$form_post_type_code = ($post_type === 'post') ? '<option value="post" selected>' . __('Posts', 'default' ) . '</option>' : '<option value="post">' . __('Posts', 'default' ) . '</option>';
		foreach ($all_custom_post_types as $cpt ) {
			if ($post_type === $cpt->name) {
				$form_post_type_code .= '<option value="' . $cpt->name . '" selected> ' . $cpt->label.'</option>';
			} else {
				$form_post_type_code .= '<option value="' . $cpt->name . '"> ' . $cpt->label.'</option>';
			}
		}
		$form_post_type_code = '<select name="' . $post_type_name . '" id="' . $post_type_id . '"> ' . $form_post_type_code . '</select>';

		// Show form
		$form_code = '<p><label for="' . $title_id . '">' . __('Title','DigiPress' ) . ':</label><br /><input type="text" name="' . $title_name . '" id="' . $title_id . '" value="' . $title . '" style="width:100%;" /></p>';
		$form_code .= '<p><label for="' . $number_id . '">' . __('Number to display','DigiPress' ) . ':</label>
			 <input type="number" name="' . $number_name . '" id="' . $number_id . '" min=1 value="' . $number . '" style="width:80px;" /></p>';
		$form_code .= '<p><label for="' . $title_length_id . '">' . __('Max title length','DigiPress' ) . ':</label>
			 <input type="number" name="' . $title_length_name . '" id="' . $title_length_id . '" min=1 value="' . $title_length . '" style="width:80px;" /></p>';
		$form_code .= '<p><label for="' . $post_type_id . '">' . __('Target post type','DigiPress' ) . ' :</label>  ' . $form_post_type_code . '</p>';
		$form_code .= '<p><label for="' . $orderby_id . '">' . __('Order by','DigiPress' ) . ' :</label> <select id="' . $orderby_id . '" name="' . $orderby_name . '" size=1 style="min-width:50%;"> ' . $orderby_form.'</select></p>';
		$form_code .= '<p><input name="' . $thumbnail_name . '" id="' . $thumbnail_id . '" type="checkbox" value="on" ' . $thumb_check.' /><label for="' . $thumbnail_id . '">' . __('Show Thumbnail','DigiPress' ) . '</label></p>';
		$form_code .= '<p style="margin-left:15px;"><input name="' . $rounded_thumb_name . '" id="' . $rounded_thumb_id . '" type="checkbox" value="on"  ' . $rounded_thumb_check.' /><label for="' . $rounded_thumb_id . '">' . __('Rounded Thumbnail','DigiPress' ) . '</label></p>';
		$form_code .= '<p><input name="' . $pub_date_name . '" id="' . $pub_date_id . '" type="checkbox" value="show" ' . $pub_date_check.' /><label for="' . $pub_date_id . '">' . __('Show date','DigiPress' ) . '</label></p>';
		$form_code .= '<p><input name="' . $last_update_name . '" id="' . $last_update_id . '" type="checkbox" value="show" ' . $last_update_check.' /> <label for="' . $last_update_id . '">' . __('Show last updated','DigiPress' ) . '</label></p>';
		$form_code .= '<p><input name="' . $comment_name . '" id="' . $comment_id . '" type="checkbox" value="on" ' . $comment_check.' /><label for="' . $comment_id . '">' . __('Show the comment number', 'DigiPress' ) . '</label></p>';
		$form_code .= '<p><input name="' . $views_name . '" id="' . $views_id . '" type="checkbox" value="on" ' . $views_check.' /><label for="' . $views_id . '">' . __('Show views.', 'DigiPress' ) . '</label></p>';
		$form_code .= '<p><input name="' . $likes_number_name . '" id="' . $likes_number_id . '" type="checkbox" value="on" ' . $likes_number_check.' /><label for="' . $likes_number_id . '">' . __('Show FB likes count', 'DigiPress' ) . '</label></p>';
		$form_code .= '<p><input name="' . $tweets_number_name . '" id="' . $tweets_number_id . '" type="checkbox" value="on" ' . $tweets_number_check.' /><label for="' . $tweets_number_id . '">' . __('Show tweeted count', 'DigiPress' ) . '</label></p>';
		$form_code .= '<p><input name="' . $hatebu_number_name . '" id="' . $hatebu_number_id . '" type="checkbox" value="on" ' . $hatebu_number_check.' /><label for="' . $hatebu_number_id . '">' . __('Show hatena bookmarked count', 'DigiPress' ) . '</label></p>';
		$form_code .= '<p><label for="' . $more_text_id . '">' . __('Show more label','DigiPress' ) . ':</label><br /><input type="text" name="' . $more_text_name . '" id="' . $more_text_id . '" value="' . $more_text . '" style="width:100%;" /></p>';
		$form_code .= '<p><label for="' . $more_url_id . '">' . __('Show more label URL','DigiPress' ) . ':</label><br /><input type="text" name="' . $more_url_name . '" id="' . $more_url_id . '" value="' . $more_url . '" style="width:100%;" /><br /><span class="ft12px">' . __('*Note: If the URL is empty, the URL determined by the theme will be set.', 'DigiPress' ) . '</span></p>';
		$form_code .= '<p><label for="' . $cat_id . '">' . __('Target Category(Optional)','DigiPress' ) . ':</label><br />
			 <input type="text" name="' . $cat_name . '" id="' . $cat_id . '" value="' . $cat . '" style="width:100%;" /><br />
			 <span class="ft12px">' . __('*Note: Multiple categories are available.(ex. 2,4,12)', 'DigiPress' ) . '</span></p>';
		$form_code .= '<p><label for="' . $tag_id . '">' . __('Target Tag\'s Slug(Optional)','DigiPress' ) . ':</label><br />
			 <input type="text" name="' . $tag_name . '" id="' . $tag_id . '" value="' . $tag . '" style="width:100%;" /><br />
			 <span class="ft12px">' . __('*Note: Multiple tags are available.(ex. bread,baking)', 'DigiPress' ) . '</span></p>';
		$form_code .= '<p><label for="' . $authors_id . '">' . __('Target Author\'s ID(Optional)','DigiPress' ) . ':</label><br />
			 <input type="text" name="' . $authors_name . '" id="' . $authors_id . '" value="' . $authors . '" style="width:100%;" /><br />
			 <span class="ft12px">' . __('*Note: Multiple authors are available.(ex. 2,6)', 'DigiPress' ) . '</span></p>';
		$form_code .= '<p><label for="' . $keyword_id . '">' . __('Search word(Optional)','DigiPress' ) . ':</label><br />
			 <input type="text" name="' . $keyword_name . '" id="' . $keyword_id . '" value="' . $keyword . '" style="width:100%;" /><br />
			 <span class="ft12px">' . __('*Note: Insert the seach words to get related posts of the specific words.', 'DigiPress' ) . '</span></p>';

		$form_code .= '<hr /><p><input name="' . $disable_cache_name . '" id="' . $disable_cache_id . '" type="checkbox" value="on" ' . $disable_cache_check.' /><label for="' . $disable_cache_id . '" class="b">' . __('Disable cache', 'DigiPress' ) . '</label><br />
			<span class="ft12px">' . __('*Note: If the theme option cache function is enabled, check to not cache this widget.', 'DigiPress' ) . '</span></p><hr />';

		// Display
		echo $form_code;
	}

	// Save Function
	// $new_instance : Input value
	// $old_instance : Exist value
	// Return : New values
	public function update($new_instance, $old_instance) {
		$instance['title']		= htmlspecialchars(stripslashes($new_instance['title']));
		$instance['number']		= $new_instance['number'];
		$instance['title_length']		= $new_instance['title_length'];
		$instance['post_type']		= $new_instance['post_type'];
		$instance['thumbnail']	= $new_instance['thumbnail'];
		$instance['rounded_thumb']	= $new_instance['rounded_thumb'];
		$instance['comment']	= $new_instance['comment'];
		$instance['views']		= $new_instance['views'];
		$instance['cat']		= $new_instance['cat'];
		$instance['authors']	= $new_instance['authors'];
		$instance['tag']	= $new_instance['tag'];
		$instance['keyword']	= $new_instance['keyword'];
		$instance['order_by']	= $new_instance['order_by'];
		$instance['hatebu_number']	= $new_instance['hatebu_number'];
		$instance['tweets_number']	= $new_instance['tweets_number'];
		$instance['likes_number']	= $new_instance['likes_number'];
		$instance['pub_date']	= $new_instance['pub_date'];
		$instance['last_update'] = $new_instance['last_update'];
		$instance['more_text']	= $new_instance['more_text'];
		$instance['more_url']	= $new_instance['more_url'];
		$instance['disable_cache']	= $new_instance['disable_cache'];

		// Check errors
		if (!$instance['title']) {
			$before_title 	= '';
			$after_title	= '';
			/*$instance['title'] = strip_tags($old_instance['title']);
			$this->m_error = '<span style="color:#ff0000;">' . __('The title is blank. It will be reset to old value.', 'DigiPress' ) . '</span>';*/
		}
		return $instance;
	}

	// Display to theme
	// $args : output array
	// $instance : exist array
	public function widget($args, $instance) {
		$instance = wp_parse_args(
			(array)$instance,
			array(
				'title' => '',
				'number' => 5,
				'title_length' => 48,
				'post_type' => 5,
				'thumbnail' => true,
				'rounded_thumb' => false,
				'comment'	=> false,
				'views'	=> false,
				'cat'		=> null,
				'tag'		=> null,
				'authors'	=> null,
				'keyword' => null,
				'order_by'	=> 'date',
				'pub_date'	=> 'show',
				'last_update' => false,
				'hatebu_number' => false,
				'tweets_number' => false,
				'likes_number' => false,
				'more_text'	=> 'More',
				'more_url'	=> '',
				'disable_cache' => false,
		));


		/**
		 * Check the transient data and return the cache if cache is exists
		 */
		if ( dp_is_enable_cache( array( 'target' => 'recent_posts_widget' ) ) && !$instance['disable_cache'] ){
			$cache = get_transient( 'dp_wdt_' . $this->id );

			if ( $cache !== false ) {
				echo $cache;
				return;
			}
		}


		extract($args);

		$title = $instance['title'];
		$title = apply_filters('widget_title', $title);
		$title = htmlspecialchars_decode($title);
		$number = $instance['number'];
		$title_length = $instance['title_length'];
		$post_type = $instance['post_type'];
		$thumbnail	= $instance['thumbnail'];
		$rounded_thumb	= $instance['rounded_thumb'];
		$comment	= $instance['comment'];
		$views		= $instance['views'];
		$cat		= $instance['cat'];
		$tag		= $instance['tag'];
		$authors	= $instance['authors'];
		$keyword	= $instance['keyword'];
		$hatebu_number = $instance['hatebu_number'];
		$tweets_number = $instance['tweets_number'];
		$likes_number = $instance['likes_number'];
		$orderby	= $instance['order_by'];
		$pub_date 	= $instance['pub_date'];
		$last_update = $instance['last_update'];
		$more_text 	= $instance['more_text'];
		$more_url 	= $instance['more_url'];


		// Display widget
		$widget_code = $before_widget;

		if ( $instance['title']) {
			$widget_code .= $before_title.$title.$after_title;
		}

		$widget_code .= DP_GET_POSTS_BY_QUERY(array(
					'number'	=> $number,
					'title_length'	=> $title_length,
					'post_type'	=> $post_type,
					'comment'	=> $comment,
					'views' 	=> $views,
					'thumbnail'	=> $thumbnail,
					'rounded_thumb' => $rounded_thumb,
					'cat_id'	=> str_replace("\s", "", $cat),
					'tag_slug'	=> str_replace("\s", "", $tag),
					'authors_id'=> str_replace("\s", "", $authors),
					'keyword'=> $keyword,
					'order_by'	=> $orderby,
					'hatebu_number'	=> $hatebu_number,
					'tweets_number'	=> $tweets_number,
					'likes_number'	=> $likes_number,
					'pub_date'	=> $pub_date,
					'last_update' => $last_update,
					'more_text'	=> $more_text,
					'more_url'	=> $more_url,
					'type'		=> 'recent',
					'return' => true
					)
		);
		$widget_code .= $after_widget;

		echo $widget_code;


		/**
		 * Save to cache
		 */
		if ( dp_is_enable_cache( array( 'target' => 'recent_posts_widget' ) ) && !$instance['disable_cache'] ){
			set_transient( 'dp_wdt_' . $this->id, $widget_code, 0 );
		}
	}
}
// widgets_init
add_action('widgets_init', function(){register_widget('DP_RecentPosts_Widget');});


/*******************************************************
* Recent Custom Post Type's post widget
*******************************************************/
class DP_RecentCustomPosts_Widget extends WP_Widget {
	public function __construct() {
		$widget_opts = array('classname' => 'dp_recent_custom_posts_widget', 
							 'description' => __('Recent Posts in specific Custom Post Type widget provided by DigiPress', 'DigiPress') );
		$control_opts = array('width' => 200, 'height' => 300);
		parent::__construct('DPRecentCustomPostsWidget', __('Recent post in Custom Post Type', 'DigiPress'), $widget_opts, $control_opts);
	}

	// Input widget form in Admin panel.
	public function form($instance) {
		// default value
		$instance = wp_parse_args(
			(array)$instance,
			array(
				'title'		=> __('News','DigiPress'), 
				'target'		=> '',
				'number'		=> 5,
				'title_length'=> 35,
				'random'		=> false,
				'views'		=> false,
				'pub_date'	=> 'show',
				'last_update' => false,
				'thumbnail'	=> true,
				'rounded_thumb' => false,
				'meta_key' 	=> 'post_views_count',
				'ranking'		=> false,
				'more_text'	=> 'More',
				'more_url'	=> '',
				'disable_cache' => false,
		));

		$term_code = '';
		$form_post_type_code = '';
		$form_code = '';

		// get values
		$title		= strip_tags($instance['title']);
		$target		= $instance['target'];
		$number		= $instance['number'];
		$title_length= $instance['title_length'];
		$pub_date	= $instance['pub_date'];
		$last_update = $instance['last_update'];
		$thumbnail	= $instance['thumbnail'];
		$rounded_thumb	= $instance['rounded_thumb'];
		$random		= $instance['random'];
		$more_text 	= $instance['more_text'];
		$more_url 	= $instance['more_url'];
		$views 		= $instance['views'];
		$meta_key 	= $instance['meta_key'];
		$ranking 	= $instance['ranking'];
		$disable_cache 	= $instance['disable_cache'];

		$title_name			= $this->get_field_name('title');
		$title_id			= $this->get_field_id('title');
		$target_name		= $this->get_field_name('target');
		$target_id			= $this->get_field_id('target');
		$number_name			= $this->get_field_name('number');
		$number_id			= $this->get_field_id('number');
		$title_length_name	= $this->get_field_name('title_length');
		$title_length_id	= $this->get_field_id('title_length');
		$pub_date_name		= $this->get_field_name('pub_date');
		$pub_date_id		= $this->get_field_id('pub_date');
		$last_update_name	= $this->get_field_name('last_update');
		$last_update_id	= $this->get_field_id('last_update');
		$thumbnail_name		= $this->get_field_name('thumbnail');
		$thumbnail_id		= $this->get_field_id('thumbnail');
		$rounded_thumb_name	= $this->get_field_name('rounded_thumb');
		$rounded_thumb_id	= $this->get_field_id('rounded_thumb');
		$randomName			= $this->get_field_name('random');
		$randomId			= $this->get_field_id('random');
		$more_text_name		= $this->get_field_name('more_text');
		$more_text_id		= $this->get_field_id('more_text');
		$more_url_name		= $this->get_field_name('more_url');
		$more_url_id		= $this->get_field_id('more_url');
		$views_name			= $this->get_field_name('views');
		$views_id			= $this->get_field_id('views');
		$meta_key_name		= $this->get_field_name('meta_key');
		$meta_key_id		= $this->get_field_id('meta_key');
		$ranking_name		= $this->get_field_name('ranking');
		$ranking_id			= $this->get_field_id('ranking');
		$disable_cache_name		= $this->get_field_name('disable_cache');
		$disable_cache_id			= $this->get_field_id('disable_cache');

		$pub_date_check = '';
		if ($pub_date === 'show') $pub_date_check = ' checked';

		$last_update_check = '';
		if ($last_update) $last_update_check = ' checked';

		$thumb_check = '';
		if ($thumbnail) $thumb_check = ' checked';

		$random_check = '';
		if ($random) $random_check = ' checked';

		$views_check = '';
		if ($views) $views_check = ' checked';

		$rounded_thumb_check = '';
		if ($rounded_thumb) $rounded_thumb_check = ' checked';

		$disable_cache_check = '';
		if ($disable_cache) $disable_cache_check = ' checked';

		// Post type
		$post_types = get_post_types(
								array(
									'public'	=> true,
									'_builtin'	=> false),
									'objects'
									);
		foreach ($post_types as $post_type ) {
			if ($target === $post_type->name) {
				$form_post_type_code .= '<option value="' . $post_type->name . '" selected>' . $post_type->label . '</option>';
			} else {
				$form_post_type_code .= '<option value="' . $post_type->name . '">' . $post_type->label . '</option>';
			}
		}
		$form_post_type_code = '<select name="' . $target_name . '" id="' . $target_id . '"> ' . $form_post_type_code . '</select>';


		// Show form
		$form_code = '<p><label for="' . $title_id . '">' . __('Title','DigiPress' ) . ':</label><br />';
		$form_code .= '<input type="text" name="' . $title_name . '" id="' . $title_id . '" value="' . $title . '" style="width:100%;" /></p>';

		$form_code .= '<div style="margin-bottom:8px;"><div style="padding-bottom:6px;">' . __('Target Custom Post Type:', 'DigiPress') . '</div> ' . $form_post_type_code . '</div>';

		// Do the custom function
		$term_code = apply_filters( 'dp_custom_post_widget_form', 
			array(
				'custom',
				$meta_key, 
				$meta_key_name, 
				$meta_key_id,
				$ranking,
				$ranking_name,
				$ranking_id)
			);
		if (is_string($term_code)) {
			$form_code .= $term_code;
		}

		$form_code .= '<p><label for="' . $number_id . '">' . __('Number to display','DigiPress' ) . ':</label>
			 <input type="number" name="' . $number_name . '" id="' . $number_id . '" min=1 value="' . $number . '" style="width:80px;" /></p>';
		$form_code .= '<p><label for="' . $title_length_id . '">' . __('Max title length','DigiPress' ) . ':</label>
			 <input type="number" name="' . $title_length_name . '" id="' . $title_length_id . '" min=1 value="' . $title_length . '" style="width:80px;" /></p>';
		$form_code .= '<p><input name="' . $pub_date_name . '" id="' . $pub_date_id . '" type="checkbox" value="show" ' . $pub_date_check.' /> <label for="' . $pub_date_id . '">' . __('Show date','DigiPress' ) . '</label></p>';
		$form_code .= '<p><input name="' . $last_update_name . '" id="' . $last_update_id . '" type="checkbox" value="show" ' . $last_update_check.' />
			 <label for="' . $last_update_id . '">' . __('Show last updated','DigiPress' ) . '</label></p>';
		$form_code .= '<p><input name="' . $thumbnail_name . '" id="' . $thumbnail_id . '" type="checkbox" value="on" ' . $thumb_check.' /> <label for="' . $thumbnail_id . '">' . __('Show Thumbnail','DigiPress' ) . '</label></p>';
		$form_code .= '<p style="margin-left:15px;"><input name="' . $rounded_thumb_name . '" id="' . $rounded_thumb_id . '" type="checkbox" value="on"  ' . $rounded_thumb_check.' /><label for="' . $rounded_thumb_id . '">' . __('Rounded Thumbnail','DigiPress' ) . '</label></p>';
		$form_code .= '<p><input name="' . $views_name . '" id="' . $views_id . '" type="checkbox" value="on" ' . $views_check.' /> <label for="' . $views_id . '">' . __('Show views.', 'DigiPress' ) . '</label></p>';
		$form_code .= '<p><input name="' . $randomName . '" id="' . $randomId . '" type="checkbox" value="on"  ' . $random_check.' /> <label for="' . $randomId . '">' . __('Random','DigiPress' ) . '</label></p>';
		$form_code .= '<p><label for="' . $more_text_id . '">' . __('Show more label','DigiPress' ) . ':</label><br /><input type="text" name="' . $more_text_name . '" id="' . $more_text_id . '" value="' . $more_text . '" style="width:100%;" /></p>';
		$form_code .= '<p><label for="' . $more_url_id . '">' . __('Show more label URL','DigiPress' ) . ':</label><br /><input type="text" name="' . $more_url_name . '" id="' . $more_url_id . '" value="' . $more_url . '" style="width:100%;" /><br /><span class="ft12px">' . __('*Note: If the URL is empty, the URL determined by the theme will be set.', 'DigiPress' ) . '</span></p>';
		$form_code .= '<hr /><p><input name="' . $disable_cache_name . '" id="' . $disable_cache_id . '" type="checkbox" value="on" ' . $disable_cache_check.' /><label for="' . $disable_cache_id . '" class="b">' . __('Disable cache', 'DigiPress' ) . '</label><br />
			<span class="ft12px">' . __('*Note: If the theme option cache function is enabled, check to not cache this widget.', 'DigiPress' ) . '</span></p><hr />';

		// Display
		echo $form_code;
	}

	// Save Function
	// $new_instance : Input value
	// $old_instance : Exist value
	// Return : New values
	public function update($new_instance, $old_instance) {
		$instance['title']		= htmlspecialchars(stripslashes($new_instance['title']));
		$instance['target']		= $new_instance['target'];
		$instance['number']		= $new_instance['number'];
		$instance['title_length']		= $new_instance['title_length'];
		$instance['pub_date']	= $new_instance['pub_date'];
		$instance['last_update'] = $new_instance['last_update'];
		$instance['thumbnail']	= $new_instance['thumbnail'];
		$instance['rounded_thumb']	= $new_instance['rounded_thumb'];
		$instance['random']		= $new_instance['random'];
		$instance['more_text']	= $new_instance['more_text'];
		$instance['more_url']	= $new_instance['more_url'];
		$instance['views']		= $new_instance['views'];
		$instance['meta_key']	= $new_instance['meta_key'];
		$instance['ranking']	= $new_instance['ranking'];
		$instance['disable_cache']	= $new_instance['disable_cache'];

		// Check errors
		if (!$instance['title']) {
			$before_title 	= '';
			$after_title	= '';
			/*$instance['title'] = strip_tags($old_instance['title']);
			$this->m_error = '<span style="color:#ff0000;">' . __('The title is blank. It will be reset to old value.', 'DigiPress' ) . '</span>';*/
		}
		return $instance;
	}

	// Display to theme
	// $args : output array
	// $instance : exist array
	public function widget($args, $instance) {
		$instance = wp_parse_args(
			(array)$instance,
			array(
				'title' 		=> '',
				'target'		=> '',
				'number' 		=> 5,
				'title_length'=> 35,
				'meta_key' 	=> 'post_views_count',
				'pub_date'	=> 'show',
				'last_update' => false,
				'thumbnail' 	=> true,
				'rounded_thumb' => false,
				'views'		=> false,
				'random'		=> false,
				'ranking'		=> false,
				'more_text'	=> 'More',
				'more_url'	=> '',
				'disable_cache' => false,
		));


		/**
		 * Check the transient data and return the cache if cache is exists
		 */
		if ( dp_is_enable_cache( array( 'target' => 'recent_custom_posts_widget' ) ) && !$instance['disable_cache'] ){
			$cache = get_transient( 'dp_wdt_' . $this->id );
			if ( $cache !== false ) {
				echo $cache;
				return;
			}
		}


		extract($args);

		$title = $instance['title'];
		$title = apply_filters('widget_title', $title);
		$title = htmlspecialchars_decode($title);
		$target = $instance['target'];
		$number = $instance['number'];
		$title_length = $instance['title_length'];
		$pub_date 	= $instance['pub_date'];
		$last_update = $instance['last_update'];
		$thumbnail	= $instance['thumbnail'];
		$rounded_thumb	= $instance['rounded_thumb'];
		$random		= $instance['random'];
		$more_text	= $instance['more_text'];
		$more_url	= $instance['more_url'];
		$views		= $instance['views'];
		$meta_key	= $instance['meta_key'];
		$ranking	= $instance['ranking'];

		// Sort order
		$order_by = '';
		if ((bool)$instance['random']) {
			$order_by = 'rand';
			$meta_key = null;
		} else {
			if ((bool)$ranking) {
				$order_by = 'meta_value_num';
			} else{
				$ordder_by = '';
				$meta_key = null;
			}
		}

		// Display widget
		$widget_code = $before_widget;

		if ( $instance['title']) {
			$widget_code .= $before_title.$title.$after_title;
		}

		$widget_code .= DP_GET_POSTS_BY_QUERY(array(
					'number'	=> $number,
					'title_length'	=> $title_length,
					'thumbnail'	=> $thumbnail,
					'rounded_thumb' => $rounded_thumb,
					'post_type'	=> $target,
					'pub_date'	=> $pub_date,
					'last_update' => $last_update,
					'order_by'	=> $order_by,
					'views' 	=> $views,
					'more_text'	=> $more_text,
					'more_url'	=> $more_url,
					'meta_key'	=> $meta_key,
					'type'		=> 'custom',
					'return' => true
					)
		);
		$widget_code .= $after_widget;

		echo $widget_code;


		/**
		 * Save to cache
		 */
		if ( dp_is_enable_cache( array( 'target' => 'recent_custom_posts_widget' ) ) && !$instance['disable_cache'] ){
			set_transient( 'dp_wdt_' . $this->id, $widget_code, 0 );
		}
	}
}
// widgets_init
add_action('widgets_init', function(){register_widget('DP_RecentCustomPosts_Widget');});




/*******************************************************
* Most Views Posts widget
*******************************************************/
class DP_Most_Viewed_Posts_Widget extends WP_Widget {
	public function __construct() {
		$widget_opts = array('classname' => 'dp_recent_posts_widget', 
							 'description' => __('Most Viewed Posts widget provided by DigiPress', 'DigiPress') );
		$control_opts = array('width' => 200, 'height' => 300);
		parent::__construct('DPMostViewedPostsWidget', __('Most Viewed Posts Widget', 'DigiPress'), $widget_opts, $control_opts);
	}

	// Input widget form in Admin panel.
	public function form($instance) {
		// default value
		$instance = wp_parse_args(
			(array)$instance,
			array(
				'title' => __('Most Viewed Posts','DigiPress'), 
				'number' => 5,
				'title_length' => 48,
				'post_type' => 'post',
				'meta_key' => 'post_views_count',
				'thumbnail' => true,
				'rounded_thumb' => false,
				'comment'	=> false,
				'views'	=> true,
				'term'	=> '',
				'cat'		=> '',
				'pub_date'	=> 'show',
				'last_update' => false,
				'hatebu_number' => false,
				'tweets_number' => false,
				'likes_number' => false,
				'disable_cache' => false,
		));

		$form_code = '';
		$term_code = '';

		// get values
		$title		= strip_tags($instance['title']);
		$number		= $instance['number'];
		$title_length= $instance['title_length'];
		$post_type	= $instance['post_type'];
		$thumbnail	= $instance['thumbnail'];
		$rounded_thumb	= $instance['rounded_thumb'];
		$comment	= $instance['comment'];
		$views		= $instance['views'];
		$term		= $instance['term'];
		$cat		= $instance['cat'];
		$pub_date	= $instance['pub_date'];
		$last_update = $instance['last_update'];
		$hatebu_number = $instance['hatebu_number'];
		$tweets_number = $instance['tweets_number'];
		$likes_number = $instance['likes_number'];
		$meta_key 	= $instance['meta_key'];
		$disable_cache 	= $instance['disable_cache'];

		$title_name	= $this->get_field_name('title');
		$title_id	= $this->get_field_id('title');
		$number_name	= $this->get_field_name('number');
		$number_id	= $this->get_field_id('number');
		$title_length_name	= $this->get_field_name('title_length');
		$title_length_id	= $this->get_field_id('title_length');
		$post_type_name	= $this->get_field_name('post_type');
		$post_type_id	= $this->get_field_id('post_type');
		$thumbnail_name	= $this->get_field_name('thumbnail');
		$thumbnail_id	= $this->get_field_id('thumbnail');
		$rounded_thumb_name	= $this->get_field_name('rounded_thumb');
		$rounded_thumb_id	= $this->get_field_id('rounded_thumb');
		$comment_name	= $this->get_field_name('comment');
		$comment_id		= $this->get_field_id('comment');
		$views_name		= $this->get_field_name('views');
		$views_id		= $this->get_field_id('views');
		$term_name		= $this->get_field_name('term');
		$term_id		= $this->get_field_id('term');
		$cat_name		= $this->get_field_name('cat');
		$cat_id			= $this->get_field_id('cat');
		$pub_date_name	= $this->get_field_name('pub_date');
		$pub_date_id	= $this->get_field_id('pub_date');
		$last_update_name	= $this->get_field_name('last_update');
		$last_update_id	= $this->get_field_id('last_update');
		$hatebu_number_name	= $this->get_field_name('hatebu_number');
		$tweets_number_name	= $this->get_field_name('tweets_number');
		$likes_number_name	= $this->get_field_name('likes_number');
		$hatebu_number_id = $this->get_field_id('hatebu_number');
		$tweets_number_id = $this->get_field_id('tweets_number');
		$likes_number_id = $this->get_field_id('likes_number');
		$meta_key_name	= $this->get_field_name('meta_key');
		$meta_key_id		= $this->get_field_id('meta_key');
		$disable_cache_name	= $this->get_field_name('disable_cache');
		$disable_cache_id		= $this->get_field_id('disable_cache');


		$thumb_check = '';
		if ($thumbnail) $thumb_check = ' checked';

		$comment_check = '';
		if ($comment) $comment_check = ' checked';

		$views_check = '';
		if ($views) $views_check = ' checked';

		$rounded_thumb_check = '';
		if ($rounded_thumb) $rounded_thumb_check = ' checked';

		$pub_date_check = '';
		if ($pub_date === 'show') $pub_date_check = ' checked';

		$last_update_check = '';
		if ($last_update) $last_update_check = ' checked';

		$hatebu_number_check = '';
		if ($hatebu_number) $hatebu_number_check = ' checked';

		$tweets_number_check = '';
		if ($tweets_number) $tweets_number_check = ' checked';

		$likes_number_check = '';
		if ($likes_number) $likes_number_check = ' checked';

		$disable_cache_check = '';
		if ($disable_cache) $disable_cache_check = ' checked';

		// Custom Post type
		$all_custom_post_types = get_post_types(
					array(
						'public'	=> true,
						'_builtin'	=> false
					), 'objects');
		$form_post_type_code = ($post_type === 'post') ? '<option value="post" selected>' . __('Posts', 'default' ) . '</option>' : '<option value="post">' . __('Posts', 'default' ) . '</option>';
		foreach ($all_custom_post_types as $cpt ) {
			if ($post_type === $cpt->name) {
				$form_post_type_code .= '<option value="' . $cpt->name . '" selected> ' . $cpt->label.'</option>';
			} else {
				$form_post_type_code .= '<option value="' . $cpt->name . '"> ' . $cpt->label.'</option>';
			}
		}
		$form_post_type_code = '<select name="' . $post_type_name . '" id="' . $post_type_id . '"> ' . $form_post_type_code . '</select>';


		// Term form
		$form_term_code = ( !isset( $term ) || empty( $term ) ) ? '<option value="" selected>' : '<option value="">';
		$form_term_code .= __( 'None', 'DigiPress' ) . '</option>';
		$form_term_code .= ( isset( $term ) && $term == 'this week' ) ? '<option value="this week" selected>' : '<option value="this week">';
		$form_term_code .= __( 'This week', 'DigiPress' ) . '</option>';
		$form_term_code .= ( isset( $term ) && $term == 'last week' ) ? '<option value="last week" selected>' : '<option value="last week">';
		$form_term_code .= __( 'Last week', 'DigiPress' ) . '</option>';
		$form_term_code .= ( isset( $term ) && $term == 'last 7 days' ) ? '<option value="last 7 days" selected>' : '<option value="last 7 days">';
		$form_term_code .= __( 'Last 7 days', 'DigiPress' ) . '</option>';
		$form_term_code .= ( isset( $term ) && $term == 'this month' ) ? '<option value="this month" selected>' : '<option value="this month">';
		$form_term_code .= __( 'This month', 'DigiPress' ) . '</option>';
		$form_term_code .= ( isset( $term ) && $term == 'last month' ) ? '<option value="last month" selected>' : '<option value="last month">';
		$form_term_code .= __( 'Last month', 'DigiPress' ) . '</option>';
		$form_term_code .= ( isset( $term ) && $term == 'last 30 days' ) ? '<option value="last 30 days" selected>' : '<option value="last 30 days">';
		$form_term_code .= __( 'Last 30 days', 'DigiPress' ) . '</option>';
		$form_term_code .= ( isset( $term ) && $term == 'this year' ) ? '<option value="this year" selected>' : '<option value="this year">';
		$form_term_code .= __( 'This year', 'DigiPress' ) . '</option>';
		$form_term_code .= ( isset( $term ) && $term == 'last year' ) ? '<option value="last year" selected>' : '<option value="last year">';
		$form_term_code .= __( 'Last year', 'DigiPress' ) . '</option>';
		$form_term_code = '<select name="' . $term_name . '" id="' . $term_id . '" style="width:280px;">' . $form_term_code . '</select>';



		// Show form
		$form_code = '<p><label for="' . $title_id . '">' . __('Title','DigiPress' ) . ':</label><br />';
		$form_code .= '<input type="text" name="' . $title_name . '" id="' . $title_id . '" value="' . $title . '" style="width:100%;" /></p>';

		// Do the custom function
		$term_code = apply_filters( 'dp_most_viewed_widget_form', 
			array(
				'post',
				$meta_key, 
				$meta_key_name, 
				$meta_key_id)
			);
		if (is_string($term_code)) {
			$form_code .= $term_code;
		}

		$form_code .= '<p><label for="' . $number_id . '">' . __('Number to display','DigiPress' ) . ':</label>
			 <input type="number" name="' . $number_name . '" id="' . $number_id . '" min=1 value="' . $number . '" style="width:80px;" /></p>';
		$form_code .= '<p><label for="' . $title_length_id . '">' . __('Max title length','DigiPress' ) . ':</label>
			 <input type="number" name="' . $title_length_name . '" id="' . $title_length_id . '" min=1 value="' . $title_length . '" style="width:80px;" /></p>';
		$form_code .= '<p><label for="' . $post_type_id . '">' . __('Target post type','DigiPress' ) . ' :</label>  ' . $form_post_type_code . '</p>';
		$form_code .= '<p><input name="' . $pub_date_name . '" id="' . $pub_date_id . '" type="checkbox" value="show" ' . $pub_date_check.' /><label for="' . $pub_date_id . '">' . __('Show date','DigiPress' ) . '</label></p>';
		$form_code .= '<p><input name="' . $last_update_name . '" id="' . $last_update_id . '" type="checkbox" value="show" ' . $last_update_check.' /> <label for="' . $last_update_id . '">' . __('Show last updated','DigiPress' ) . '</label></p>';
		$form_code .= '<p><input name="' . $thumbnail_name . '" id="' . $thumbnail_id . '" type="checkbox" value="on" ' . $thumb_check.' /><label for="' . $thumbnail_id . '">' . __('Show Thumbnail','DigiPress' ) . '</label></p>';
		$form_code .= '<p style="margin-left:15px;"><input name="' . $rounded_thumb_name . '" id="' . $rounded_thumb_id . '" type="checkbox" value="on"  ' . $rounded_thumb_check.' /><label for="' . $rounded_thumb_id . '">' . __('Rounded Thumbnail','DigiPress' ) . '</label></p>';
		$form_code .= '<p><input name="' . $comment_name . '" id="' . $comment_id . '" type="checkbox" value="on" ' . $comment_check.' /><label for="' . $comment_id . '">' . __('Show the comment number', 'DigiPress' ) . '</label></p>';
		$form_code .= '<p><input name="' . $views_name . '" id="' . $views_id . '" type="checkbox" value="on" ' . $views_check.' /><label for="' . $views_id . '">' . __('Show views.', 'DigiPress' ) . '</label></p>';
		$form_code .= '<p><input name="' . $hatebu_number_name . '" id="' . $hatebu_number_id . '" type="checkbox" value="on" ' . $hatebu_number_check . ' /><label for="' . $hatebu_number_id . '">' . __('Show hatena bookmarked count', 'DigiPress' ) . '</label></p>';
		$form_code .= '<p><input name="' . $tweets_number_name . '" id="' . $tweets_number_id . '" type="checkbox" value="on" ' . $tweets_number_check . ' /><label for="' . $tweets_number_id . '">' . __('Show tweeted count', 'DigiPress' ) . '</label></p>';
		$form_code .= '<p><input name="' . $likes_number_name . '" id="' . $likes_number_id . '" type="checkbox" value="on" ' . $likes_number_check . ' /><label for="' . $likes_number_id . '">' . __('Show FB likes count', 'DigiPress' ) . '</label></p>';
		$form_code .= '<p><label for="' . $term_id . '">' . __('Coverage period','DigiPress') . __( '(Optional)', 'DigiPress' ) . ':</label><br />' . $form_term_code . '</p>';
		$form_code .= '<p><label for="' . $cat_id . '">' . __('Target Category(Optional)','DigiPress' ) . ':</label><br />
			 <input type="text" name="' . $cat_name . '" id="' . $cat_id . '" value="' . $cat . '" style="width:100%;" /><br />
			 <span class="ft12px">' . __('*Note: Multiple categories are available.(ex. 2,4,12)', 'DigiPress' ) . '</span></p>';
		$form_code .= '<p><input name="' . $disable_cache_name . '" id="' . $disable_cache_id . '" type="checkbox" value="on" ' . $disable_cache_check . ' /><label for="' . $disable_cache_id . '" class="b">' . __('Disable cache', 'DigiPress' ) . '</label><br />
			<span class="ft12px">' . __('*Note: If the theme option cache function is enabled, check to not cache this widget.', 'DigiPress' ) . '</span></p><hr />';

		// Display
		echo $form_code;
	}


	// Save Function
	// $new_instance : Input value
	// $old_instance : Exist value
	// Return : New values
	public function update($new_instance, $old_instance) {
		$instance['title']		= htmlspecialchars(stripslashes($new_instance['title']));
		$instance['number']		= $new_instance['number'];
		$instance['title_length']		= $new_instance['title_length'];
		$instance['post_type']		= $new_instance['post_type'];
		$instance['thumbnail']	= $new_instance['thumbnail'];
		$instance['rounded_thumb']	= $new_instance['rounded_thumb'];
		$instance['comment']	= $new_instance['comment'];
		$instance['views']		= $new_instance['views'];
		$instance['term']		= $new_instance['term'];
		$instance['cat']		= $new_instance['cat'];
		$instance['pub_date']	= $new_instance['pub_date'];
		$instance['last_update'] = $new_instance['last_update'];
		$instance['hatebu_number']	= $new_instance['hatebu_number'];
		$instance['tweets_number']	= $new_instance['tweets_number'];
		$instance['likes_number']	= $new_instance['likes_number'];
		$instance['meta_key']	= $new_instance['meta_key'];
		$instance['disable_cache']	= $new_instance['disable_cache'];

		// Check errors
		if (!$instance['title']) {
			$before_title 	= '';
			$after_title	= '';
			/*$instance['title'] = strip_tags($old_instance['title']);
			$this->m_error = '<span style="color:#ff0000;">' . __('The title is blank. It will be reset to old value.', 'DigiPress' ) . '</span>';*/
		}
		return $instance;
	}

	// Display to theme
	// $args : output array
	// $instance : exist array
	public function widget($args, $instance) {
		$instance = wp_parse_args(
			(array)$instance,
			array(
				'title' => '',
				'number' => 5,
				'title_length' => 48,
				'post_type' => 'post',
				'meta_key' => 'post_views_count',
				'thumbnail' => true,
				'rounded_thumb' => false,
				'comment'	=> false,
				'views'	=> true,
				'term'	=> '',
				'cat'		=> '',
				'pub_date'	=> 'show',
				'last_update' => false,
				'hatebu_number' => false,
				'tweets_number' => false,
				'likes_number' => false,
				'disable_cache' => false,
		));


		/**
		 * Check the transient data and return the cache if cache is exists
		 */
		if ( dp_is_enable_cache( array( 'target' => 'most_viewed_posts_widget' ) ) && !$instance['disable_cache'] ){
			$cache = get_transient( 'dp_wdt_' . $this->id );
			if ( $cache !== false ) {
				echo $cache;
				return;
			}
		}


		extract($args);

		$title = $instance['title'];
		$title = apply_filters('widget_title', $title);
		$title = htmlspecialchars_decode($title);
		$number = $instance['number'];
		$title_length = $instance['title_length'];
		$post_type = $instance['post_type'];
		$thumbnail	= $instance['thumbnail'];
		$rounded_thumb	= $instance['rounded_thumb'];
		$comment	= $instance['comment'];
		$views		= $instance['views'];
		$term		= $instance['term'];
		$cat		= $instance['cat'];
		$pub_date	= $instance['pub_date'];
		$last_update = $instance['last_update'];
		$hatebu_number = $instance['hatebu_number'];
		$tweets_number = $instance['tweets_number'];
		$likes_number = $instance['likes_number'];
		$meta_key 	= $instance['meta_key'] ? $instance['meta_key'] : 'post_views_count';

		// Display
		$widget_code = $before_widget;

		if ( $instance['title']) {
			$widget_code .= $before_title.$title.$after_title;
		}

		$widget_code .= DP_GET_POSTS_BY_QUERY(array(
					'number'	=> $number,
					'title_length'	=> $title_length,
					'post_type'	=> $post_type,
					'comment'	=> $comment,
					'views' 	=> $views,
					'thumbnail'	=> $thumbnail,
					'rounded_thumb' => $rounded_thumb,
					'hatebu_number'	=> $hatebu_number,
					'tweets_number'	=> $tweets_number,
					'likes_number'	=> $likes_number,
					'cat_id'	=> str_replace("\s", "", $cat),
					'term'		=> $term,
					'pub_date'	=> $pub_date,
					'last_update' => $last_update,
					'meta_key'	=> $meta_key,
					'order_by'	=> 'meta_value_num',
					'return' => true
					)
		);
		$widget_code .= $after_widget;

		echo $widget_code;


		/**
		 * Save to cache
		 */
		if ( dp_is_enable_cache( array( 'target' => 'most_viewed_posts_widget' ) ) && !$instance['disable_cache'] ){
			set_transient( 'dp_wdt_' . $this->id, $widget_code, 0 );
		}
	}
}
// widgets_init
add_action('widgets_init', function(){register_widget('DP_Most_Viewed_Posts_Widget');});



/*******************************************************
* Most Commented Posts widget
*******************************************************/
class DP_MostCommentedPosts_Widget extends WP_Widget {
	public function __construct() {
		$widget_opts = array('classname' => 'dp_recent_posts_widget', 
							 'description' => __('Most Commented Posts widget provided by DigiPress', 'DigiPress') );
		$control_opts = array('width' => 200, 'height' => 300);
		parent::__construct('DPMostCommentedPostsWidget', __('Most Commented Posts Widget', 'DigiPress'), $widget_opts, $control_opts);
	}

	// Input widget form in Admin panel.
	public function form($instance) {
		// default value
		$instance = wp_parse_args(
			(array)$instance,
			array(
				'title' => __('Most Commented Posts','DigiPress'), 
				'number' => 5,
				'title_length' => 48,
				'thumbnail' => true,
				'rounded_thumb' => false,
				'comment'	=> true,
				'views'	=> false,
				'term'	=> '',
				'cat'		=> '',
				'pub_date'	=> 'show',
				'last_update' => false,
				'hatebu_number' => false,
				'tweets_number' => false,
				'likes_number' => false,
				'disable_cache' => false,
		));

		// get values
		$title		= strip_tags($instance['title']);
		$number		= $instance['number'];
		$title_length= $instance['title_length'];
		$thumbnail	= $instance['thumbnail'];
		$rounded_thumb	= $instance['rounded_thumb'];
		$comment	= $instance['comment'];
		$views		= $instance['views'];
		$term		= $instance['term'];
		$cat		= $instance['cat'];
		$pub_date	= $instance['pub_date'];
		$last_update = $instance['last_update'];
		$hatebu_number = $instance['hatebu_number'];
		$tweets_number = $instance['tweets_number'];
		$likes_number = $instance['likes_number'];
		$disable_cache = $instance['disable_cache'];


		$title_name	= $this->get_field_name('title');
		$title_id	= $this->get_field_id('title');
		$number_name	= $this->get_field_name('number');
		$number_id	= $this->get_field_id('number');
		$title_length_name	= $this->get_field_name('title_length');
		$title_length_id	= $this->get_field_id('title_length');
		$thumbnail_name	= $this->get_field_name('thumbnail');
		$thumbnail_id	= $this->get_field_id('thumbnail');
		$rounded_thumb_name	= $this->get_field_name('rounded_thumb');
		$rounded_thumb_id	= $this->get_field_id('rounded_thumb');
		$comment_name	= $this->get_field_name('comment');
		$comment_id		= $this->get_field_id('comment');
		$views_name		= $this->get_field_name('views');
		$views_id		= $this->get_field_id('views');
		$term_name		= $this->get_field_name('term');
		$term_id		= $this->get_field_id('term');
		$cat_name		= $this->get_field_name('cat');
		$cat_id			= $this->get_field_id('cat');
		$pub_date_name	= $this->get_field_name('pub_date');
		$pub_date_id	= $this->get_field_id('pub_date');
		$last_update_name	= $this->get_field_name('last_update');
		$last_update_id	= $this->get_field_id('last_update');

		$disable_cache_name	= $this->get_field_name('disable_cache');
		$disable_cache_id	= $this->get_field_id('disable_cache');

		$hatebu_number_name	= $this->get_field_name('hatebu_number');
		$tweets_number_name	= $this->get_field_name('tweets_number');
		$likes_number_name	= $this->get_field_name('likes_number');
		$hatebu_number_id = $this->get_field_id('hatebu_number');
		$tweets_number_id = $this->get_field_id('tweets_number');
		$likes_number_id = $this->get_field_id('likes_number');

		$thumb_check = '';
		if ($thumbnail) $thumb_check = ' checked';

		$comment_check = '';
		if ($comment) $comment_check = ' checked';

		$views_check = '';
		if ($views) $views_check = ' checked';

		$rounded_thumb_check = '';
		if ($rounded_thumb) $rounded_thumb_check = ' checked';

		$pub_date_check = '';
		if ($pub_date === 'show') $pub_date_check = ' checked';

		$last_update_check = '';
		if ($last_update) $last_update_check = ' checked';

		$hatebu_number_check = '';
		if ($hatebu_number) $hatebu_number_check = ' checked';

		$tweets_number_check = '';
		if ($tweets_number) $tweets_number_check = ' checked';

		$likes_number_check = '';
		if ($likes_number) $likes_number_check = ' checked';

		$disable_cache_check = '';
		if ($disable_cache) $disable_cache_check = ' checked';


		// Term form
		$form_term_code = ( !isset( $term ) || empty( $term ) ) ? '<option value="" selected>' : '<option value="">';
		$form_term_code .= __( 'None', 'DigiPress' ) . '</option>';
		$form_term_code .= ( isset( $term ) && $term == 'this week' ) ? '<option value="this week" selected>' : '<option value="this week">';
		$form_term_code .= __( 'This week', 'DigiPress' ) . '</option>';
		$form_term_code .= ( isset( $term ) && $term == 'last week' ) ? '<option value="last week" selected>' : '<option value="last week">';
		$form_term_code .= __( 'Last week', 'DigiPress' ) . '</option>';
		$form_term_code .= ( isset( $term ) && $term == 'last 7 days' ) ? '<option value="last 7 days" selected>' : '<option value="last 7 days">';
		$form_term_code .= __( 'Last 7 days', 'DigiPress' ) . '</option>';
		$form_term_code .= ( isset( $term ) && $term == 'this month' ) ? '<option value="this month" selected>' : '<option value="this month">';
		$form_term_code .= __( 'This month', 'DigiPress' ) . '</option>';
		$form_term_code .= ( isset( $term ) && $term == 'last month' ) ? '<option value="last month" selected>' : '<option value="last month">';
		$form_term_code .= __( 'Last month', 'DigiPress' ) . '</option>';
		$form_term_code .= ( isset( $term ) && $term == 'last 30 days' ) ? '<option value="last 30 days" selected>' : '<option value="last 30 days">';
		$form_term_code .= __( 'Last 30 days', 'DigiPress' ) . '</option>';
		$form_term_code .= ( isset( $term ) && $term == 'this year' ) ? '<option value="this year" selected>' : '<option value="this year">';
		$form_term_code .= __( 'This year', 'DigiPress' ) . '</option>';
		$form_term_code .= ( isset( $term ) && $term == 'last year' ) ? '<option value="last year" selected>' : '<option value="last year">';
		$form_term_code .= __( 'Last year', 'DigiPress' ) . '</option>';
		$form_term_code = '<select name="' . $term_name . '" id="' . $term_id . '" style="width:280px;">' . $form_term_code . '</select>';


		// Show form
		$form_code = '<p><label for="' . $title_id . '">' . __('Title','DigiPress' ) . ':</label><br />';
		$form_code .= '<input type="text" name="' . $title_name . '" id="' . $title_id . '" value="' . $title . '" style="width:100%;" /></p>';
		$form_code .= '<p><label for="' . $number_id . '">' . __('Number to display','DigiPress' ) . ':</label>
			 <input type="number" name="' . $number_name . '" id="' . $number_id . '" min=1 value="' . $number . '" style="width:80px;" /></p>';
		$form_code .= '<p><label for="' . $title_length_id . '">' . __('Max title length','DigiPress' ) . ':</label>
			 <input type="number" name="' . $title_length_name . '" id="' . $title_length_id . '" min=1 value="' . $title_length . '" style="width:80px;" /></p>';
		$form_code .= '<p><input name="' . $pub_date_name . '" id="' . $pub_date_id . '" type="checkbox" value="show" ' . $pub_date_check.' /><label for="' . $pub_date_id . '">' . __('Show date','DigiPress' ) . '</label></p>';
		$form_code .= '<p><input name="' . $last_update_name . '" id="' . $last_update_id . '" type="checkbox" value="show" ' . $last_update_check.' /> <label for="' . $last_update_id . '">' . __('Show last updated','DigiPress' ) . '</label></p>';
		$form_code .= '<p><input name="' . $thumbnail_name . '" id="' . $thumbnail_id . '" type="checkbox" value="on" ' . $thumb_check.' /><label for="' . $thumbnail_id . '">' . __('Show Thumbnail','DigiPress' ) . '</label></p>';
		$form_code .= '<p style="margin-left:15px;"><input name="' . $rounded_thumb_name . '" id="' . $rounded_thumb_id . '" type="checkbox" value="on"  ' . $rounded_thumb_check.' /><label for="' . $rounded_thumb_id . '">' . __('Rounded Thumbnail','DigiPress' ) . '</label></p>';
		$form_code .= '<p><input name="' . $comment_name . '" id="' . $comment_id . '" type="checkbox" value="on" ' . $comment_check.' /><label for="' . $comment_id . '">' . __('Show the comment number', 'DigiPress' ) . '</label></p>';
		$form_code .= '<p><input name="' . $views_name . '" id="' . $views_id . '" type="checkbox" value="on" ' . $views_check.' /><label for="' . $views_id . '">' . __('Show views.', 'DigiPress' ) . '</label></p>';
		$form_code .= '<p><input name="' . $hatebu_number_name . '" id="' . $hatebu_number_id . '" type="checkbox" value="on" ' . $hatebu_number_check.' /><label for="' . $hatebu_number_id . '">' . __('Show hatena bookmarked count', 'DigiPress' ) . '</label></p>';
		$form_code .= '<p><input name="' . $tweets_number_name . '" id="' . $tweets_number_id . '" type="checkbox" value="on" ' . $tweets_number_check.' /><label for="' . $tweets_number_id . '">' . __('Show tweeted count', 'DigiPress' ) . '</label></p>';
		$form_code .= '<p><input name="' . $likes_number_name . '" id="' . $likes_number_id . '" type="checkbox" value="on" ' . $likes_number_check.' /><label for="' . $likes_number_id . '">' . __('Show FB likes count', 'DigiPress' ) . '</label></p>';
		$form_code .= '<p><label for="' . $term_id . '">' . __('Coverage period','DigiPress') . __( '(Optional)', 'DigiPress' ) . ':</label><br />' . $form_term_code . '</p>';
		$form_code .= '<p><label for="' . $cat_id . '">' . __('Target Category(Optional)','DigiPress' ) . ':</label><br />
			 <input type="text" name="' . $cat_name . '" id="' . $cat_id . '" value="' . $cat . '" style="width:100%;" /><br />
			 <span class="ft12px">' . __('*Note: Multiple categories are available.(ex. 2,4,12)', 'DigiPress' ) . '</span></p>';
		$form_code .= '<p><input name="' . $disable_cache_name . '" id="' . $disable_cache_id . '" type="checkbox" value="on" ' . $disable_cache_check.' /><label for="' . $disable_cache_id . '" class="b">' . __('Disable cache', 'DigiPress' ) . '</label><br />
			<span class="ft12px">' . __('*Note: If the theme option cache function is enabled, check to not cache this widget.', 'DigiPress' ) . '</span></p><hr />';

		echo $form_code;
	}

	// Save Function
	// $new_instance : Input value
	// $old_instance : Exist value
	// Return : New values
	public function update($new_instance, $old_instance) {
		$instance['title']		= htmlspecialchars(stripslashes($new_instance['title']));
		$instance['number']		= $new_instance['number'];
		$instance['title_length']		= $new_instance['title_length'];
		$instance['thumbnail']	= $new_instance['thumbnail'];
		$instance['rounded_thumb']	= $new_instance['rounded_thumb'];
		$instance['comment']	= $new_instance['comment'];
		$instance['views']		= $new_instance['views'];
		$instance['term']		= $new_instance['term'];
		$instance['cat']		= $new_instance['cat'];
		$instance['pub_date']	= $new_instance['pub_date'];
		$instance['last_update'] = $new_instance['last_update'];
		$instance['hatebu_number']	= $new_instance['hatebu_number'];
		$instance['tweets_number']	= $new_instance['tweets_number'];
		$instance['likes_number']	= $new_instance['likes_number'];
		$instance['disable_cache']	= $new_instance['disable_cache'];

		// Check errors
		if (!$instance['title']) {
			$before_title 	= '';
			$after_title	= '';
			/*$instance['title'] = strip_tags($old_instance['title']);
			$this->m_error = '<span style="color:#ff0000;">' . __('The title is blank. It will be reset to old value.', 'DigiPress' ) . '</span>';*/
		}
		return $instance;
	}

	// Display to theme
	// $args : output array
	// $instance : exist array
	public function widget($args, $instance) {
		$instance = wp_parse_args(
			(array)$instance,
			array(
				'title' => '',
				'number' => 5,
				'title_length' => 48,
				'thumbnail' => true,
				'rounded_thumb' => false,
				'comment'	=> true,
				'views'	=> false,
				'term'	=> '',
				'cat'		=> '',
				'pub_date'	=> 'show',
				'last_update' => false,
				'hatebu_number' => false,
				'tweets_number' => false,
				'likes_number' => false,
				'disable_cache' => false,
		));


		/**
		 * Check the transient data and return the cache if cache is exists
		 */
		if ( dp_is_enable_cache( array( 'target' => 'most_commented_posts_widget' ) ) && !$instance['disable_cache'] ){
			$cache = get_transient( 'dp_wdt_' . $this->id );
			if ( $cache !== false ) {
				echo $cache;
				return;
			}
		}


		extract($args);

		$title = $instance['title'];
		$title = apply_filters('widget_title', $title);
		$title = htmlspecialchars_decode($title);
		$number = $instance['number'];
		$title_length = $instance['title_length'];
		$thumbnail	= $instance['thumbnail'];
		$rounded_thumb	= $instance['rounded_thumb'];
		$comment	= $instance['comment'];
		$views		= $instance['views'];
		$term		= $instance['term'];
		$cat		= $instance['cat'];
		$pub_date	= $instance['pub_date'];
		$last_update = $instance['last_update'];
		$hatebu_number = $instance['hatebu_number'];
		$tweets_number = $instance['tweets_number'];
		$likes_number = $instance['likes_number'];

		$widget_code = $before_widget;

		if ( $instance['title']) {
			$widget_code .= $before_title.$title.$after_title;
		}

		$widget_code .= DP_GET_POSTS_BY_QUERY(array(
					'number'	=> $number,
					'title_length'	=> $title_length,
					'comment'	=> $comment,
					'views' 	=> $views,
					'thumbnail'	=> $thumbnail,
					'rounded_thumb' => $rounded_thumb,
					'cat_id'	=> str_replace("\s", "", $cat),
					'term'		=> $term,
					'pub_date'	=> $pub_date,
					'last_update' => $last_update,
					'order_by'	=> 'comment_count',
					'hatebu_number' 	=> $hatebu_number,
					'tweets_number' 	=> $tweets_number,
					'likes_number' 	=> $likes_number,
					'return' => true
					)
		);
		$widget_code .= $after_widget;

		echo $widget_code;


		/**
		 * Save to cache
		 */
		if ( dp_is_enable_cache( array( 'target' => 'most_commented_posts_widget' ) ) && !$instance['disable_cache'] ){
			set_transient( 'dp_wdt_' . $this->id, $widget_code, 0 );
		}
	}
}
// widgets_init
add_action('widgets_init', function(){register_widget('DP_MostCommentedPosts_Widget');});


/*******************************************************
* Original Custom Text widget
*******************************************************/
class DP_Custom_Text_Widget extends WP_Widget {
	protected $registered = false;

	public function __construct() {
		$widget_opts = array('classname' => 'dp_custom_text_widget', 
							 'description' => __('Enhanced Custom Text Widget provided by DigiPress', 'DigiPress'),
							 'customize_selective_refresh' => true);
		$control_opts = array('width' => 400, 'height' => 350);
		parent::__construct('DPCustomTextWidget', __('Custom Text Widget','DigiPress'), $widget_opts, $control_opts);
	}

	public function _register_one( $number = -1 ) {
		parent::_register_one( $number );
		if ( $this->registered ) {
			return;
		}
		$this->registered = true;
		wp_add_inline_script( 'text-widgets', sprintf( 'wp.textWidgets.idBases.push( %s );', wp_json_encode( $this->id_base ) ) );
		add_action( 'admin_print_scripts-widgets.php', array( $this, 'enqueue_admin_scripts' ) );
		add_action( 'admin_footer-widgets.php', array( 'DP_Custom_Text_Widget', 'dp_render_control_template_scripts' ) );
	}

	public function is_legacy_instance( $instance ) {
		if ( isset( $instance['visual'] ) ) {
			return ! $instance['visual'];
		}
		if ( isset( $instance['filter'] ) && 'content' === $instance['filter'] ) {
			return false;
		}
		if ( empty( $instance['contents'] ) ) {
			return false;
		}
		$wpautop = ! empty( $instance['filter'] );
		$has_line_breaks = ( false !== strpos( trim( $instance['contents'] ), "\n" ) );
		if ( ! $wpautop && $has_line_breaks ) {
			return true;
		}
		if ( false !== strpos( $instance['contents'], '<!--' ) ) {
			return true;
		}
		if ( ! class_exists( 'DOMDocument' ) ) {
			// @codeCoverageIgnoreStart
			return true;
			// @codeCoverageIgnoreEnd
		}
		$doc = new DOMDocument();
		@$doc->loadHTML( sprintf(
			'<!DOCTYPE html><html><head><meta charset="%s"></head><body>%s</body></html>',
			esc_attr( get_bloginfo( 'charset' ) ),
			$instance['contents']
		) );
		$body = $doc->getElementsByTagName( 'body' )->item( 0 );
		$safe_elements_attributes = array(
			'strong' => array(),
			'em' => array(),
			'b' => array(),
			'i' => array(),
			'u' => array(),
			's' => array(),
			'ul' => array(),
			'ol' => array(),
			'li' => array(),
			'hr' => array(),
			'abbr' => array(),
			'acronym' => array(),
			'code' => array(),
			'dfn' => array(),
			'a' => array(
				'href' => true,
			),
			'img' => array(
				'src' => true,
				'alt' => true,
			),
		);
		$safe_empty_elements = array( 'img', 'hr', 'iframe' );

		foreach ( $body->getElementsByTagName( '*' ) as $element ) {
			$tag_name = strtolower( $element->nodeName );
			if ( ! isset( $safe_elements_attributes[ $tag_name ] ) ) {
				return true;
			}
			if ( ! in_array( $tag_name, $safe_empty_elements, true ) && '' === trim( $element->textContent ) ) {
				return true;
			}
			foreach ( $element->attributes as $attribute ) {
				$attribute_name = strtolower( $attribute->nodeName );
				if ( ! isset( $safe_elements_attributes[ $tag_name ][ $attribute_name ] ) ) {
					return true;
				}
			}
		}
		return false;
	}

	public function _filter_gallery_shortcode_attrs( $attrs ) {
		if ( ! is_singular() && empty( $attrs['id'] ) && empty( $attrs['include'] ) ) {
			$attrs['id'] = -1;
		}
		return $attrs;
	}

	public function inject_video_max_width_style( $matches ) {
		$html = $matches[0];
		$html = preg_replace( '/\sheight="\d+"/', '', $html );
		$html = preg_replace( '/\swidth="\d+"/', '', $html );
		$html = preg_replace( '/(?<=width:)\s*\d+px(?=;?)/', '100%', $html );
		return $html;
	}

	public function enqueue_admin_scripts() {
		wp_enqueue_editor();
		wp_enqueue_script( 'text-widgets' );
		wp_add_inline_script( 'text-widgets', 'wp.textWidgets.init();', 'after' );
	}

	public function form($instance) {
		$instance = wp_parse_args(
			(array)$instance,
			array('title' => '', 
				  'contents' => '',
				  'scrollFix' => false)
			);

		if ( ! $this->is_legacy_instance( $instance ) ) :
			if ( user_can_richedit() ) {
				add_filter( 'the_editor_content', 'format_for_editor', 10, 2 );
				$default_editor = 'tinymce';
			} else {
				$default_editor = 'html';
			}
			/** This filter is documented in wp-includes/class-wp-editor.php */
			$contents = apply_filters( 'the_editor_content', $instance['contents'], $default_editor );
			// Reset filter addition.
			if ( user_can_richedit() ) {
				remove_filter( 'the_editor_content', 'format_for_editor' );
			}
			// Prevent premature closing of textarea in case format_for_editor() didn't apply or the_editor_content filter did a wrong thing.
			$escaped_text = preg_replace( '#</textarea#i', '&lt;/textarea', $contents );?>
<input id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" class="title sync-input" type="hidden" value="<?php echo esc_attr( $instance['title'] ); ?>">
<textarea id="<?php echo $this->get_field_id( 'contents' ); ?>" name="<?php echo $this->get_field_name( 'contents' ); ?>" class="text sync-input" hidden><?php echo $escaped_text; ?></textarea>
<input id="<?php echo $this->get_field_id( 'filter' ); ?>" name="<?php echo $this->get_field_name( 'filter' ); ?>" class="filter sync-input" type="hidden" value="on">
<input id="<?php echo $this->get_field_id( 'visual' ); ?>" name="<?php echo $this->get_field_name( 'visual' ); ?>" class="visual sync-input" type="hidden" value="on"><?php
		else :?>
<input id="<?php echo $this->get_field_id( 'visual' ); ?>" name="<?php echo $this->get_field_name( 'visual' ); ?>" class="visual" type="hidden" value="">
<p>
<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Title:' ); ?></label>
<input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo esc_attr( $instance['title'] ); ?>"/>
</p>
<div class="notice inline notice-info notice-alt"><?php
			if ( ! isset( $instance['visual'] ) ) : ?>
<p><?php _e( 'This widget may contain code that may work better in the &#8220;Custom HTML&#8221; widget. How about trying that widget instead?' ); ?></p><?php
			else : ?>
<p><?php _e( 'This widget may have contained code that may work better in the &#8220;Custom HTML&#8221; widget. If you haven&#8217;t yet, how about trying that widget instead?' ); ?></p><?php
			endif; ?>
</div>
<p>
<label for="<?php echo $this->get_field_id( 'contents' ); ?>"><?php _e( 'Content:' ); ?></label>
<textarea class="widefat" rows="16" cols="20" id="<?php echo $this->get_field_id( 'contents' ); ?>" name="<?php echo $this->get_field_name( 'contents' ); ?>"><?php echo esc_textarea( $instance['contents'] ); ?></textarea>
</p>
<p>
<input id="<?php echo $this->get_field_id( 'filter' ); ?>" name="<?php echo $this->get_field_name( 'filter' ); ?>" type="checkbox"<?php checked( ! empty( $instance['filter'] ) ); ?> />&nbsp;<label for="<?php echo $this->get_field_id( 'filter' ); ?>"><?php _e( 'Automatically add paragraphs' ); ?></label>
</p><?php
		endif;?>
<p>
<label for="<?php echo $this->get_field_id('scrollFix'); ?>"><input name="<?php echo $this->get_field_name('scrollFix'); ?>" id="<?php echo $this->get_field_id('scrollFix'); ?>" type="checkbox" value="on" <?php checked( !empty( $instance['scrollFix'] ) ); ?> />&nbsp;<?php
_e('Fix position when sidebar is blank by scrolling','DigiPress'); ?>
</label><br />
<span style="font-size:12px;color:red;"><?php _e('*Note : This option is available at only one widget.','DigiPress'); ?></span></p><?php
	}

	public function update($new_instance, $old_instance) {
		$new_instance = wp_parse_args( $new_instance, array(
			'title' => '',
			'contents' => '',
			'filter' => false, // For back-compat.
			'visual' => null, // Must be explicitly defined.
			'scrollFix' => false
		) );
		$instance = $old_instance;

		$instance['title'] = sanitize_text_field( $new_instance['title'] );
		if ( current_user_can( 'unfiltered_html' ) ) {
			$instance['contents'] = $new_instance['contents'];
		} else {
			$instance['contents'] = wp_kses_post( $new_instance['contents'] );
		}
		$instance['filter'] = ! empty( $new_instance['filter'] );
		// Upgrade 4.8.0 format.
		if ( isset( $old_instance['filter'] ) && 'content' === $old_instance['filter'] ) {
			$instance['visual'] = true;
		}
		if ( 'content' === $new_instance['filter'] ) {
			$instance['visual'] = true;
		}
		if ( isset( $new_instance['visual'] ) ) {
			$instance['visual'] = ! empty( $new_instance['visual'] );
		}
		// Filter is always true in visual mode.
		if ( ! empty( $instance['visual'] ) ) {
			$instance['filter'] = true;
		}
		$instance['scrollFix']	= $new_instance['scrollFix'];

		return $instance;
	}

	public function widget($args, $instance) {
		global $post;

		$title = ! empty( $instance['title'] ) ? $instance['title'] : '';
		/** This filter is documented in wp-includes/widgets/class-wp-widget-pages.php */
		$title = apply_filters( 'widget_title', $title, $instance, $this->id_base );

		$contents = ! empty( $instance['contents'] ) ? $instance['contents'] : '';
		$is_visual_text_widget = ( ! empty( $instance['visual'] ) && ! empty( $instance['filter'] ) );

		// In 4.8.0 only, visual Text widgets get filter=content, without visual prop; upgrade instance props just-in-time.
		if ( ! $is_visual_text_widget ) {
			$is_visual_text_widget = ( isset( $instance['filter'] ) && 'content' === $instance['filter'] );
		}
		if ( $is_visual_text_widget ) {
			$instance['filter'] = true;
			$instance['visual'] = true;
		}
		$scrollFix	= isset($instance['scrollFix']) && !empty($instance['scrollFix']) ? true : false;

		$widget_text_do_shortcode_priority = has_filter( 'dp_widget_text', 'do_shortcode' );
		$should_suspend_legacy_shortcode_support = ( $is_visual_text_widget && false !== $widget_text_do_shortcode_priority );
		if ( $should_suspend_legacy_shortcode_support ) {
			remove_filter( 'dp_widget_text', 'do_shortcode', $widget_text_do_shortcode_priority );
		}

		$original_post = $post;
		if ( is_singular() ) {
			$post = get_queried_object();
		} else {
			$post = null;
		}
		add_filter( 'shortcode_atts_gallery', array( $this, '_filter_gallery_shortcode_attrs' ) );

		// Filter hook
		$contents = apply_filters( 'dp_widget_text', $contents, $instance, $this );

		if ( $is_visual_text_widget ) {
			$contents = apply_filters( 'dp_widget_text_content', $contents, $instance, $this );
			$contents = wpautop( $contents );
		} else {
			if ( ! empty( $instance['filter'] ) ) {
				$contents = wpautop( $contents );
			}
			if ( has_filter( 'dp_widget_text_content', 'do_shortcode' ) && ! $widget_text_do_shortcode_priority ) {
				if ( ! empty( $instance['filter'] ) ) {
					$contents = shortcode_unautop( $contents );
				}
				$contents = do_shortcode( $contents );
			}
		}
		$post = $original_post;
		remove_filter( 'shortcode_atts_gallery', array( $this, '_filter_gallery_shortcode_attrs' ) );
		// Undo suspension of legacy plugin-supplied shortcode handling.
		if ( $should_suspend_legacy_shortcode_support ) {
			add_filter( 'dp_widget_text', 'do_shortcode', $widget_text_do_shortcode_priority );
		}

		$widget_wrapper = $scrollFix ? '<div id="dp_fix_widget" class="dp_text_widget">' : '<div class="dp_text_widget">';

		echo $args['before_widget'];
		if (!empty($title)) {
			echo $args['before_title'].$title.$args['after_title'];
		}
		$contents = preg_replace_callback('#<(video|iframe|object|embed)\s[^>]*>#i', array($this, 'inject_video_max_width_style'), $contents);

		echo $widget_wrapper.$contents."</div>".$args['after_widget'];
	}

	public static function dp_render_control_template_scripts() {
		$dismissed_pointers = explode( ',', (string) get_user_meta( get_current_user_id(), 'dismissed_wp_pointers', true ) );?>
<script type="text/html" id="tmpl-widget-text-control-fields">
<# var elementIdPrefix = 'el' + String( Math.random() ).replace( /\D/g, '' ) + '_' #>
<p>
<label for="{{ elementIdPrefix }}title"><?php esc_html_e( 'Title:' ); ?></label>
<input id="{{ elementIdPrefix }}title" type="text" class="widefat title" />
</p><?php
if ( ! in_array( 'text_widget_custom_html', $dismissed_pointers, true ) ) : ?>
<div hidden class="wp-pointer custom-html-widget-pointer wp-pointer-top">
<div class="wp-pointer-content">
<h3><?php _e( 'New Custom HTML Widget' ); ?></h3><?php
	if ( is_customize_preview() ) : ?>
<p><?php
_e( 'Did you know there is a &#8220;Custom HTML&#8221; widget now? You can find it by pressing the &#8220;<a class="add-widget" href="#">Add a Widget</a>&#8221; button and searching for &#8220;HTML&#8221;. Check it out to add some custom code to your site!' ); ?></p><?php
	else : ?>
<p><?php _e( 'Did you know there is a &#8220;Custom HTML&#8221; widget now? You can find it by scanning the list of available widgets on this screen. Check it out to add some custom code to your site!' ); ?></p><?php
	endif; ?>
<div class="wp-pointer-buttons"><a class="close" href="#"><?php _e( 'Dismiss' ); ?></a></div></div><div class="wp-pointer-arrow"><div class="wp-pointer-arrow-inner"></div></div></div><?php
endif;
if ( ! in_array( 'text_widget_paste_html', $dismissed_pointers, true ) ) : ?>
<div hidden class="wp-pointer paste-html-pointer wp-pointer-top">
<div class="wp-pointer-content">
<h3><?php _e( 'Did you just paste HTML?' ); ?></h3>
<p><?php
_e( 'Hey there, looks like you just pasted HTML into the &#8220;Visual&#8221; tab of the Text widget. You may want to paste your code into the &#8220;Text&#8221; tab instead. Alternately, try out the new &#8220;Custom HTML&#8221; widget!' ); ?></p>
<div class="wp-pointer-buttons">
<a class="close" href="#"><?php _e( 'Dismiss' ); ?></a></div></div>
<div class="wp-pointer-arrow"><div class="wp-pointer-arrow-inner"></div></div></div><?php
endif; ?>
<p>
<label for="{{ elementIdPrefix }}contents" class="screen-reader-text"><?php esc_html_e( 'Content:' ); ?></label>
<textarea id="{{ elementIdPrefix }}contents" class="widefat contents wp-editor-area" style="height: 200px" rows="16" cols="20"></textarea></p>
</script><?php
	}
}
add_action('widgets_init', function(){register_widget('DP_Custom_Text_Widget');});


/*******************************************************
* Custom Social widget
*******************************************************/
class DP_Custom_Social_Widget extends WP_Widget {
	public function __construct() {
		$widget_opts = array('classname' => 'dp_cusotom_social_widget', 
							 'description' => __('Site feed and SNS link widget provided by DigiPress', 'DigiPress') );
		$control_opts = array('width' => 200, 'height' => 300);
		parent::__construct('DPCustomSocialWidget', __('Custom Subscribe Link', 'DigiPress'), $widget_opts, $control_opts);
	}

	public function form($instance) {
		$instance = wp_parse_args((array)$instance, array('title' => 'Subscribe / Share', 
														  'rss' => true,
														  'to_feedly' => true,
														  'twitter' => '',
														  'facebook' => '',
														  'instagram' => '',
														  'pinterest' => '',
														  'youtube'	=> '',
														  'tiktok' => ''
														));

		$title		= strip_tags($instance['title']);
		$rss		= $instance['rss'];
		$to_feedly	= $instance['to_feedly'];
		$twitter	= strip_tags($instance['twitter']);
		$facebook	= strip_tags($instance['facebook']);
		$instagram	= strip_tags($instance['instagram']);
		$youtube	= strip_tags($instance['youtube']);
		$pinterest	= strip_tags($instance['pinterest']);
		$tiktok		= strip_tags($instance['tiktok']);

		$title_name		= $this->get_field_name('title');
		$title_id		= $this->get_field_id('title');
		$rssname		= $this->get_field_name('rss');
		$rssid			= $this->get_field_id('rss');
		$to_feedly_name	= $this->get_field_name('to_feedly');
		$to_feedly_id	= $this->get_field_id('to_feedly');
		$twittername	= $this->get_field_name('twitter');
		$twitterid		= $this->get_field_id('twitter');
		$facebookname	= $this->get_field_name('facebook');
		$facebookid		= $this->get_field_id('facebook');
		$instagramname	= $this->get_field_name('instagram');
		$instagramid	= $this->get_field_id('instagram');
		$youtubename	= $this->get_field_name('youtube');
		$youtubeid		= $this->get_field_id('youtube');
		$pinterestname	= $this->get_field_name('pinterest');
		$pinterestid	= $this->get_field_id('pinterest');
		$tiktokname		= $this->get_field_name('tiktok');
		$tiktokid		= $this->get_field_id('tiktok');

		$rsscheck;
		if ( $rss ) $rsscheck = ' checked';
		$to_feedly_check;
		if ( $to_feedly ) $to_feedly_check = ' checked';

		$code = '';

		$code = '<p><label for="' . $title_id . '">' . __( 'Title', 'DigiPress' ) . ':</label><br />';
		$code .= '<input type="text" name="' . $title_name . '" id="' . $title_id . '" value="' . $title . '" style="width:100%;" /></p>';
		$code .= '<p><span style="margin-left:4px;"><input name="' . $rssname . '" id="' . $rssid . '" type="checkbox" value="on"  ' . $rsscheck.' style="padding-bottom:12px;" /><label for="' . $rssid . '">' . __('Show RSS Icon','DigiPress' ) . '</label></span><br />';
		$code .= '<span style="margin-left:12px;">└ <input name="' . $to_feedly_name . '" id="' . $to_feedly_id . '" type="checkbox" value="true"  ' . $to_feedly_check.' /><label for="' . $to_feedly_id . '">' . __('Redirect to feedly','DigiPress' ) . '</label></span></p>';

		$code .= '<p><label for="' . $twitterid . '">' . __('Twitter URL','DigiPress') . ' :</label><br /><input type="text" name="' . $twittername . '" id="' . $twitterid . '" value="' . $twitter . '" style="width:100%;" /></p>';
		$code .= '<p><label for="' . $facebookid . '">' . __('Facebook URL','DigiPress' ) . ' :</label><br /><input type="text" name="' . $facebookname . '" id="' . $facebookid . '" value="' . $facebook . '" style="width:100%;" /></p>';
		$code .= '<p><label for="' . $instagramid . '">' . __('Instagram URL','DigiPress' ) . ' :</label><br /><input type="text" name="' . $instagramname . '" id="' . $instagramid . '" value="' . $instagram . '" style="width:100%;" /></p>';
		$code .= '<p><label for="' . $youtubeid . '">' . __('YouTube URL','DigiPress' ) . ' :</label><br /><input type="text" name="' . $youtubename . '" id="' . $youtubeid . '" value="' . $youtube . '" style="width:100%;" /></p>';
		$code .= '<p><label for="' . $pinterestid . '">' . __('Pinterest URL','DigiPress' ) . ' :</label><br /><input type="text" name="' . $pinterestname . '" id="' . $pinterestid . '" value="' . $pinterest . '" style="width:100%;" /></p>';
		$code .= '<p><label for="' . $tiktokid . '">' . __('TikTok URL','DigiPress' ) . ' :</label><br /><input type="text" name="' . $tiktokname . '" id="' . $tiktokid . '" value="' . $tiktok . '" style="width:100%;" /></p>';

		echo $code;
	}

	public function update($new_instance, $old_instance) {
		$instance['title']		= htmlspecialchars(stripslashes($new_instance['title']));
		$instance['rss']		= $new_instance['rss'];
		$instance['to_feedly']	= $new_instance['to_feedly'];
		$instance['twitter']	= $new_instance['twitter'];
		$instance['facebook']	= $new_instance['facebook'];
		$instance['instagram']	= $new_instance['instagram'];
		$instance['youtube']	= $new_instance['youtube'];
		$instance['pinterest']	= $new_instance['pinterest'];
		$instance['tiktok']		= $new_instance['tiktok'];

		return $instance;
	}

	public function widget($args, $instance) {
		extract($args);
		$instance = wp_parse_args((array)$instance, 
									array(
										'title'		=> '',
										'rss'		=> true,
										'to_feedly' => true,
										'twitter'	=> '',
										'facebook'	=> '',
										'instagram' => '',
										'youtube'	=> '',
										'pinterest'	=> '',
										'tiktok'	=> ''
									) );

		$title		= strip_tags($instance['title']);
		$title		= apply_filters('widget_title', $title);

		$code = $rss = '';

		if ( $instance['twitter'] ) {
			$rss = '<li><a href="'
						. $instance['twitter']
						. '" title="Follow on Twitter" target="_blank"><span><i class="icon-twitter"></i></span></a></li>';
		}
		if ( $instance['facebook']) {
			$rss .= '<li><a href="'
						. $instance['facebook']
						. '" title="Follow on Facebook" target="_blank"><span><i class="icon-facebook"></i></span></a></li>';
		}
		if ( $instance['instagram']) {
			$rss .= '<li><a href="'
						. $instance['instagram']
						. '" title="Follow on Instagram" target="_blank"><span><i class="icon-instagram"></i></span></a></li>';
		}
		if ( $instance['youtube']) {
			$rss .= '<li><a href="'
						. $instance['youtube']
						. '" title="Follow on YouTube" target="_blank"><span><i class="icon-youtube"></i></span></a></li>';
		}
		if ( $instance['pinterest']) {
			$rss .= '<li><a href="'
						. $instance['pinterest']
						. '" title="Follow on Pinterest" target="_blank"><span><i class="icon-pinterest"></i></span></a></li>';
		}
		if ( $instance['tiktok']) {
			$rss .= '<li><a href="'
						. $instance['tiktok']
						. '" title="Follow on TikTok" target="_blank"><span><i class="icon-tiktok"></i></span></a></li>';
		}
		if ( $instance['rss']) {
			if ( $instance['to_feedly']) {
				$rss .= '<li><a href="https://feedly.com/i/subscription/feed/' . urlencode(get_feed_link()) . '" target="_blank" title="Follow on feedly"><span><i class="icon-feedly"></i></span></a></li>';
			} else {
				$rss .= '<li><a href="'
					.get_bloginfo('rss2_url')
					. '" title="' . __('Subscribe feed', 'DigiPress')
					. '" target="_blank"><span><i class="icon-rss"></i></span></a></li>';
			}
		}

		// show widget
		$code = $before_widget;
		$code .= $before_title . $title . $after_title;
		$code .= '<ul class="dp_feed_widget clearfix"> ' . $rss . '</ul>';
		$code .= $after_widget;

		echo $code;
	}
}
add_action('widgets_init', function(){ register_widget( 'DP_Custom_Social_Widget' ); } );


/*******************************************************
* Twitter Follow widget
*******************************************************/
class DP_Twitter_Follow_Widget extends WP_Widget {
	public function __construct() {
		$widget_opts = array('classname' => 'dp_twitter_follow_widget', 
							 'description' => __('Twitter follow button widget provided by DigiPress', 'DigiPress') );
		$control_opts = array('width' => 200, 'height' => 300);
		parent::__construct('DPTwitterFollowWidget', __('Twitter Follow Button', 'DigiPress'), $widget_opts, $control_opts);
	}

	public function form($instance) {
		$instance = wp_parse_args((array)$instance, array('user' => '',
														  'size' => 'normal'));

		$user	= $instance['user'];
		$size		= $instance['size'];

		$user_name		= $this->get_field_name('user');
		$user_id		= $this->get_field_id('user');
		$size_name		= $this->get_field_name('size');
		$size_id		= $this->get_field_id('size');

		$size_check = '';
		if ($size === 'large') $size_check = ' checked';

		echo '<p><label for="' . $user_id . '">' . __('User ID', 'DigiPress' ) . ':</label><br />';
		echo '<input type="text" name="' . $user_name . '" id="' . $user_id . '" value="' . $user . '" style="width:100%;" /><br />' . __('*Note : Specify your twitter user_id(not user _name) that is excluded @(at) mark.', 'DigiPress') . '</p>';
		echo '<p><input name="' . $size_name . '" id="' . $size_id . '" type="checkbox" value="large"  ' . $size_check.' /><label for="' . $size_id . '">' . __('Large button', 'DigiPress' ) . '</label></p>';
	}

	public function update($new_instance, $old_instance) {
		$instance['user']		= $new_instance['user'];
		$instance['size']		= $new_instance['size'];
		return $instance;
	}

	public function widget($args, $instance) {
		extract($args);
		$instance = wp_parse_args((array)$instance, array('user' => '', 'size' => 'normal'));

		$code = '';
		if ( $instance['user']) {
			 if ( $instance['size'] == 'large') {
				$code = $before_widget	. '<a href="https://twitter.com/' . $instance['user'] . '" class="twitter-follow-button" data-show-count="false" data-size="large">Follow @' . $instance['user'] . '</a>' . $after_widget;
			 } else {
			 	$code = $before_widget	. '<a href="https://twitter.com/' . $instance['user'] . '" class="twitter-follow-button" data-show-count="false">Follow @' . $instance['user'] . '</a>' . $after_widget;
			 }
			// show widget
			echo $code;
		}
	}
}
add_action('widgets_init', function(){register_widget('DP_Twitter_Follow_Widget');});



/*******************************************************
* Feedly widget
*******************************************************/
class DP_Feedly_Widget extends WP_Widget {
	public function __construct() {
		$widget_opts = array('classname' => 'dp_feedly_widget', 
							 'description' => __('Follow on feedly widget provided by DigiPress', 'DigiPress') );
		$control_opts = array('width' => 200, 'height' => 300);
		parent::__construct('DPFeedlyWidget', __('Follow on feedly widget', 'DigiPress'), $widget_opts, $control_opts);
	}

	public function form($instance) {
		$instance = wp_parse_args((array)$instance, array('type' => 'rectangle-flat-big'));

		$type		= $instance['type'];
		$type_name	= $this->get_field_name('type');
		$type_id	= $this->get_field_id('type');

		$chk1 = $chk2 = $chk3 = $chk4 = $chk5 = $chk6 = $chk7 = $chk8 = $chk9 = $chk10 = $chk11 = $chk12 = $chk13 = '';

		switch ($type) {
			case 'rectangle-volume-big':
				$chk1 = ' checked';
				break;
			case 'rectangle-flat-big':
				$chk2 = ' checked';
				break;
			case 'rectangle-volume-medium':
				$chk3 = ' checked';
				break;
			case 'rectangle-flat-medium':
				$chk4 = ' checked';
				break;
			case 'rectangle-volume-small':
				$chk5 = ' checked';
				break;
			case 'rectangle-flat-small':
				$chk6 = ' checked';
				break;
			case 'square-volume':
				$chk7 = ' checked';
				break;
			case 'square-flat-green':
				$chk8 = ' checked';
				break;
			case 'circle-flat-green':
				$chk9 = ' checked';
				break;
			case 'logo-green':
				$chk10 = ' checked';
				break;
			case 'square-flat-black':
				$chk11 = ' checked';
				break;
			case 'circle-flat-black':
				$chk12 = ' checked';
				break;
			case 'logo-black':
				$chk13 = ' checked';
				break;
		}

		echo '<p>' . __('Button design:', 'DigiPress' ) . '</p>';

		echo '<input type="radio" name="' . $type_name . '" value="rectangle-volume-big" id="' . $type_id.'_1" style="position:relative;bottom:24px;"  ' . $chk1.' /> <label for="' . $type_id.'_1"><img src="//s3.feedly.com/img/follows/feedly-follow-rectangle-volume-big_2x.png" width="131" height="56" /></label><br />';
		echo '<input type="radio" name="' . $type_name . '" id="' . $type_id.'_2" value="rectangle-flat-big" style="position:relative;bottom:24px;"  ' . $chk2.' /> <label for="' . $type_id.'_2"><img src="//s3.feedly.com/img/follows/feedly-follow-rectangle-flat-big_2x.png" width="131" height="56" /></label><br />';
		echo '<span style="margin-right:12px;"><input type="radio" name="' . $type_name . '" id="' . $type_id.'_3" value="rectangle-volume-medium" style="position:relative;bottom:10px;"  ' . $chk3.' /> <label for="' . $type_id.'_3"><img src="//s3.feedly.com/img/follows/feedly-follow-rectangle-volume-medium_2x.png" width="71" height="28" /></label></span>';
		echo '<input type="radio" name="' . $type_name . '" id="' . $type_id.'_4" value="rectangle-flat-medium" style="position:relative;bottom:10px;"  ' . $chk4.' /> <label for="' . $type_id.'_4"><img src="//s3.feedly.com/img/follows/feedly-follow-rectangle-flat-medium_2x.png" width="71" height="28" /></label><br />';
		echo '<span style="margin-right:17px;"><input type="radio" name="' . $type_name . '" id="' . $type_id.'_5" value="rectangle-volume-small" style="position:relative;bottom:6px;"  ' . $chk5.' /> <label for="' . $type_id.'_5"><img src="//s3.feedly.com/img/follows/feedly-follow-rectangle-volume-small_2x.png" width="66" height="20" /></label></span>';
		echo '<input type="radio" name="' . $type_name . '" id="' . $type_id.'_6" value="rectangle-flat-small" style="position:relative;bottom:6px;"  ' . $chk6.' /> <label for="' . $type_id.'_6"><img src="//s3.feedly.com/img/follows/feedly-follow-rectangle-flat-small_2x.png" width="66" height="20" /></label><br />';

		echo '<span style="margin-right:10px;"><input type="radio" name="' . $type_name . '" id="' . $type_id.'_7" value="square-volume" style="position:relative;bottom:10px;"  ' . $chk7.' /> <label for="' . $type_id.'_7"><img src="//s3.feedly.com/img/follows/feedly-follow-square-volume_2x.png" width="28" height="28" /></label></span>';
		echo '<span style="margin-right:10px;"><input type="radio" name="' . $type_name . '" id="' . $type_id.'_8" value="square-flat-green" style="position:relative;bottom:10px;"  ' . $chk8.' /> <label for="' . $type_id.'_8"><img src="//s3.feedly.com/img/follows/feedly-follow-square-flat-green_2x.png" width="28" height="28" /></label></span>';
		echo '<span style="margin-right:10px;"><input type="radio" name="' . $type_name . '" id="' . $type_id.'_9" value="circle-flat-green" style="position:relative;bottom:10px;"  ' . $chk9.' /> <label for="' . $type_id.'_9"><img src="//s3.feedly.com/img/follows/feedly-follow-circle-flat-green_2x.png" width="28" height="28" /></label></span>';
		echo '<span style="margin-right:10px;"><input type="radio" name="' . $type_name . '" id="' . $type_id.'_10" value="logo-green" style="position:relative;bottom:10px;"  ' . $chk10.' /> <label for="' . $type_id.'_10"><img src="//s3.feedly.com/img/follows/feedly-follow-logo-green_2x.png" width="28" height="28" /></label></span>';

		echo '<span style="margin-right:10px;"><input type="radio" name="' . $type_name . '" id="' . $type_id.'_11" value="square-flat-black" style="position:relative;bottom:10px;"  ' . $chk11.' /> <label for="' . $type_id.'_11"><img src="//s3.feedly.com/img/follows/feedly-follow-square-flat-black_2x.png" width="28" height="28" /></label></span>';
		echo '<span style="margin-right:10px;"><input type="radio" name="' . $type_name . '" id="' . $type_id.'_12" value="circle-flat-black" style="position:relative;bottom:10px;"  ' . $chk12.' /> <label for="' . $type_id.'_12"><img src="//s3.feedly.com/img/follows/feedly-follow-circle-flat-black_2x.png" width="28" height="28" /></label></span>';
		echo '<span style="margin-right:10px;"><input type="radio" name="' . $type_name . '" id="' . $type_id.'_13" value="logo-black" style="position:relative;bottom:10px;"  ' . $chk13.' /> <label for="' . $type_id.'_13"><img src="//s3.feedly.com/img/follows/feedly-follow-logo-black_2x.png" width="28" height="28" /></label></span>';
	}

	public function update($new_instance, $old_instance) {
		$instance['type']		= $new_instance['type'];
		return $instance;
	}

	public function widget($args, $instance) {
		extract($args);
		$instance = wp_parse_args((array)$instance, array('type' => ''));

		$imgUrl = '';
		if ( $instance['type']) {
			switch ($instance['type']) {
				case 'rectangle-volume-big':
					$imgUrl = '<img id="feedlyFollow" src="//s3.feedly.com/img/follows/feedly-follow-rectangle-volume-big_2x.png" alt="follow us in feedly" width="131" height="56" />';
					break;
				case 'rectangle-volume-medium':
					$imgUrl = '<img id="feedlyFollow" src="//s3.feedly.com/img/follows/feedly-follow-rectangle-volume-medium_2x.png" alt="follow us in feedly" width="71" height="28" />';
					break;
				case 'rectangle-volume-small':
					$imgUrl = '<img id="feedlyFollow" src="//s3.feedly.com/img/follows/feedly-follow-rectangle-volume-small_2x.png" alt="follow us in feedly" width="66" height="20" />';
					break;
				case 'square-volume':
					$imgUrl = '<img id="feedlyFollow" src="//s3.feedly.com/img/follows/feedly-follow-square-volume_2x.png" alt="follow us in feedly" width="28" height="28" />';
					break;
				case 'square-flat-green':
					$imgUrl = '<img id="feedlyFollow" src="//s3.feedly.com/img/follows/feedly-follow-square-flat-green_2x.png" alt="follow us in feedly" width="28" height="28" />';
					break;
				case 'circle-flat-green':
					$imgUrl = '<img id="feedlyFollow" src="//s3.feedly.com/img/follows/feedly-follow-circle-flat-green_2x.png" alt="follow us in feedly" width="28" height="28" />';
					break;
				case 'logo-green':
					$imgUrl = '<img id="feedlyFollow" src="//s3.feedly.com/img/follows/feedly-follow-logo-green_2x.png" alt="follow us in feedly" width="28" height="28" />';
					break;
				case 'square-flat-black':
					$imgUrl = '<img id="feedlyFollow" src="//s3.feedly.com/img/follows/feedly-follow-square-flat-black_2x.png" alt="follow us in feedly" width="28" height="28" />';
					break;
				case 'circle-flat-black':
					$imgUrl = '<img id="feedlyFollow" src="//s3.feedly.com/img/follows/feedly-follow-circle-flat-black_2x.png" alt="follow us in feedly" width="28" height="28" />';
					break;
				case 'logo-black':
					$imgUrl = '<img id="feedlyFollow" src="//s3.feedly.com/img/follows/feedly-follow-logo-black_2x.png" alt="follow us in feedly" width="28" height="28" />';
					break;
				case 'rectangle-flat-big':
					$imgUrl = '<img id="feedlyFollow" src="//s3.feedly.com/img/follows/feedly-follow-rectangle-flat-big_2x.png" alt="follow us in feedly" width="131" height="56" />';
					break;
				case 'rectangle-flat-medium':
					$imgUrl = '<img id="feedlyFollow" src="//s3.feedly.com/img/follows/feedly-follow-rectangle-flat-medium_2x.png" alt="follow us in feedly" width="71" height="28" />';
					break;
				case 'rectangle-flat-small':
					$imgUrl = '<img id="feedlyFollow" src="//s3.feedly.com/img/follows/feedly-follow-rectangle-flat-small_2x.png" alt="follow us in feedly" width="66" height="20" />';
					break;
			}

			$code = $before_widget . '<a href="https://feedly.com/i/subscription/feed/'.urlencode(get_feed_link()) . '" target="_blank" title="Follow on feedly"> ' . $imgUrl.'</a>'. $after_widget;

			// show widget
			echo $code;
		}
	}
}
add_action('widgets_init', function(){register_widget('DP_Feedly_Widget');});



/*******************************************************
* Facebook Like box widget
*******************************************************/
class DP_Facebook_Like_Box_Widget extends WP_Widget {
	public function __construct() {
		$widget_opts = array('classname' => 'dp_facebook_like_box_widget', 
							 'description' => __('Facebook Page Plugin provided by DigiPress', 'DigiPress') );
		$control_opts = array('width' => 200, 'height' => 300);
		parent::__construct('DPFacebookLikeBoxWidget', __('DP - Facebook Page Plugin', 'DigiPress'), $widget_opts, $control_opts);
		add_action('wp_enqueue_scripts', array(&$this, 'fbLikeBoxCheck'));
	}

	function fbLikeBoxCheck() {
		global $EXIST_FB_LIKE_BOX;
		if ( is_active_widget(false, false, $this->id_base, true) ) {
			$EXIST_FB_LIKE_BOX = true;
		} else {
			$EXIST_FB_LIKE_BOX = false;
		}
	}

	public function form($instance) {
		$instance = wp_parse_args((array)$instance, array('app_id'		=> '',
														  'url'			=> '',
														  'width' 		=> '',
														  'height' 		=> '',
														  'show_faces' 	=> true,
														  'show_strm'	=> false,
														  'hide_cover'	=> false,
														  'small_header'=> false));

		$app_id		= $instance['app_id'];
		$url		= $instance['url'];
		$width		= $instance['width'];
		$height		= $instance['height'];
		$show_faces	= $instance['show_faces'];
		$show_strm	= $instance['show_strm'];
		$hide_cover = $instance['hide_cover'];
		$small_header = $instance['small_header'];

		$app_id_name		= $this->get_field_name('app_id');
		$app_id_id			= $this->get_field_id('app_id');
		$url_name			= $this->get_field_name('url');
		$url_id				= $this->get_field_id('url');
		$width_name			= $this->get_field_name('width');
		$width_id			= $this->get_field_id('width');
		$height_name		= $this->get_field_name('height');
		$height_id			= $this->get_field_id('height');
		$show_faces_name	= $this->get_field_name('show_faces');
		$show_faces_id		= $this->get_field_id('show_faces');
		$show_strm_name		= $this->get_field_name('show_strm');
		$show_strm_id		= $this->get_field_id('show_strm');
		$hide_cover_name	= $this->get_field_name('hide_cover');
		$hide_cover_id		= $this->get_field_id('hide_cover');
		$small_header_name	= $this->get_field_name('small_header');
		$small_header_id		= $this->get_field_id('small_header');

		// Check box
		$show_faces_check = ($show_faces) ? 'checked' : '';
		$show_strm_check = ($show_strm) ? 'checked' : '';
		$hide_cover_check = ($hide_cover) ? 'checked' : '';
		$small_header_check = ($small_header) ? 'checked' : '';

		$strTag = '<p><label for="' . $app_id_id . '">' . __('App ID', 'DigiPress' ) . '(*):</label><br />' . 
				  '<input type="text" name="' . $app_id_name . '" id="' . $app_id_id . '" value="' . $app_id . '" style="width:100%;" /><br /><span class="ft12px">' . __('*Note : You need to register as a <a href="https://developers.facebook.com/apps/" target="_blank">Facebook developer</a> bedore you show this widget.', 'DigiPress') . '</span></p>' .
				  '<p><label for="' . $url_id . '">' . __('Facebook Page URL', 'DigiPress' ) . '(*):</label><br />' . 
				  '<input type="text" name="' . $url_name . '" id="' . $url_id . '" value="' . $url . '" style="width:100%;" /></p>' .
				  '<p><label for="' . $width_id . '">' . __('Width', 'DigiPress' ) . ':</label><br />' . 
				  '<input type="text" name="' . $width_name . '" id="' . $width_id . '" value="' . $width . '" style="width:60%;" />px<br /><span class="ft12px">' . __('*Note: Default:340px, Range:280px-500px','DigiPress' ) . '</span></p>' .
				  '<p><label for="' . $height_id . '">' . __('Max Height', 'DigiPress' ) . ':</label><br />' . 
				  '<input type="text" name="' . $height_name . '" id="' . $height_id . '" value="' . $height . '" style="width:60%;" />px<br /><span class="ft12px">' . __('*Note: Default:500px, Min:130px','DigiPress' ) . '</span></p>' .
				  '<p><input name="' . $show_faces_name . '" id="' . $show_faces_id . '" type="checkbox" value="large"  ' . $show_faces_check.' /><label for="' . $show_faces_id . '">' . __('Show Face Piles', 'DigiPress' ) . '</label></p>'. 
			 	  '<p><input name="' . $show_strm_name . '" id="' . $show_strm_id . '" type="checkbox" value="large"  ' . $show_strm_check.' /><label for="' . $show_strm_id . '">' . __('Show Posts from the Page\'s timeline', 'DigiPress' ) . '</label></p>'.
			 	  '<p><input name="' . $small_header_name . '" id="' . $small_header_id . '" type="checkbox" value="large"  ' . $small_header_check.' /><label for="' . $small_header_id . '">' . __('Use small header', 'DigiPress' ) . '</label></p>'.
			 	  '<p><input name="' . $hide_cover_name . '" id="' . $hide_cover_id . '" type="checkbox" value="large"  ' . $hide_cover_check.' /><label for="' . $hide_cover_id . '">' . __('Hide Cover Photo', 'DigiPress' ) . '</label></p>';

		echo $strTag;
	}

	public function update($new_instance, $old_instance) {
		$instance['app_id']		= $new_instance['app_id'];
		$instance['url']		= $new_instance['url'];
		$instance['width']		= $new_instance['width'];
		$instance['height']		= $new_instance['height'];
		$instance['show_faces']	= $new_instance['show_faces'];
		$instance['show_strm']	= $new_instance['show_strm'];
		$instance['hide_cover']= $new_instance['hide_cover'];
		$instance['small_header']= $new_instance['small_header'];

		return $instance;
	}

	public function widget($args, $instance) {
		extract($args);
		$instance = wp_parse_args((array)$instance, array('app_id'		=> '',
														  'url'			=> '',
														  'width' 		=> '',
														  'height' 		=> '',
														  'show_faces' 	=> true,
														  'show_strm'	=> false,
														  'hide_cover'	=> false,
														  'small_header'=> false));

		global $FB_APP_ID;
		$code = '';

		if ( $instance['app_id'] != '' && $instance['url'] != '') {
			$FB_APP_ID		= $instance['app_id'];
			$url			= $instance['url'];
			$tagWidth 		= ($instance['width'] != '') ? ' data-width="' . $instance['width'] . '"' : '';
			$tagHeight		= ($instance['height'] != '') ? ' data-height="' . $instance['height'] . '"' : '';
			$tagFaces		= ($instance['show_faces']) ? ' data-show-facepile="true"' : ' data-show-facepile="false"';
			$tagStream		= ($instance['show_strm']) ? ' data-tabs="timeline"' : '';
			$tagHideCover		= ($instance['hide_cover']) ? ' data-hide-cover="true"' : ' data-hide-cover="false"';
			$tagSmallHeader	= ($instance['small_header']) ? ' data-small-header="true"' : ' data-small-header="false"';

			$code = '<div class="fb-page" data-href="' . $url . '" data-adapt-container-width="true" ' . $tagWidth.$tagHeight.$tagFaces.$tagStream.$tagHideCover.$tagSmallHeader.'><blockquote cite="' . $url . '" class="fb-xfbml-parse-ignore"><a href="' . $url . '">' . get_bloginfo('name' ) . '</a></blockquote></div>';

			// show widget
			echo $code;
		}
	}
}
add_action('widgets_init', function(){register_widget('DP_Facebook_Like_Box_Widget');});


/*******************************************************
* Hatena Bookmark popular posts widget
*******************************************************/
class DP_Hatebu_Popular_Posts_Widget extends WP_Widget {
	public function __construct() {
		$widget_opts = array('classname' => 'dp_hatebu_popular_posts_widget', 
							 'description' => __('Show the lists of opular posts in Hatena bookmark widget provided by DigiPress', 'DigiPress') );
		$control_opts = array('width' => 200, 'height' => 300);
		parent::__construct('DPHatebuPopularPostsWidget', __('Popular posts in Hatena bookmark', 'DigiPress'), $widget_opts, $control_opts);
	}

	public function form($instance) {
		$instance = wp_parse_args((array)$instance, array('title'	=> __('Bookmarked Entry', 'DigiPress'),
														  'type'	=> 'count',
														  'width' 	=> '300',
														  'number' 	=> 5,
														  'theme'	=> 'default'));

		$title		= $instance['title'];
		$type		= $instance['type'];
		$width		= $instance['width'];
		$number		= $instance['number'];
		$theme		= $instance['theme'];

		$title_name		= $this->get_field_name('title');
		$title_id		= $this->get_field_id('title');
		$type_name		= $this->get_field_name('type');
		$type_id		= $this->get_field_id('type');
		$width_name		= $this->get_field_name('width');
		$width_id		= $this->get_field_id('width');
		$number_name	= $this->get_field_name('number');
		$number_id		= $this->get_field_id('number');
		$theme_name		= $this->get_field_name('theme');
		$theme_id		= $this->get_field_id('theme');?>

		<p><label for="<?php echo $title_id; ?>"><?php _e('Title', 'DigiPress'); ?>:</label><br />
		<input type="text" name="<?php echo $title_name; ?>" id="<?php echo $title_id; ?>" value="<?php echo $title; ?>" style="width:100%;" /></p>
		<p><label for="<?php echo $type_name; ?>" style="padding-bottom:4px;"><?php _e('Type', 'DigiPress'); ?>:</label><br />
		<input type="radio" name="<?php echo $type_name; ?>" id="<?php echo $type_id; ?>1" value="hot" <?php if ($type == 'hot') echo 'checked'; ?> /><label for="<?php echo $type_id; ?>1" style="margin-right:12px;"> <?php _e('Recent Posts', 'DigiPress'); ?></label>
		<input type="radio" name="<?php echo $type_name; ?>" id="<?php echo $type_id; ?>2" value="count" <?php if($type == 'count') echo 'checked'; ?> /><label for="<?php echo $type_id; ?>2"> <?php _e('Popular Posts', 'DigiPress'); ?></label></p>
		<p><label for="<?php echo $width_id; ?>"><?php _e('Width (pixel)', 'DigiPress'); ?>:</label><br />
		<input type="text" name="<?php echo $width_name; ?>" id="<?php echo $width_id; ?>" value="<?php echo $width; ?>" style="width:100%;" /><br /><span class="ft12px"><?php _e('*Note: Only digit(pixel) . ', 'DigiPress'); ?></span></p>
		<p><label for="<?php echo $number_name; ?>"><?php _e('Number of posts', 'DigiPress'); ?>:</label><br />
		<select name="<?php echo $number_name; ?>" size="1" style="width:100%;">
			<option value="1" <?php if ($number == 1) echo 'selected' ; ?>>1</option>
			<option value="2" <?php if ($number == 2) echo 'selected' ; ?>>2</option>
			<option value="3" <?php if ($number == 3) echo 'selected' ; ?>>3</option>
			<option value="4" <?php if ($number == 4) echo 'selected' ; ?>>4</option>
			<option value="5" <?php if ($number == 5) echo 'selected' ; ?>>5</option>
			<option value="6" <?php if ($number == 6) echo 'selected' ; ?>>6</option>
			<option value="7" <?php if ($number == 7) echo 'selected' ; ?>>7</option>
			<option value="8" <?php if ($number == 8) echo 'selected' ; ?>>8</option>
			<option value="9" <?php if ($number == 9) echo 'selected' ; ?>>9</option>
			<option value="10" <?php if ($number == 10) echo 'selected' ; ?>>10</option>
		</select></p>
		<p><label for="' . $theme_name . '"><?php _e('Theme', 'DigiPress'); ?>:</label><br />
		<select name="<?php echo $theme_name; ?>" size="1" style="width:100%;">
			<option value="default" <?php if ($theme == 'default') echo 'selected' ; ?>><?php _e('Default', 'DigiPress'); ?></option>
			<option value="mytheme" <?php if ($theme == 'mytheme') echo 'selected' ; ?>><?php _e('Suitable for this theme', 'DigiPress'); ?></option>
			<option value="notheme" <?php if ($theme == 'notheme') echo 'selected' ; ?>><?php _e('None', 'DigiPress'); ?></option>
		</select></p>
<?php }		// End of form function.

	public function update($new_instance, $old_instance) {
		$instance['title']	= htmlspecialchars(stripslashes($new_instance['title']));
		$instance['type']	= $new_instance['type'];
		$instance['width']	= $new_instance['width'];
		$instance['number']	= $new_instance['number'];
		$instance['theme']	= $new_instance['theme'];

		return $instance;
	}

	public function widget($args, $instance) {
		extract($args);
		$instance = wp_parse_args((array)$instance, array('title'	=> __('Bookmarked Entry', 'DigiPress'),
														  'type'	=> 'count',
														  'width' 	=> '300',
														  'number' 	=> '5',
														  'theme'	=> 'default'));

		$title = apply_filters('widget_title', $instance['title'], $instance, $this->id_base);
		$theme = $instance['theme'];

		// CSS
		$css = '';
		if ( $instance['theme'] == 'mytheme') {
			$theme = 'notheme';
			$css = 
'<style type="text/css">
.hatena-bookmark-widget-title {
	display:none;
}
.hatena-bookmark-widget-body li {
	padding:6px 0 6px 0;
	border-bottom:1px dotted #bbb;
}
.hatena-bookmark-entrytitle {
	font-size:12px;
	line-height:148%;
}
.hatena-bookmark-count,
.hatena-bookmark-widget-footer {
	display:block;
	margin:0 0 0 auto;
	text-align:right;
}
.hatena-bookmark-count a{
	color:#ff0000;
	background-color:#ffd5d5;
	font-size:10px;
	font-weight:bold;
	text-decoration:underline;
	height:16px;
}
</style>';
		}
		$css = str_replace(array("\r\n","\r","\n", "\t"), '', $css);

$code = '<div class="shadow-none"> ' . $css.'<script language="javascript" type="text/javascript" src="//b.hatena.ne.jp/js/widget.js" charset="utf-8"></script><script language="javascript" type="text/javascript">Hatena.BookmarkWidget.url   = "'.home_url() . '";Hatena.BookmarkWidget.title = "";Hatena.BookmarkWidget.sort  = " ' . $instance['type'] . '";Hatena.BookmarkWidget.width = " ' . $instance['width'] . '";Hatena.BookmarkWidget.num   = " ' . $instance['number'] . '";Hatena.BookmarkWidget.theme = " ' . $theme . '";Hatena.BookmarkWidget.load();</script></div>';

		// show
		echo $before_widget;
		if ( $title ) echo $before_title . $title . $after_title;
		echo $code . $after_widget;
	}
}
add_action('widgets_init', function(){register_widget('DP_Hatebu_Popular_Posts_Widget');});