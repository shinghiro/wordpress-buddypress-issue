<?php
function dp_override_widget_recent_comments() {
	class DP_Widget_Recent_Comments extends WP_Widget {

		public function __construct() {
			$widget_ops = array(
				'classname' => 'widget_recent_comments',
				'description' => __( 'Your site&#8217;s most recent comments.' ),
				'customize_selective_refresh' => true,
			);
			parent::__construct( 'recent-comments', __( 'Recent Comments' ), $widget_ops );
			$this->alt_option_name = 'widget_recent_comments';

			if ( is_active_widget( false, false, $this->id_base ) || is_customize_preview() ) {
				add_action( 'wp_head', array( $this, 'recent_comments_style' ) );
			}
		}

		public function recent_comments_style() {
			return;
		}

		public function widget( $args, $instance ) {
			// default value
			$instance = wp_parse_args(
				(array)$instance, array(
					'title' => __( 'Recent Comments' ),
					'number' => 5,
					'str_count' => 80,
					'avatar' => true,
					'author_not_in' => 0,
					'show_date' => true,
					'include_time' => false,
					'post_id' => null,
					'search' => ''
					)
			);

			if ( ! isset( $args['widget_id'] ) )
				$args['widget_id'] = $this->id;
			// Params
			$title = ( ! empty( $instance['title'] ) ) ? $instance['title'] : __( 'Recent Comments' );
			/** This filter is documented in wp-includes/widgets/class-wp-widget-pages.php */
			$title = apply_filters( 'widget_title', $title, $instance, $this->id_base );
			$number = ( isset($instance['number']) && ! empty( $instance['number'] ) ) ? absint( $instance['number'] ) : 5;
			$str_count = ( ! empty( $instance['str_count'] ) ) ? absint( $instance['str_count'] ) : 80;
			$avatar = ( isset($instance['avatar']) && ! empty( $instance['avatar'] ) ) ? true : false;
			$author_not_in = ( isset($instance['author_not_in']) && ! empty( $instance['author_not_in'] ) ) ? 1 : 0;
			$show_date = ( isset($instance['show_date']) && ! empty( $instance['show_date'] ) ) ? true : false;
			$include_time = ( isset($instance['include_time']) && ! empty( $instance['include_time'] ) ) ? true : false;
			$post_id = ( isset($instance['post_id']) && ! empty( $instance['post_id'] ) ) ? absint($instance['post_id']) : null;
			$search = ( isset($instance['search']) && ! empty( $instance['search'] ) ) ? $instance['search'] : '';

			$output = '';

			// Get comments
			$comments = get_comments( apply_filters( 'widget_comments_args', array(
				'number'      => $number,
				'status'      => 'approve',
				'type' => 'comment',
				'author__not_in' => $author_not_in,
				'post_id' => $post_id,
				'search' => $search,
				'post_status' => 'publish'
			), $instance ) );

			$output .= $args['before_widget'];
			if ( $title ) {
				$output .= $args['before_title'] . $title . $args['after_title'];
			}

			$output .= '<div class="dp_comment_list_section as-wdgt"><ul class="commentlist">';
			if ( is_array( $comments ) && $comments ) {
				// Prime cache for associated posts. (Prime post term cache if we need it for permalinks.)
				$post_ids = array_unique( wp_list_pluck( $comments, 'comment_post_ID' ) );
				_prime_post_caches( $post_ids, strpos( get_option( 'permalink_structure' ), '%category%' ), false );

				foreach ( (array) $comments as $comment ) {
					$author_url_pre = $author_url_suf = '';
					$com_link = esc_url( get_comment_link( $comment ) );
					$output .= '<li class="comment"><div class="comment-author">';
					// Author url
					if (!empty($comment->comment_author_url)){
						$author_url_pre = '<a href="'.$comment->comment_author_url.'" rel="external nofollow" class="url" target="_blank">';
						$author_url_suf = '</a>';
					}
					// avatar
					if ($avatar){
						$avatar_img = get_avatar( $comment, 28 );
						$output .= '<div class="comment-avatar com-inline as-wdgt">' . $avatar_img . '</div>';
					} else {
						$output .= '<i class="icon-user"></i>';
					}
					$output .= $author_url_pre . '<span class="author-name com-inline">' . $comment->comment_author . '</span>' . $author_url_suf;
					// Date
					if ($show_date){
						$comment_date = '';
						if ($include_time) {
							$comment_date = $comment->comment_date;
						} else {
							$comment_date = get_comment_date(get_option('date_format'), $comment->comment_ID);
						}
						$output .= '<span class="cmt-date com-inline">' . $comment_date . '</span>';
					}
					// End of meta
					$output .= '</div>';
					// target post link
					$output .= '<div class="comment-author cmt-post-link icon-right-light"> "<a href="' . $com_link . '">' . get_the_title( $comment->comment_post_ID ) . '</a>"</div>';
					// Comment
					if ($str_count > 0) {
						$comment_content = strip_tags($comment->comment_content);
						if (mb_strlen($comment_content,"UTF-8") > $str_count) {
							$comment_content = mb_substr($comment_content, 0, $str_count).'...<a href="' . $com_link . '" class="more"><i class="icon-written-doc"></i></a>';
						}
						$output .= '<div class="cmt-str icon-comment"> '. $comment_content . '</div>';
					}
					$output .= '</li>';
				}
			}
			$output .= '</ul></div>';
			$output .= $args['after_widget'];

			echo $output;
		}

		public function update( $new_instance, $old_instance ) {
			$instance = $old_instance;
			$instance['title'] = sanitize_text_field( $new_instance['title'] );
			$instance['number'] = absint( $new_instance['number'] );
			$instance['avatar'] = $new_instance['avatar'];
			$instance['show_date'] = $new_instance['show_date'];
			$instance['include_time'] = $new_instance['include_time'];
			$instance['author_not_in'] = $new_instance['author_not_in'];
			$instance['str_count'] = absint( $new_instance['str_count'] );
			$instance['post_id'] = absint( $new_instance['post_id'] );
			$instance['search'] = sanitize_text_field($new_instance['search'] );
			return $instance;
		}

		public function form( $instance ) {
			$title = isset( $instance['title'] ) ? $instance['title'] : '';
			$number = isset( $instance['number'] ) ? absint( $instance['number'] ) : 5;
			$avatar = isset( $instance['avatar'] ) && !empty($instance['avatar']) ? true : false;
			$show_date = isset( $instance['show_date'] ) && !empty($instance['show_date']) ? true : false;
			$include_time = isset( $instance['include_time'] ) && !empty($instance['include_time']) ? true : false;
			$author_not_in = isset( $instance['author_not_in'] ) && !empty($instance['author_not_in']) ? true : false;
			$str_count = isset( $instance['str_count'] ) ? absint( $instance['str_count'] ) : 80;
			$post_id = isset( $instance['post_id'] ) && !empty($instance['post_id'])  ? absint($instance['post_id']) : null;
			$search = isset( $instance['search'] ) ? $instance['search'] : '';
?>
<p><label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Title:' ); ?></label><input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" /></p>

<p><label for="<?php echo $this->get_field_id( 'number' ); ?>"><?php _e( 'Number of comments to show:' ); ?></label>
<input class="tiny-text" id="<?php echo $this->get_field_id( 'number' ); ?>" name="<?php echo $this->get_field_name( 'number' ); ?>" type="number" step="1" min="1" value="<?php echo $number; ?>" size="3" /></p>

<p><label for="<?php echo $this->get_field_id( 'avatar' ); ?>"><input class="widefat" id="<?php echo $this->get_field_id( 'avatar' ); ?>" name="<?php echo $this->get_field_name( 'avatar' ); ?>" type="checkbox"<?php if (isset($avatar) && !empty($avatar)) echo " checked"; ?> value="1" /><?php _e('Display avatar','DigiPress'); ?></label></p>

<p><label for="<?php echo $this->get_field_id( 'show_date' ); ?>"><input class="widefat" id="<?php echo $this->get_field_id( 'show_date' ); ?>" name="<?php echo $this->get_field_name( 'show_date' ); ?>" type="checkbox"<?php if (isset($show_date) && !empty($show_date)) echo " checked"; ?> value="1" /><?php _e('Display commented date','DigiPress'); ?></label>
	<label for="<?php echo $this->get_field_id( 'include_time' ); ?>" style="display:block;margin:8px auto auto 15px;"><input class="widefat" id="<?php echo $this->get_field_id( 'include_time' ); ?>" name="<?php echo $this->get_field_name( 'include_time' ); ?>" type="checkbox"<?php if (isset($include_time) && !empty($include_time)) echo " checked"; ?> value="1" /><?php _e('Include time','DigiPress'); ?></label></p>

<p><label for="<?php echo $this->get_field_id( 'author_not_in' ); ?>"><input class="widefat" id="<?php echo $this->get_field_id( 'author_not_in' ); ?>" name="<?php echo $this->get_field_name( 'author_not_in' ); ?>" type="checkbox"<?php if (isset($author_not_in) && !empty($author_not_in)) echo " checked"; ?> value="1" /><?php _e('Exclude author\'s comments','DigiPress'); ?></label></p>

<p><label for="<?php echo $this->get_field_id( 'str_count' ); ?>"><?php _e( 'Number of comment chars:', 'DigiPress' ); ?></label><input id="<?php echo $this->get_field_id( 'str_count' ); ?>" name="<?php echo $this->get_field_name( 'str_count' ); ?>" type="number" step="1" min="0" max="500" value="<?php echo $str_count; ?>" size="5" /></p>

<p><label for="<?php echo $this->get_field_id( 'post_id' ); ?>"><?php _e( 'Target post ID:', 'DigiPress' ); ?></label><input id="<?php echo $this->get_field_id( 'post_id' ); ?>" name="<?php echo $this->get_field_name( 'post_id' ); ?>" type="text" value="<?php echo $post_id; ?>" /><br /><span style="display:block;font-size:11px;margin:5px 0 1em;"><?php _e('*If you want to restrict to only comments on arbitrary posts, specify the post ID.', 'DigiPress'); ?></span></p>

<p><label for="<?php echo $this->get_field_id( 'search' ); ?>"><?php _e( 'Search words:', 'DigiPress' ); ?></label><input class="widefat" id="<?php echo $this->get_field_id( 'search' ); ?>" name="<?php echo $this->get_field_name( 'search' ); ?>" type="text" value="<?php echo $search; ?>" /><br /><span style="display:block;font-size:11px;margin:5px 0;"><?php _e('*To extract only comments including arbitrary words, specify that keyword.', 'DigiPress'); ?></span></p>
<?php
		}

		/**
		 * Flushes the Recent Comments widget cache.
		 */
		public function flush_widget_cache() {
			_deprecated_function( __METHOD__, '4.4.0' );
		}
	}
	unregister_widget( 'WP_Widget_Recent_Comments' );
	register_widget( 'DP_Widget_Recent_Comments' );
}
add_action( 'widgets_init', 'dp_override_widget_recent_comments' );