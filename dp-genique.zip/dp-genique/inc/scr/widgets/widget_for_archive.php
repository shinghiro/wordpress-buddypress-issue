<?php
/**
 * Widgets for archive (post listing)
 * 
 */
/*******************************************************
* Get posts by get_posts Query
*******************************************************/
function DP_LISTING_POST_EACH_STYLES( $args ) {
	// Defauls and parse params
	$args = wp_parse_args(
			(array)$args,
			array(
				'id' => '',
				'echo'=> true,
				'number' 	=> 5,
				'show_cat'	=> true,
				'views'=> false,
				'author'	=> true,
				'comment'	=> false,
				'orderby'	=> 'date',
				'order' => 'DESC',
				'hatebu_num'	=> false,
				'tweets_num'	=> false,
				'likes_num'	=> false,
				'loop_col' => 3,
				'cat_id'	=> '',
				'authors_id'=> '',
				'tag_id' => '',
				'tag_slug' => '',
				'keyword' => '',
				'meta_key'	=> '',
				'meta_value' => '',
				'post_type'	=> 'post',
				'year'=> '',
				'month'=> '',
				'pub_date'	=> false,
				'type'=> '',
				'more_text'	=> 'More',
				'more_url'	=> '',
				'read_more_str' => 'Read More',
				'voted_icon' => '',
				'voted_count' => false,
				'layout'	=> 'normal',
				'excerpt_length' => 120,
				'loop_col' => 3,
				'one_col' => false,
				'use_filter' => false,
				'filter_exclude_cat' => '',
				'fix_thumb_h' => true,
				'overlay_color'=> 'cat',
				'slider_mode' => 'carousel',
				'slider_speed' => 800,
				'slider_duration' => 3000,
				'slider_navigation' => false,
				'slider_control_btn' => true,
				'article_box_shadow' => false,
				'article_round_corner' => false,
				'magazine_cover_frame' => '',
				'magazine_cover_frame_color' => '#ffffff',
				'magazine_title_position' => '',
				'magazine_title_color' => '#ffffff',
				'magazine_title_back' => '',
				'magazine_title_back_color' => '',
				'magazine_title_back_color_opacity' => '',
				'magazine_title_back_border' => '',
				'magazine_title_by_bold' => '',
				'magazine_title_tilt' => '',
				'magazine_text_by_serif' => '',
				'magazine_text_vertically' => '',
				'magazine_date_design' => 'date1',
				'magazine_accent_shape' => '',
				'magazine_accent_shape_color' => '#ffffff',
				'magazine_accent_shape_opacity' => 30,
	) );

	// Import require functions
	require_once( DP_THEME_DIR . "/inc/scr/generator/listing_post_styles.php" );

	global $options, $post, $COLUMN_NUM, $IS_MOBILE_DP;

	// Counter
	$i = 0;

	// Params
	$loop_section_class = 'loop-section lp-widget ' . $args['layout'];
	$html_code = $loop_code = $grid_size = $isotope_grid_gutter = $slider_trigger_class = $slider_code = $thumbnav_code = $slider_mode_class = $slider_pagenation_code = $slider_nav_btn_code = $slider_number = $slider_nav_id = $slider_page_nav_id = $suffix_mb = $filter_form = $loop_section_style = $col_class = '';
	$main_js = 'main.min.js';


	// Adjust params
	$args['cat_id'] = isset( $args['cat_id'] ) && !empty( $args['cat_id'] ) ? str_replace( array( "\"", "'" ), "", $args['cat_id'] ) : '';
	$args['meta_key'] = isset( $args['meta_key'] ) && !empty( $args['meta_key'] ) && $args['orderby'] === 'meta_value_num' ? $args['meta_key'] : '';
	$args['loop_col_class'] = isset( $args['loop_col']) && !empty( $args['loop_col']) ? ' lp-col' . $args['loop_col'] : ' lp-col3';
	$args['overlay_color'] = isset( $args['overlay_color']) && !empty( $args['overlay_color']) ? ' ' . $args['overlay_color'] . '-bg' : '';

	// Addtional params
	$args['if_img_tag'] = false;

	// Params for slider
	$slider_mode = isset( $args['slider_mode'] ) && !empty( $args['slider_mode'] ) ? $args['slider_mode'] : 'carousel';
	$slider_speed = isset( $args['slider_speed'] ) && preg_match("/^[0-9]+$/",$args['slider_speed'] ) ? $args['slider_speed'] : 800;
	$slider_duration = isset( $args['slider_duration'] ) && preg_match("/^[0-9]+$/",$args['slider_duration'] ) ? $args['slider_duration'] : 3000;
	$slider_navigation = isset( $args['slider_navigation'] ) && !empty( $args['slider_navigation'] ) ? ' data-slider-nav="true"' : '';
	$slider_control_btn = isset( $args['slider_control_btn'] ) && !empty( $args['slider_control_btn'] ) ? ' data-slider-btn="true"' : '';

	$more_url = isset( $args['more_url'] ) && !empty( $args['more_url'] ) ? $args['more_url'] : '';


	$loop_section_class .= $args['layout'] == 'normal' || $args['layout'] == 'portfolio' ? ' nm-pf-common' : '';
	$loop_section_class .= $args['layout'] == 'portfolio' || $args['layout'] == 'magazine' ? ' pf-mz-common' : '';


	// *********************
	// Category ID & name
	// *********************
	if ( $args['post_type'] !== 'post' && $args['post_type'] !== 'page') {
		$args['cat_id'] = null;
	}

	// *********************
	// Add meta key to array (If not empty)
	// *********************
	if ( !empty( $args['meta_key'] ) ) {
		$args['meta_key_views_count'] =  $args['meta_key'];
	}

	// *********************
	// More link
	// *********************
	if ( !empty( $args['more_text'] ) ) {

		if ( empty($more_url) && ( $args['type'] === 'recent' || $args['type'] === 'custom' )  && $args['orderby'] === 'date' ) {

			if ( $args['post_type'] === $options['news_cpt_slug_id'] ) {

				$more_url = get_post_type_archive_link( $args['post_type'] );

			} else if ( $args['post_type'] == 'post' ) {

				if ( !empty($args['cat_id']) ) {
					$arr_cat_id 	= explode( ",", $args['cat_id'] );
					$more_url = get_category_link( $arr_cat_id[0] );

				} else if ( !empty($args['tag_slug']) ) {

					$tag_id = explode( ",", $args['tag_slug'] );

					if ( is_array($tag_id) ) {
						$tag_id = get_tags( array('slug' => $tag_id[0]) );
					} else {
						$tag_id = get_tags( array('slug' => $args['tag_slug']) );
					}

					$tag_id = $tag_id[0]->term_id;
					$more_url = get_tag_link( $tag_id );

				} else {

					if ( is_home() ) {
						$more_url = esc_url( get_pagenum_link(2) );
					} else {
						// All posts and not home
						$more_url = home_url('/');
					}
				}
			}
		}

		if ( !empty( $more_url) ) {
			$more_url = '<div class="more-entry-link"><a href="' . $more_url . '"><span>' . $args['more_text'] . '</span></a></div>';
		}
	}


	// Mobile
	if ( $IS_MOBILE_DP ){
		$suffix_mb = '_mobile';
		$main_js = 'mb-' . $main_js;
		$args['layout'] .= ' mobile';
		$col_class = '';
	}
	// PC
	else {
		// Column
		$col_class = ' two-col';

		if ( $COLUMN_NUM === 1 || $args['one_col'] ) {

			$col_class = ' one-col';
		}
		else if ( $COLUMN_NUM === 3 ) {

			$col_class = ' three-col';
		}
	}


	// Site column class
	$args['col_class'] = $col_class;

	// Reload js and css
	DP_RecentPosts_Widget_For_Archive::enqueue_css_js( $args['layout'] );


	// Portfolio or magazine
	if ( ( strpos($args['layout'], 'portfolio') !== false ) || ( strpos($args['layout'], 'magazine') !== false ) ) {

		// Filtering form UI for isotope
		if ( $args['use_filter'] ){

			$arg_cats = array(
				'hierarchical' => 0,
				'exclude' => $args['filter_exclude_cat']
			);

			$cats = get_categories($arg_cats);

			foreach( $cats as $key => $cat ){
				$filter_form .= '<label class="flt-btn"><input type="checkbox" value=".cat-flt' . $cat->term_id . '" /><span>' . $cat->name . '</span></label>';
			}

			$filter_form = '<div class="loop-filter-form' . $args['col_class'] . '">' . $filter_form . '</div>';
		}

		// For isotope grid and gutter
		$isotope_grid_gutter = '<div class="grid-sizer' . $args['col_class'] . $args['loop_col_class'] . '"></div><div class="gutter-sizer' . $args['col_class'] . $args['loop_col_class'] . '"></div>';
	}

	// ********************
	// wow.js
	// ********************
	$wow_article_css = '';
	if ( !(bool)$options['disable_wow_js' . $suffix_mb] ){
		if ( empty( $filter_form) ) {
			$wow_article_css 	= ' wow fadeInUp';
		}
	}
	$args['wow_article_css'] = $wow_article_css;

	/**
	 * Main query
	 * @var array
	 */
	$arg_query = array(
			'numberposts' => (int)$args['number'],
			'category' => $args['cat_id'],
			'tag_id' => $args['tag_id'],
			'tag' => $args['tag_slug'],
			'author' => $args['authors_id'],
			's' => $args['keyword'],
			'post_type' => $args['post_type'],
			'meta_key' => $args['meta_key'],
			'meta_value' => $args['meta_value'],
			'orderby' => $args['orderby'],
			'date_query' => array(
				array(
					'year' => (int)$args['year'],
					'monthnum' => (int)$args['month']
					)),
			'order'	=> $args['order']
			);
	$posts = get_posts( $arg_query );

	/**
	 * Show post list
	 *
	 * Call the function written in "listing_post_styles.php"
	 */
	switch ( $args['layout'] ) {
		case 'normal':
		case 'normal mobile':

			$args['title_length'] = 180;

			foreach( $posts as $post_num => $post ) : setup_postdata($post);

				$args['comment'] = comments_open();
				$arr_post_ele = dp_post_list_get_elements($args);
				$loop_code .= dp_show_post_list_for_archive_normal($args, $arr_post_ele);

			endforeach;

			wp_reset_postdata();

			break;

		case 'portfolio':
		case 'portfolio mobile':

			if ( isset($args['fix_thumb_h']) && !empty($args['fix_thumb_h']) ){
				$loop_section_class .= ' fix_thumb_h';
			}

			$args['title_length'] = 120;
			$args['grid_size'] = $grid_size; // nothing

			foreach( $posts as $post_num => $post ) : setup_postdata($post);

				$args['comment'] = comments_open();
				$arr_post_ele = dp_post_list_get_elements($args);

				$loop_code .= dp_show_post_list_for_archive_portfolio1($args, $arr_post_ele);
			endforeach;

			wp_reset_postdata();

			break;

		case 'magazine':
		case 'magazine mobile':

			$loop_section_class .= ' fix_thumb_h';

			// Chain classes
			$args['magazine_title_by_bold'] = !empty( $args['magazine_title_by_bold'] ) ? ' ' . $args['magazine_title_by_bold'] : '';
			$args['magazine_text_by_serif'] = !empty( $args['magazine_text_by_serif'] ) ? ' ' . $args['magazine_text_by_serif'] : '';
			$args['magazine_text_vertically'] = !empty( $args['magazine_text_vertically'] ) ? ' ' . $args['magazine_text_vertically'] : '';
			$args['magazine_cover_frame'] = !empty( $args['magazine_cover_frame'] ) ? ' ' . $args['magazine_cover_frame'] : '';
			$args['magazine_title_position'] = !empty( $args['magazine_title_position'] ) && empty( $args['magazine_text_vertically'] ) ? ' ' . $args['magazine_title_position'] : '';
			$args['magazine_title_tilt'] = !empty( $args['magazine_title_tilt'] ) ? ' ' . $args['magazine_title_tilt'] : '';
			$args['magazine_title_back'] = !empty($args['magazine_title_back'] ) ? ' ' . $args['magazine_title_back'] : '';
			$args['magazine_title_back_border'] = !empty( $args['magazine_title_back'] ) && !empty( $args['magazine_title_back_border'] ) ? ' ' . $args['magazine_title_back_border'] : '';
			$args['magazine_date_design'] = !empty( $args['magazine_date_design'] ) ? ' ' . $args['magazine_date_design'] : ' date1';
			$args['magazine_accent_shape'] = !empty( $args['magazine_accent_shape'] ) ? ' ' . $args['magazine_accent_shape'] : '';

			// Common color, opacity styles
			$loop_section_style = !empty($args['magazine_cover_frame_color']) && $args['magazine_cover_frame_color'] !== '#ffffff' ? '--mgz-frame-color:' . $args['magazine_cover_frame_color'] . ';' : '';
			$loop_section_style .= !empty($args['magazine_title_color']) && $args['magazine_title_color'] !== '#ffffff' ? '--mgz-title-color:' . $args['magazine_title_color'] . ';' : '';
			$loop_section_style .=  !empty( $args['magazine_title_back'] ) && !empty($args['magazine_title_back_color']) && $args['magazine_title_back_color'] !== '#000000' ? '--mgz-title-bg-color:' . $args['magazine_title_back_color'] . ';' : '';
			$loop_section_style .= !empty( $args['magazine_title_back'] ) && !empty($args['magazine_title_back_color_opacity']) && $args['magazine_title_back_color_opacity'] !== 50 ? '--mgz-title-bg-opacity:' . ( $args['magazine_title_back_color_opacity'] / 100 ) . ';' : '';
			$loop_section_style .= !empty($args['magazine_accent_shape_color']) ? '--acc-shape-color:' . $args['magazine_accent_shape_color'] . ';' : '';
			$loop_section_style .= !empty($args['magazine_accent_shape_opacity']) && $args['magazine_accent_shape_opacity'] !== 30 ? '--acc-shape-opacity:' . ( $args['magazine_accent_shape_opacity'] / 100 ) . ';' : '';


			$args['title_length'] = 62;
			$args['excerpt_length'] = 68;

			foreach( $posts as $post_num => $post ) : setup_postdata($post);

				$args['comment'] = comments_open();
				$arr_post_ele = dp_post_list_get_elements($args);
				$loop_code .= dp_show_post_list_for_archive_magazine1($args, $arr_post_ele);

			endforeach;

			wp_reset_postdata();

			break;

		case 'news':
		case 'news mobile':

			$args['title_length'] = 160;

			foreach( $posts as $post ) : setup_postdata($post);
				$arr_post_ele = dp_post_list_get_elements($args);
				$loop_code .= dp_show_post_list_for_archive_news($args, $arr_post_ele);
			endforeach;

			wp_reset_postdata();

			break;

		case 'simple':
		case 'simple mobile':

			$args['layout'] .= ' news';

			$args['title_length'] = 160;
			$args['if_img_tag'] = true;

			foreach( $posts as $post ) : setup_postdata($post);
				$arr_post_ele = dp_post_list_get_elements($args);
				$loop_code .= dp_show_post_list_for_archive_simple($args, $arr_post_ele);
			endforeach;

			wp_reset_postdata();

			break;

		case 'slider':
		case 'slider mobile':

			$nav_selector = 'nav_slider swiper loading';

			// Ristrict for mobile
			if ( $IS_MOBILE_DP ) {
				if ( $args['slider_mode'] === 'thumb' || $args['slider_mode'] === 'split' || $args['slider_mode'] === 'carousel' || strpos( $args['slider_mode'], 'center' ) ) {
					$args['slider_mode'] = 'fade';
				}
				else if ( $args['slider_mode'] === 'coverflow three' || $args['slider_mode'] === 'coverflow five' ) {
					$args['slider_mode'] = 'coverflow one';
				}
			}

			// Slide media parallax
			if ( $args['slider_mode'] === 'fade' ) {
				$args['data_plx_media'] = ' data-swiper-parallax-scale="1.24"';
			}

			else if ( $args['slider_mode'] === 'horizontal' || ( $args['slider_mode'] === 'thumb' && !$IS_MOBILE_DP ) ) {
				$args['data_plx_media'] = ' data-swiper-parallax-x="60%"';
			}

			else if ( false !== strpos($args['slider_mode'], 'center' ) && !$IS_MOBILE_DP ) {
				$args['data_plx_media'] = ' data-swiper-parallax-x="20%" data-swiper-parallax-scale="1.4"';
			}

			else if ( $args['slider_mode'] === 'vertical' ) {
				$args['data_plx_media'] = ' data-swiper-parallax-y="50%"';
			}

			else {
				$args['data_plx_media'] = '';
			}

			// Above text parallax
			if ( $args['slider_mode'] !== 'carousel' ) {

				$args['data_plx_content'] = ' data-swiper-parallax-opacity="0"';

				if ( $args['slider_mode'] === 'vertical' ) {
					$args['data_plx_title'] = ' data-swiper-parallax-y="300%" ';
					$args['data_plx_category'] = ' data-swiper-parallax-y="220%"';
					$args['data_plx_date'] = ' data-swiper-parallax-y="160%"';
				}

				else if ( $args['slider_mode'] === 'fade' ) {
					$args['data_plx_title'] = ' data-swiper-parallax-scale="0.8"';
					$args['data_plx_category'] = ' data-swiper-parallax-scale="0.8"';
					$args['data_plx_date'] = ' data-swiper-parallax-scale="1.2"';
				}

				else if ( $args['slider_mode'] === 'split' && !$IS_MOBILE_DP ) {
					$args['data_plx_title'] = ' data-swiper-parallax-x="40%"';
					$args['data_plx_category'] = ' data-swiper-parallax-x="60%"';
					$args['data_plx_date'] = ' data-swiper-parallax-x="80%"';
				}

				else {
					$args['data_plx_title'] = ' data-swiper-parallax-x="20%"';
					$args['data_plx_category'] = ' data-swiper-parallax-x="40%"';
					$args['data_plx_date'] = ' data-swiper-parallax-x="60%"';
				}
			} else {

				$args['data_plx_content'] = '';
				$args['data_plx_title'] = '';
				$args['data_plx_category'] = '';
				$args['data_plx_date'] = '';
			}

			$args['title_length'] = 68;

			foreach( $posts as $post ) : setup_postdata($post);

				$args['comment'] = comments_open();

				$arr_post_ele = dp_post_list_get_elements($args);
				$loop_code = dp_show_post_list_for_archive_slider($args, $arr_post_ele);

				$slider_code .= $loop_code['slider_code'];
				$thumbnav_code .= $loop_code['thumbnav_code'];

			endforeach;
			wp_reset_postdata();


			// Navigation code
			if ( !empty( $args['slider_navigation'] ) && !$IS_MOBILE_DP ){
				$slider_pagenation_code = '<div id="page-nav-' . $args['id'] . '" class="swiper-pagination' . $slider_mode_class . '"></div>';
			}
			if ( !empty( $args['slider_control_btn'] ) && !$IS_MOBILE_DP ){
				$slider_nav_btn_code = '<div class="swiper-nav-button-wrapper"><div class="swiper-button-prev"></div><div class="swiper-button-next"></div></div>';
			}

			// Main slider
			$slider_code = '<div class="swiper-wrapper">' . $slider_code . '</div>' . $slider_nav_btn_code;

			// Thumbnail slider
			$thumbnav_code = $args['slider_mode'] == 'thumb' ? '<div id="nav-' . $args['id'] . '" class="' . $nav_selector . '"><div class="swiper-wrapper">' . $thumbnav_code . '</div></div>' : '';

			break;

		case 'mega-menu':

			$args['title_length'] = 68;

			foreach( $posts as $post ) : setup_postdata($post);

				$arr_post_ele = dp_post_list_get_elements($args);
				$loop_code .= dp_show_post_list_for_mega_menu($args, $arr_post_ele);

			endforeach;

			wp_reset_postdata();
			break;
	}


	/**
	 * Artcle list section source
	 */
	if ( !$IS_MOBILE_DP && $args['layout'] === 'mega-menu' ){

		$html_code = '<div class="' . $loop_section_class . '"><ul class="loop-div">' . $loop_code . '</ul></div>';
	}
	else {

		// Slider
		if ( $args['layout'] == 'slider' || $args['layout'] == 'slider mobile' ) {

			// var_dump($args['layout']);

			$loop_section_class .= ' sl-style-' . $args['slider_mode'];
			$args['col_class'] = '';

			// Params
			$slider_trigger_class = ' swiper alist_slider hero-slider loading';
			$slider_duration = ' data-slider-duration="' . $slider_duration . '"';
			$slider_speed = ' data-slider-speed="' . $slider_speed . '"';
			$slider_mode_class = ' style-' . $slider_mode;
			$slider_mode = ' data-slider-mode="' . $slider_mode . '" data-slider-num="' . $args['number'] . '"';
			$slider_number = ' data-slider-num="' . count($posts) . '"';
			$slider_nav_id = ' data-slider-nav-id="nav-' . $args['id'] . '"';
			$slider_page_nav_id = ' data-slider-page-nav-id="page-nav-' . $args['id'] . '"';

			$loop_code = $slider_code;

		} else {

			$slider_trigger_class = $slider_code = $slider_mode_class = $slider_pagenation_code = $slider_nav_btn_code = $slider_number = $slider_nav_id = $slider_page_nav_id = '';

			// Loop section styles
			$loop_section_style = !empty($loop_section_style) ? ' style="' . $loop_section_style . '"' : '';

			// Loop section classes
			$loop_section_class .= ' ' . $args['layout'] . $args['loop_col_class'] . $args['col_class'];
			$loop_section_class .= isset( $args['article_round_corner'] ) && !empty( $args['article_round_corner'] ) ? ' item-rounded' : '' ;
			$loop_section_class .= isset( $args['article_box_shadow'] ) && !empty( $args['article_box_shadow'] ) ? ' item-boxshadow' : '' ;
			$loop_section_class .= isset( $args['article_alternately'] ) && !empty( $args['article_alternately'] ) ? ' item-alter' : '' ;
		}

		// Wrap the loop code
		$html_code = '<section class="' . $loop_section_class . '"' . $loop_section_style .'>' . $filter_form . '<div class="loop-div ' . $slider_trigger_class . $slider_mode_class . '"' . $slider_mode . $slider_duration . $slider_speed . $slider_navigation . $slider_control_btn . $slider_number . $slider_nav_id . $slider_page_nav_id . '>' . $isotope_grid_gutter . $loop_code . '</div>' . $thumbnav_code . $slider_pagenation_code . $more_url . '</section>';

	}

	// Display
	if ( $args['echo'] ) {
		echo $html_code;
	} else {
		return $html_code;
	}
}


/*******************************************************
* Recent Posts widget
*******************************************************/
class DP_RecentPosts_Widget_For_Archive extends WP_Widget {
	function __construct() {
		// Widget meta
		$widget_opts = array('classname' 	=> 'dp_archive_widget',
							 'description' 	=> __('Enhanced Recent Posts widget for archive page. Use this only in conent area  of archive page', 'DigiPress')
							 );
		parent::__construct( strtolower( __CLASS__ ), __('DP - New Posts for Archive', 'DigiPress'), $widget_opts );
	}


	// Reload enqueuing js and css
	public static function enqueue_css_js( $layout = '', $main_js = 'main.min.js', $main_js_mb = 'mb-main.min.js' ){

		if ( !isset( $layout ) || empty( $layout ) ) return;

		global $options, $IS_MOBILE_DP;

		// reload main.min.js flag
		$is_reload = false;
		$arr_main_pri_js = array( 'jquery', 'imagesloaded' );

		// Disable pjax flag
		// $is_disable_pjax = $IS_MOBILE_DP ? $options['disable_pjax'] : $options['disable_pjax_mobile'];


		// Load assets
		if ( strpos( $layout, 'slider' ) !== false ) {
			wp_enqueue_style( 'dp-swiper', DP_THEME_URI.'/css/swiper-bundle.css', null, DP_OPTION_SPT_VERSION );
			wp_enqueue_script( 'dp-swiper', DP_THEME_URI.'/inc/js/swiper-bundle.min.js', null, false, true );

			$is_reload = true;
			$arr_main_pri_js[] = 'dp-swiper';

		}
		else if ( ( strpos( $layout, 'portfolio' ) !== false ) || ( strpos( $layout, 'magazine' ) !== false ) ) {
			// isotope
			wp_enqueue_script( 'imagesloaded', null, array( 'jquery' ), null, true );
			wp_enqueue_script( 'isotope', DP_THEME_URI.'/inc/js/jquery/jquery.isotope.min.js', array( 'jquery', 'imagesloaded' ), DP_OPTION_SPT_VERSION, true);

			$is_reload = true;
			$arr_main_pri_js[] = 'isotope';
		}

		if ( $is_reload ) {
			if ( $IS_MOBILE_DP ) {
				$main_js = $main_js_mb;
			}

			// ImagesLoaded
			wp_enqueue_script( 'imagesloaded', null, array( 'jquery' ), null, true );

			// Reload main js
			wp_deregister_script( 'dp-main' );
			wp_enqueue_script( 'dp-main', DP_THEME_URI . '/inc/js/' . $main_js, $arr_main_pri_js, echo_filedate( DP_THEME_DIR . '/inc/js/' . $main_js ), true );
		}
	}


	// Input widget form in Admin panel.
	function form($instance) {
		// default value
		$instance = wp_parse_args(
			(array)$instance,
			array('title' => __('Recent Posts','DigiPress'),
				'number' => 5,
				'cat'=> null,
				'tag' => null,
				'authors' => null,
				'keyword' => null,
				'show_cat' => true,
				'comment'	=> false,
				'meta_key' => 'post_views_count',
				'post_type' => 'post',
				'author' 	=> true,
				'views'	=> false,
				'orderby'	=> 'date',
				'pub_date'	=> true,
				'hatebu_num' => true,
				'tweets_num' => false,
				'likes_num' => false,
				'loop_col' => 3,
				'more_text'	=> 'More',
				'more_url'	=> '',
				'read_more_str' => 'Read More',
				'layout'	=> 'normal',
				'excerpt_length' => 120,
				'overlay_color' => 'cat',
				'one_col'	=> false,
				'use_filter'	=> false,
				'filter_exclude_cat' => '',
				'fix_thumb_h' => true,
				'slider_mode' => 'carousel',
				'slider_speed' => 1200,
				'slider_duration' => 3000,
				'slider_navigation' => false,
				'slider_control_btn' => true,
				'article_box_shadow' => true,
				'article_round_corner' => false,
				'article_alternately' => false,
				'disable_cache' => false,
				'enable_tab_list' => false,
				'tab_title' => array_fill( 0, 4, '' ),
				'tab_orderby' => array_fill( 0, 4, '' ),
				'tab_category' => array_fill( 0, 4, '' ),
				'tab_design' => 1,
				'magazine_cover_frame' => '',
				'magazine_cover_frame_color' => '#ffffff',
				'magazine_title_position' => '',
				'magazine_title_color' => '#ffffff',
				'magazine_title_back' => '',
				'magazine_title_back_color' => '',
				'magazine_title_back_color_opacity' => '',
				'magazine_title_back_border' => '',
				'magazine_title_by_bold' => '',
				'magazine_title_tilt' => '',
				'magazine_text_by_serif' => '',
				'magazine_text_vertically' => '',
				'magazine_date_design' => 'date1',
				'magazine_accent_shape' => '',
				'magazine_accent_shape_color' => '#ffffff',
				'magazine_accent_shape_opacity' => 30,
				)
			);

		// get values
		$title = strip_tags($instance['title'] );
		$number = $instance['number'];
		$show_cat	= $instance['show_cat'];
		$comment	= $instance['comment'];
		$author 	= $instance['author'];
		$views= $instance['views'];
		$hatebu_num = $instance['hatebu_num'];
		$tweets_num = $instance['tweets_num'];
		$likes_num 	= $instance['likes_num'];
		$loop_col 	= $instance['loop_col'];
		$cat= $instance['cat'];
		$tag	= $instance['tag'];
		$authors	= $instance['authors'];
		$keyword	= $instance['keyword'];
		$pub_date 	= $instance['pub_date'];
		$more_text 	= $instance['more_text'];
		$more_url 	= $instance['more_url'];
		$read_more_str 	= $instance['read_more_str'];
		$layout 	= $instance['layout'];
		$orderby 	= $instance['orderby'];
		$excerpt_length = $instance['excerpt_length'];
		$meta_key 	= $instance['meta_key'];
		$post_type 	= $instance['post_type'];
		$one_col 	= $instance['one_col'];
		$use_filter 	= $instance['use_filter'];
		$filter_exclude_cat 	= $instance['filter_exclude_cat'];
		$fix_thumb_h 	= $instance['fix_thumb_h'];
		$overlay_color= $instance['overlay_color'];
		$slider_mode = $instance['slider_mode'];
		$slider_speed = $instance['slider_speed'];
		$slider_duration = $instance['slider_duration'];
		$slider_navigation = $instance['slider_navigation'];
		$slider_control_btn = $instance['slider_control_btn'];
		$article_box_shadow = $instance['article_box_shadow'];
		$article_round_corner = $instance['article_round_corner'];
		$article_alternately = $instance['article_alternately'];
		$disable_cache = $instance['disable_cache'];
		$enable_tab_list = $instance['enable_tab_list'];
		$tab_title = $instance['tab_title'];
		$tab_orderby = $instance['tab_orderby'];
		$tab_category = $instance['tab_category'];
		$tab_design = $instance['tab_design'];
		$magazine_cover_frame = $instance['magazine_cover_frame'];
		$magazine_cover_frame_color = $instance['magazine_cover_frame_color'];
		$magazine_title_position = $instance['magazine_title_position'];
		$magazine_title_color = $instance['magazine_title_color'];
		$magazine_title_back = $instance['magazine_title_back'];
		$magazine_title_back_color = $instance['magazine_title_back_color'];
		$magazine_title_back_color_opacity = $instance['magazine_title_back_color_opacity'];
		$magazine_title_back_border = $instance['magazine_title_back_border'];
		$magazine_title_by_bold = $instance['magazine_title_by_bold'];
		$magazine_title_tilt = $instance['magazine_title_tilt'];
		$magazine_text_by_serif = $instance['magazine_text_by_serif'];
		$magazine_text_vertically = $instance['magazine_text_vertically'];
		$magazine_date_design = $instance['magazine_date_design'];
		$magazine_accent_shape = $instance['magazine_accent_shape'];
		$magazine_accent_shape_color = $instance['magazine_accent_shape_color'];
		$magazine_accent_shape_opacity = $instance['magazine_accent_shape_opacity'];


		$title_name	= $this->get_field_name('title');
		$title_id	= $this->get_field_id('title');
		$number_name	= $this->get_field_name('number');
		$number_id	= $this->get_field_id('number');
		$show_cat_name	= $this->get_field_name('show_cat');
		$show_cat_id	= $this->get_field_id('show_cat');
		$comment_name	= $this->get_field_name('comment');
		$comment_id= $this->get_field_id('comment');
		$views_name= $this->get_field_name('views');
		$views_id= $this->get_field_id('views');
		$cat_name= $this->get_field_name('cat');
		$cat_id	= $this->get_field_id('cat');
		$authors_name	= $this->get_field_name('authors');
		$authors_id		= $this->get_field_id('authors');
		$tag_name	= $this->get_field_name('tag');
		$tag_id		= $this->get_field_id('tag');
		$keyword_name	= $this->get_field_name('keyword');
		$keyword_id		= $this->get_field_id('keyword');
		$hatebu_num_name	= $this->get_field_name('hatebu_num');
		$tweets_num_name	= $this->get_field_name('tweets_num');
		$likes_num_name	= $this->get_field_name('likes_num');
		$hatebu_num_id = $this->get_field_id('hatebu_num');
		$tweets_num_id = $this->get_field_id('tweets_num');
		$likes_num_id = $this->get_field_id('likes_num');
		$pub_date_name	= $this->get_field_name('pub_date');
		$pub_date_id	= $this->get_field_id('pub_date');
		$more_text_name	= $this->get_field_name('more_text');
		$more_text_id	= $this->get_field_id('more_text');
		$more_url_name	= $this->get_field_name('more_url');
		$more_url_id	= $this->get_field_id('more_url');
		$read_more_str_name	= $this->get_field_name('read_more_str');
		$read_more_str_id	= $this->get_field_id('read_more_str');
		$orderby_name	= $this->get_field_name('orderby');
		$orderby_id= $this->get_field_id('orderby');
		$layout_name	= $this->get_field_name('layout');
		$layout_id= $this->get_field_id('layout');
		$excerpt_length_name	= $this->get_field_name('excerpt_length');
		$excerpt_length_id= $this->get_field_id('excerpt_length');
		$author_name	= $this->get_field_name('author');
		$author_id= $this->get_field_id('author');
		$meta_key_name	= $this->get_field_name('meta_key');
		$meta_key_id= $this->get_field_id('meta_key');
		$post_type_name	= $this->get_field_name('post_type');
		$post_type_id= $this->get_field_id('post_type');
		$loop_col_name	= $this->get_field_name('loop_col');
		$loop_col_id	= $this->get_field_id('loop_col');
		$one_col_name	= $this->get_field_name('one_col');
		$one_col_id= $this->get_field_id('one_col');
		$use_filter_name = $this->get_field_name('use_filter');
		$use_filter_id = $this->get_field_id('use_filter');
		$overlay_color_name	= $this->get_field_name('overlay_color');
		$overlay_color_id= $this->get_field_id('overlay_color');
		$filter_exclude_cat_name	= $this->get_field_name('filter_exclude_cat');
		$filter_exclude_cat_id= $this->get_field_id('filter_exclude_cat');
		$fix_thumb_h_name	= $this->get_field_name('fix_thumb_h');
		$fix_thumb_h_id= $this->get_field_id('fix_thumb_h');
		$slider_mode_name	= $this->get_field_name('slider_mode');
		$slider_mode_id= $this->get_field_id('slider_mode');
		$slider_speed_name	= $this->get_field_name('slider_speed');
		$slider_speed_id = $this->get_field_id('slider_speed');
		$slider_duration_name  = $this->get_field_name('slider_duration');
		$slider_duration_id =$this->get_field_id('slider_duration');
		$slider_navigation_name = $this->get_field_name('slider_navigation');
		$slider_navigation_id  =$this->get_field_id('slider_navigation');
		$slider_control_btn_name = $this->get_field_name('slider_control_btn');
		$slider_control_btn_id  = $this->get_field_id('slider_control_btn');
		$article_box_shadow_name = $this->get_field_name('article_box_shadow');
		$article_box_shadow_id = $this->get_field_id('article_box_shadow');
		$article_round_corner_name = $this->get_field_name('article_round_corner');
		$article_round_corner_id = $this->get_field_id('article_round_corner');
		$article_alternately_name = $this->get_field_name('article_alternately');
		$article_alternately_id = $this->get_field_id('article_alternately');
		$disable_cache_name = $this->get_field_name('disable_cache');
		$disable_cache_id = $this->get_field_id('disable_cache');
		$enable_tab_list_name = $this->get_field_name('enable_tab_list');
		$enable_tab_list_id = $this->get_field_id('enable_tab_list');
		$tab_title_name = $this->get_field_name('tab_title');
		$tab_title_id = $this->get_field_id('tab_title');
		$tab_orderby_name = $this->get_field_name('tab_orderby');
		$tab_orderby_id = $this->get_field_id('tab_orderby');
		$tab_category_name = $this->get_field_name('tab_category');
		$tab_category_id = $this->get_field_id('tab_category');
		$tab_design_name = $this->get_field_name('tab_design');
		$tab_design_id = $this->get_field_id('tab_design');
		$magazine_cover_frame_name = $this->get_field_name('magazine_cover_frame');
		$magazine_cover_frame_id = $this->get_field_id('magazine_cover_frame');
		$magazine_cover_frame_color_name = $this->get_field_name('magazine_cover_frame_color');
		$magazine_cover_frame_color_id = $this->get_field_id('magazine_cover_frame_color');
		$magazine_title_position_name = $this->get_field_name('magazine_title_position');
		$magazine_title_position_id = $this->get_field_id('magazine_title_position');
		$magazine_title_color_name = $this->get_field_name('magazine_title_color');
		$magazine_title_color_id = $this->get_field_id('magazine_title_color');
		$magazine_title_back_name = $this->get_field_name('magazine_title_back');
		$magazine_title_back_id = $this->get_field_id('magazine_title_back');
		$magazine_title_back_color_name = $this->get_field_name('magazine_title_back_color');
		$magazine_title_back_color_id = $this->get_field_id('magazine_title_back_color');
		$magazine_title_back_color_opacity_name = $this->get_field_name('magazine_title_back_color_opacity');
		$magazine_title_back_color_opacity_id = $this->get_field_id('magazine_title_back_color_opacity');
		$magazine_title_back_border_name = $this->get_field_name('magazine_title_back_border');
		$magazine_title_back_border_id = $this->get_field_id('magazine_title_back_border');
		$magazine_title_by_bold_name = $this->get_field_name('magazine_title_by_bold');
		$magazine_title_by_bold_id = $this->get_field_id('magazine_title_by_bold');
		$magazine_title_tilt_name = $this->get_field_name('magazine_title_tilt');
		$magazine_title_tilt_id = $this->get_field_id('magazine_title_tilt');
		$magazine_text_by_serif_name = $this->get_field_name('magazine_text_by_serif');
		$magazine_text_by_serif_id = $this->get_field_id('magazine_text_by_serif');
		$magazine_text_vertically_name = $this->get_field_name('magazine_text_vertically');
		$magazine_text_vertically_id = $this->get_field_id('magazine_text_vertically');
		$magazine_date_design_name = $this->get_field_name('magazine_date_design');
		$magazine_date_design_id = $this->get_field_id('magazine_date_design');
		$magazine_accent_shape_name = $this->get_field_name('magazine_accent_shape');
		$magazine_accent_shape_id = $this->get_field_id('magazine_accent_shape');
		$magazine_accent_shape_color_name = $this->get_field_name('magazine_accent_shape_color');
		$magazine_accent_shape_color_id = $this->get_field_id('magazine_accent_shape_color');
		$magazine_accent_shape_opacity_name = $this->get_field_name('magazine_accent_shape_opacity');
		$magazine_accent_shape_opacity_id = $this->get_field_id('magazine_accent_shape_opacity');


		$form_code = $orderby_form = $layout_form = $loop_col_form = $overlay_color_form = $slider_mode_form = $magazine_cover_frame_form = $magazine_title_position_form = $tab_list_form = $arr_tab_orderby = '';

		$arr_layout = array(
			'normal' => __('Standard layout','DigiPress'),
			'portfolio' => __('Portfolio layout','DigiPress'),
			'magazine' => __('Magazine layout','DigiPress'),
			'news' => __('Simple list layout','DigiPress'),
			'simple' => __('Simple list layout','DigiPress') . ' (' . __('with thumbnail', 'DigiPress') . ')',
			'slider' => __('Slider', 'DigiPress')
		);

		$arr_orderby = array(
			'date' => __('Order by posted date','DigiPress'),
			'modified' => __('Order by last modified','DigiPress'),
			'meta_value_num' => __('Order by viewed count','DigiPress'),
			'comment_count' => __('Order by comment count','DigiPress'),
			'ID' => __('Order by ID','DigiPress'),
			'rand' => __('Random order','DigiPress'),
			'author' => __('Order by author','DigiPress')
		);

		$arr_tab_orderby = array(
			'' => __( 'Do not show', 'DigiPress' ),
			'date' => __('Order by posted date','DigiPress'),
			'modified' => __('Order by last modified','DigiPress'),
			'meta_value_num' => __('Order by viewed count','DigiPress'),
			'comment_count' => __('Order by comment count','DigiPress'),
			'ID' => __('Order by ID','DigiPress'),
			'rand' => __('Random order','DigiPress'),
			'author' => __('Order by author','DigiPress')
		);


		$arr_loop_col = array(
			2 => __('Two columns','DigiPress'),
			3 => __('Three columns','DigiPress'),
			4 => __('Four columns(Enable in no-sidebar)','DigiPress'),
			5 => __('Five columns(Enable in no-sidebar)','DigiPress')
		);

		$arr_overlay_color = array(
			'black' => __('Black','DigiPress'),
			'white' => __('White','DigiPress'),
			'pri_color' => __('Primary Color','DigiPress'),
			// 'gradient' => __('Primary/Secondary color gradient','DigiPress'),
			'cat' => __('Category color','DigiPress')
		);

		$arr_slider_mode = array(
			'fade' => __('Fade in/out', 'DigiPress'),
			'horizontal' => __('Horizontal slider', 'DigiPress'),
			'vertical' => __('Vertical slider', 'DigiPress'),
			'split' => __('Split slider(2 slides)', 'DigiPress'),
			'thumb' => __('Slider with thumbnail nav', 'DigiPress'),
			'carousel' => __('Carousel','DigiPress'),
			'center three' => sprintf(__('Centered(%s slides)','DigiPress'), '3'),
			'center five' => sprintf(__('Centered(%s slides)','DigiPress'), '5'),
			'coverflow one' => sprintf(__('3D coverflow(%s slides)','DigiPress'), '1'),
			'coverflow three' => sprintf(__('3D coverflow(%s slides)','DigiPress'), '3'),
			'coverflow five' => sprintf(__('3D coverflow(%s slides)','DigiPress'), '5'),
			'creative one' => __( 'Slice', 'DigiPress' ),
			'creative two' => __( 'Shifting slider', 'DigiPress' ),
			'creative three' => __( 'Horizontal rotation', 'DigiPress' ),
			'creative four' => '3D ' . __( 'Horizontal rotation', 'DigiPress' ),
			'creative five' => '3D ' . __( 'Vertical rotation', 'DigiPress' ),
			'creative six' => __( 'Central rotation', 'DigiPress' )
		);

		$arr_magazine_cover_frame = array(
			'' => __('None', 'DigiPress'),
			'has-frame line-frame __solid' => __('Solid line', 'DigiPress'),
			'has-frame line-frame __double' => __('Double line', 'DigiPress'),
			'has-frame line-frame __dashed' => __('Dashed line', 'DigiPress'),
			'has-frame line-frame __dot' => __('Dot line', 'DigiPress'),
			'has-frame thick-bd' => __('Thick border', 'DigiPress'),
			'has-frame thick-bd no-r no-btm' => __('Thick border', 'DigiPress') . __('(top, left)', 'DigiPress'),
			'has-frame thick-bd no-l no-btm' => __('Thick border', 'DigiPress') . __('(top, right)', 'DigiPress'),
			'has-frame thick-bd no-r no-top' => __('Thick border', 'DigiPress') . __('(bottom, left)', 'DigiPress'),
			'has-frame thick-bd no-l no-top' => __('Thick border', 'DigiPress') . __('(bottom, right)', 'DigiPress'),
			'has-frame thick-bd no-l no-r no-btm' => __('Thick border', 'DigiPress') . __('(top)', 'DigiPress'),
			'has-frame thick-bd no-l no-r no-top' => __('Thick border', 'DigiPress') . __('(bottom)', 'DigiPress'),
		);

		$arr_magazine_title_position = array(
			'' => __('Center', 'DigiPress'),
			'title-pos__top title-pos__l' => __('Upper left', 'DigiPress'),
			'title-pos__top' => __('Upper center', 'DigiPress'),
			'title-pos__top title-pos__r' => __('Upper right', 'DigiPress'),
			'title-pos__btm title-pos__l' => __('Bottom left', 'DigiPress'),
			'title-pos__btm' => __('Bottom center', 'DigiPress'),
			'title-pos__btm title-pos__r' => __('Bottom right', 'DigiPress'),
		);

		$arr_tab_design = array(
			1 => __( 'Tab design', 'DigiPress' ) . ' 1',
			2 => __( 'Tab design', 'DigiPress' ) . ' 2',
			3 => __( 'Tab design', 'DigiPress' ) . ' 3',
		);


		$show_cat_check = '';
		if ((bool)$show_cat) $show_cat_check = 'checked';

		$comment_check = '';
		if ((bool)$comment) $comment_check = 'checked';

		$views_check = '';
		if ((bool)$views) $views_check = 'checked';

		$hatebu_num_check = '';
		if ((bool)$hatebu_num) $hatebu_num_check = 'checked';

		$tweets_num_check = '';
		if ((bool)$tweets_num) $tweets_num_check = 'checked';

		$likes_num_check = '';
		if ((bool)$likes_num) $likes_num_check = 'checked';

		$pub_date_check = '';
		if ((bool)$pub_date) $pub_date_check = 'checked';

		$author_check = '';
		if ((bool)$author) $author_check = 'checked';

		$one_col_check = '';
		if ((bool)$one_col) $one_col_check = 'checked';

		$fix_thumb_h_check = '';
		if ((bool)$fix_thumb_h) $fix_thumb_h_check = 'checked';


		$use_filter_check = '';
		if ((bool)$use_filter) $use_filter_check = 'checked';

		$slider_navigation_check = '';
		if ((bool)$slider_navigation) $slider_navigation_check = 'checked';

		$slider_control_btn_check = '';
		if ((bool)$slider_control_btn) $slider_control_btn_check = 'checked';

		$article_box_shadow_check = '';
		if ((bool)$article_box_shadow) $article_box_shadow_check = 'checked';

		$article_round_corner_check = '';
		if ((bool)$article_round_corner) $article_round_corner_check = 'checked';

		$article_alternately_check = '';
		if ((bool)$article_alternately) $article_alternately_check = 'checked';

		$disable_cache_check = '';
		if ((bool)$disable_cache) $disable_cache_check = 'checked';

		$enable_tab_list_check = '';
		if ((bool)$enable_tab_list) $enable_tab_list_check = ' checked';


		// Order by
		foreach ( $arr_orderby as $key => $val ) {
			if ( $key === $orderby) {
				$orderby_form .= '<option value="' . $key . '" selected>' . $val . '</option>';
			} else {
				$orderby_form .= '<option value="' . $key . '">' . $val . '</option>';
			}
		}


		/**
		 * When this content is the tab list
		 */
		// tab design
		$tab_list_form = '<div class="mg20px-btm"><p><label for="' . $tab_design_id . '" class="b">' . __( 'Tab design', 'DigiPress' ) . '</label></p><select id="' . $tab_design_id . '" name="' . $tab_design_name . '" style="width:100%;">';
		foreach ( $arr_tab_design as $key => $val ) {
			if ( $key == $tab_design ) {
				$tab_list_form .= '<option value="' . $key . '" selected>' . $val . '</option>';
			} else {
				$tab_list_form .= '<option value="' . $key . '">' . $val . '</option>';
			}
		}
		$tab_list_form .= '</select></div>';

		// Each tab setting
		foreach ( $tab_title as $i => $val ) {
			$tab_list_form .= '<div class="mg20px-btm"><div class="b icon-folder">' .
				sprintf(
					__( 'Tab %s', 'DigiPress' ),
					'#' . ( $i + 1 )
				) . '</div><p><label>- ' . __('Title', 'DigiPress') . ' : <input type="text" name="' .
				sprintf(
					'%1$s[%2$s]',
					$tab_title_name,
					$i
				) . '" value="' . htmlspecialchars( $val ?? '' ) . '" placeholder="' . __('Recent Posts','DigiPress') . '" style="width:55%;" /></label></p><p><label for="' .
				sprintf(
					'%1$s[%2$s]',
					$tab_orderby_id,
					$i
				) . '">- ' . __('Order by','DigiPress') . ' : </label><select id="' .
				sprintf(
					'%1$s[%2$s]',
					$tab_orderby_id,
					$i
				) . '" name="' .
				sprintf(
					'%1$s[%2$s]',
					$tab_orderby_name,
					$i
				) . '" size=1 style="min-width:55%;">';

			// Order by select form
			foreach ( $arr_tab_orderby as $j => $order ) {
				if ( isset($tab_orderby[$i]) && !empty($tab_orderby[$i]) && $j === $tab_orderby[$i] ) {
					$tab_list_form .= '<option value="' . $j . '" selected>' . $order . '</option>';
				} else {
					$tab_list_form .= '<option value="' . $j . '">' . $order . '</option>';
				}
			}
			$tab_list_form .= '</select>';

			// Target categories
			$tab_list_form .= '<p><label for="' .
				sprintf(
					'%1$s[%2$s]',
					$tab_category_id,
					$i
				) . '">- ' . __( 'Target Category(ID or slug)', 'DigiPress' ) . ' : </label><input type="text" id="' .
				sprintf(
					'%1$s[%2$s]',
					$tab_category_id,
					$i
				) . '" name="' .
				sprintf(
					'%1$s[%2$s]',
					$tab_category_name,
					$i
				) . '" value="' . htmlspecialchars( $tab_category[$i] ?? '' ) . '" placeholder="' . __('1,23,-4','DigiPress') . '" style="width:40%;" />';

			$tab_list_form .= '</div>';
		}

		// Layout
		foreach ( $arr_layout as $key => $val ) {
			if ( $key === $layout ) {
				$layout_form .= '<option value="' . $key . '" selected>' . $val . '</option>';
			} else {
				$layout_form .= '<option value="' . $key . '">' . $val . '</option>';
			}
		}

		// Loop column
		foreach ( $arr_loop_col as $key => $val ) {
			if ( $key == $loop_col ) {
				$loop_col_form .= '<option value="' . $key . '" selected>' . $val . '</option>';
			} else {
				$loop_col_form .= '<option value="' . $key . '">' . $val . '</option>';
			}
		}

		// Slider mode
		foreach ( $arr_slider_mode as $key => $val ) {
			if ( $key === $slider_mode ) {
				$slider_mode_form .= '<option value="' . $key . '" selected>' . $val . '</option>';
			} else {
				$slider_mode_form .= '<option value="' . $key . '">' . $val . '</option>';
			}
		}

		// Custom frame design
		foreach ( $arr_magazine_cover_frame as $key => $val ) {
			if ( $key === $magazine_cover_frame ) {
				$magazine_cover_frame_form .= '<option value="' . $key . '" selected>' . $val . '</option>';
			} else {
				$magazine_cover_frame_form .= '<option value="' . $key . '">' . $val . '</option>';
			}
		}

		// Magazine title position
		foreach ( $arr_magazine_title_position as $key => $val ) {
			if ( $key === $magazine_title_position ) {
				$magazine_title_position_form .= '<option value="' . $key . '" selected>' . $val . '</option>';
			} else {
				$magazine_title_position_form .= '<option value="' . $key . '">' . $val . '</option>';
			}
		}

		// Overlay color
		foreach ( $arr_overlay_color as $key => $val ) {
			if ( $key === $overlay_color ) {
				$overlay_color_form .= '<option value="' . $key . '" selected>' . $val . '</option>';
			} else {
				$overlay_color_form .= '<option value="' . $key . '">' . $val . '</option>';
			}
		}
		$overlay_color_form = '<select id="' . $overlay_color_id . '" name="' . $overlay_color_name . '" size=1 style="width:150px;">' . $overlay_color_form . '</select>';

		// Custom Post type
		$all_custom_post_types = get_post_types(
					array(
						'public'	=> true,
						'_builtin'	=> false
					), 'objects');
		$form_post_type_code = ($post_type === 'post') ? '<option value="post" selected>'.__('Posts', 'default').'</option>' : '<option value="post">'.__('Posts', 'default').'</option>';
		foreach ( $all_custom_post_types as $cpt ) {
			if ( $post_type === $cpt->name ) {
				$form_post_type_code .= '<option value="' . $cpt->name . '" selected>' . $cpt->label.'</option>';
			} else {
				$form_post_type_code .= '<option value="' . $cpt->name . '">' . $cpt->label.'</option>';
			}
		}
		$form_post_type_code = '<select name="' . $post_type_name . '" id="' . $post_type_id . '">' . $form_post_type_code.'</select>';

		/**
		 * Apply filter(For Popular Posts plugin)
		 */
		$term_code = apply_filters( 'dp_most_viewed_widget_form', 
			array(
				'post',
				$meta_key, 
				$meta_key_name, 
				$meta_key_id)
			);
		if ( !empty($term_code) && is_string($term_code) ) {
			$term_code .= '<p class="pd20px-l ft12px">' . __( '*Note : This option is available when the display order is sort by viewed count.', 'DigiPress' ) . '</p>';
		}

		// Show form
		$form_code = '<p>'.__('*Note : This widget is suitable for container or content area.','DigiPress').'</p><hr />';
		$form_code .= '<p><label for="' . $title_id . '">'.__('Title','DigiPress').':</label><br /><input type="text" name="' . $title_name . '" id="' . $title_id . '" value="' . $title . '" style="width:100%;" /></p>';
		$form_code .= '<p><label for="' . $number_id . '">'.__('Number to display','DigiPress').': </label><input type="number" min=1 name="' . $number_name . '" id="' . $number_id . '" value="' . $number . '" style="width:80px;" /></p>';
		$form_code .= '<p><label for="' . $post_type_id . '">'.__('Target post type','DigiPress').' :</label> ' . $form_post_type_code.'</p>';
		$form_code .= '<p><label for="' . $layout_id . '">'.__('Archive layout','DigiPress').' :</label> <select id="' . $layout_id . '" name="' . $layout_name . '" size=1 style="min-width:50%;">' . $layout_form.'</select></p>';

		$form_code .= '<div class="dp_widget_expand_option">
						<div class="opt_title">' . sprintf(__('%s option(*Hover open)', 'DigiPress'), __('Magazine', 'DigiPress')) . '</div>
						<div class="option_table"><hr />
							<div class="flex-box dir-col gap10">
								<div class="flex-item">
									<label for="' . $magazine_cover_frame_id . '" class="disp-blk">'.__('Frame design', 'DigiPress') . '</label>
									<select id="' . $magazine_cover_frame_id . '" name="' . $magazine_cover_frame_name . '" size=1>' . $magazine_cover_frame_form . '</select>
								</div>
								<div class="flex-item">
									<label for="' . $magazine_cover_frame_color_id . '" class="disp-blk">'.__('Frame color', 'DigiPress') . '</label>
									<input type="text" name="' . $magazine_cover_frame_color_name . '" value="' . ( !isset( $magazine_cover_frame_color ) || empty( $magazine_cover_frame_color ) ? '#ffffff' : $magazine_cover_frame_color ) . '" class="dp-color-field" data-default-color="#ffffff" />
								</div>
							</div>

							<div class="flex-box dir-col gap10">
								<div class="flex-item">
									<label for="' . $magazine_title_position_id . '" class="disp-blk">'.__('Title position', 'DigiPress') . '</label>
									<select id="' . $magazine_title_position_id . '" name="' . $magazine_title_position_name . '" size=1>' . $magazine_title_position_form . '</select>
								</div>
								<div class="flex-item">
									<label for="' . $magazine_title_color_id . '" class="disp-blk">' . __( 'Title color', 'DigiPress' ) . '</label>
					 				<input type="text" name="' . $magazine_title_color_name . '" id="' . $magazine_title_color_id . '" value="' . ( !isset( $magazine_title_color ) || empty( $magazine_title_color ) ? '#ffffff' : $magazine_title_color ) . '" class="dp-color-field" data-default-color="#ffffff" />
								</div>
							</div>

							<div class="flex-box dir-col">
								<div class="flex-item">
									<input type="checkbox" name="' . $magazine_title_back_name . '" id="' . $magazine_title_back_id . '" class="toggle_ele" value="has-title-back"' . ( isset( $magazine_title_back ) && $magazine_title_back == 'has-title-back' ? ' checked="checked"' : '' ) . ' />
									<label for="' . $magazine_title_back_id . '">' . __( 'Show the title background color', 'DigiPress' ) . '</label>
									<div class="toggle_content mg20px-l box-c">
										<div class="flex-box gap10">
											<div class="flex-item">
												<label for="' . $magazine_title_back_color_id . '" class="disp-blk">' . __( 'Title background color', 'DigiPress' ) . '</label>
								 				<input type="text" name="' . $magazine_title_back_color_name . '" id="' . $magazine_title_back_color_id . '" value="' . ( !isset( $magazine_title_back_color ) || empty( $magazine_title_back_color ) ? '#000000' : $magazine_title_back_color ) . '" class="dp-color-field" data-default-color="#000000" />
											</div>
										</div>
										<div class="flex-box gap10">
											<div class="flex-item">
												<label for="' . $magazine_title_back_color_opacity_id . '" class="disp-blk">' . __( 'Title background opacity', 'DigiPress' ) . '</label>
								 				<input type="number" name="' . $magazine_title_back_color_opacity_name . '" id="' . $magazine_title_back_color_opacity_id . '" value="' . ( !isset( $magazine_title_back_color_opacity ) || empty( $magazine_title_back_color_opacity ) ? 50 : $magazine_title_back_color_opacity ) . '" min="1" max="100" step="1" /> %
											</div>
										</div>
										<div class="flex-box gap10">
											<div class="flex-item">
												<label for="' . $magazine_title_back_border_id . '" class="disp-blk"> ' . __( 'Title background border', 'DigiPress' ) . '</label>
												<select name="' . $magazine_title_back_border_name . '" id="' . $magazine_title_back_border_id . '" size=1>
													<option value="" ' . ( !isset( $magazine_title_back_border ) || empty( $magazine_title_back_border ) ? ' selected="selected"' : '' ) . '>' . __( 'None', 'DigiPress' ) . '</option>
													<option value="has-title-bd title-back-bd" ' . ( isset( $magazine_title_back_border ) && $magazine_title_back_border == 'has-title-bd title-back-bd' ? ' selected="selected"' : '' ) . '>' . __( 'Solid line', 'DigiPress' ). '</option>
													<option value="has-title-bd title-back-bd__double" ' . ( isset( $magazine_title_back_border ) && $magazine_title_back_border == 'has-title-bd title-back-bd__double' ? ' selected="selected"' : '' ) . '>' . __( 'Double line', 'DigiPress' ). '</option>
													<option value="has-title-bd title-back-bd__dashed" ' . ( isset( $magazine_title_back_border ) && $magazine_title_back_border == 'has-title-bd title-back-bd__dashed' ? ' selected="selected"' : '' ) . '>' . __( 'Dashed line', 'DigiPress' ). '</option>
													<option value="has-title-bd title-back-bd__dot" ' . ( isset( $magazine_title_back_border ) && $magazine_title_back_border == 'has-title-bd title-back-bd__dot' ? ' selected="selected"' : '' ) . '>' . __( 'Dot line', 'DigiPress' ). '</option>
												</select>
											</div>
										</div>
									</div>
								</div>

								<div class="flex-item">
									<input type="checkbox" name="' . $magazine_title_by_bold_name . '" id="' . $magazine_title_by_bold_id . '" value="title-normal-weight"' . ( isset( $magazine_title_by_bold ) && $magazine_title_by_bold == 'title-normal-weight' ? ' checked="checked"' : '' ) . ' />
									<label for="' . $magazine_title_by_bold_id . '">' . __( 'Disable bold title', 'DigiPress' ) . '</label>
								</div>

								<div class="flex-item">
									<label for="' . $magazine_title_tilt_id . '" class="disp-blk"> ' . __( 'Title tilt', 'DigiPress' ) . '</label>
									<select name="' . $magazine_title_tilt_name . '" id="' . $magazine_title_tilt_id . '" size=1>
										<option value="" ' . ( !isset( $magazine_title_tilt ) || empty( $magazine_title_tilt ) ? ' selected="selected"' : '' ) . '>' . __( 'None', 'DigiPress' ) . '</option>
										<option value="title-tilt" ' . ( isset( $magazine_title_tilt ) && $magazine_title_tilt == 'title-tilt' ? ' selected="selected"' : '' ) . '>' . __( 'Upper to right', 'DigiPress' ). '</option>
										<option value="title-tilt down-to-r" ' . ( isset( $magazine_title_tilt ) && $magazine_title_tilt == 'title-tilt down-to-r' ? ' selected="selected"' : '' ) . '>' . __( 'Downward to right', 'DigiPress' ). '</option>
									</select>
								</div>

								<div class="flex-item">
									<input type="checkbox" name="' . $magazine_text_by_serif_name . '" id="' . $magazine_text_by_serif_id . '" value="serif"' . ( isset( $magazine_text_by_serif ) && $magazine_text_by_serif == 'serif' ? ' checked="checked"' : '' ) . ' />
									<label for="' . $magazine_text_by_serif_id . '">' . __( 'Display the text in serif font', 'DigiPress' ) . '</label>
								</div>

								<div class="flex-item">
									<input type="checkbox" name="' . $magazine_text_vertically_name . '" id="' . $magazine_text_vertically_id . '" value="txt-vertical"' . ( isset( $magazine_text_vertically ) && $magazine_text_vertically == 'txt-vertical' ? ' checked="checked"' : '' ) . ' />
									<label for="' . $magazine_text_vertically_id . '">' . __( 'Display the text vertically', 'DigiPress' ) . '</label>
									<p class="description">' . __( '*In vertical writing mode, the title position is disabled.', 'DigiPress' ) . '</p>
								</div>
							</div>

							<div class="flex-box">
								<div class="flex-item">
									<label for="' . $magazine_date_design_id . '" class="disp-blk"> ' . __( 'Date design', 'DigiPress' ) . '</label>
									<select name="' . $magazine_date_design_name . '" id="' . $magazine_date_design_id . '" size=1>
										<option value="date1" ' . ( !isset( $magazine_date_design ) || $magazine_date_design == 'date1' ? ' selected="selected"' : '' ) . '>' . __( 'Default', 'DigiPress' ) . '</option>
										<option value="date2" ' . ( isset( $magazine_date_design ) && $magazine_date_design == 'date2' ? ' selected="selected"' : '' ) . '>' . __( 'Vertically', 'DigiPress' ). '</option>
										<option value="date3" ' . ( isset( $magazine_date_design ) && $magazine_date_design == 'date3' ? ' selected="selected"' : '' ) . '>' . __( 'Line square', 'DigiPress' ). '</option>
										<option value="date4" ' . ( isset( $magazine_date_design ) && $magazine_date_design == 'date4' ? ' selected="selected"' : '' ) . '>' . __( 'Round shape', 'DigiPress' ). '</option>
									</select>
								</div>
							</div>

							<div class="flex-box gap10">
								<div class="flex-item">
									<label for="' . $magazine_accent_shape_id . '" class="disp-blk"> ' . __( 'Accent shape', 'DigiPress' ) . '</label>
									<select name="' . $magazine_accent_shape_name . '" id="' . $magazine_accent_shape_id . '" size=1>
										<option value="" ' . ( !isset( $magazine_accent_shape ) || empty( $magazine_accent_shape ) ? ' selected="selected"' : '' ) . '>' . __( 'None', 'DigiPress' ) . '</option>
										<option value="has-acc-shape acc__shape1" ' . ( isset( $magazine_accent_shape ) && $magazine_accent_shape == 'has-acc-shape acc__shape1' ? ' selected="selected"' : '' ) . '>' . __( 'Square', 'DigiPress' ). '</option>
										<option value="has-acc-shape acc__shape2" ' . ( isset( $magazine_accent_shape ) && $magazine_accent_shape == 'has-acc-shape acc__shape2' ? ' selected="selected"' : '' ) . '>' . __( 'Rhombus', 'DigiPress' ). '</option>
										<option value="has-acc-shape acc__shape3" ' . ( isset( $magazine_accent_shape ) && $magazine_accent_shape == 'has-acc-shape acc__shape3' ? ' selected="selected"' : '' ) . '>' . __( 'Circle', 'DigiPress' ). '</option>
										<option value="has-acc-shape acc__shape4" ' . ( isset( $magazine_accent_shape ) && $magazine_accent_shape == 'has-acc-shape acc__shape4' ? ' selected="selected"' : '' ) . '>' . __( 'Right triangle', 'DigiPress' ) . ' #1' . '</option>
										<option value="has-acc-shape acc__shape5" ' . ( isset( $magazine_accent_shape ) && $magazine_accent_shape == 'has-acc-shape acc__shape5' ? ' selected="selected"' : '' ) . '>' . __( 'Right triangle', 'DigiPress' ) . ' #2' . '</option>
										<option value="has-acc-shape acc__shape6" ' . ( isset( $magazine_accent_shape ) && $magazine_accent_shape == 'has-acc-shape acc__shape6' ? ' selected="selected"' : '' ) . '>' . __( 'Parallelogram', 'DigiPress' ) . ' #1' . '</option>
										<option value="has-acc-shape acc__shape7" ' . ( isset( $magazine_accent_shape ) && $magazine_accent_shape == 'has-acc-shape acc__shape7' ? ' selected="selected"' : '' ) . '>' . __( 'Parallelogram', 'DigiPress' ) . ' #2' . '</option>
										<option value="has-acc-shape acc__shape8" ' . ( isset( $magazine_accent_shape ) && $magazine_accent_shape == 'has-acc-shape acc__shape8' ? ' selected="selected"' : '' ) . '>' . __( 'Pentagon', 'DigiPress' ) . '</option>
									</select>
								</div>
							</div>

							<div class="flex-box dir-col gap10">
								<div class="flex-item">
									<label for="' . $magazine_accent_shape_color_id . '" class="disp-blk">' . __( 'Accent shape color', 'DigiPress' ) . '</label>
					 				<input type="text" name="' . $magazine_accent_shape_color_name . '" id="' . $magazine_accent_shape_color_id . '" value="' . ( !isset( $magazine_accent_shape_color ) || empty( $magazine_accent_shape_color ) ? '#ffffff' : $magazine_accent_shape_color ) . '" class="dp-color-field" data-default-color="#ffffff" />
								</div>
								<div class="flex-item">
									<label for="' . $magazine_accent_shape_opacity_id . '" class="disp-blk">' . __( 'Accent shape opacity', 'DigiPress' ) . '</label>
					 				<input type="number" name="' . $magazine_accent_shape_opacity_name . '" id="' . $magazine_accent_shape_opacity_id . '" value="' . ( !isset( $magazine_accent_shape_opacity ) || empty( $magazine_accent_shape_opacity ) ? 30 : $magazine_accent_shape_opacity ) . '" min="1" max="100" step="1" /> %
								</div>
							</div>
						</div>
					</div>';

		$form_code .= '<div class="dp_widget_expand_option">
						<div class="opt_title">' . sprintf(__('%s option(*Hover open)', 'DigiPress'), __('Slider', 'DigiPress')) . '</div>
							<div class="option_table"><hr />
								<div class="flex-box">
									<div class="flex-item">
										<label for="' . $slider_mode_id . '" class="disp-blk">'.__('- Slider mode : ', 'DigiPress').'</label>
										<select id="' . $slider_mode_id . '" name="' . $slider_mode_name . '" size=1>' . $slider_mode_form.'</select>
									</div>
								</div>

								<div class="flex-box dir-col">
									<div class="flex-item">
										<label for="' . $slider_duration_id . '" class="disp-blk">'.__('- Duration : ', 'DigiPress').'</label>
										<input id="' . $slider_duration_id . '" name="' . $slider_duration_name . '" type="number" value="' . $slider_duration . '" style="width:90px;" />' . __('ms', 'DigiPress') .
									'</div>
									<div class="flex-item">
										<label for="' . $slider_speed_id . '" class="disp-blk">' . __('- Transition speed : ', 'DigiPress') . '</label>
										<input id="' . $slider_speed_id . '" name="' . $slider_speed_name . '" type="number" value="' . $slider_speed . '" style="width:90px;" />' . __('ms', 'DigiPress') .
									'</div>
								</div>

								<div class="flex-box dir-col">
									<div class="flex-item">
										<label for="' . $slider_control_btn_id . '">
											<input id="' . $slider_control_btn_id . '" name="' . $slider_control_btn_name . '" type="checkbox" value="true" ' . $slider_control_btn_check . ' />' . __('Show prev/next', 'DigiPress') .
										'</label>
									</div>
									<div class="flex-item">
										<label for="' . $slider_navigation_id . '">
											<input id="' . $slider_navigation_id . '" name="' . $slider_navigation_name . '" type="checkbox" value="true" ' . $slider_navigation_check . ' />' . __('Show navigation', 'DigiPress').
										'</label>
									</div>
								</div>
							</div>
						</div>';

		$form_code .= '<p><label for="' . $loop_col_id . '">'.__('Column :','DigiPress').'</label> <select id="' . $loop_col_id . '" name="' . $loop_col_name . '" size=1 style="min-width:50%;">' . $loop_col_form.'</select><br /><span class="pd20px-l ft12px">' . sprintf( __( '*Note: For %s', 'DigiPress' ), __('Portfolio', 'DigiPress') . ', ' . __('Magazine', 'DigiPress') ) . '</span></p>';

		// Toggle form
		$form_code .= '<div class="mg20px-top mg20px-btm">';
		$form_code .= '<input name="' . $enable_tab_list_name . '" id="' . $enable_tab_list_id . '" type="checkbox" value="1" class="toggle_ele rev"' . $enable_tab_list_check.' /><label for="' . $enable_tab_list_id . '">' . __( 'Switch article list with tab', 'DigiPress' ) . '</label>';

		$form_code .= '<div class="toggle_content mg20px-top mg20px-btm"><label for="' . $orderby_id . '">'.__('Order by','DigiPress').' :</label> <select id="' . $orderby_id . '" name="' . $orderby_name . '" size=1 style="min-width:50%;">' . $orderby_form . '</select></div>';

		$form_code .= '<div class="toggle_content box mg15px-top mg20px-btm">' . $tab_list_form . '<hr /><div class="ft12px">'.__('*Note: Specific category ID or slug are available.(ex. 2,4,12,"cat-slug")', 'DigiPress').'</div></div>';
		$form_code .= '</div>';


		if ( is_string($term_code) ) {
			$form_code .= $term_code;
		}

		$form_code .= '<p><label for="' . $overlay_color_id . '">' . __('Overlay color','DigiPress') . '</label> : ' . $overlay_color_form . '<br /><span class="pd20px-l ft12px">' . sprintf( __( '*Note: For %s', 'DigiPress' ), __('Standard', 'DigiPress') . ',' . __('Portfolio', 'DigiPress') ) . '</span></p>';

		$form_code .= '<p><label for="' . $excerpt_length_id . '">'.__('Excerpt length:','DigiPress').' </label><input type="number" min=0 max=300 name="' . $excerpt_length_name . '" id="' . $excerpt_length_id . '" value="' . $excerpt_length . '" style="width:80px;" />'.__('strings', 'DigiPress').'</p>';

		$form_code .= '<p><label for="' . $pub_date_id . '"><input name="' . $pub_date_name . '" id="' . $pub_date_id . '" type="checkbox" value="show" ' . $pub_date_check.' />'.__('Show date','DigiPress').'</label></p>';
		$form_code .= '<p><label for="' . $author_id . '"><input name="' . $author_name . '" id="' . $author_id . '" type="checkbox" value="show" ' . $author_check.' />'.__('Show author','DigiPress').'</label></p>';
		$form_code .= '<p><label for="' . $show_cat_id . '"><input name="' . $show_cat_name . '" id="' . $show_cat_id . '" type="checkbox" value="true" ' . $show_cat_check.' />'.__('Show category','DigiPress').'</label></p>';
		$form_code .= '<p><label for="' . $views_id . '"><input name="' . $views_name . '" id="' . $views_id . '" type="checkbox" value="on" ' . $views_check.' />'.__('Show views.', 'DigiPress').'</label></p>';
		$form_code .= '<p><label for="' . $comment_id . '"><input name="' . $comment_name . '" id="' . $comment_id . '" type="checkbox" value="on" ' . $comment_check.' />'.__('Show the comment number', 'DigiPress').'</label></p>';
		$form_code .= '<p><label for="' . $likes_num_id . '"><input name="' . $likes_num_name . '" id="' . $likes_num_id . '" type="checkbox" value="on" ' . $likes_num_check.' />'.__('Show FB likes count', 'DigiPress').'</label></p>';
		$form_code .= '<p><label for="' . $tweets_num_id . '"><input name="' . $tweets_num_name . '" id="' . $tweets_num_id . '" type="checkbox" value="on" ' . $tweets_num_check.' />'.__('Show tweeted count', 'DigiPress').'</label></p>';
		$form_code .= '<p><label for="' . $hatebu_num_id . '"><input name="' . $hatebu_num_name . '" id="' . $hatebu_num_id . '" type="checkbox" value="on" ' . $hatebu_num_check.' />'.__('Show hatena bookmarked count', 'DigiPress').'</label></p>';

		$form_code .= '<hr /><p><input name="' . $article_alternately_name . '" id="' . $article_alternately_id . '" type="checkbox" value="on" ' . $article_alternately_check . ' /><label for="' . $article_alternately_id . '">' . __('Display thumbnails alternately', 'DigiPress') . '</label><br /><span class="pd20px-l ft12px">' . sprintf( __('*Note: For %s', 'DigiPress'), __('Standard', 'DigiPress') ) . '</span></p>';


		$form_code .= '<hr /><p><label for="' . $fix_thumb_h_id . '"><input name="' . $fix_thumb_h_name . '" id="' . $fix_thumb_h_id . '" type="checkbox" value="true" ' . $fix_thumb_h_check.' />'.__('Fix the thumbnail height', 'DigiPress').'</label></p>';
		$form_code .= '<p><label for="' . $article_box_shadow_id . '"><input id="' . $article_box_shadow_id . '" name="' . $article_box_shadow_name . '" type="checkbox" value="true" ' . $article_box_shadow_check.' />'.__('Show box shadow on each article', 'DigiPress').'</label></p>';
		$form_code .= '<p><label for="' . $article_round_corner_id . '"><input id="' . $article_round_corner_id . '" name="' . $article_round_corner_name . '" type="checkbox" value="true" ' . $article_round_corner_check.' />'.__('Round element corners', 'DigiPress').'</label></p>';

		// Toggle form
		$form_code .= '<div class="mg20px-top mg20px-btm">';
		$form_code .= '<input name="' . $use_filter_name . '" id="' . $use_filter_id . '" type="checkbox" value="true" class="toggle_ele" ' . $use_filter_check.' />
		<label for="' . $use_filter_id . '">' . __('Enable filtering by category', 'DigiPress') . '</label><br /><span class="pd20px-l ft12px">' . sprintf( __( '*Note: For %s', 'DigiPress' ), __('Portfolio', 'DigiPress') . ', ' . __('Magazine', 'DigiPress') ) . '</span>';

		$form_code .= '<div class="toggle_content mg20px-top mg20px-btm">';
		$form_code .= '<p><label for="' . $filter_exclude_cat_id . '">'.__('Excluded categories (ID) from filtering','DigiPress').':</label><br /><input type="text" name="' . $filter_exclude_cat_name . '" id="' . $filter_exclude_cat_id . '" value="' . $filter_exclude_cat . '" style="width:100%;" placeholder="12,50,104" /></p>';
		$form_code .= '</div></div>';

		$form_code .= '<hr /><p><label for="' . $one_col_id . '"><input name="' . $one_col_name . '" id="' . $one_col_id . '" type="checkbox" value="true" ' . $one_col_check.' />'.__('Show on full width.', 'DigiPress').'</label></p>';


		$form_code .= '<hr /><p><label for="' . $read_more_str_id . '">'.__('More label for each posts','DigiPress').':</label><br /><input type="text" name="' . $read_more_str_name . '" id="' . $read_more_str_id . '" value="' . $read_more_str . '" style="width:100%;" placeholder="' . __('Read more','DigiPress') . '" /></p>';
		$form_code .= '<p><label for="' . $more_text_id . '">'.__('Show more label to the archive','DigiPress').':</label><br /><input type="text" name="' . $more_text_name . '" id="' . $more_text_id . '" value="' . $more_text . '" style="width:100%;" placeholder="' . __('Show more','DigiPress') . '" /></p>';
		$form_code .= '<p><label for="' . $more_url_id . '">'.__('Show more label URL','DigiPress').':</label><br /><input type="text" name="' . $more_url_name . '" id="' . $more_url_id . '" value="' . $more_url . '" style="width:100%;" /><br /><span class="ft12px">'.__('*Note: If the URL is empty, the URL determined by the theme will be set.', 'DigiPress').'</span></p>';
		$form_code .= '<p><label for="' . $cat_id . '">'.__('Target Category(ID or slug)','DigiPress').':</label><br /><input type="text" name="' . $cat_name . '" id="' . $cat_id . '" value="' . htmlspecialchars( $cat ?? '' ) . '" style="width:100%;" placeholder="2,4,12,-102" /><br />
			 <span class="ft12px">'.__('*Note: Specific category ID or slug are available.(ex. 2,4,12,"cat-slug")', 'DigiPress').'</span></p>';
		$form_code .= '<p><label for="' . $tag_id . '">'.__('Target Tag\'s Slug(Optional)','DigiPress').':</label><br />
			 <input type="text" name="' . $tag_name . '" id="' . $tag_id . '" value="' . $tag . '" style="width:100%;" placeholder="bread,morning" /><br />
			 <span class="ft12px">'.__('*Note: Multiple tags are available.(ex. bread,baking)', 'DigiPress').'</span></p>';
		$form_code .= '<p><label for="' . $authors_id . '">'.__('Target Author\'s ID(Optional)','DigiPress').':</label><br />
			 <input type="text" name="' . $authors_name . '" id="' . $authors_id . '" value="' . $authors . '" style="width:100%;" /><br />
			 <span class="ft12px">'.__('*Note: Multiple authors are available.(ex. 2,6)', 'DigiPress').'</span></p>';
		$form_code .= '<p><label for="' . $keyword_id . '">'.__('Search word(Optional)','DigiPress').':</label><br />
			 <input type="text" name="' . $keyword_name . '" id="' . $keyword_id . '" value="' . $keyword . '" style="width:100%;" /><br />
			 <span class="ft12px">'.__('*Note: Insert the seach words to get related posts of the specific words.', 'DigiPress').'</span></p><hr />';
		$form_code .= '<p><label for="' . $disable_cache_id . '" class="b"><input name="' . $disable_cache_name . '" id="' . $disable_cache_id . '" type="checkbox" value="on" ' . $disable_cache_check.' />'.__('Disable cache', 'DigiPress').'</label><br />
			<span class="ft12px">'.__('*Note: If the theme option cache function is enabled, check to not cache this widget.', 'DigiPress').'</span></p><hr />';

		// Display
		echo $form_code;
	}

	// Save Function
	// $new_instance : Input value
	// $old_instance : Exist value
	// Return : New values
	function update( $new_instance, $old_instance ) {
		$instance = $old_instance;

		$instance['title'] = strip_tags($new_instance['title'] );
		$instance['number'] = $new_instance['number'];
		$instance['show_cat']	= $new_instance['show_cat'];
		$instance['comment']	= $new_instance['comment'];
		$instance['author'] = $new_instance['author'];
		$instance['views'] = $new_instance['views'];
		$instance['cat'] = $new_instance['cat'];
		$instance['authors']	= $new_instance['authors'];
		$instance['tag']	= $new_instance['tag'];
		$instance['keyword']	= $new_instance['keyword'];
		$instance['hatebu_num']	= $new_instance['hatebu_num'];
		$instance['tweets_num']	= $new_instance['tweets_num'];
		$instance['likes_num']	= $new_instance['likes_num'];
		$instance['loop_col']	= $new_instance['loop_col'];
		$instance['orderby']	= $new_instance['orderby'];
		$instance['pub_date']	= $new_instance['pub_date'];
		$instance['more_text']	= $new_instance['more_text'];
		$instance['more_url']	= $new_instance['more_url'];
		$instance['read_more_str']	= $new_instance['read_more_str'];
		$instance['layout'] = $new_instance['layout'];
		$instance['excerpt_length']	= $new_instance['excerpt_length'];
		$instance['meta_key']	= $new_instance['meta_key'];
		$instance['post_type']	= $new_instance['post_type'];
		$instance['one_col']	= $new_instance['one_col'];
		$instance['use_filter']	= $new_instance['use_filter'];
		$instance['filter_exclude_cat']	= $new_instance['filter_exclude_cat'];
		$instance['fix_thumb_h']	= $new_instance['fix_thumb_h'];
		$instance['overlay_color']	= $new_instance['overlay_color'];
		$instance['slider_mode']	= $new_instance['slider_mode'];
		$instance['slider_speed']	= $new_instance['slider_speed'];
		$instance['slider_duration'] = $new_instance['slider_duration'];
		$instance['slider_control_btn'] = $new_instance['slider_control_btn'];
		$instance['slider_navigation'] = $new_instance['slider_navigation'];
		$instance['article_box_shadow'] = $new_instance['article_box_shadow'];
		$instance['article_round_corner'] = $new_instance['article_round_corner'];
		$instance['article_alternately'] = $new_instance['article_alternately'];
		$instance['disable_cache'] = $new_instance['disable_cache'];
		$instance['enable_tab_list'] = $new_instance['enable_tab_list'];
		$instance['tab_design'] = $new_instance['tab_design'];
		$instance['magazine_cover_frame'] = $new_instance['magazine_cover_frame'];
		$instance['magazine_cover_frame_color'] = $new_instance['magazine_cover_frame_color'];
		$instance['magazine_title_position'] = $new_instance['magazine_title_position'];
		$instance['magazine_title_color'] = $new_instance['magazine_title_color'];
		$instance['magazine_title_back'] = $new_instance['magazine_title_back'];
		$instance['magazine_title_back_color'] = $new_instance['magazine_title_back_color'];
		$instance['magazine_title_back_color_opacity'] = $new_instance['magazine_title_back_color_opacity'];
		$instance['magazine_title_back_border'] = $new_instance['magazine_title_back_border'];
		$instance['magazine_title_by_bold'] = $new_instance['magazine_title_by_bold'];
		$instance['magazine_title_tilt'] = $new_instance['magazine_title_tilt'];
		$instance['magazine_text_by_serif'] = $new_instance['magazine_text_by_serif'];
		$instance['magazine_text_vertically'] = $new_instance['magazine_text_vertically'];
		$instance['magazine_date_design'] = $new_instance['magazine_date_design'];
		$instance['magazine_accent_shape'] = $new_instance['magazine_accent_shape'];
		$instance['magazine_accent_shape_color'] = $new_instance['magazine_accent_shape_color'];
		$instance['magazine_accent_shape_opacity'] = $new_instance['magazine_accent_shape_opacity'];


		$instance['tab_title'] = $instance['tab_orderby'] = $instance['tab_category'] = array();

		if ( isset( $new_instance['tab_title'] ) ) {
			foreach ( $new_instance['tab_title'] as $value ) {
				if ( empty( $value ) ) {
					$instance['tab_title'][] = '';
				} else {
					$instance['tab_title'][] = $value;
				}
			}
		}
		if ( isset( $new_instance['tab_orderby'] ) ) {
			foreach ( $new_instance['tab_orderby'] as $value ) {
				if ( empty( $value ) ) {
					$instance['tab_orderby'][] = '';
				} else {
					$instance['tab_orderby'][] = $value;
				}
			}
		}
		if ( isset( $new_instance['tab_category'] ) ) {
			foreach ( $new_instance['tab_category'] as $value ) {
				if ( empty( $value ) ) {
					$instance['tab_category'][] = '';
				} else {
					$instance['tab_category'][] = $value;
				}
			}
		}

		// Check errors
		if ( !$instance['title'] ) {
			$before_title 	= '';
			$after_title	= '';
		}
		return $instance;
	}

	// Display to theme
	// $args : output array
	// $instance : exist array
	function widget($args, $instance) {

		global $options, $IS_MOBILE_DP;

		$instance = wp_parse_args(
			(array)$instance,
			array('title' => '',
				'number' => 5,
				'show_cat' => true,
				'comment'	=> false,
				'author'	=> true,
				'views'	=> false,
				'cat'=> null,
				'tag'		=> null,
				'authors'	=> null,
				'keyword'	=> null,
				'orderby'	=> 'date',
				'pub_date' => true,
				'meta_key' => 'post_views_count',
				'post_type' => 'post',
				'hatebu_num' => true,
				'tweets_num' => false,
				'likes_num' => false,
				'loop_col' => 3,
				'more_text'	=> 'More',
				'more_url'	=> '',
				'read_more_str' => 'Read More',
				'layout'=> 'normal',
				'excerpt_length' => 120,
				'one_col' => false,
				'use_filter' => false,
				'filter_exclude_cat' => '',
				'fix_thumb_h' => true,
				'overlay_color' => 'cat',
				'slider_mode' => 'carousel',
				'slider_speed' => 1200,
				'slider_duration' => 3000,
				'slider_control_btn' => true,
				'slider_navigation' => false,
				'article_box_shadow' => false,
				'article_round_corner' => false,
				'article_alternately' => false,
				'disable_cache' => false,
				'enable_tab_list' => false,
				'tab_title' => array_fill( 0, 4, '' ),
				'tab_orderby' => array_fill( 0, 4, '' ),
				'tab_category' => array_fill( 0, 4, '' ),
				'tab_design' => 1,
				'magazine_cover_frame' => '',
				'magazine_cover_frame_color' => '#ffffff',
				'magazine_title_position' => '',
				'magazine_title_color' => '#ffffff',
				'magazine_title_back' => '',
				'magazine_title_back_color' => '',
				'magazine_title_back_color_opacity' => '',
				'magazine_title_back_border' => '',
				'magazine_title_by_bold' => '',
				'magazine_title_tilt' => '',
				'magazine_text_by_serif' => '',
				'magazine_text_vertically' => '',
				'magazine_date_design' => 'date1',
				'magazine_accent_shape' => '',
				'magazine_accent_shape_color' => '#ffffff',
				'magazine_accent_shape_opacity' => 30,
		));

		$widget_code = '';


		/**
		 * Check the transient data and return the cache if cache is exists
		 */
		if ( dp_is_enable_cache( array( 'target' => 'archive_widget' ) ) && !$instance['disable_cache'] ){
			$cache = false;
			if ( $IS_MOBILE_DP ){
				$cache = get_transient( 'dp_wdt_mb_' . $this->id );
			} else {
				$cache = get_transient( 'dp_wdt_' . $this->id );
			}

			if ( $cache !== false ) {
				// Reload js and css
				self::enqueue_css_js( $instance['layout'] );

				echo $cache;
				return;
			}
		}


		extract($args);

		$title = $instance['title'];
		$title = apply_filters('widget_title', $title);
		$number = $instance['number'];
		$show_cat	= $instance['show_cat'];
		$comment	= $instance['comment'];
		$author= $instance['author'];
		$views= $instance['views'];
		$cat = $instance['cat'];
		$tag		= $instance['tag'];
		$authors	= $instance['authors'];
		$keyword	= $instance['keyword'];
		$hatebu_num = $instance['hatebu_num'];
		$tweets_num = $instance['tweets_num'];
		$likes_num = $instance['likes_num'];
		$loop_col = $instance['loop_col'];
		$orderby	= $instance['orderby'];
		$pub_date 	= $instance['pub_date'];
		$more_text 	= $instance['more_text'];
		$more_url 	= $instance['more_url'];
		$read_more_str 	= $instance['read_more_str'];
		$layout 	= $instance['layout'];
		$excerpt_length = $instance['excerpt_length'];
		$one_col 	= $instance['one_col'];
		$use_filter 	= $instance['use_filter'];
		$filter_exclude_cat 	= $instance['filter_exclude_cat'];
		$fix_thumb_h 	= $instance['fix_thumb_h'];
		$overlay_color = $instance['overlay_color'];
		$slider_mode 	= $instance['slider_mode'];
		$slider_speed 	= $instance['slider_speed'];
		$slider_duration= $instance['slider_duration'];
		$slider_control_btn = $instance['slider_control_btn'];
		$slider_navigation = $instance['slider_navigation'];
		$article_box_shadow = $instance['article_box_shadow'];
		$article_round_corner = $instance['article_round_corner'];
		$article_alternately = $instance['article_alternately'];
		$magazine_cover_frame = $instance['magazine_cover_frame'];
		$magazine_cover_frame_color = $instance['magazine_cover_frame_color'];
		$magazine_title_position = $instance['magazine_title_position'];
		$magazine_title_color = $instance['magazine_title_color'];
		$magazine_title_back = $instance['magazine_title_back'];
		$magazine_title_back_color = $instance['magazine_title_back_color'];
		$magazine_title_back_color_opacity = $instance['magazine_title_back_color_opacity'];
		$magazine_title_back_border = $instance['magazine_title_back_border'];
		$magazine_title_by_bold = $instance['magazine_title_by_bold'];
		$magazine_title_tilt = $instance['magazine_title_tilt'];
		$magazine_text_by_serif = $instance['magazine_text_by_serif'];
		$magazine_text_vertically = $instance['magazine_text_vertically'];
		$magazine_date_design = $instance['magazine_date_design'];
		$magazine_accent_shape = $instance['magazine_accent_shape'];
		$magazine_accent_shape_color = $instance['magazine_accent_shape_color'];
		$magazine_accent_shape_opacity = $instance['magazine_accent_shape_opacity'];
		$meta_key 	= $instance['meta_key'] ? $instance['meta_key'] : 'post_views_count';
		$post_type 	= $instance['post_type'] ? $instance['post_type'] : 'post';

		// Mobile suffix
		$suffix_mb = $IS_MOBILE_DP ? '_mobile' : '';

		// wow.js
		$wow_list_css 	= '';
		if ( !(bool)$options['disable_wow_js' . $suffix_mb] ){
			$wow_list_css = ' wow fadeIn';
		}



		// If the list is tab mode
		$tab_title_code = '';
		if ( isset( $instance['enable_tab_list'] ) && $instance['enable_tab_list'] ) {

			$li_class = 'dp_arc_wd_tab__title dp_role_tab_list__item';
			$btn_class = 'dp_arc_wd_tab__btn dp_role_tab_list__btn';
			$panel_class = 'dp_role_tab_panels__item';

			if ( isset( $instance['tab_orderby'] ) && !empty( $instance['tab_orderby'] ) ) {

				// Counter
				$counter = 0;

				// Tab title code
				$tab_title_code = '<div class="dp_role_tab_list_area' . $wow_list_css . '"><ul class="dp_role_tab_list dp_arc_wd_tab__ul tab_design_' . $instance['tab_design'] . '" role="tablist">';

				// get target caterogies
				$cat = $instance['tab_category'];


				foreach ( $instance['tab_orderby'] as $i => $orderby ) {

					if ( !empty( $orderby ) ) {

						$counter++;

						// Panel content wrapper
						$widget_code .= sprintf(
							'<div id="%s" class="%s" aria-hidden="',
							'tab-' . $this->id . '-' . $counter,
							$panel_class
						);

						// Tab titles
						$tab_title_code .= sprintf(
							'<li class="%s" role="presentation"><button type="button" class="%s" role="tab" aria-controls="%s" aria-selected="',
							$li_class,
							$btn_class,
							'tab-' . $this->id . '-' . $counter
						);

						if ( $counter === 1 ) {
							$tab_title_code .= 'true';
							$widget_code .= 'false';
						} else {
							$tab_title_code .= 'false';
							$widget_code .= 'true';
						}
						$tab_title_code .= '"><span>' . $instance['tab_title'][$i] . '</span></button></li>';


						// Article list
						$widget_code .= '">';
						$widget_code .= DP_LISTING_POST_EACH_STYLES(array(
								'id' 		=> $this->id . '-' . $i,
								'echo'		=> false,
								'number'	=> $number,
								'comment'	=> $comment,
								'author'	=> $author,
								'views' 	=> $views,
								'show_cat'	=> $show_cat,
								'cat_id'	=> isset( $cat[$i] ) ? str_replace( "\s", "", $cat[$i] ) : '',
								'tag_slug'	=> str_replace( "\s", "", $tag ?? '' ),
								'authors_id'=> str_replace( "\s", "", $authors ?? '' ),
								'keyword' => $keyword,
								'hatebu_num'=> $hatebu_num,
								'tweets_num'=> $tweets_num,
								'likes_num'	=> $likes_num,
								'loop_col' => $loop_col,
								'orderby'	=> $orderby,
								'order' => 'DESC',
								'pub_date'	=> $pub_date,
								'more_text'	=> $more_text,
								'more_url'	=> $more_url,
								'read_more_str'	=> $read_more_str,
								'type'=> 'recent',
								'layout'	=> $layout,
								'excerpt_length' => $excerpt_length,
								'meta_key'	=> $meta_key,
								'post_type'	=> $post_type,
								'one_col' => $one_col,
								'use_filter' => $use_filter,
								'filter_exclude_cat' => $filter_exclude_cat,
								'fix_thumb_h' => $fix_thumb_h,
								'overlay_color'=> $overlay_color,
								'slider_mode' => $slider_mode,
								'slider_speed' => $slider_speed,
								'slider_duration' => $slider_duration,
								'slider_control_btn' => $slider_control_btn,
								'slider_navigation' => $slider_navigation,
								'article_box_shadow' => $article_box_shadow,
								'article_round_corner' => $article_round_corner,
								'article_alternately' => $article_alternately,
								'magazine_cover_frame' => $magazine_cover_frame,
								'magazine_cover_frame_color' => $magazine_cover_frame_color,
								'magazine_title_position' => $magazine_title_position,
								'magazine_title_color' => $magazine_title_color,
								'magazine_title_back' => $magazine_title_back,
								'magazine_title_back_color' => $magazine_title_back_color,
								'magazine_title_back_color_opacity' => $magazine_title_back_color_opacity,
								'magazine_title_back_border' => $magazine_title_back_border,
								'magazine_title_by_bold' => $magazine_title_by_bold,
								'magazine_title_tilt' => $magazine_title_tilt,
								'magazine_text_by_serif' => $magazine_text_by_serif,
								'magazine_text_vertically' => $magazine_text_vertically,
								'magazine_date_design' => $magazine_date_design,
								'magazine_accent_shape' => $magazine_accent_shape,
								'magazine_accent_shape_color' => $magazine_accent_shape_color,
								'magazine_accent_shape_opacity' => $magazine_accent_shape_opacity,
							)
						);
						$widget_code .= '</div>';
					}
				}

				$tab_title_code .= '</ul></div>';
				$widget_code = '<div class="dp_role_tab_panels">' . $widget_code . '</div>';

				// Close
				if ( $instance['title'] ) {
					$widget_code = $before_widget . $before_title . $title . $after_title . $tab_title_code . $widget_code;
				} else {
					$widget_code = $before_widget . $tab_title_code . $widget_code;
				}
			}

		} else {

			// Display widget
			$widget_code = $before_widget;
			if ( $instance['title'] ) {
				$widget_code .= $before_title . $title . $after_title;
			}

			$widget_code .= DP_LISTING_POST_EACH_STYLES(array(
					'id' 		=> $this->id,
					'echo'		=> false,
					'number'	=> $number,
					'comment'	=> $comment,
					'author'	=> $author,
					'views' 	=> $views,
					'show_cat'	=> $show_cat,
					'cat_id'	=> str_replace( "\s", "", $cat ?? '' ),
					'tag_slug'	=> str_replace( "\s", "", $tag ?? '' ),
					'authors_id'=> str_replace( "\s", "", $authors ?? '' ),
					'keyword' => $keyword,
					'hatebu_num'=> $hatebu_num,
					'tweets_num'=> $tweets_num,
					'likes_num'	=> $likes_num,
					'loop_col' => $loop_col,
					'orderby'	=> $orderby,
					'order' => 'DESC',
					'pub_date'	=> $pub_date,
					'more_text'	=> $more_text,
					'more_url'	=> $more_url,
					'read_more_str'	=> $read_more_str,
					'type'=> 'recent',
					'layout'	=> $layout,
					'excerpt_length' => $excerpt_length,
					'meta_key'	=> $meta_key,
					'post_type'	=> $post_type,
					'one_col' => $one_col,
					'use_filter' => $use_filter,
					'filter_exclude_cat' => $filter_exclude_cat,
					'fix_thumb_h' => $fix_thumb_h,
					'overlay_color'=> $overlay_color,
					'slider_mode' => $slider_mode,
					'slider_speed' => $slider_speed,
					'slider_duration' => $slider_duration,
					'slider_control_btn' => $slider_control_btn,
					'slider_navigation' => $slider_navigation,
					'article_box_shadow' => $article_box_shadow,
					'article_round_corner' => $article_round_corner,
					'article_alternately' => $article_alternately,
					'magazine_cover_frame' => $magazine_cover_frame,
					'magazine_cover_frame_color' => $magazine_cover_frame_color,
					'magazine_title_position' => $magazine_title_position,
					'magazine_title_color' => $magazine_title_color,
					'magazine_title_back' => $magazine_title_back,
					'magazine_title_back_color' => $magazine_title_back_color,
					'magazine_title_back_color_opacity' => $magazine_title_back_color_opacity,
					'magazine_title_back_border' => $magazine_title_back_border,
					'magazine_title_by_bold' => $magazine_title_by_bold,
					'magazine_title_tilt' => $magazine_title_tilt,
					'magazine_text_by_serif' => $magazine_text_by_serif,
					'magazine_text_vertically' => $magazine_text_vertically,
					'magazine_date_design' => $magazine_date_design,
					'magazine_accent_shape' => $magazine_accent_shape,
					'magazine_accent_shape_color' => $magazine_accent_shape_color,
					'magazine_accent_shape_opacity' => $magazine_accent_shape_opacity,
				)
			);
		}

		$widget_code .= $after_widget;

		echo $widget_code;


		/**
		 * Save to cache
		 */
		if ( dp_is_enable_cache( array( 'target' => 'plx_widget' ) ) && !$instance['disable_cache'] ){
			if ( $IS_MOBILE_DP ){
				set_transient( 'dp_wdt_mb_' . $this->id, $widget_code, 0 );
			} else {
				set_transient( 'dp_wdt_' . $this->id, $widget_code, 0 );
			}
		}
	}

	/**
	* Tell WP we want to use this widget.
	*
	* @wp-hook widgets_init
	* @return void
	*/
	public static function register() {
		register_widget( __CLASS__ );
	}
}
// widgets_init
add_action( 'widgets_init', array( 'DP_RecentPosts_Widget_For_Archive', 'register' ) );