<?php
/**
 * The Footer widget areas.
 *
 * @package WordPress
 * @subpackage DigiPress
 */
function dp_get_footer() {
	global $options, $IS_MOBILE_DP;

	$widget_flag 	= true;

	// ***********************
	// Start footer container
	// ***********************
	if ( $IS_MOBILE_DP ) {
		// Widgets
		if ( is_active_sidebar( 'widget-footer-mb' ) ) {
			// get the widget
			ob_start();
			dynamic_sidebar( 'widget-footer-mb' );
			$widget_footer = ob_get_contents();
			ob_end_clean();

			if ( !empty( $widget_footer ) ) {
				// Display
				echo '<div class="ft-widget-wrapper">' . $widget_footer . '</div>';
			}
		}
	} else {
		// PC
		if (!is_active_sidebar( 'footer-widget1' )
			&& !is_active_sidebar( 'footer-widget2' )
			&& !is_active_sidebar( 'footer-widget3' )
			&& !is_active_sidebar( 'footer-widget4' ) ) {
				$widget_flag = false;
			}

		// Widgets
		if ( (bool)$widget_flag ) {
			$code = '<div class="ft-widget-wrapper"><div class="__container colnum-' . $options['footer_col_number'] . '">';

			ob_start();
			// 1st Column
			if ( is_active_sidebar( 'footer-widget1' ) ) {?>
<div class="widget-area one clearfix"><?php dynamic_sidebar( 'footer-widget1' ); ?></div><?php
			}
			// 2nd Column
			if ( is_active_sidebar( 'footer-widget2' ) && $options['footer_col_number'] != 1 ) {?>
<div class="widget-area two clearfix"><?php dynamic_sidebar( 'footer-widget2' ); ?></div><?php
			}
			// 3rd Column
			if ( is_active_sidebar( 'footer-widget3' ) && (int)$options['footer_col_number'] >= 3  ) {?>
<div class="widget-area three clearfix"><?php dynamic_sidebar( 'footer-widget3' ); ?></div><?php
			}
			// 4th Column
			if ( is_active_sidebar( 'footer-widget4' ) && $options['footer_col_number'] == 4 ) {?>
<div class="widget-area four clearfix"><?php dynamic_sidebar( 'footer-widget4' ); ?></div><?php
			}
			$code .= ob_get_contents();
			ob_end_clean();

			$code .= '</div></div>';

			echo $code;

		} // End of if ((bool)$widget_flag)
	}	// if ($IS_MOBILE_DP)
}	// End of "function dp_get_footer()"