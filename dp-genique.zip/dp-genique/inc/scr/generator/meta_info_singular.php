<?php
/**
 * Meta content for single page
 */
function get_post_meta_for_single_page() {

	global $options, $def_options, $post, $SINGLE_META;

	// Exception page
	if ( !is_singular() ){
		$SINGLE_META = array();
		return;
	}

	$post_type = get_post_type_object( get_post_type() );
	$post_type_name = isset( $post_type->name ) ? esc_html( $post_type->name ) : 'post';
	if ( $post_type_name == 'topic' || $post_type_name == 'forum' || $post_type_name == 'forums' || !is_singular()) {
		$SINGLE_META = array();
		return;
	}


	$this_id = get_the_ID();

	/**
	 * Check the transient data and return the cache if cache is exists
	 */
	if ( dp_is_enable_cache( array( 'target' => 'single_post_meta' ) ) ){
		$cache = false;
		$cache = get_transient( 'dp_single_meta_' . $this_id );
		if ( $cache !== false ) {
			$SINGLE_META = $cache;
			return $cache;
		}
	}



	$prefix_name	= '';
	$avatar_img= '';
	$date_eng_flg = '';
	$date_year = '';
	$date_year = '';
	$date_month 	= '';
	$date_month_en 	= '';
	$date_month_en_full = '';
	$date_day = '';
	$date_day_double = '';
	$week_day= '';
	$date_code = '';
	$date_top_code = '';
	$date_bottom_code = '';
	$last_update 	= '';
	$tags_code= '';
	$cats_code= '';
	$cat_top_code = '';
	$cat_bottom_code = '';
	$cat_short_code = '';
	$arr_cat_ids = $arr_first_cat_color = array();
	$comment_code 	= '';
	$post_comment_code = '';
	$time_for_reading_code = '';
	$views_top_code = '';
	$views_bottom_code = '';
	$author_top_code = '';
	$author_bottom_code = '';
	$free_meta_code = '';
	$sns_btn_code 	= '';
	$edit_code = '';
	$page_suffix = is_page() ? '_page' : '_post';

	// GET THE POST TYPE
	$post_type = get_post_type() ?? '';

	// Post parameters
	$cf_hide_date = get_post_meta($this_id, 'dp_hide_date', true);
	$cf_hide_author 	= get_post_meta($this_id, 'dp_hide_author', true);
	$cf_hide_cat = get_post_meta($this_id, 'dp_hide_cat', true);
	$cf_hide_tag = get_post_meta($this_id, 'dp_hide_tag', true);
	$cf_hide_views = get_post_meta($this_id, 'dp_hide_views', true);
	$cf_hide_fb_comment = get_post_meta($this_id, 'dp_hide_fb_comment', true);
	$cf_star_rating_enable = get_post_meta($this_id, 'dp_star_rating_enable', true);
	$cf_hide_sns_icon = get_post_meta($this_id, 'hide_sns_icon', true);
	$cf_hide_time_for_reading = get_post_meta($this_id, 'dp_hide_time_for_reading', true);
	$cf_free_meta_title = get_post_meta($this_id, 'dp_free_meta_title', true);
	$cf_free_meta1_key = get_post_meta($this_id, 'dp_free_meta1_key', true);
	$cf_free_meta1_val = get_post_meta($this_id, 'dp_free_meta1_val', true);
	$cf_free_meta2_key = get_post_meta($this_id, 'dp_free_meta2_key', true);
	$cf_free_meta2_val = get_post_meta($this_id, 'dp_free_meta2_val', true);
	$cf_free_meta3_key = get_post_meta($this_id, 'dp_free_meta3_key', true);
	$cf_free_meta3_val = get_post_meta($this_id, 'dp_free_meta3_val', true);
	$cf_free_meta4_key = get_post_meta($this_id, 'dp_free_meta4_key', true);
	$cf_free_meta4_val = get_post_meta($this_id, 'dp_free_meta4_val', true);
	$cf_free_meta5_key = get_post_meta($this_id, 'dp_free_meta5_key', true);
	$cf_free_meta5_val = get_post_meta($this_id, 'dp_free_meta5_val', true);
	$arr_free_meta_key = array($cf_free_meta1_key, $cf_free_meta2_key, $cf_free_meta3_key, $cf_free_meta4_key, $cf_free_meta5_key);
	$arr_free_meta_val = array($cf_free_meta1_val, $cf_free_meta2_val, $cf_free_meta3_val, $cf_free_meta4_val, $cf_free_meta5_val);

	// Common parametaers
	$show_pubdate_on_meta = isset($options['show_pubdate_on_meta'.$page_suffix]) && !empty($options['show_pubdate_on_meta'.$page_suffix]) ? $options['show_pubdate_on_meta'.$page_suffix] : $def_options['show_pubdate_on_meta'.$page_suffix];
	$show_last_update 	= isset($options['show_last_update']) && !empty($options['show_last_update']) ? $options['show_last_update'] : $def_options['show_last_update'];
	$show_author_on_meta = isset($options['show_author_on_meta'.$page_suffix]) && !empty($options['show_author_on_meta'.$page_suffix]) ? $options['show_author_on_meta'.$page_suffix] : $def_options['show_author_on_meta'.$page_suffix];
	$time_for_reading 	= isset($options['time_for_reading']) && !empty($options['time_for_reading']) ? true : false;
	$show_tags 	= isset($options['show_tags']) && !empty($options['show_tags']) ? true : false;
	$show_views_on_meta = isset($options['show_views_on_meta']) && !empty($options['show_views_on_meta']) ? $options['show_views_on_meta'] : $def_options['show_views_on_meta'];
	$show_cat_on_meta 	= isset($options['show_cat_in_single_post']) && !empty($options['show_cat_in_single_post']) ? $options['show_cat_in_single_post'] : $def_options['show_cat_in_single_post'];
	$show_sns_button_on_meta = isset($options['show_sns_button_on_meta'.$page_suffix]) && !empty($options['show_sns_button_on_meta'.$page_suffix]) ? true : false;


	// Post date
	if ((is_single() || is_page() || $post_type_name === $options['news_cpt_slug_id']) && $show_pubdate_on_meta !== 'hide' && !$cf_hide_date) {

		$timestamp_gmt = get_the_date( 'Ymd' );
		$timestamp_mod_gmt = get_the_modified_date( 'Ymd' );

		if ( $show_last_update && $timestamp_mod_gmt > $timestamp_gmt ) {
			$date_year 	= '<span class="date_year">'.get_the_modified_date('Y').'</span>';
			$date_month = '<span class="date_month">'.get_the_modified_date('n').'</span>';
			$date_month_en = '<span class="date_month_en">'.get_the_modified_date('M').'</span>';
			$date_month_en_full = '<span class="date_month_en_full">'.get_the_modified_date('F').'</span>';
			$date_day 	= '<span class="date_day">'.get_the_modified_date('j').'</span>';
			$date_day_double 	= '<span class="date_day_double">'.get_the_modified_date('d').'</span>';
			$week_day 	= '<span class="date_week_day">'.get_the_modified_date('D').'</span>';

			if (isset($options['date_eng_mode']) && (bool)$options['date_eng_mode']) {
				$date_eng_flg = ' eng';
				$last_update = $date_month_en_full.' '.$date_day.', '.$date_year;
			} else {
				$last_update = get_the_modified_date();
			}

			$last_update = '<time datetime="' . get_the_modified_date('c') . '" class="updated icon-update' . $date_eng_flg . '">' . $last_update . '</time>';

		}

		if ( isset($options['show_only_last_update']) && !empty($options['show_only_last_update']) && !empty($last_update) ) {
			// Show only Last update
			$date_code = $last_update;
			$last_update = '';

		} else {
			// Posted date
			$date_year 	= '<span class="date_year">'.get_post_time('Y').'</span>';
			$date_month = '<span class="date_month">'.get_post_time('n').'</span>';
			$date_month_en = '<span class="date_month_en">'.get_post_time('M').'</span>';
			$date_month_en_full = '<span class="date_month_en_full">'.get_post_time('F').'</span>';
			$date_day 	= '<span class="date_day">'.get_post_time('j').'</span>';
			$date_day_double 	= '<span class="date_day_double">'.get_post_time('d').'</span>';
			$week_day 	= '<span class="date_week_day">'.get_post_time('D').'</span>';

			if ( isset( $options['date_reckon_mode'] ) && !empty( $options['date_reckon_mode'] ) ) {
				$date_code = dp_published_diff();
			} else if (isset($options['date_eng_mode']) && (bool)$options['date_eng_mode']) {
				$date_eng_flg = ' eng';
				$date_code = $date_month_en_full.' '.$date_day.', '.$date_year;
			} else {
				$date_code = get_the_date();
			}

			$date_code = '<time datetime="'. get_the_date('c').'" class="published icon-clock'.$date_eng_flg.'">'.$date_code.'</time>';
		}

		switch ($show_pubdate_on_meta) {
			case 'meta_top':
				$date_top_code = $date_code;
				break;
			case 'meta_bottom':
				$date_bottom_code = $date_code;
				break;
			default:
				$date_top_code = $date_bottom_code = $date_code;
				break;
		}
	}


	// Category
	if ( $post_type === 'post' && $show_cat_on_meta !== 'hide' && !$cf_hide_cat) {

		$cats = get_the_category( $this_id );

		if ( is_array( $cats ) && isset( $cats[0]->term_id ) ) {

			$term_meta = get_option('ex_term_meta_' . $cats[0]->term_id);

			// Category color
			if ( isset($term_meta) && !empty($term_meta['color']) ) {
				$arr_first_cat_color = array($term_meta['color'], $cats[0]->term_id );
			}

			// Category on page header
			if ( $show_cat_on_meta == 'meta_top' || $show_cat_on_meta == 'meta_both' ) {

				$cat_top_code = '<span class="cat-name">' . $cats[0]->cat_name . '</span>';

				if ( count($cats) > 2 ) {
					$cat_top_code .= '<span class="cat-more" role="none">, &#8230;</span>';
				}
			}

			// Category in post meta
			if ( $show_cat_on_meta == 'meta_bottom' || $show_cat_on_meta == 'meta_both' ) {

				// Whole categories
				foreach ( $cats as $key => $cat ) {

					// Category links
					$cat_bottom_code .= '<a href="' . get_category_link( $cat->term_id ) . '" rel="tag" class="cat-link term-color' . $cat->term_id .'"><span class="cat-name">' . $cat->cat_name . '</span></a>';

					// Array of category ids
					$arr_cat_ids[] = $cat->term_id;
				}

				// Category code for meta area
				$cat_bottom_code = '<div class="meta meta-cat in-single"><div class="meta-item-list">' . $cat_bottom_code . '</div></div>';
			}
		}
	}


	// Comment
	if ( isset( $post->comment_status ) && $post->comment_status == 'open' && !is_page() ) {
		$comment_code = '<div class="meta meta-comment icon-comment">'. get_comments_popup_link(
			'No comment',
			'1 Comment', 
			'% Commentes').'</div>';
		$post_comment_code = '<div class="meta leave-comment icon-edit"><a href="#respond">Leave a comment</a></div>';
	}

	// Views
	if ( $post_type === 'post' && $show_views_on_meta !== 'hide' && !$cf_hide_views) {
		$views_top_code = $views_bottom_code = '<div class="meta meta-views">'.dp_get_post_views($this_id, null).' views</div>';
		switch ($show_views_on_meta) {
			case 'meta_top':
				$views_bottom_code = '';
				break;
			case 'meta_bottom':
				$views_top_code = '';
				break;
		}
	}

	// Author
	if (($post_type === 'post' || $post_type === 'page') && $show_author_on_meta !== 'hide' && !$cf_hide_author ) {
		$this_author = get_userdata($post->post_author);
		$avatar_img = get_avatar( $this_author->ID, 36, '', 'avatar' );
		$author_top_code = $author_bottom_code = '<div class="meta meta-author vcard"><a href="'.get_author_posts_url($this_author->ID).'" rel="author" class="fn">'.$avatar_img.'<span class="name">'.$this_author->display_name.'</span></a></div>';
		switch ($show_author_on_meta) {
			case 'meta_top':
				$author_bottom_code = '';
				break;
			case 'meta_bottom':
				$author_top_code = '';
				break;
		}
	}

	// Time for reading
	if ( $post_type === 'post' && $time_for_reading && !$cf_hide_time_for_reading) {
		$str = get_post();
		$str = $str->post_content;
		$minutes = round( mb_strlen( strip_tags($str) ) / 600 ) + 1;
		$time_for_reading_code = '<div class="meta time_for_reading icon-alarm">' . sprintf( __('It takes about %s minute(s) to read this content.', 'DigiPress'), $minutes ) . '</div>';
	}

	// Edit link
	if ( ! dp_is_enable_cache( array( 'target' => 'single_post_meta' ) ) ){
		if (is_user_logged_in() && current_user_can('level_10')) {
			$edit_code = ' <a href="'.get_edit_post_link().'" class="edit-link no-barba">Edit</a> ';
		}
	}

	//Show tags
	if ( $show_tags && !$cf_hide_tag) {
		$tags = get_the_tags();
		if ( isset( $tags ) && is_array( $tags ) ) {
			foreach ($tags as $tag) {
				$tags_code .= '<a href="'.get_tag_link($tag->term_id).'" rel="tag" class="tag-link"><span class="tag-name">'.$tag->name.'</span></a> ';
			}
			$tags_code = '<div class="meta meta-cat tag"><div class="meta-item-list">' . $tags_code . '</div></div>';
		}
	}

	// SNS Buttons
	if ( ($post_type === 'post' || $post_type === 'page') && (bool)$show_sns_button_on_meta && !$cf_hide_sns_icon ) {
		$sns_btn_code = dp_show_sns_buttons_original(false);
	}

	// Free meta
	$this_meta = '';
	$arr_tmp = array_filter($arr_free_meta_key);
	if (!empty($arr_tmp)) {
		foreach ($arr_free_meta_key as $key => $value) {
			if (!empty($value)) {
				$this_meta = '<th class="meta_item">'.$value.'</th>';
				if (!empty($arr_free_meta_val[$key])) {
					$this_meta .= '<td class="meta_item">'.$arr_free_meta_val[$key].'</td>';
				}
				$free_meta_code .= '<tr class="meta_row">'.$this_meta.'</tr>';
			}
		}

		if ( isset($cf_free_meta_title) && !empty($cf_free_meta_title) ) {
			$cf_free_meta_title = '<thead><tr class="meta_row"><th class="meta_item" colspan="2">' . $cf_free_meta_title . '</th></tr></thead>';
		} else {
			$cf_free_meta_title = '';
		}
		$free_meta_code = '<table class="fmeta">' . $cf_free_meta_title . '<tbody>' . $free_meta_code . '</tbody></table>';
	}

	$SINGLE_META = array(
		'date_top' => $date_top_code ?? '',
		'date_bottom' => $date_bottom_code ?? '',
		'year' 	=> $date_year ?? '',
		'month'	=> $date_month ?? '',
		'month_en'	=> $date_month_en ?? '',
		'month_en_full'	=> $date_month_en_full ?? '',
		'day'	=> $date_day ?? '',
		'day_double' => $date_day_double ?? '',
		'week_day'	=> $week_day ?? '',
		'last_update' => $last_update ?? '',
		'cat_top_code' => $cat_top_code ?? '',
		'cat_bottom_code' => $cat_bottom_code ?? '',
		'arr_cat_ids' => $arr_cat_ids ?? array(),
		'arr_first_cat_color' => $arr_first_cat_color ?? array(),
		'tags' => $tags_code ?? '',
		'comments' => $comment_code ?? '',
		'post_comment' => $post_comment_code ?? '',
		'views_top_code' => $views_top_code ?? '',
		'views_bottom_code' => $views_bottom_code ?? '',
		'author_top_code' => $author_top_code ?? '',
		'author_bottom_code' => $author_bottom_code ?? '',
		'free_meta_code' => $free_meta_code ?? '',
		'edit_link' => $edit_code ?? '',
		'time_for_reading' => $time_for_reading_code ?? '',
		'sns_btn'	=> $sns_btn_code ?? ''
	);



	/**
	 * Save to cache
	 */
	if ( dp_is_enable_cache( array( 'target' => 'single_post_meta' ) ) ){
		set_transient( 'dp_single_meta_' . $this_id, $SINGLE_META, 0 );
	}


	return $SINGLE_META;

}	// End function