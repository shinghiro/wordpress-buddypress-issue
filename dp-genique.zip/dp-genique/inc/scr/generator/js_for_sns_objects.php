<?php
function js_for_sns_objects($echo = true) {
	global $options, $FB_APP_ID, $EXIST_FB_LIKE_BOX;

	$js_code = $fb_app_id = '';
	$hide_fbcomment_flag = null;

	if (is_single() || is_page() && (isset($options['disable_pjax']) && !empty($options['disable_pjax']))) {
		$hide_fbcomment_flag = (bool)get_post_meta(get_the_ID(), 'dp_hide_fb_comment', true);
		// *** Facebook js trigger
		if ( ((isset($options['facebookcomment_post']) && !empty($options['facebookcomment_post'])) || (isset($options['facebookcomment_page']) && !empty($options['facebookcomment_page']))) && !$hide_fbcomment_flag ) {
			// Change the flag
			$EXIST_FB_LIKE_BOX = true;
		}
	}
	// *** JS for facebook
	if ( $EXIST_FB_LIKE_BOX ) {
		$fb_app_id = isset($options['fb_app_id']) ? $options['fb_app_id'] : '';
		$lang = isset($options['fb_api_lang']) ? $options['fb_api_lang'] : 'ja_JP';
		if (empty($fb_app_id)) {
			$fb_app_id = $FB_APP_ID;
		}
		$js_code .= '<div id="fb-root"></div><script async defer crossorigin="anonymous" src="https://connect.facebook.net/' . $lang . '/sdk.js#xfbml=1&version=v13.0&appId=' . $fb_app_id . '&autoLogAppEvents=1"></script>';
	}

	$js_code .= '<script async defer src="https://platform.twitter.com/widgets.js"></script>';

	// Display
	if ($echo){
		echo $js_code;
	} else {
		return $js_code;
	}
}