<?php
/**
 * OGP & Twitter card
 */
function dp_show_ogp() {
	global $options;

	if ( (bool)$options['disable_auto_ogp'] || class_exists('All_in_One_SEO_Pack') || function_exists( 'aioseo' ) || function_exists( 'YoastSEO' ) ) return;
	// Disable Jetpack's Open Graph Meta Tags.
	if ( class_exists('Jetpack') ) {
		if ( in_array( 'publicize', Jetpack::get_active_modules() ) || in_array( 'sharedaddy', Jetpack::get_active_modules() ) ) {
			add_filter( 'jetpack_enable_opengraph', '__return_false', 99 );
		}
	}

	require_once( DP_THEME_DIR . '/inc/scr/control/punycode.php' );

	$ogp_code = '';
	$og_image_sizes = '';
	$title = '';
	$desc = '';
	$url = '';
	$og_img_url= '';
	$fb_app_id = '';
	$twitter_card_code = '';
	$is_local_image = true;
	$type= 'article';
	$site_name = dp_h1_title();

	if ( is_singular() && !is_home() ) {
		$title 	 = the_title_attribute(array('before'=> '', 
											 'after' => '', 
											 'echo' => false));
		$url 	 = Punycode::urlencode( get_permalink() );
		$arg = array( 'width' => 1200, 'height' => 630, 'size' => 'full', 'if_img_tag' => false );
		$og_img_url = DP_Post_Thumbnail::get_post_thumbnail($arg);
		$og_img_url = Punycode::urlencode( $og_img_url );

	} else {
		$title = dp_site_title('', '', false);
		$url = is_ssl() ? 'https://' : 'http://';
		$url .= Punycode::urlencode( $_SERVER['HTTP_HOST'] ) . $_SERVER['REQUEST_URI'];

		if ( is_category() || is_tag() ) {
			global $ARCHIVE_STYLE;

			if ( isset( $ARCHIVE_STYLE ) && is_array($ARCHIVE_STYLE) ) {
				if ( isset( $ARCHIVE_STYLE['image'] ) && !empty( $ARCHIVE_STYLE['image'] ) ) {
					$og_img_url = Punycode::urlencode( $ARCHIVE_STYLE['image'] );
				}

				if ( !empty( $ARCHIVE_STYLE['image_width'] ) && !empty( $ARCHIVE_STYLE['image_height'] ) ) {
					$og_image_sizes = array( $ARCHIVE_STYLE['image_width'], $ARCHIVE_STYLE['image_height'] );
				}
			}
		}

		if ( empty($og_img_url) && ( isset($options['meta_ogp_img_url']) && !empty($options['meta_ogp_img_url']) ) ) {
			$og_img_url = Punycode::urlencode( $options['meta_ogp_img_url'] );
		}

		if ( is_home() && is_front_page() ) {
			$type= 'website';
		}
	}

	// og:image, sizes
	if ( !isset( $og_img_url ) || empty( $og_img_url ) ){
		// Final fall back, blank image.
		$og_img_url = 'https://s0.wp.com/i/blank.jpg';
		// Flag sets to false
		$is_local_image = false;
	}

	if ( isset( $og_img_url ) && !empty( $og_img_url ) ){

		if ( !isset($og_image_sizes) || empty($og_image_sizes) || !is_array($og_image_sizes) ) {
			$og_image_sizes = dp_get_image_size( $og_img_url, $is_local_image );
		}

		if ( is_array( $og_image_sizes ) && isset( $og_image_sizes[0] ) && isset( $og_image_sizes[1] ) ){
			$og_image_sizes = '<meta property="og:image:width" content="' . $og_image_sizes[0] . '" /><meta property="og:image:height" content="' . $og_image_sizes[1] . '" />';
		} else {
			$og_image_sizes = '';
		}

		$og_img_url = '<meta property="og:image" content="' . $og_img_url . '" />';
	}

	// FB App ID
	if (isset($options['fb_app_id']) && !empty($options['fb_app_id'])) {
		$fb_app_id = '<meta property="fb:app_id" content="'.$options['fb_app_id'].'" />';
	}

	// desc
	$desc = create_meta_desc_tag();

	// OGP tag
	$ogp_code = 
'<meta property="og:title" content="' . $title . '" /><meta property="og:type" content="' . $type . '" /><meta property="og:url" content="' . $url .'" />'.$og_img_url . $og_image_sizes . '<meta property="og:description" content="' . $desc . '" /><meta property="og:site_name" content="' . $site_name . '" />'.$fb_app_id;

	// twitter card tag
	if ( !empty($options['twitter_card_user_id']) ) {
		$twitter_card_code = '<meta name="twitter:card" content="summary_large_image" /><meta name="twitter:site" content="@'.$options['twitter_card_user_id'].'" />';
	}

	echo $ogp_code.$twitter_card_code;
}