<?php
/**
 * Meta content for listing post style
 */
function get_post_meta_for_listing_post_styles($args = array()) {
	// if ( post_password_required() ) return;

	global $options, $post, $IS_MOBILE_DP;

	// Get post type
	$post_type = get_post_type() ?? '';
	$current_archive_flag = '';
	$arr_meta = array();
	$avatar_img= '';
	$date_eng_flg = '';
	$date_year = '';
	$date_month 	= '';
	$date_month_en 	= '';
	$date_month_en_full = '';
	$date_day = '';
	$date_day_double = '';
	$week_day= '';
	$date_code = '';
	// $tags_code= '';
	$cats_code= '';
	$arr_cat_ids = array();
	$comment_code 	= '';
	$views_code 	= '';
	$author_code	= '';
	$free_meta_code = '';
	$this_id = get_the_ID();

	// Post parameters
	$dp_hide_date 	= get_post_meta($this_id, 'dp_hide_date', true);
	$dp_hide_author = get_post_meta($this_id, 'dp_hide_author', true);
	$dp_hide_cat 	= get_post_meta($this_id, 'dp_hide_cat', true);
	$dp_hide_views 	= get_post_meta($this_id, 'dp_hide_views', true);
	$dp_star_rating_enable 	= get_post_meta($this_id, 'dp_star_rating_enable', true);
	$dp_star_rating = get_post_meta($this_id, 'dp_star_rating', true);
	$dp_free_meta1_key = get_post_meta($this_id, 'dp_free_meta1_key', true);
	$dp_free_meta1_val = get_post_meta($this_id, 'dp_free_meta1_val', true);
	$dp_free_meta2_key = get_post_meta($this_id, 'dp_free_meta2_key', true);
	$dp_free_meta2_val = get_post_meta($this_id, 'dp_free_meta2_val', true);
	$dp_free_meta3_key = get_post_meta($this_id, 'dp_free_meta3_key', true);
	$dp_free_meta3_val = get_post_meta($this_id, 'dp_free_meta3_val', true);
	$arr_free_meta_key = array($dp_free_meta1_key, $dp_free_meta2_key, $dp_free_meta3_key);
	$arr_free_meta_val = array($dp_free_meta1_val, $dp_free_meta2_val, $dp_free_meta3_val);

	// Published date
	if ( isset($args['pub_date']) && !empty($args['pub_date']) && !$dp_hide_date) {

		$datetime = '';

		$timestamp_gmt = get_the_date( 'Ymd' );
		$timestamp_mod_gmt = get_the_modified_date( 'Ymd' );

		if ( isset($options['show_only_last_update']) && !empty($options['show_only_last_update']) && $timestamp_mod_gmt > $timestamp_gmt ) {
			$datetime 			= get_the_modified_date('c');
			$date_code 			= get_the_modified_date();
			$date_year 			= get_the_modified_date('Y');
			$date_month 		= get_the_modified_date('n');
			$date_month_en 		= get_the_modified_date('M');
			$date_month_en_full = get_the_modified_date('F');
			$date_day 			= get_the_modified_date('j');
			$date_day_double 	= get_the_modified_date('d');
			$week_day 			= get_the_modified_date('D');
		} else {
			$datetime 			= get_the_date('c');
			$date_code 			= get_the_date();
			$date_year 			= get_post_time('Y');
			$date_month 		= get_post_time('n');
			$date_month_en 		= get_post_time('M');
			$date_month_en_full = get_post_time('F');
			$date_day 			= get_post_time('j');
			$date_day_double 	= get_post_time('d');
			$week_day 			= get_post_time('D');
		}

		$date_year 			= '<span class="date_year">' . $date_year . '</span>';
		$date_month 		= '<span class="date_month">' . $date_month . '</span>';
		$date_month_en 		= '<span class="date_month_en">' . $date_month_en . '</span>';
		$date_month_en_full = '<span class="date_month_en_full">' . $date_month_en_full . '</span>';
		$date_day 			= '<span class="date_day">' . $date_day . '</span>';
		$date_day_double 	= '<span class="date_day_double">' . $date_day_double . '</span>';
		$week_day 			= '<span class="date_week_day">' . $week_day . '</span>';

		if (isset($options['date_eng_mode']) && (bool)$options['date_eng_mode']) {
			$date_eng_flg = ' eng';
			$date_code = $date_month_en_full.' ' . $date_day.', ' . $date_year;
		}

		$date_code 	= '<div class="loop-date' . $date_eng_flg . '"><time datetime="'. $datetime . '" class="entry-date">' . $date_code . '</time></div>';
	}

	// Category
	if ($post_type === 'post') {

		if ( isset($args['show_cat']) && !empty($args['show_cat']) && !$dp_hide_cat ) {

			$cats = get_the_category($this_id);

			if ( !empty( $cats ) && is_array( $cats ) ) {
				if ( strpos($args['layout'], 'slider') !== false ) {

					// For slider
					$cats_code = $cats[0]->cat_name;

				} else {

					// Not slider
					$cats_code = '<span class="cat-name">';

					// ALl categories
					foreach ($cats as $key => $cat) {
						$arr_cat_ids[] = $cat->term_id;
					}

					if ( count($cats) === 1 ) {

						$cats_code .= $cats[0]->cat_name . '</span>';

					} else if ( count($cats) > 1 ) {

						$cats_code .= $cats[0]->cat_name . '</span><span class="cat-more">, &#8230;</span>';

					}

					$cats_code = '<div class="meta-cat in-loop">' . $cats_code . '</div>';
				}
			}
		}
	}


	// Comments
	if ( isset($args['comment']) && !empty($args['comment']) ) {
		$comment_code = '<div class="meta-comment"><span class="share-icon"><i class="icon-comment"></i></span><span class="share-num">'. get_comments_number().'</span></div>';
	}

	// Views 
	if (isset($args['views']) && !empty($args['views']) && function_exists('dp_get_post_views') && !$dp_hide_views) {
		if (!empty($args['meta_key_views_count'])) {
			$views_code = '<div class="meta-views">'.dp_get_post_views($this_id, $args['meta_key_views_count']).' views</div>';
		} else {
			$views_code = '<div class="meta-views">'.dp_get_post_views($this_id, null).' views</div>';
		}
	}

	// Author
	if ( isset($args['author']) && !empty($args['author']) && !$dp_hide_author ) {

		$this_author = get_userdata($post->post_author);
		$avatar_img = get_avatar( $this_author->ID, 36 );

		$author_code = '<div class="meta-author vcard">' . $avatar_img . '<span class="name">' . $this_author->display_name . '</span></div>';
	}

	// Free meta
	$this_meta = '';
	$arr_tmp = array_filter($arr_free_meta_key);
	if (!empty($arr_tmp)) {
		foreach ($arr_free_meta_key as $key => $value) {
			if (!empty($value)) {
				$this_meta = '<th class="meta_item">' . $value . '</th>';
				if (!empty($arr_free_meta_val[$key])) {
					$this_meta .= '<td class="meta_item">' . strip_tags($arr_free_meta_val[$key]) . '</td>';
				}
				$free_meta_code .= '<tr class="meta_row">' . $this_meta . '</tr>';
			}
		}
		$free_meta_code = '<table class="fmeta"><tbody>' . $free_meta_code . '</tbody></table>';
	}

	$arr_meta = array(
		'date' 	=> $date_code ?? '',
		'year' 	=> $date_year ?? '',
		'month'	=> $date_month ?? '',
		'month_en'	=> $date_month_en ?? '',
		'month_en_full'	=> $date_month_en_full ?? '',
		'day'	=> $date_day ?? '',
		'day_double' => $date_day_double ?? '',
		'week_day'	=> $week_day ?? '',
		'cats' => $cats_code ?? '',
		// 'tags' => $tags_code ?? '',
		'comments' => $comment_code ?? '',
		'views' => $views_code ?? '',
		'author' => $author_code ?? '',
		'free_meta_code' => $free_meta_code ?? '',
		'arr_cat_ids' => $arr_cat_ids ?? array()
	);

	return $arr_meta;
}