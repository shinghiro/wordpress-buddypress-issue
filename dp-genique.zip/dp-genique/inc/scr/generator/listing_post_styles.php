<?php
/**
 * Listing article styles for the widgets in container in archive page
 */
function dp_post_list_get_elements( $args ) {

	global $options, $post, $IS_MOBILE_DP;


	// Get post ID
	$post_id = $post->ID;


	/**
	 * Check the transient data and return the cache if cache is exists
	 */
	$transient_suffix = $post_id . '_' . str_replace( array(' ', '-'), '', $args['layout'] );
	if ( dp_is_enable_cache( array( 'target' => 'loop_post_meta' ) ) ){
		$cache = false;
		$cache = get_transient( 'dp_list_elem_' . $transient_suffix );

		if ( $cache !== false ) {
			// Reload swiper.js for thumbnail slider
			if ( strpos( $args['layout'], 'slider' ) === false && $args['layout'] !== 'simple' ) {
				// Load swiper.js
				wp_enqueue_style('dp-swiper',DP_THEME_URI.'/css/swiper-bundle.css',null,DP_OPTION_SPT_VERSION);
				wp_enqueue_script('dp-swiper',DP_THEME_URI.'/inc/js/swiper-bundle.min.js',null,false,true);
			}
			return $cache;
		}
	}


	/**
	 * Init params
	 */
	// For 'extract($args)' params
	$meta_key = '';
	$voted_count = '';
	$post_title = '';
	$sns_insert_content = '';
	$sns_share_code = '';
	$hatebu_num = false;
	$tweets_num = false;
	$likes_num = false;
	$if_img_tag = true;

	// Thumbnail
	$thumbnail_code	= $embed_code = '';

	// Viewed rank counter
	$counter = 0;

	// For Meta
	$meta_code = '';
	$desc = '';
	$ranking_code = '';
	$vimeo_hash = '';
	$thumb_type = '';
	$arr_meta = array();

	// Return elements
	$arr_post_ele = array();

	// Extract params
	extract($args);

	// post URL
	$post_url = get_permalink( $post_id );

	// Page type
	$page_suffix = is_page() ? '_page' : '_post';
	// Post format
	$post_format = get_post_format($post_id);
	// Tag of the post
	$post_label = get_post_meta($post_id, 'dp_post_tag', true);
	// Tag color of the post
	$label_color = get_post_meta($post_id, 'dp_post_tag_color', true);
	// Params for SNS buttons
	$hide_sns_icon = get_post_meta($post_id, 'hide_sns_icon', true);
	// Video ID(YouTube only)
	$videoID = get_post_meta($post_id, 'item_video_id', true);
	// Target video service
	$video_service = get_post_meta($post_id, 'video_service', true);
	// Slider images
	$sl_img1 = get_post_meta($post_id, 'dp_archive_slider_img1', true);
	$sl_img2 = get_post_meta($post_id, 'dp_archive_slider_img2', true);
	$sl_img3 = get_post_meta($post_id, 'dp_archive_slider_img3', true);
	// Whether img tag or not
	$if_img_tag = (bool)$if_img_tag ? true : false;

	//For thumbnail size
	$width = 460;
	$height = 320;
	$arg_thumb = array('width' => $width, 'height' => $height, "size" => "dp-archive-thumb", "if_img_tag"=> $if_img_tag);

	// Get icon class each post format
	$title_icon_class = post_format_icon($post_format);
	// For media icon
	// $media_icon_code = '<i class="' . $title_icon_class . '"></i>';

	// Get post meta codes (Call this function written in "meta_info.php")
	$arr_meta = get_post_meta_for_listing_post_styles( $args );

	// Ranking tag
	if (strpos($meta_key, 'post_views_count') !== false || !empty( $voted_count) ) {
		$counter++;
		$ranking_code = '<span class="rank_label thumb">' . $counter . '</span>';
	}

	// Share count
	if ( !( isset( $options['disable_sns_share_count'] ) && !empty( $options['disable_sns_share_count'] ) ) ){
		if ( ! $hide_sns_icon ) {
			// Count Facebook Like 
			if ((bool)$likes_num) {
				$sns_share_code = '<div class="bg-likes ct-fb"><span class="share-icon"><i class="icon-facebook"></i></span><span class="share-num"></span></div>';
			}
			// Tweets
			if ((bool)$tweets_num) {
				$sns_share_code .= '<div class="bg-tweets ct-tw"><span class="share-icon"><i class="icon-twitter"></i></span><span class="share-num"></span></div>';
			}
			// hatebu
			if ((bool)$hatebu_num) {
				$sns_share_code .= '<div class="bg-hatebu ct-hb"><span class="share-icon"><i class="icon-hatebu"></i></span><span class="share-num"></span></div>';
			}
			/***
			 * Filter hook
			 */
			$sns_insert_content = apply_filters( 'dp_top_insert_sns_content', $post_id );
			if ($sns_insert_content == $post_id || !is_string($sns_insert_content)) {
				$sns_insert_content = '';
			}
		}
	}
	// Whole share code
	if  ( isset( $arr_meta['comments'] ) && !empty( $arr_meta['comments'] ) ) {
		$sns_share_code .= $arr_meta['comments'];
	}
	if ( !empty( $sns_insert_content ) ) {
		$sns_share_code .= $sns_insert_content;
	}
	$sns_share_code = !empty( $sns_share_code) ? '<div class="loop-share-num ct-shares" data-url="' . esc_attr( $post_url ) . '">' . $sns_share_code . '</div>' : '';

	// Post title
	$post_title =  the_title('', '', false) ? the_title('', '', false) : 'No Title'; //__('No Title', 'DigiPress');
	// Title
	$post_title = (mb_strlen($post_title, 'utf-8') > $title_length) ? mb_substr($post_title, 0, $title_length, 'utf-8') . '...' : $post_title;

	//Post excerpt
	if ( (int)$excerpt_length !== 0 ) {
		$desc = strip_tags( get_the_excerpt() );
		if ( mb_strlen($desc,'utf-8') > $excerpt_length ) {
			$desc = mb_substr( $desc, 0, $excerpt_length,'utf-8' ) . '...';
			$desc = !empty( $desc) ? '<div class="loop-excerpt entry-summary is-over-length">' . $desc . '</div>' : '';
		} else {
			$desc = !empty( $desc) ? '<div class="loop-excerpt entry-summary">' . $desc . '</div>' : '';
		}
	}

	// Post tag(custom field)
	if ( !empty( $post_label ) ) {
		if ( !empty( $label_color) ) {
			$label_color = ' style="--label-color:' . $label_color . ';"';
		} else {
			$label_color = '';
		}
		$post_label = '<div class="label_ft"' . $label_color . '><span>' . $post_label . '</span></div>';
	}

	// Thumbail
	if ( empty( $videoID ) ) {

		if ( ($sl_img1 || $sl_img2 || $sl_img3) && strpos($layout, 'slider') === false && $layout !== 'simple' ) {
			// Load swiper.js
			wp_enqueue_style('dp-swiper', DP_THEME_URI . '/css/swiper-bundle.css', null, DP_OPTION_SPT_VERSION);
			wp_enqueue_script('dp-swiper', DP_THEME_URI . '/inc/js/swiper-bundle.min.js', null, false, true);

			if ($sl_img1) $sl_img1 = '<figure class="swiper-slide loop-figure sl-img' . $overlay_color . '"><img src="' . $sl_img1 . '" class="figure-img" /></figure>';
			if ($sl_img2) $sl_img2 = '<figure class="swiper-slide loop-figure sl-img' . $overlay_color . '"><img src="' . $sl_img2 . '" class="figure-img" /></figure>';
			if ($sl_img3) $sl_img3 = '<figure class="swiper-slide loop-figure sl-img' . $overlay_color . '"><img src="' . $sl_img3 . '" class="figure-img" /></figure>';

			$sl_nav_code = !$IS_MOBILE_DP ? '<div class="swiper-button-prev"></div><div class="swiper-button-next"></div>' : '';
			$thumbnail_code = '<div class="swiper aslider"><div class="swiper-wrapper">' . $sl_img1 . $sl_img2 . $sl_img3 . '</div>' . $sl_nav_code . '</div>';
			$thumb_type = 'slider';

		} else {

			$thumbnail_code = DP_Post_Thumbnail::get_post_thumbnail($arg_thumb);
			$thumb_type = 'eyecatch';

		}

	} else {

		switch ( $video_service ) {
			case 'Vimeo':
				$json = wp_remote_get( 'https://vimeo.com/api/oembed.json?url=https://vimeo.com/' . $videoID );

				if ( $json['response']['code'] === 200 ) {

					$json = json_decode( $json['body'], true );

					if ( $if_img_tag ) {
						$thumbnail_code = '<img src="' . $json['thumbnail_url'] . '" width="' . $json['thumbnail_width'] . '" height="' . $json['thumbnail_height'] . '" alt="thumbnail" class="wp-post-image" />';
					} else {
						$thumbnail_code = $json['thumbnail_url'];
					}

					$embed_code = '<iframe src="https://player.vimeo.com/video/' . $videoID . '?title=0&byline=0&portrait=0&badge=0" webkitallowfullscreen mozallowfullscreen allowfullscreen class="emb"></iframe>';

				} else {
					$thumbnail_code = DP_Post_Thumbnail::get_post_thumbnail( $arg_thumb );
				}

				$embed_code = '<iframe src="https://player.vimeo.com/video/' . $videoID . '?title=0&byline=0&portrait=0&badge=0" webkitallowfullscreen mozallowfullscreen allowfullscreen class="emb"></iframe>';
				break;

			case 'YouTube':
			default:
				$size = dp_get_image_size('https://img.youtube.com/vi/' . $videoID . '/sddefault.jpg');
				if ($if_img_tag) {
					$thumbnail_code = '<img src="https://img.youtube.com/vi/' . $videoID . '/sddefault.jpg" width="' . $size[0] . '" height="' . $size[1] . '" class="wp-post-image" />';
				} else {
					$thumbnail_code = 'https://img.youtube.com/vi/' . $videoID . '/sddefault.jpg';
				}
				$embed_code 	= '<iframe class="emb" src="https://www.youtube.com/embed/' . $videoID . '/?wmode=transparent&hd=1&autohide=1&rel=0" allowfullscreen></iframe>';
				break;
		}
		$thumb_type = 'video';
	}

	// Return
	$arr_post_ele = array(
		'thumbnail_code'=> $thumbnail_code,
		'embed_code' => $embed_code,
		// 'media_icon_code' => $media_icon_code,
		'post_id' => $post_id,
		'post_url' => $post_url,
		'post_title' => $post_title,
		'post_label' => $post_label,
		'ranking_code' => $ranking_code,
		'desc' => $desc,
		'thumb_type' => $thumb_type,
		'meta_code'=> $meta_code,
		'sns_share_code' => $sns_share_code,
		'arr_meta'=> $arr_meta
		);


	/**
	 * Save to cache
	 */
	if ( dp_is_enable_cache( array( 'target' => 'loop_post_meta' ) ) ){
		$res = set_transient( 'dp_list_elem_' . $transient_suffix, $arr_post_ele, 0 );
	}



	return $arr_post_ele;
}
/*******************************************************
* Normal style
*******************************************************/
function dp_show_post_list_for_archive_normal($args = array(), $arr_post_ele = array()) {
	if (empty( $args) && empty( $arr_post_ele)) return;
	global $options;

	// init
	$loop_article_class = 'loop-article';
	$date_code = $eyecatch_code = $cat_ids_class = $meta_cell = '';

	$arr_meta = $arr_post_ele['arr_meta'];

	// date code
	if ( isset( $arr_meta['date'] ) ){
		$date_code = $arr_meta['date'];
	}

	$wow_article_css = isset( $args['wow_article_css'] ) ? $args['wow_article_css'] : '';
	$post_label = isset( $arr_post_ele['post_label'] ) ? $arr_post_ele['post_label'] : '';
	$desc = isset( $arr_post_ele['desc'] ) ? $arr_post_ele['desc'] : '';
	$cats = isset( $arr_meta['cats'] ) ? $arr_meta['cats'] : '';
	$author = isset( $arr_meta['author'] ) ? $arr_meta['author'] : '';
	$views = isset( $arr_meta['views'] ) ? $arr_meta['views'] : '';
	$sns_share_code = isset( $arr_post_ele['sns_share_code'] ) ? $arr_post_ele['sns_share_code'] : '';

	$no_cat_class = empty( $cats ) ? ' no-cat' : ' has-cat';

	// category slug data
	if ( isset( $arr_meta['arr_cat_ids'] ) && !empty( $arr_meta['arr_cat_ids'] ) && is_array($arr_meta['arr_cat_ids'] ) ){

		foreach ( $arr_meta['arr_cat_ids'] as $key => $cat_id ) {
			$cat_ids_class .= ' cat-flt' . $cat_id;
		}

		if ( $args['overlay_color'] === ' cat-bg' ){
			$loop_article_class .= ' term-color' . $arr_meta['arr_cat_ids'][0];
		}
	}

	// Meta info(sub)
	if ( !isset( $arr_meta['free_meta_code'] ) || empty( $arr_meta['free_meta_code'] ) ) {
		// Free meta data is nothing
		$meta_cell = $sns_share_code;
		if ( !empty( $author ) || !empty( $views ) ) {
			$meta_cell .= '<div class="meta-flex">' . $author . $views . '</div>';
		}
		if ( !empty( $meta_cell ) ) {
			$meta_cell = '<div class="meta-cell">' . $meta_cell . '</div>';
		}
	} else {
		// If exists free meta data
		$meta_cell = '<div class="meta-cell">' . $arr_meta['free_meta_code'] . '</div>';
		$desc = '';
	}

	// Thumbnail
	switch( $arr_post_ele['thumb_type'] ) {
		case 'video':
			$eyecatch_code = $arr_post_ele['embed_code'];
			break;
		case 'slider':
			$eyecatch_code = $arr_post_ele['thumbnail_code'];
			break;
		default:
			// More text
			$more_code = '<figcaption class="more-text"><span>' . $args['read_more_str'] . '</span></figcaption>';
			// Thumbnail
			$eyecatch_code = '<img src="' . $arr_post_ele['thumbnail_code'] . '" alt="post image" class="figure-img" width="460" height="320" />';
			$eyecatch_code = '<figure class="loop-figure loop-bg' . $args['overlay_color'] . '">' . $eyecatch_code . $more_code . '</figure>';
			break;
	}

	$eyecatch_code = '<div class="loop-c-block block-1">' . $cats . '<div class="loop-post-thumb ' . $arr_post_ele['thumb_type'] . '">' . $eyecatch_code . '</div></div>';


	// Wrapper classes
	$loop_article_class .= $cat_ids_class . $no_cat_class . $wow_article_css . $args['overlay_color'];

	/**
	 * Article Source
	 */
	$loop_code =
'<article class="' . $loop_article_class . '"><a href="' . $arr_post_ele['post_url'] . '" class="item-link"><div class="loop-article-content">' . $eyecatch_code . '<div class="loop-c-block block-2"><div class="loop-c-block-content"><div class="meta-title"><h2 class="loop-title">' . $arr_post_ele['post_title'] . '</h2></div>' . $desc . $meta_cell . '</div></div>' . $date_code . $post_label . '</div></a></article>';

	return $loop_code;
}


/*******************************************************
* Normal style for mobile
*******************************************************/
function dp_show_post_list_for_archive_normal_mb($args = array(), $arr_post_ele = array()) {
	if (empty( $args) && empty( $arr_post_ele)) return;
	global $options;

	// init
	$loop_article_class = 'loop-article';
	$date_code = $eyecatch_code = $cat_ids_class = $meta_cell = '';

	$arr_meta = $arr_post_ele['arr_meta'];

	// date code
	if ( isset( $arr_meta['date'] ) ){
		$date_code = $arr_meta['date'];
	}

	$wow_article_css = isset( $args['wow_article_css'] ) ? $args['wow_article_css'] : '';
	$post_label = isset( $arr_post_ele['post_label'] ) ? $arr_post_ele['post_label'] : '';
	$desc = isset( $arr_post_ele['desc'] ) ? $arr_post_ele['desc'] : '';
	$cats = isset( $arr_meta['cats'] ) ? $arr_meta['cats'] : '';
	$author = isset( $arr_meta['author'] ) ? $arr_meta['author'] : '';
	$views = isset( $arr_meta['views'] ) ? $arr_meta['views'] : '';
	$sns_share_code = isset( $arr_post_ele['sns_share_code'] ) ? $arr_post_ele['sns_share_code'] : '';

	$no_cat_class = empty( $cats ) ? ' no-cat' : ' has-cat';

	// category slug data
	if ( isset( $arr_meta['arr_cat_ids'] ) && !empty( $arr_meta['arr_cat_ids'] ) && is_array($arr_meta['arr_cat_ids'] ) ){

		foreach ( $arr_meta['arr_cat_ids'] as $key => $cat_id ) {
			$cat_ids_class .= ' cat-flt' . $cat_id;
		}

		if ( $args['overlay_color'] === ' cat-bg' ){
			$loop_article_class .= ' term-color' . $arr_meta['arr_cat_ids'][0];
		}
	}

	// Meta info(sub)
	if ( !isset( $arr_meta['free_meta_code'] ) || empty( $arr_meta['free_meta_code'] ) ) {
		// Free meta data is nothing
		$meta_cell = $sns_share_code;
		if ( !empty( $author ) || !empty( $views ) ) {
			$meta_cell .= '<div class="meta-flex">' . $author . $views . '</div>';
		}
		if ( !empty( $meta_cell ) ) {
			$meta_cell = '<div class="meta-cell">' . $meta_cell . '</div>';
		}
	} else {
		// If exists free meta data
		$meta_cell = '<div class="meta-cell">' . $arr_meta['free_meta_code'] . '</div>';
		$desc = '';
	}

	// Thumbnail
	switch( $arr_post_ele['thumb_type'] ) {
		case 'video':
			$eyecatch_code = $arr_post_ele['embed_code'];
			break;
		case 'slider':
			$eyecatch_code = $arr_post_ele['thumbnail_code'];
			break;
		default:
			// More text
			$more_code = '<figcaption class="more-text"><span>' . $args['read_more_str'] . '</span></figcaption>';
			// Thumbnail
			$eyecatch_code = '<img src="' . $arr_post_ele['thumbnail_code'] . '" alt="post image" class="figure-img" width="460" height="320" />';
			$eyecatch_code = '<figure class="loop-figure loop-bg' . $args['overlay_color'] . '">' . $eyecatch_code . $more_code . '</figure>';
			break;
	}

	$eyecatch_code = '<div class="loop-c-block block-1">' . $cats . '<div class="loop-post-thumb ' . $arr_post_ele['thumb_type'] . '">' . $eyecatch_code . '</div></div>';


	// Wrapper classes
	$loop_article_class .= $cat_ids_class . $no_cat_class . $wow_article_css . $args['overlay_color'];

	/**
	 * Article Source
	 */
	$loop_code =
'<article class="' . $loop_article_class . '"><a href="' . $arr_post_ele['post_url'] . '" class="item-link"><div class="loop-article-content">' . $eyecatch_code . '<div class="loop-c-block block-2"><div class="loop-c-block-content"><div class="meta-title"><h2 class="loop-title">' . $arr_post_ele['post_title'] . '</h2></div>' . $desc . $meta_cell . '</div></div>' . $date_code . $post_label . '</div></a></article>';

	return $loop_code;
}


/*******************************************************
* Portfolio style
*******************************************************/
function dp_show_post_list_for_archive_portfolio1($args = array(), $arr_post_ele = array()) {
	if (empty( $args) && empty( $arr_post_ele)) return;
	global $options;

	// init
	$loop_article_class = 'loop-article';
	$date_code = $eyecatch_code = $cat_ids_class = $meta_cell = '';

	$arr_meta = $arr_post_ele['arr_meta'];

	$wow_article_css = isset( $args['wow_article_css'] ) ? $args['wow_article_css'] : '';
	$post_label = isset( $arr_post_ele['post_label'] ) ? $arr_post_ele['post_label'] : '';
	$cats = isset( $arr_meta['cats'] ) ? $arr_meta['cats'] : '';
	$author = isset( $arr_meta['author'] ) ? $arr_meta['author'] : '';
	$views = isset( $arr_meta['views'] ) ? $arr_meta['views'] : '';
	$sns_share_code = isset( $arr_post_ele['sns_share_code'] ) ? $arr_post_ele['sns_share_code'] : '';

	// date code
	if ( isset( $arr_meta['date'] ) && !empty( $arr_meta['date'] ) ) {
		$date_code = '<div class="loop-date eng">' . $arr_meta['month'] . '<span class="separator">.</span>' . $arr_meta['day'] . $arr_meta['year'] . '</div>';
	}

	$no_cat_class = empty( $cats ) ? ' no-cat' : ' has-cat';

	// category slug data
	if ( isset( $arr_meta['arr_cat_ids'] ) && !empty( $arr_meta['arr_cat_ids'] ) && is_array($arr_meta['arr_cat_ids'] ) ){

		foreach ( $arr_meta['arr_cat_ids'] as $key => $cat_id ) {
			$cat_ids_class .= ' cat-flt' . $cat_id;
		}

		if ( $args['overlay_color'] === ' cat-bg' ){
			$loop_article_class .= ' term-color' . $arr_meta['arr_cat_ids'][0];
		}
	}


	// Meta info(sub)
	if ( !isset( $arr_meta['free_meta_code'] ) || empty( $arr_meta['free_meta_code'] ) ) {
		// Free meta data is nothing
		$meta_cell = $sns_share_code;
		if ( !empty( $author ) || !empty( $views ) ) {
			$meta_cell .= '<div class="meta-flex">' . $author . $views . '</div>';
		}
		if ( !empty( $meta_cell) ) {
			$meta_cell = '<div class="meta-cell">' . $meta_cell . '</div>';
		}
	} else {
		// If exists free meta data
		$meta_cell = '<div class="meta-cell">' . $arr_meta['free_meta_code'] . '</div>';
	}

	// Thumbnail
	switch( $arr_post_ele['thumb_type'] ) {
		case 'video':
			$eyecatch_code = $arr_post_ele['embed_code'];
			break;
		case 'slider':
			$eyecatch_code = $arr_post_ele['thumbnail_code'];
			break;
		default:
			// More text
			$more_code = '<figcaption class="more-text"><span>' . $args['read_more_str'] . '</span></figcaption>';

			// Thumbnail
			$eyecatch_code = '<img src="' . $arr_post_ele['thumbnail_code'] . '" alt="post image" class="figure-img" width="460" height="320" />';
			$eyecatch_code = '<a href="' . $arr_post_ele['post_url'] . '" class="thumb-link"><figure class="loop-figure loop-bg' . $args['overlay_color'] . '">' . $eyecatch_code . $more_code . '</figure></a>';
			break;
	}

	$eyecatch_code = '<div class="loop-c-block block-1">' . $cats . '<div class="loop-post-thumb ' . $arr_post_ele['thumb_type'] . '">' . $eyecatch_code . '</div></div>';


	// Wrapper classes
	$loop_article_class .= $cat_ids_class . $no_cat_class . $wow_article_css . $args['overlay_color'];

	/**
	 * Article Source
	 */
	$loop_code =
'<article class="' . $loop_article_class . '"><div class="loop-article-content">' . $eyecatch_code . '<div class="loop-c-block block-2"><a href="' . $arr_post_ele['post_url'] . '" class="item-link"><div class="loop-c-block-content"><div class="meta-title"><h2 class="loop-title">' . $arr_post_ele['post_title'] . '</h2></div>' . $meta_cell . '</div>' . $date_code . '</a></div>' . $post_label . '</div></article>';

	return $loop_code;
}

/*******************************************************
* Portfolio style for mobile
*******************************************************/
function dp_show_post_list_for_archive_portfolio_mb($args = array(), $arr_post_ele = array()) {
	if (empty( $args) && empty( $arr_post_ele)) return;
	global $options;

	// init
	$loop_article_class = 'loop-article';
	$date_code = $eyecatch_code = $cat_ids_class = $meta_cell = '';

	$arr_meta = $arr_post_ele['arr_meta'];

	$wow_article_css = isset( $args['wow_article_css'] ) ? $args['wow_article_css'] : '';
	$post_label = isset( $arr_post_ele['post_label'] ) ? $arr_post_ele['post_label'] : '';
	$cats = isset( $arr_meta['cats'] ) ? $arr_meta['cats'] : '';
	$author = isset( $arr_meta['author'] ) ? $arr_meta['author'] : '';
	$views = isset( $arr_meta['views'] ) ? $arr_meta['views'] : '';
	$sns_share_code = isset( $arr_post_ele['sns_share_code'] ) ? $arr_post_ele['sns_share_code'] : '';

	// date code
	if ( isset( $arr_meta['date'] ) && !empty( $arr_meta['date'] ) ) {
		$date_code = '<div class="loop-date eng">' . $arr_meta['month'] . '<span class="separator">.</span>' . $arr_meta['day'] . $arr_meta['year'] . '</div>';
	}

	$no_cat_class = empty( $cats ) ? ' no-cat' : ' has-cat';

	// category slug data
	if ( isset( $arr_meta['arr_cat_ids'] ) && !empty( $arr_meta['arr_cat_ids'] ) && is_array($arr_meta['arr_cat_ids'] ) ){

		foreach ( $arr_meta['arr_cat_ids'] as $key => $cat_id ) {
			$cat_ids_class .= ' cat-flt' . $cat_id;
		}

		if ( $args['overlay_color'] === ' cat-bg' ){
			$loop_article_class .= ' term-color' . $arr_meta['arr_cat_ids'][0];
		}
	}


	// Meta info(sub)
	if ( !isset( $arr_meta['free_meta_code'] ) || empty( $arr_meta['free_meta_code'] ) ) {
		// Free meta data is nothing
		$meta_cell = $sns_share_code;
		if ( !empty( $author ) || !empty( $views ) ) {
			$meta_cell .= '<div class="meta-flex">' . $author . $views . '</div>';
		}
		if ( !empty( $meta_cell) ) {
			$meta_cell = '<div class="meta-cell">' . $meta_cell . '</div>';
		}
	} else {
		// If exists free meta data
		$meta_cell = '<div class="meta-cell">' . $arr_meta['free_meta_code'] . '</div>';
	}

	// Thumbnail
	switch( $arr_post_ele['thumb_type'] ) {
		case 'video':
			$eyecatch_code = $arr_post_ele['embed_code'];
			break;
		case 'slider':
			$eyecatch_code = $arr_post_ele['thumbnail_code'];
			break;
		default:
			// More text
			$more_code = '<figcaption class="more-text"><span>' . $args['read_more_str'] . '</span></figcaption>';

			// Thumbnail
			$eyecatch_code = '<img src="' . $arr_post_ele['thumbnail_code'] . '" alt="post image" class="figure-img" width="460" height="320" />';
			$eyecatch_code = '<a href="' . $arr_post_ele['post_url'] . '" class="thumb-link"><figure class="loop-figure loop-bg' . $args['overlay_color'] . '">' . $eyecatch_code . $more_code . '</figure></a>';
			break;
	}

	$eyecatch_code = '<div class="loop-c-block block-1">' . $cats . '<div class="loop-post-thumb ' . $arr_post_ele['thumb_type'] . '">' . $eyecatch_code . '</div></div>';


	// Wrapper classes
	$loop_article_class .= $cat_ids_class . $no_cat_class . $wow_article_css . $args['overlay_color'];

	/**
	 * Article Source
	 */
	$loop_code =
'<article class="' . $loop_article_class . '"><div class="loop-article-content">' . $eyecatch_code . '<div class="loop-c-block block-2"><a href="' . $arr_post_ele['post_url'] . '" class="item-link"><div class="loop-c-block-content"><div class="meta-title"><h2 class="loop-title">' . $arr_post_ele['post_title'] . '</h2></div>' . $meta_cell . '</div>' . $date_code . '</a></div>' . $post_label . '</div></article>';

	return $loop_code;
}


/*******************************************************
* Magazine layout #1
*******************************************************/
function dp_show_post_list_for_archive_magazine1($args = array(), $arr_post_ele = array()) {

	if ( empty( $args ) && empty( $arr_post_ele ) ) return;

	global $options;

	// init
	$loop_article_class = 'loop-article';
	$loop_article_style = '';
	$date_code = $eyecatch_code = $cat_ids_class = $meta_cell = '';

	$arr_meta = $arr_post_ele['arr_meta'];

	$wow_article_css = isset( $args['wow_article_css'] ) ? $args['wow_article_css'] : '';
	$post_label = isset( $arr_post_ele['post_label'] ) ? $arr_post_ele['post_label'] : '';
	$post_title = $arr_post_ele['post_title'];
	$desc = isset( $arr_post_ele['desc'] ) ? $arr_post_ele['desc'] : '';
	$cats = isset( $arr_meta['cats'] ) ? $arr_meta['cats'] : '';

	// Alternative title
	$alt_title = get_post_meta( $arr_post_ele['post_id'], 'magazine_title', true );
	$alt_desc = get_post_meta( $arr_post_ele['post_id'], 'magazine_caption', true );
	if ( isset( $alt_title ) && !empty( $alt_title )  ) {
		$post_title = $alt_title;
	}
	if ( isset( $alt_desc ) && !empty( $alt_desc )  ) {
		$desc = '<div class="loop-excerpt entry-summary">' . $alt_desc . '</div>';
	}


	// For custom magazine design
	$frame = $args['magazine_cover_frame'];
	$title_pos = $args['magazine_title_position'];
	$title_bold = $args['magazine_title_by_bold'];
	$title_back = $args['magazine_title_back'];
	$text_serif = $args['magazine_text_by_serif'];
	$title_tilt = $args['magazine_title_tilt'];
	$text_vertically = $args['magazine_text_vertically'];
	$title_back_border = $args['magazine_title_back_border'];
	$date_design = $args['magazine_date_design'];
	$accent_shape = $args['magazine_accent_shape'];

	$is_custom_design = get_post_meta( $arr_post_ele['post_id'], 'magazine_custom_design', true );

	if ( isset( $is_custom_design ) && !empty( $is_custom_design ) ) {

		// Frame design
		$frame = ' ' . get_post_meta( $arr_post_ele['post_id'], 'magazine_cover_frame', true );

		// Frame color
		$frame_color = get_post_meta( $arr_post_ele['post_id'], 'magazine_cover_frame_color', true );
		$loop_article_style .= isset( $frame_color ) && !empty( $frame_color ) ? '--mgz-frame-color:' . $frame_color . ';' : '';

		// Title color
		$title_color = get_post_meta( $arr_post_ele['post_id'], 'magazine_title_color', true );
		$loop_article_style .= isset( $title_color ) && !empty( $title_color ) ? '--mgz-title-color:' . $title_color . ';' : '';

		// Title background
		$title_back = get_post_meta( $arr_post_ele['post_id'], 'magazine_title_back', true );
		if ( isset( $title_back ) && $title_back == 'has-title-back' ){

			$title_back = ' ' . $title_back;

			$title_back_color = get_post_meta( $arr_post_ele['post_id'], 'magazine_title_back_color', true );
			$loop_article_style .= isset( $title_back_color ) && !empty( $title_back_color ) ? '--mgz-title-bg-color:' . $title_back_color . ';' : '';

			$title_back_color_opacity = get_post_meta( $arr_post_ele['post_id'], 'magazine_title_back_color_opacity', true );
			$loop_article_style .= isset( $title_back_color_opacity ) && !empty( $title_back_color_opacity ) ? '--mgz-title-bg-opacity:' . (int)$title_back_color_opacity / 100 . ';' : '';

			$title_back_border = ' ' . get_post_meta( $arr_post_ele['post_id'], 'magazine_title_back_border', true );
		}

		// Title position
		$title_pos = ' ' . get_post_meta( $arr_post_ele['post_id'], 'magazine_title_position', true );

		// Disable bolder title
		$title_bold = ' ' . get_post_meta( $arr_post_ele['post_id'], 'magazine_title_by_bold', true );

		// Text serif
		$text_serif = ' ' . get_post_meta( $arr_post_ele['post_id'], 'magazine_text_by_serif', true );

		// Text vertically
		$text_vertically = ' ' . get_post_meta( $arr_post_ele['post_id'], 'magazine_text_vertically', true );

		// Title tilt
		$title_tilt = ' ' . get_post_meta( $arr_post_ele['post_id'], 'magazine_title_tilt', true );

		// Date style
		$date_design = ' ' . get_post_meta( $arr_post_ele['post_id'], 'magazine_date_design', true );

		// Accent layer
		$accent_shape = ' ' . get_post_meta( $arr_post_ele['post_id'], 'magazine_accent_shape', true );

		// Accent shape color
		$accent_shape_color = get_post_meta( $arr_post_ele['post_id'], 'magazine_accent_shape_color', true );
		$loop_article_style .= isset( $accent_shape_color ) && !empty( $accent_shape_color ) ? '--acc-shape-color:' . $accent_shape_color . ';' : '';

		// Accent shape color opacity
		$accent_shape_color_opacity = get_post_meta( $arr_post_ele['post_id'], 'magazine_accent_shape_opacity', true );
		$loop_article_style .= isset( $accent_shape_color_opacity ) && !empty( $accent_shape_color_opacity ) ? '--acc-shape-opacity:' . (int)$accent_shape_color_opacity / 100 . ';' : '';
	}
	$loop_article_style = !empty( $loop_article_style ) ? ' style="' . $loop_article_style . '"' : '';


	// date code
	if ( isset( $arr_meta['date'] ) && !empty( $arr_meta['date'] ) ) {
		$date_code = '<div class="loop-date eng">' . $arr_meta['year'] . ' <span class="mon-day">' . $arr_meta['month'] . $arr_meta['day'] . '</span></div>';
	}

	// $no_cat_class = empty( $cats ) ? ' no-cat' : ' has-cat';

	// category slug data
	if ( isset( $arr_meta['arr_cat_ids'] ) && !empty( $arr_meta['arr_cat_ids'] ) && is_array($arr_meta['arr_cat_ids'] ) ){

		foreach ( $arr_meta['arr_cat_ids'] as $key => $cat_id ) {
			$cat_ids_class .= ' cat-flt' . $cat_id;
		}

		if ( $args['overlay_color'] === ' cat-bg' ){
			$loop_article_class .= ' term-color' . $arr_meta['arr_cat_ids'][0];
		}
	}

	// Thumbnail
	$eyecatch_code = get_post_meta( $arr_post_ele['post_id'], 'magazine_image', true );
	if ( isset( $eyecatch_code ) && !empty( $eyecatch_code ) ) {
		$eyecatch_code = '<figure class="loop-figure"><img src="' . $eyecatch_code . '" alt="post image" class="figure-img" width="460" height="320" /></figure>';
	} else {
		switch( $arr_post_ele['thumb_type'] ) {
			case 'slider':
				$eyecatch_code = $arr_post_ele['thumbnail_code'];
				break;
			default:
				// Thumbnail
				$eyecatch_code = '<figure class="loop-figure' . $args['overlay_color'] . '"><img src="' . $arr_post_ele['thumbnail_code'] . '" alt="post image" class="figure-img" width="460" height="320" /></figure>';
				break;
		}
	}
	$eyecatch_code = '<div class="loop-post-thumb ' . $arr_post_ele['thumb_type'] . '">' . $eyecatch_code . '</div>';


	// For custom design
	$loop_article_class .= $frame . $title_pos . $title_bold . $text_serif . $text_vertically . $title_back . $title_tilt . $title_back_border . $date_design . $accent_shape;

	$loop_article_class .= !empty( $post_label ) ? ' has-label' : '';

	// Wrapper classes
	$loop_article_class .= $cat_ids_class . $wow_article_css;

	/**
	 * Article Source
	 */
	$loop_code =
'<article class="' . $loop_article_class . '"' . $loop_article_style . '><a href="' . $arr_post_ele['post_url'] . '" class="loop-article-content">' . $eyecatch_code . '<div class="loop-c-block"><div class="title-area"><h2 class="loop-title"><span class="title-inner">' . $post_title . '</span></h2>' . $desc . '</div>' . $date_code . $cats . '</div>' . $post_label . '</a></article>';

	return $loop_code;
}


/*******************************************************
* Magazine style for mobile
*******************************************************/
function dp_show_post_list_for_archive_magazine_mb($args = array(), $arr_post_ele = array()) {

	if ( empty( $args ) && empty( $arr_post_ele ) ) return;

	global $options;

	// init
	$loop_article_class = 'loop-article';
	$loop_article_style = '';
	$date_code = $eyecatch_code = $cat_ids_class = $meta_cell = '';

	$arr_meta = $arr_post_ele['arr_meta'];

	$wow_article_css = isset( $args['wow_article_css'] ) ? $args['wow_article_css'] : '';
	$post_label = isset( $arr_post_ele['post_label'] ) ? $arr_post_ele['post_label'] : '';
	$post_title = $arr_post_ele['post_title'];
	$desc = isset( $arr_post_ele['desc'] ) ? $arr_post_ele['desc'] : '';
	$cats = isset( $arr_meta['cats'] ) ? $arr_meta['cats'] : '';

	// Alternative title
	$alt_title = get_post_meta( $arr_post_ele['post_id'], 'magazine_title', true );
	$alt_desc = get_post_meta( $arr_post_ele['post_id'], 'magazine_caption', true );
	if ( isset( $alt_title ) && !empty( $alt_title )  ) {
		$post_title = $alt_title;
	}
	if ( isset( $alt_desc ) && !empty( $alt_desc )  ) {
		$desc = '<div class="loop-excerpt entry-summary">' . $alt_desc . '</div>';
	}


	// For custom magazine design
	$frame = $args['magazine_cover_frame'];
	$title_pos = $args['magazine_title_position'];
	$title_bold = $args['magazine_title_by_bold'];
	$title_back = $args['magazine_title_back'];
	$text_serif = $args['magazine_text_by_serif'];
	$title_tilt = $args['magazine_title_tilt'];
	$text_vertically = $args['magazine_text_vertically'];
	$title_back_border = $args['magazine_title_back_border'];
	$date_design = $args['magazine_date_design'];
	$accent_shape = $args['magazine_accent_shape'];

	$is_custom_design = get_post_meta( $arr_post_ele['post_id'], 'magazine_custom_design', true );

	if ( isset( $is_custom_design ) && !empty( $is_custom_design ) ) {

		// Frame design
		$frame = ' ' . get_post_meta( $arr_post_ele['post_id'], 'magazine_cover_frame', true );

		// Frame color
		$frame_color = get_post_meta( $arr_post_ele['post_id'], 'magazine_cover_frame_color', true );
		$loop_article_style .= isset( $frame_color ) && !empty( $frame_color ) ? '--mgz-frame-color:' . $frame_color . ';' : '';

		// Title color
		$title_color = get_post_meta( $arr_post_ele['post_id'], 'magazine_title_color', true );
		$loop_article_style .= isset( $title_color ) && !empty( $title_color ) ? '--mgz-title-color:' . $title_color . ';' : '';

		// Title background
		$title_back = get_post_meta( $arr_post_ele['post_id'], 'magazine_title_back', true );
		if ( isset( $title_back ) && $title_back == 'has-title-back' ){

			$title_back = ' ' . $title_back;

			$title_back_color = get_post_meta( $arr_post_ele['post_id'], 'magazine_title_back_color', true );
			$loop_article_style .= isset( $title_back_color ) && !empty( $title_back_color ) ? '--mgz-title-bg-color:' . $title_back_color . ';' : '';

			$title_back_color_opacity = get_post_meta( $arr_post_ele['post_id'], 'magazine_title_back_color_opacity', true );
			$loop_article_style .= isset( $title_back_color_opacity ) && !empty( $title_back_color_opacity ) ? '--mgz-title-bg-opacity:' . (int)$title_back_color_opacity / 100 . ';' : '';

			$title_back_border = ' ' . get_post_meta( $arr_post_ele['post_id'], 'magazine_title_back_border', true );
		}

		// Title position
		$title_pos = ' ' . get_post_meta( $arr_post_ele['post_id'], 'magazine_title_position', true );

		// Disable bolder title
		$title_bold = ' ' . get_post_meta( $arr_post_ele['post_id'], 'magazine_title_by_bold', true );

		// Text serif
		$text_serif = ' ' . get_post_meta( $arr_post_ele['post_id'], 'magazine_text_by_serif', true );

		// Text vertically
		$text_vertically = ' ' . get_post_meta( $arr_post_ele['post_id'], 'magazine_text_vertically', true );

		// Title tilt
		$title_tilt = ' ' . get_post_meta( $arr_post_ele['post_id'], 'magazine_title_tilt', true );

		// Date style
		$date_design = ' ' . get_post_meta( $arr_post_ele['post_id'], 'magazine_date_design', true );

		// Accent layer
		$accent_shape = ' ' . get_post_meta( $arr_post_ele['post_id'], 'magazine_accent_shape', true );

		// Accent shape color
		$accent_shape_color = get_post_meta( $arr_post_ele['post_id'], 'magazine_accent_shape_color', true );
		$loop_article_style .= isset( $accent_shape_color ) && !empty( $accent_shape_color ) ? '--acc-shape-color:' . $accent_shape_color . ';' : '';

		// Accent shape color opacity
		$accent_shape_color_opacity = get_post_meta( $arr_post_ele['post_id'], 'magazine_accent_shape_opacity', true );
		$loop_article_style .= isset( $accent_shape_color_opacity ) && !empty( $accent_shape_color_opacity ) ? '--acc-shape-opacity:' . (int)$accent_shape_color_opacity / 100 . ';' : '';
	}
	$loop_article_style = !empty( $loop_article_style ) ? ' style="' . $loop_article_style . '"' : '';


	// date code
	if ( isset( $arr_meta['date'] ) && !empty( $arr_meta['date'] ) ) {
		$date_code = '<div class="loop-date eng">' . $arr_meta['year'] . ' <span class="mon-day">' . $arr_meta['month'] . $arr_meta['day'] . '</span></div>';
	}

	// $no_cat_class = empty( $cats ) ? ' no-cat' : ' has-cat';

	// category slug data
	if ( isset( $arr_meta['arr_cat_ids'] ) && !empty( $arr_meta['arr_cat_ids'] ) && is_array($arr_meta['arr_cat_ids'] ) ){

		foreach ( $arr_meta['arr_cat_ids'] as $key => $cat_id ) {
			$cat_ids_class .= ' cat-flt' . $cat_id;
		}

		if ( $args['overlay_color'] === ' cat-bg' ){
			$loop_article_class .= ' term-color' . $arr_meta['arr_cat_ids'][0];
		}
	}

	// Thumbnail
	$eyecatch_code = get_post_meta( $arr_post_ele['post_id'], 'magazine_image', true );
	if ( isset( $eyecatch_code ) && !empty( $eyecatch_code ) ) {
		$eyecatch_code = '<figure class="loop-figure"><img src="' . $eyecatch_code . '" alt="post image" class="figure-img" width="460" height="320" /></figure>';
	} else {
		switch( $arr_post_ele['thumb_type'] ) {
			case 'slider':
				$eyecatch_code = $arr_post_ele['thumbnail_code'];
				break;
			default:
				// Thumbnail
				$eyecatch_code = '<figure class="loop-figure' . $args['overlay_color'] . '"><img src="' . $arr_post_ele['thumbnail_code'] . '" alt="post image" class="figure-img" width="460" height="320" /></figure>';
				break;
		}
	}
	$eyecatch_code = '<div class="loop-post-thumb ' . $arr_post_ele['thumb_type'] . '">' . $eyecatch_code . '</div>';


	// For custom design
	$loop_article_class .= $frame . $title_pos . $title_bold . $text_serif . $text_vertically . $title_back . $title_tilt . $title_back_border . $date_design . $accent_shape;

	$loop_article_class .= !empty( $post_label ) ? ' has-label' : '';

	// Wrapper classes
	$loop_article_class .= $cat_ids_class . $wow_article_css;

	/**
	 * Article Source
	 */
	$loop_code =
'<article class="' . $loop_article_class . '"' . $loop_article_style . '><a href="' . $arr_post_ele['post_url'] . '" class="loop-article-content">' . $eyecatch_code . '<div class="loop-c-block"><div class="title-area"><h2 class="loop-title"><span class="title-inner">' . $post_title . '</span></h2>' . $desc . '</div>' . $date_code . $cats . '</div>' . $post_label . '</a></article>';

	return $loop_code;
}


/*******************************************************
* Slider style
*******************************************************/
function dp_show_post_list_for_archive_slider($args = array(), $arr_post_ele = array()) {
	if ( empty( $args) && empty( $arr_post_ele) ) return;
	global $options;

	// init
	$cats_code = '';
	$date_code = '';
	$slide_class = 'swiper-slide style-' . $args['slider_mode'];
	$slide_content_class = 'sl-content';
	$slide_content_title_class = 'title ';
	$slide_content_cap_class = 'caption ';

	// Articl meta
	$arr_meta = $arr_post_ele['arr_meta'];

	// Fix the error in PHP 8
	$cats = isset( $arr_meta['cats'] ) ? $arr_meta['cats'] : '';

	// Category
	if ( !empty( $cats )){
		$cats_code = '<div class="meta-cat"' . $args['data_plx_category'] . '><span class="cat-name">' . $cats . '</span></div>';
	}

	// Date
	if ( isset( $arr_meta['date'] ) && !empty( $arr_meta['date'] ) ) {
		$date_code 	= '<div class="date-wrap loop-date"' . $args['data_plx_date'] . '><span class="date_month">' . get_post_time( 'n' ) . '</span><span class="separator">.</span><span class="date_day">' . get_post_time( 'j' ) . '</span><span class="date_year">' . get_post_time( 'Y' ) . '</span></div>';
	}


	// Main slider
	$slider_code = '<div class="' . $slide_class . '"><a href="' . $arr_post_ele['post_url'] . '" class="slide-link"><figure class="sl-media sl-img" style="background-image:url(\'' . $arr_post_ele['thumbnail_code'] . '\' );" data-slide-img="' . $arr_post_ele['thumbnail_code'] . '"' . $args['data_plx_media'] . '></figure><div class="' . $slide_content_class . ' sl-meta style-' . $args['slider_mode'] . '"><div class="sl-content__inner loop-flex"' . $args['data_plx_content'] . '>' . $date_code . '<p class="' . $slide_content_title_class . '"' . $args['data_plx_title'] . '>' . $arr_post_ele['post_title'] . '</p>' . $cats_code . '</div></div></a></div>';

	// Thumbnail slider
	$thumbnav_code = $args['slider_mode'] == 'thumb' ? '<div class="' . $slide_class . '"><figure class="sl-media sl-img" style="background-image:url(\'' . $arr_post_ele['thumbnail_code'] . '\' );"></figure></div>' : '';

	return array(
		'slider_code' => $slider_code,
		'thumbnav_code' => $thumbnav_code,
	);
}


/*******************************************************
* For mega menu
*******************************************************/
function dp_show_post_list_for_mega_menu($args = array(), $arr_post_ele = array()) {
	if (empty($args) && empty($arr_post_ele)) return;

	global $options;

	// init
	$date_code = $meta_code = $overlay_color = '';
	$loop_flex_class = 'loop-flex';

	extract($args);
	extract($arr_post_ele);	// Including $arr_meta


	// Date code
	if ( isset( $arr_meta['date'] ) && !empty( $arr_meta['date'] ) ) {
		$date_code = $arr_meta['date'];
	}

	// category slug data
	if (!empty($arr_meta['arr_cat_ids']) && is_array($arr_meta['arr_cat_ids'])){
		// Overlay color
		if ($overlay_color === ' cat-bg'){
			$overlay_color = ' cat-ov-color' . $arr_meta['arr_cat_ids'][0];
		}
	}

	/**
	 * Article Source
	 */

	// Thumbnail
	if ( $arr_post_ele['thumb_type'] === 'slider' ){
		$eyecatch_code = '<div class="loop-figure loop-bg' . $args['overlay_color'] . '">' . $arr_post_ele['thumbnail_code'] . '</div>';
	} else {
		$eyecatch_code = '<figure class="loop-figure loop-bg' . $args['overlay_color'] . '"><img src="' . $arr_post_ele['thumbnail_code'] . '" alt="post image" class="figure-img" width="460" height="320" /></figure>';
	}

	// Meta code
	if ( !empty( $arr_meta['cats'] ) || !empty( $arr_meta['author'] ) ) {
		$meta_code = '<div class="loop-meta">' . $arr_meta['cats'] . $arr_meta['author'] . '</div>';
		$loop_flex_class .= ' has-meta';
	}

	// Whole
	$loop_code = 
'<li class="loop-article"><a href="' . $arr_post_ele['post_url'] . '" class="item-link"><div class="loop-article-content">' . $eyecatch_code . '<div class="' . $loop_flex_class . '">' . $date_code . '<div class="loop-title ' . $layout . '" role="heading">' . $post_title . '</div>' . $meta_code . '</div></div></a></li>';

	return $loop_code;
}


/*******************************************************
* News style
*******************************************************/
function dp_show_post_list_for_archive_news($args = array(), $arr_post_ele = array()) {
	if (empty( $args) && empty( $arr_post_ele)) return;
	global $options, $post, $IS_MOBILE_DP;

	// init
	$date_code = '';
	$arr_meta = $arr_post_ele['arr_meta'];

	// Fix the error in PHP 8
	$wow_article_css = isset( $args['wow_article_css'] ) ? $args['wow_article_css'] : '';


	// Date
	if ( isset( $arr_meta['date'] ) && !empty( $arr_meta['date'] ) ) {
		$date_code = '<div class="loop-c-block one">' . $arr_meta['date']. '</div>';
	}

	/**
	 * Article Source
	 */
	$loop_code =
'<article class="loop-article' . $wow_article_css . '">' . $date_code . '<div class="loop-c-block two"><a href="' . $arr_post_ele['post_url'] . '" class="item-link"><h2 class="loop-title ' . $args['layout'] . '">' . $arr_post_ele['post_title'] . '</h2>' . $arr_meta['author'] . '</a></div></article>';

	return $loop_code;
}


/*******************************************************
* Simple style
*******************************************************/
function dp_show_post_list_for_archive_simple($args = array(), $arr_post_ele = array()) {
	if (empty( $args) && empty( $arr_post_ele)) return;
	global $options, $post, $IS_MOBILE_DP;

	// init
	$meta_code = '';
	$arr_meta = $arr_post_ele['arr_meta'];

	// Fix the error in PHP 8
	$wow_article_css = isset( $args['wow_article_css'] ) ? $args['wow_article_css'] : '';

	// Thumbnail
	$eyecatch_code = '<div class="loop-c-block one"><div class="widget-post-thumb ' . $arr_post_ele['thumb_type'] . '"><a href="' . $arr_post_ele['post_url'] . '" class="thumb-link">' . $arr_post_ele['thumbnail_code'] . $arr_meta['cats'] . '</a></div></div>';

	// Meta code
	if ( !empty( $arr_meta['date'] ) || !empty( $arr_meta['author'] ) ) {
		$meta_code = '<div class="loop-meta">' . $arr_meta['date'] . $arr_meta['author'] . '</div>';
	}

	/**
	 * Article Source
	 */
	$loop_code =
'<article class="loop-article' . $wow_article_css . '">' . $eyecatch_code . '<div class="loop-c-block two">' . $meta_code . '<h2 class="loop-title ' . $args['layout'] . '"><a href="' . $arr_post_ele['post_url'] . '" class="item-link">' . $arr_post_ele['post_title'] . '</a></h2></div></article>';

	return $loop_code;
}