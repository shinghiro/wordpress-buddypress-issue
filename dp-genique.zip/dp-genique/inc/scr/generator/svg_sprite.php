<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" class="svg_sprite">
<symbol id="svg_edge_wave1" viewBox="0 0 100 10" preserveAspectRatio="none">
<path d="M 100,4.9746905 C 100,4.9746905 89.49367,9.8973932 75,10 67.52172,10.052942 61.741731,8.7843107 50.000002,4.9746905 38.82997,1.3505584 32.305573,0.07020723 25,0 9.7424699,-0.14662628 0,4.9746905 0,4.9746905 V 10 h 100 z"></path>
</symbol>
<symbol id="svg_edge_wave1__layer1" viewBox="0 0 100 20" preserveAspectRatio="none">
<path d="m 100,1.7829916 c 0,0 -5.290644,5.5795175 -21.757558,8.7503354 C 71.309224,11.868367 60.444754,13.16133 47.146653,6.1932233 35.353336,0.01361228 32.305573,0.27863316 25,0.13826687 9.7424704,-0.15488486 0,9.0465248 0,9.0465248 V 20.131408 l 99.999998,-4.16e-4 z"></path>
</symbol>
<symbol id="svg_edge_wave1__layer2" viewBox="0 0 100 20" preserveAspectRatio="none">
<path d="m 100,7.8787841 c 0,0 -2.824333,1.4586585 -13.067811,4.9891019 -8.168833,2.815411 -17.685492,8.67805 -31.225487,0.06962 C 46.041914,6.7928448 33.732248,1.1865171 24.092116,1.9540348 8.8799082,3.1651841 0,11.121689 0,11.121689 v 9.009719 l 99.999998,-4.16e-4 z"></path>
</symbol>
<symbol id="svg_edge_wave1__layer3" viewBox="0 0 100 10" preserveAspectRatio="none">
<path d="M 100,5.8825745 C 100,5.8825745 89.49367,9.8973932 75,10 67.52172,10.052942 61.645013,9.5890065 49.870304,5.8825745 37.532993,1.999047 32.305573,2.4047661 25,2.3345588 9.7424699,2.1879325 0,6.9204573 0,6.9204573 V 10 h 100 z"></path>
</symbol>
<symbol id="svg_edge_wave2" viewBox="0 0 100 10" preserveAspectRatio="none">
<path d="M 75,0.02308684 C 67.694435,0.09326684 61.170023,1.3729628 50,4.9954308 38.258282,8.8033018 32.478274,10.07134 25,10.01842 h 75 V 4.9954308 c 0,0 -9.742483,-5.11890296 -25,-4.97234396 z M 25,10.01842 C 10.506344,9.9158582 0,4.9954308 0,4.9954308 V 10.01842 Z"></path>
</symbol>
<symbol id="svg_edge_wave2__layer1" viewBox="0 0 100 20" preserveAspectRatio="none">
<path d="m 0,1.7829916 c 0,0 5.290644,5.5795175 21.757558,8.7503354 6.933218,1.33504 17.797688,2.628003 31.095789,-4.3401037 C 64.646664,0.01361228 67.694427,0.27863316 75,0.13826687 90.25753,-0.15488486 100,9.0465248 100,9.0465248 V 20.131408 L 2e-6,20.130992 Z"></path>
</symbol>
<symbol id="svg_edge_wave2__layer2" viewBox="0 0 100 20" preserveAspectRatio="none">
<path d="m 0,7.8787841 c 0,0 2.824333,1.4586585 13.067811,4.9891019 8.168833,2.815411 17.685492,8.67805 31.225487,0.06962 C 53.958086,6.7928448 66.267752,1.1865171 75.907884,1.9540348 91.120092,3.1651841 100,11.121689 100,11.121689 v 9.009719 L 2e-6,20.130992 Z"></path>
</symbol>
<symbol id="svg_edge_wave2__layer3" viewBox="0 0 100 10" preserveAspectRatio="none">
<path d="M 0,5.8825745 C 0,5.8825745 10.50633,9.8973932 25,10 32.47828,10.052942 38.354987,9.5890065 50.129696,5.8825745 62.467007,1.999047 67.694427,2.4047661 75,2.3345588 90.25753,2.1879325 100,6.9204573 100,6.9204573 V 10 H 0 Z"></path>
</symbol>
<symbol id="svg_edge_curve1" viewBox="0 0 100 10" preserveAspectRatio="none">
<path d="M 0,0 C 0,0 25,10 50,10 75,10 100,0 100,0 V 10 H 0 Z"></path>
</symbol>
<symbol id="svg_edge_curve1__layer1" viewBox="0 0 100 10" preserveAspectRatio="none">
<path d="M 0,0 C 0,0 35,5.3308823 60,5.3308823 85,5.3308823 100,0 100,0 V 10 H 0 Z"></path>
</symbol>
<symbol id="svg_edge_curve1__layer2" viewBox="0 0 100 10" preserveAspectRatio="none">
<path d="m 0,2.0751634 c 0,0 19.85335,5.7199754 44.85335,5.7199754 25,0 55.14665,-5.5902777 55.14665,-5.5902777 V 10 H 0 Z"></path>
</symbol>
<symbol id="svg_edge_curve1__layer3" viewBox="0 0 100 10" preserveAspectRatio="none">
<path d="M 0,2.8531305 C 0,2.8531305 25,10 50,10 75,10 100,2.7236519 100,2.7236519 V 10 H 0 Z"></path>
</symbol>
<symbol id="svg_edge_curve2" viewBox="0 0 100 10" preserveAspectRatio="none">
<path d="m 0,10 c 0,0 25,-10 50,-10 25,0 50,10 50,10 v 0 z"></path>
</symbol>
<symbol id="svg_edge_curve2__layer1" viewBox="0 0 100 10" preserveAspectRatio="none">
<path d="M 0,10 C 0,10 23.703023,0 59.208538,0 84.208538,0 100,10 100,10 v 0 z"></path>
</symbol>
<symbol id="svg_edge_curve2__layer2" viewBox="0 0 100 10" preserveAspectRatio="none">
<path d="M 0,10 C 0,10 15.870691,3.2665666 36.252042,2.8533497 87.335536,1.8176694 100,10 100,10 v 0 z"></path>
</symbol>
<symbol id="svg_edge_curve2__layer3" viewBox="0 0 100 10" preserveAspectRatio="none">
<path d="M 0,10 C 0,10 34.598001,4.3028456 52.983047,4.1503268 74.351163,3.973061 100,10 100,10 v 0 z"></path>
</symbol>
</svg>