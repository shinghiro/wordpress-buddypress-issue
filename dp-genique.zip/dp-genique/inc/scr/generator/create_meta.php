<?php
/**
* Create meta tag including description and keywords attributes.
*/
function dp_meta_kw_desc() {
	global $options;

	if ( class_exists( 'amt_add_meta_tags' ) || class_exists('All_in_One_SEO_Pack') || function_exists( 'aioseo' ) || function_exists( 'YoastSEO' ) ) return;

	$meta_code = '<meta name="description" content="' . create_meta_desc_tag() . '" />';
	if ( !( isset( $options['disable_meta_keywords'] ) && ! empty( $options['disable_meta_keywords'] ) ) ) {
		$meta_code .= '<meta name="keywords" content="' . get_meta_keywords() . '" />';
	}
	echo $meta_code;
}

/**
 * meta description tag
 */
function create_meta_desc_tag() {
	global $options;

	$meta_desc_tag = "";

	if (is_home()) {
		if (isset($options['meta_def_desc']) && !empty($options['meta_def_desc'])) {
			$meta_desc_tag = $options['meta_def_desc'];
		} else {
			$meta_desc_tag = get_bloginfo('description');
		}
		if (is_paged()) {
			$meta_desc_tag .= '(' . get_query_var('paged') . ')';
		}
	} else if (is_search()) {
		if (is_paged()) {
			$meta_desc_tag = wp_title('', false, 'right') . '(' .get_query_var('paged') . ')';
		} else {
			$meta_desc_tag = wp_title('', false, 'right') ;
		}
	} else if (is_category()) {	
		$catDesc = category_description();
		if (empty($catDesc)) {
			if (is_paged()) {
				$meta_desc_tag = wp_title('[', false) 
						. __(' ]Category page is displayed.', 'DigiPress')
						. '(' . get_query_var('paged') . ')';
			} else {
				$meta_desc_tag = wp_title('[', false) 
						. __(' ]Category page is displayed.', 'DigiPress');
			}
		} else {
			if (is_paged()) {
				$meta_desc_tag = $catDesc . '(' . get_query_var('paged') . ')';
			} else {
				$meta_desc_tag = $catDesc;
			}
		}
	} else if (is_year()) {
		if (is_paged()) {
			$meta_desc_tag =  __('Archive of the ', 'DigiPress') 
					. get_the_time(__('Y', 'DigiPress')) 
					. __(' is displayed.', 'DigiPress') 
					. '(' . get_query_var('paged') . ')';
		} else {
			$meta_desc_tag = __('Archive of the ', 'DigiPress')
					. get_the_time(__('Y', 'DigiPress')) 
					. __(' is displayed.', 'DigiPress');
		}
	} else if (is_month()) {
		if (is_paged()) {
			$meta_desc_tag = __('Archive of the ', 'DigiPress')
					. get_the_time(__('Y/m', 'DigiPress')) 
					. __(' is displayed.', 'DigiPress')
					. '(' . get_query_var('paged') . ')';
		} else {
			$meta_desc_tag = __('Archive of the ', 'DigiPress')
					. get_the_time(__('Y/m', 'DigiPress')) 
					. __(' is displayed.', 'DigiPress');
		}
	} else if (is_day()) {
		if (is_paged()) {
			$meta_desc_tag = __('Archive of the ', 'DigiPress')
					. get_the_time(__('Y/m/d', 'DigiPress')) 
					. __(' is displayed.', 'DigiPress')
					. '(' . get_query_var('paged') . ')';
		} else {
			$meta_desc_tag = __('Archive of the ', 'DigiPress')
					. get_the_time(__('Y/m/d', 'DigiPress')) 
					. __(' is displayed.', 'DigiPress');
		}
	} else if (is_time()) {
		if (is_paged()) {
			$meta_desc_tag = __('Archive of the ', 'DigiPress')
					. get_the_time(__('Y/m/d', 'DigiPress')) 
					. __(' is displayed.', 'DigiPress')
					. '(' . get_query_var('paged') . ')';
		} else {
			$meta_desc_tag = __('Archive of the ', 'DigiPress')
					. get_the_time(__('Y/m/d', 'DigiPress')) 
					. __(' is displayed.', 'DigiPress');
		}
	} else if (is_tag()) {
		$tagDesc = tag_description();
		if (empty($tagDesc)) {
			if (is_paged()) {
				$meta_desc_tag =  wp_title('',false)
						. __(' Tagged posts is displayed.', 'DigiPress')
						. ' Page(' . get_query_var('paged') . ')';
			} else {
				$meta_desc_tag =  wp_title('',false) 
						. __(' Tagged posts is displayed.', 'DigiPress');
			}
		} else {
			if (is_paged()) {
				$meta_desc_tag = $tagDesc . '(' . get_query_var('paged') . ')';
			} else {
				$meta_desc_tag = $tagDesc;
			}
		}
	} else if ( is_singular() ) {
		while ( have_posts() ) {
			the_post();
			$desc = get_the_excerpt();
			if ( mb_strlen($desc) > 300) $desc = mb_substr($desc, 0, 300, 'UTF-8' ) . '...';
			$meta_desc_tag = $desc;
		}
	} else if (is_author()){
		$desc = get_the_author_meta('description');
		if (empty($desc)) {
			$meta_desc_tag =  wp_title('',false) . __(' is displayed.', 'DigiPress');
			if (is_paged()) {
				$meta_desc_tag .= '(' . get_query_var('paged') . ')';
			}
		} else {
			if (mb_strlen($desc) > 300) $desc = mb_substr($desc, 0, 300, 'UTF-8').'...';
			if (is_paged()) {
				$meta_desc_tag = $desc . '(' . get_query_var('paged') . ')';
			} else {
				$meta_desc_tag = $desc;
			}
		}
	} else {
		$meta_desc_tag =  wp_title('',false) . __(' is displayed.', 'DigiPress');
		if (is_paged()) {
			$meta_desc_tag .= '(' . get_query_var('paged') . ')';
		}
	}

	return str_replace( PHP_EOL, '', esc_attr( strip_tags( $meta_desc_tag ) ) );
}


/**
 * meta keyword tag
 */
function get_meta_keywords() {
	global $options;
	$meta_kw = "";

	if (is_singular()) {
		// get_post_meta(get_the_ID(), 'dp_meta_keyword', true)

		if (get_post_meta(get_the_ID(), 'dp_meta_keyword', true)) {
				$meta_kw = get_post_meta(get_the_ID(), 'dp_meta_keyword', true);
		} else {
			if (is_single()) {
				while (have_posts()) : the_post();
					$posttags = get_the_tags();
					$strTags = "";
					if ($posttags) {
						foreach($posttags as $tag) {
							$strTags =  $strTags . $tag->name . ',';
						}
					}
					if ( ! $strTags == "") {
						$meta_kw = rtrim($strTags, ",");
					}
				endwhile;
			} else if (is_page()) {
				$meta_kw = '';
			} else {
				$meta_kw = wp_title(',', false, 'right');
			}
		}

	} else if (is_archive()) {
		$arcName = wp_title(',', false, 'right');
		$meta_kw = $arcName . trim($options['meta_def_kw']);

	} else if (is_search()) {
		$arcName = wp_title(',', false, 'right');
		$meta_kw = $arcName . trim($options['meta_def_kw']) . ',search result';

	} else if (is_home()) {
		$meta_kw = trim($options['meta_def_kw']);
	} else {
		$meta_kw = wp_title(',', false, 'right');
	}

	if (is_paged()) {
		$meta_kw .= ',Paged'. get_query_var('paged');
	}

	return $meta_kw;
}

/**
 * [dp_show_canonical description]
 * @param  boolean $echo [description]
 * @return [type]        [description]
 */
function dp_show_canonical($echo = true) {
	if (is_404()) return;
	global $options, $paged, $wp_query;
	$canonical_url = $next_prev_url = '';

	// canonical URL
	if ( is_singular() ) {
		$canonical_url = wp_get_canonical_url();
	} else {
		$canonical_url = is_ssl() ? 'https://' : 'http://';
		$canonical_url .= $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
	}

	if ( !empty( $canonical_url ) && (bool)$echo ) $canonical_url = '<link rel="canonical" href="' . esc_url( $canonical_url ) . '" />';

	// Previous / Next page link
	if ( !is_singular() ) {
		$max_page = (int)$wp_query->max_num_pages;
		if ( $max_page > 1 ) {
			$nextpage = $paged + 1;
			if ( $nextpage <= $max_page ) {
				$next_prev_url = '<link rel="next" href="' . next_posts( $max_page, false ) . '" />';
			}
			if( $paged > 1 ){
				$next_prev_url .= '<link rel="prev" href="' . previous_posts( false ) . '" />';
			}
		}
	}

	if ( isset( $options['disable_canonical'] ) && !empty( $options['disable_canonical'] ) ){
		$canonical_url = '';
	}
	if ( (bool)$echo ) {
		echo $canonical_url . $next_prev_url;
	} else {
		return $canonical_url;
	}
}