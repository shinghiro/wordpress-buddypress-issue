<?php
/**
* Create main CSS file.
*/
function dp_css_create() {
	// Make directory if necessary
	dp_permission_check();

	$options = get_option('dp_theme_options');
	//Custom CSS file
	$file_path	=  DP_UPLOAD_DIR."/css/visual-custom.css";
	// Create CSS
	$str_css = dp_custom_design_css($options);
	// Strip blank, tags
	$str_css = str_replace(array("\r\n","\r","\n","\t","/^\s(?=\s)/"), '', $str_css);
	// Rewrite CSS for custom design
	dp_export_file($file_path, $str_css);
	// gzip compress
	dp_export_gzip($file_path, $str_css);

	// Do custom action
	do_action( 'dp_custom_css_create' );

	return true;
}

/**
 * Create css for custom design
 */
function dp_custom_design_css($options) {
	global $def_options;
	extract($options);

	$original_font_size_px = 16;

	// For CS
	$site_bg_img_css= '';
	$font_face = '';
	$alphanumeric_font_css = '';
	$typography_css = '';
	$header_filter_css = '';
	$term_color_css = '';
	$wow_css = '';

	$variant_css = '';



	// RGB
	$rgb_header_banner_text_color = dp_hex_to_rgb( $header_banner_text_color );
	$rgb_header_banner_text_color_mobile = dp_hex_to_rgb( $header_banner_text_color_mobile );
	$rgb_header_banner_text_shadow_color = dp_hex_to_rgb( $header_banner_text_shadow_color );
	$rgb_header_banner_text_shadow_color_mobile = dp_hex_to_rgb( $header_banner_text_shadow_color_mobile );
	$rgb_header_banner_overlay_color = dp_hex_to_rgb( $header_banner_overlay_color );
	$rgb_header_banner_overlay_color_mobile = dp_hex_to_rgb( $header_banner_overlay_color_mobile );
	$rgb_container_bg_color = dp_hex_to_rgb( $container_bg_color );
	$rgb_lighten_container_bg_color = dp_color_luminance($container_bg_color, 0.04 );
	$rgb_darken_container_bg_color = dp_color_luminance($container_bg_color, -0.03 );
	$rgb_base_font_color = dp_hex_to_rgb( $base_font_color );
	$rgb_base_link_color = dp_hex_to_rgb( $base_link_color );
	$rgb_hidden_menu_link_color = dp_hex_to_rgb( $hidden_menu_link_color );
	$rgb_header_bar_bgcolor = dp_hex_to_rgb( $header_bar_bgcolor );
	$rgb_header_bar_link_color = dp_hex_to_rgb( $header_bar_link_color );
	$rgb_footer_text_color = dp_hex_to_rgb( $footer_text_color );
	$rgb_footer_bgcolor = dp_hex_to_rgb( $footer_bgcolor );
	$rgb_primary_color = dp_hex_to_rgb( $primary_color );
	$rgb_secondary_color = dp_hex_to_rgb( $secondary_color );
	$rgb_darken_primary_color = dp_color_luminance( $primary_color, -0.4 );



	/**
	 * Variant CSS
	 */
	$variant_css =
":root{
	--container-bg-color:" . $container_bg_color . ";
	--container-bg-color-76p:rgba(" . $rgb_container_bg_color[0] . "," . $rgb_container_bg_color[1] . "," . $rgb_container_bg_color[2] . ",.76);
	--container-bg-color-62p:rgba(" . $rgb_container_bg_color[0] . "," . $rgb_container_bg_color[1] . "," . $rgb_container_bg_color[2] . ",.62);
	--container-bg-opacity:" . (int)$container_bg_opacity / 100 . ";
	--container-top-gradient:linear-gradient(180deg," . $container_bg_color . ",transparent);
	--base-letter-spacing:" . $base_letter_spacing . "em;
	--base-font-color:" . $base_font_color . ";
	--base-link-color:" . $base_link_color . ";
	--base-link-hover-color:" . $base_link_hover_color . ";
	--base-font-color-76p:rgba(" . $rgb_base_font_color[0] . "," . $rgb_base_font_color[1] . "," . $rgb_base_font_color[2] . ",.76);
	--base-font-color-62p:rgba(" . $rgb_base_font_color[0] . "," . $rgb_base_font_color[1] . "," . $rgb_base_font_color[2] . ",.62);
	--base-font-color-48p:rgba(" . $rgb_base_font_color[0] . "," . $rgb_base_font_color[1] . "," . $rgb_base_font_color[2] . ",.48);
	--base-font-color-40p:rgba(" . $rgb_base_font_color[0] . "," . $rgb_base_font_color[1] . "," . $rgb_base_font_color[2] . ",.40);
	--base-font-color-34p:rgba(" . $rgb_base_font_color[0] . "," . $rgb_base_font_color[1] . "," . $rgb_base_font_color[2] . ",.34);
	--base-font-color-28p:rgba(" . $rgb_base_font_color[0] . "," . $rgb_base_font_color[1] . "," . $rgb_base_font_color[2] . ",.28);
	--base-font-color-24p:rgba(" . $rgb_base_font_color[0] . "," . $rgb_base_font_color[1] . "," . $rgb_base_font_color[2] . ",.24);
	--base-font-color-20p:rgba(" . $rgb_base_font_color[0] . "," . $rgb_base_font_color[1] . "," . $rgb_base_font_color[2] . ",.2);
	--base-font-color-16p:rgba(" . $rgb_base_font_color[0] . "," . $rgb_base_font_color[1] . "," . $rgb_base_font_color[2] . ",.16);
	--base-font-color-12p:rgba(" . $rgb_base_font_color[0] . "," . $rgb_base_font_color[1] . "," . $rgb_base_font_color[2] . ",.12);
	--base-font-color-8p:rgba(" . $rgb_base_font_color[0] . "," . $rgb_base_font_color[1] . "," . $rgb_base_font_color[2] . ",.08);
	--base-font-color-4p:rgba(" . $rgb_base_font_color[0] . "," . $rgb_base_font_color[1] . "," . $rgb_base_font_color[2] . ",.04);
	--common-title-spacing:" . $title_letter_spacing . "em;
	--term-color:" . $primary_color . ";
	--primary-color:" . $primary_color . ";
	--primary-color-6p:rgba(" . $rgb_primary_color[0] . "," . $rgb_primary_color[1] . "," . $rgb_primary_color[2] . ",.06);
	--primary-color-10p:rgba(" . $rgb_primary_color[0] . "," . $rgb_primary_color[1] . "," . $rgb_primary_color[2] . ",.1);
	--primary-color-14p:rgba(" . $rgb_primary_color[0] . "," . $rgb_primary_color[1] . "," . $rgb_primary_color[2] . ",.14);
	--primary-color-64p:rgba(" . $rgb_primary_color[0] . "," . $rgb_primary_color[1] . "," . $rgb_primary_color[2] . ",.64);
	--secondary-color:" . $secondary_color . ";
	--accent-color-gradient:linear-gradient(135deg, " . $primary_color . " 0%," . $secondary_color . " 100%);
	--global-menu-parent-spacing:" . $header_bar_menu_letter_spacing . "em;
	--header-bar-menu-font-size:" . $header_bar_menu_font_size . "px;
	--header-bar-bg-color:" . $header_bar_bgcolor . ";
	--header-bar-bg-color-10p:rgba(" . $rgb_header_bar_bgcolor[0] . "," . $rgb_header_bar_bgcolor[1] . "," . $rgb_header_bar_bgcolor[2] . ",.1);
	--header-bar-bg-color-50p:rgba(" . $rgb_header_bar_bgcolor[0] . "," . $rgb_header_bar_bgcolor[1] . "," . $rgb_header_bar_bgcolor[2] . ",.5);
	--header-bar-piled-layer-color:" . $header_bar_layer_color . ";
	--header-bar-link-color:" . $header_bar_link_color . ";
	--header-bar-link-color-8p:rgba(" . $rgb_header_bar_link_color[0] . "," . $rgb_header_bar_link_color[1] . "," . $rgb_header_bar_link_color[2] . ",.08);
	--header-bar-link-color-16p:rgba(" . $rgb_header_bar_link_color[0] . "," . $rgb_header_bar_link_color[1] . "," . $rgb_header_bar_link_color[2] . ",.16);
	--header-bar-link-color-28p:rgba(" . $rgb_header_bar_link_color[0] . "," . $rgb_header_bar_link_color[1] . "," . $rgb_header_bar_link_color[2] . ",.28);
	--header-bar-link-color-34p:rgba(" . $rgb_header_bar_link_color[0] . "," . $rgb_header_bar_link_color[1] . "," . $rgb_header_bar_link_color[2] . ",.34);
	--hidden-menu-link-color:" . $hidden_menu_link_color . ";
	--hidden-menu-link-color-8p:rgba(" . $rgb_hidden_menu_link_color[0] . "," . $rgb_hidden_menu_link_color[1] . "," . $rgb_hidden_menu_link_color[2] . ",.08);
	--hidden-menu-link-color-18p:rgba(" . $rgb_hidden_menu_link_color[0] . "," . $rgb_hidden_menu_link_color[1] . "," . $rgb_hidden_menu_link_color[2] . ",.18);
	--hidden-menu-link-color-28p:rgba(" . $rgb_hidden_menu_link_color[0] . "," . $rgb_hidden_menu_link_color[1] . "," . $rgb_hidden_menu_link_color[2] . ",.28);
	--hidden-menu-link-color-34p:rgba(" . $rgb_hidden_menu_link_color[0] . "," . $rgb_hidden_menu_link_color[1] . "," . $rgb_hidden_menu_link_color[2] . ",.34);
	--hidden-menu-bg-color:" . $hidden_menu_bgcolor . ";
	--header-banner-text-color:" . $header_banner_text_color . ";
	--header-banner-overlay-color:" . $header_banner_overlay_color . ";
	--header-banner-overlay-opacity:" . (int)$header_banner_overlay_opacity / 100 . ";
	--header-banner-text-color-mb:" . $header_banner_text_color_mobile . ";
	--header-banner-overlay-color-mb:" . $header_banner_overlay_color_mobile . ";
	--header-banner-overlay-opacity-mb:" . (int)$header_banner_overlay_opacity_mobile / 100 . ";
	--global-menu-mouseover-accent-color:" . $global_menu_mouseover_accent_color . ";
	--footer-text-color:" . $footer_text_color . ";
	--footer-link-color:" . $footer_link_color. ";
	--footer-link-hover-color:" . $footer_link_hover_color. ";
	--footer-text-color-4p:rgba(" . $rgb_footer_text_color[0] . "," . $rgb_footer_text_color[1] . "," . $rgb_footer_text_color[2] . ",.04);
	--footer-text-color-16p:rgba(" . $rgb_footer_text_color[0] . "," . $rgb_footer_text_color[1] . "," . $rgb_footer_text_color[2] . ",.16);
	--footer-text-color-28p:rgba(" . $rgb_footer_text_color[0] . "," . $rgb_footer_text_color[1] . "," . $rgb_footer_text_color[2] . ",.28);
	--footer-text-color-38p:rgba(" . $rgb_footer_text_color[0] . "," . $rgb_footer_text_color[1] . "," . $rgb_footer_text_color[2] . ",.38);
	--footer-text-color-48p:rgba(" . $rgb_footer_text_color[0] . "," . $rgb_footer_text_color[1] . "," . $rgb_footer_text_color[2] . ",.48);
	--footer-bg-color:" . $footer_bgcolor . ";
	--footer-bg-gradient:linear-gradient(180deg," . $footer_bgcolor . " 0%,rgba(" . $rgb_footer_bgcolor[0] . "," . $rgb_footer_bgcolor[1] . "," . $rgb_footer_bgcolor[2] . "," . (int)$footer_bg_opacity / 100 . ") 20%,rgba(" . $rgb_footer_bgcolor[0] . "," . $rgb_footer_bgcolor[1] . "," . $rgb_footer_bgcolor[2] . "," . (int)$footer_bg_opacity / 100 . ") 100%);
	--loop-bg-color1:linear-gradient(transparent,rgba(" . $rgb_primary_color[0] . "," . $rgb_primary_color[1] . "," . $rgb_primary_color[2] . ",.62), " . $primary_color . ");
	--loop-bg-color2:linear-gradient(transparent," . $primary_color . "," . $secondary_color . ");
";

	/**
	 * Primary color base
	 */
	if (isset($options['enable_primary_color_gradient'] ) && !empty($options['enable_primary_color_gradient'] )) {
		$variant_css .= "--primary-color-gradient:linear-gradient(135deg," . $primary_color." 0%,rgba(" . $rgb_darken_primary_color[0] . "," . $rgb_darken_primary_color[1] . "," . $rgb_darken_primary_color[2] . ",1) 100%);";
	}


	// Alternate color
	if ( $base_font_color == '#ffffff' ) {
		$variant_css .= '--alternate-font-color:#000000;';
	}


	/**
	 * Common block element color
	 */
	if ( isset($options['enable_primary_color_gradient'] ) && !empty($options['enable_primary_color_gradient'] ) ) {
		$variant_css .= "--arc-wd-tab-arrow-color:rgba(" . $rgb_darken_primary_color[0] . "," . $rgb_darken_primary_color[1] . "," . $rgb_darken_primary_color[2] . ",1);";
	} else {
		$variant_css .= "--arc-wd-tab-arrow-color:" . $primary_color . ";";
	}

	/**
	 * Background image
	 */
	if ( isset($background_img) && !empty($background_img) ) {
		$background_img = is_ssl() ? str_replace('http:', 'https:', $background_img) : $background_img;
		if ($background_repeat === 'no-repeat'){
			$variant_css .=
"--site-bg-size:cover;
--site-bg-position:center;";
		} else {
			$variant_css .=
"--site-bg-repeat:" . $background_repeat . ";
--site-bg-position:left top;";
		}

		$variant_css .=
"--site-bg-image:url(" . $background_img . ");";
	}


	/**
	 * Font size
	 */
	if ( empty($base_font_size) ) {
		$variant_css .= "--base-font-size:" . $original_font_size_px . "px;";
	} else {
		$variant_css .= "--base-font-size:" . $base_font_size . "px;";
	}

	// For mobile
	if ( empty($base_font_size_mb) ) {
		$variant_css .= "--base-font-size-mb:" . $original_font_size_px . "px;";
	} else {
		$variant_css .= "--base-font-size-mb:" . $base_font_size_mb . "px;";
	}

	/**
	 * Link style
	 */
	if ( $base_link_bold ) {
		$variant_css .= "--entry-link-weight:700;";
	}
	if ( $base_link_underline === 'not_mouseover' ) {

		$variant_css .=
"--entry-link-decoration:underline;
--entry-link-decoration-hover:none;";

	} else if ( $base_link_underline === 'none' ) {
		$variant_css .= "--entry-link-decoration-hover:none;";
	}

	/**
	 * Global menu link
	 */
	if ( $header_bar_menu_font_bold ){
		$variant_css .= "--header-bar-menu-parent-weight:600;";
	}


	/**
	 * Header banner overlay CSS
	 */
	// PC
	$variant_css .= (bool)$header_banner_text_shadow_enable ?  "--header-banner-text-shadow:0 0 16px rgba(" . $rgb_header_banner_text_shadow_color[0] . "," . $rgb_header_banner_text_shadow_color[1] . "," . $rgb_header_banner_text_shadow_color[2] . ",.68),0 4px 22px rgba(" . $rgb_header_banner_text_shadow_color[0] . "," . $rgb_header_banner_text_shadow_color[1] . "," . $rgb_header_banner_text_shadow_color[2] . ",.72);" : '';
	// Mobile
	$variant_css .= (bool)$header_banner_text_shadow_enable_mobile ?  "--header-banner-text-shadow-mb:0 0.12vh 0.42vh rgba(" . $rgb_header_banner_text_shadow_color_mobile[0] . "," . $rgb_header_banner_text_shadow_color_mobile[1] . "," . $rgb_header_banner_text_shadow_color_mobile[2] . ",.68);" : '';


	/**
	 * Fade-in with text shadow on header banner (PC)
	 */
	if ( $header_text_vertically && $header_img_text_animate ) {
		$variant_css .=
"--ver-banner-title-color:transparent;
--ver-banner-title-txt-shadow-1:0 0 60px " . $header_banner_text_color . ";
--ver-banner-title-txt-shadow-2:0 0 " . $header_banner_text_color . ";";
	}

	if ( $header_text_vertically_mobile && $header_img_text_animate_mobile ) {
		$variant_css .=
"--ver-banner-title-color-mb:transparent;
--ver-banner-title-txt-shadow-mb-1:0 0 50px " . $header_banner_text_color_mobile . ";
--ver-banner-title-txt-shadow-mb-2:0 0 " . $header_banner_text_color_mobile . ";";
	}


	/**
	 * Top page header banner layer mask
	 */
	if ($dp_header_area_mask_pattern !== 'none') {
		$mask_opacity = (int)$dp_header_area_mask_opacity / 100;
		$line_thickness = (int)$dp_header_area_mask_line_thickness;
		$line_spacing = (int)$dp_header_area_mask_line_spacing;

		switch ( $dp_header_area_mask_pattern ) {
			case 'dot1':
				$variant_css .=
"--header-banner-layer-pattern:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAQAAAAECAYAAACp8Z5+AAAAFklEQVQYV2NkQAOMUP5/KM2IUwCuEQBF3gIFIVBLNgAAAABJRU5ErkJggg==) repeat;
--header-banner-layer-opacity:" . $mask_opacity . ";";
				break;

			case 'dot1w':
				$variant_css .=
"--header-banner-layer-pattern:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAQAAAAECAYAAACp8Z5+AAAAG0lEQVQYV2NkQAOMIP7/////g2hGEMAqgKwLACC9CAUi/07yAAAAAElFTkSuQmCC) repeat;
--header-banner-layer-opacity:" . $mask_opacity . ";";
				break;

			case 'dot2':
				$variant_css .=
"--header-banner-layer-pattern:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAQAAAAECAYAAACp8Z5+AAAAG0lEQVQYV2NkYGD4z8DAwMgABXAGNgGwSgwVAFbmAgXQdISfAAAAAElFTkSuQmCC) repeat;
--header-banner-layer-opacity:" . $mask_opacity . ";";
				break;

			case 'dot2w':
				$variant_css .=
"--header-banner-layer-pattern:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAQAAAAECAYAAACp8Z5+AAAAHElEQVQYV2P8////f0ZGRkYGKIAzMARgKjFUAABk3QgFeD0pTAAAAABJRU5ErkJggg==) repeat;
--header-banner-layer-opacity:" . $mask_opacity . ";";
				break;

			case 'stripe1':
				$variant_css .= "--header-banner-layer-pattern:repeating-linear-gradient(90deg,transparent,transparent " . $line_spacing . "px,rgba(0,0,0," . $mask_opacity . ") " . $line_spacing . "px,rgba(0,0,0," . $mask_opacity . ") " . ($line_spacing+$line_thickness) . "px);";
				break;

			case 'stripe1w':
				$variant_css .= "--header-banner-layer-pattern:repeating-linear-gradient(90deg,transparent,transparent " . $line_spacing . "px,rgba(255,255,255," . $mask_opacity . ") " . $line_spacing . "px,rgba(255,255,255," . $mask_opacity . ") " . ($line_spacing+$line_thickness) . "px);";
				break;

			case 'stripe2':
				$variant_css .= "--header-banner-layer-pattern:repeating-linear-gradient(-45deg,transparent,transparent " . $line_spacing . "px,rgba(0,0,0," . $mask_opacity . ") " . $line_spacing . "px,rgba(0,0,0," . $mask_opacity . ") " . ($line_spacing+$line_thickness) . "px);";
				break;

			case 'stripe2w':
				$variant_css .= "--header-banner-layer-pattern:repeating-linear-gradient(-45deg,transparent,transparent " . $line_spacing . "px,rgba(255,255,255," . $mask_opacity . ") " . $line_spacing . "px,rgba(255,255,255," . $mask_opacity . ") " . ($line_spacing+$line_thickness) . "px);";
				break;

			case 'border':
				$variant_css .= "--header-banner-layer-pattern:repeating-linear-gradient(0deg,transparent,transparent " . $line_spacing . "px,rgba(0,0,0," . $mask_opacity . ") " . $line_spacing . "px,rgba(0,0,0," . $mask_opacity . ") " . ($line_spacing+$line_thickness) . "px);";
				break;

			case 'borderw':
				$variant_css .= "--header-banner-layer-pattern:repeating-linear-gradient(0deg,transparent,transparent " . $line_spacing . "px,rgba(255,255,255," . $mask_opacity . ") " . $line_spacing . "px,rgba(255,255,255," . $mask_opacity . ") " . ($line_spacing+$line_thickness) . "px);";
				break;

			case 'mesh':
				$variant_css .=
"--header-banner-layer-pattern:linear-gradient(90deg,rgba(0,0,0," . $mask_opacity . ") 50%,transparent 50%),linear-gradient(rgba(0,0,0," . ($mask_opacity / 2) . ") 50%,transparent 50%);
--header-banner-layer-size:" . $line_thickness . "px " . $line_thickness . "px;";
				break;

			case 'meshw':
				$variant_css .=
"--header-banner-layer-pattern:linear-gradient(90deg,rgba(255,255,255," . $mask_opacity . ") 50%,transparent 50%),linear-gradient(rgba(255,255,255," . ($mask_opacity / 2) . ") 50%,transparent 50%);
--header-banner-layer-size:" . $line_thickness . "px " . $line_thickness . "px;";
				break;
		}
	}


	/**
	 * Common page header background image layer mask (Except site home)
	 */
	$variant_css .= isset( $page_header_text_color ) && $page_header_text_color !== '#fffff' ? "--ct-hd-color:" . $page_header_text_color . ";" : '';

	if ( isset( $page_header_text_shadow_enable ) && !empty( $page_header_text_shadow_enable ) && isset( $page_header_text_shadow_color ) && !empty( $page_header_text_shadow_color ) ) {

		$rgb_page_header_text_shadow_color = dp_hex_to_rgb( $page_header_text_shadow_color );

		if ( is_array( $rgb_page_header_text_shadow_color ) ) {
			$variant_css .= "--ct-hd-text-shadow-color:0 0 16px rgba(" . $rgb_page_header_text_shadow_color[0] . "," . $rgb_page_header_text_shadow_color[1] . "," . $rgb_page_header_text_shadow_color[2] . ",.6),0 4px 22px rgba(" . $rgb_page_header_text_shadow_color[0] . "," . $rgb_page_header_text_shadow_color[1] . "," . $rgb_page_header_text_shadow_color[2] . ",.66);";
		}
	}

	if ( $page_header_bgimg_mask_pattern !== 'none' ) {
		$mask_opacity = (int)$page_header_bgimg_mask_opacity / 100;
		$line_thickness = (int)$page_header_bgimg_mask_line_thickness;
		$line_spacing = (int)$page_header_bgimg_mask_line_spacing;

		switch ($page_header_bgimg_mask_pattern) {
			case 'dot1':
				$variant_css .=
"--ct-hd-layer-pattern:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAQAAAAECAYAAACp8Z5+AAAAFklEQVQYV2NkQAOMUP5/KM2IUwCuEQBF3gIFIVBLNgAAAABJRU5ErkJggg==) repeat;
--ct-hd-layer-opacity:" . $mask_opacity . ";";
				break;

			case 'dot1w':
				$variant_css .=
"--ct-hd-layer-pattern:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAQAAAAECAYAAACp8Z5+AAAAG0lEQVQYV2NkQAOMIP7/////g2hGEMAqgKwLACC9CAUi/07yAAAAAElFTkSuQmCC) repeat;
--ct-hd-layer-opacity:" . $mask_opacity . ";";
				break;

			case 'dot2':
				$variant_css .=
"--ct-hd-layer-pattern:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAQAAAAECAYAAACp8Z5+AAAAG0lEQVQYV2NkYGD4z8DAwMgABXAGNgGwSgwVAFbmAgXQdISfAAAAAElFTkSuQmCC) repeat;
--ct-hd-layer-opacity:" . $mask_opacity . ";";
				break;

			case 'dot2w':
				$variant_css .=
"--ct-hd-layer-pattern:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAQAAAAECAYAAACp8Z5+AAAAHElEQVQYV2P8////f0ZGRkYGKIAzMARgKjFUAABk3QgFeD0pTAAAAABJRU5ErkJggg==) repeat;
--ct-hd-layer-opacity:" . $mask_opacity . ";";
				break;

			case 'stripe1':
				$variant_css .= "--ct-hd-layer-pattern:repeating-linear-gradient(90deg,transparent,transparent " . $line_spacing . "px,rgba(0,0,0," . $mask_opacity . ") " . $line_spacing . "px,rgba(0,0,0," . $mask_opacity . ") " . ( $line_spacing + $line_thickness ) . "px);";
				break;

			case 'stripe1w':
				$variant_css .= "--ct-hd-layer-pattern:repeating-linear-gradient(90deg,transparent,transparent " . $line_spacing . "px,rgba(255,255,255," . $mask_opacity . ") " . $line_spacing . "px,rgba(255,255,255," . $mask_opacity . ") " . ($line_spacing + $line_thickness) . "px);";
				break;

			case 'stripe2':
				$variant_css .= "--ct-hd-layer-pattern:repeating-linear-gradient(-45deg,transparent,transparent " . $line_spacing . "px,rgba(0,0,0," . $mask_opacity . ") " . $line_spacing . "px,rgba(0,0,0," . $mask_opacity . ") " . ($line_spacing + $line_thickness) . "px);";
				break;

			case 'stripe2w':
				$variant_css .= "--ct-hd-layer-pattern:repeating-linear-gradient(-45deg,transparent,transparent " . $line_spacing . "px,rgba(255,255,255," . $mask_opacity . ") " . $line_spacing . "px,rgba(255,255,255," . $mask_opacity . ") " . ($line_spacing + $line_thickness) . "px);";
				break;

			case 'border':
				$variant_css .= "--ct-hd-layer-pattern:repeating-linear-gradient(0deg,transparent,transparent " . $line_spacing . "px,rgba(0,0,0," . $mask_opacity . ") " . $line_spacing . "px,rgba(0,0,0," . $mask_opacity . ") " . ($line_spacing + $line_thickness) . "px);";
				break;

			case 'borderw':
				$variant_css .= "--ct-hd-layer-pattern:repeating-linear-gradient(0deg,transparent,transparent " . $line_spacing . "px,rgba(255,255,255," . $mask_opacity . ") " . $line_spacing . "px,rgba(255,255,255," . $mask_opacity . ") " . ($line_spacing + $line_thickness) . "px);";
				break;

			case 'mesh':
				$variant_css .=
"--ct-hd-layer-pattern:linear-gradient(90deg,rgba(0,0,0," . $mask_opacity . ") 50%,transparent 50%),linear-gradient(rgba(0,0,0," . ($mask_opacity / 2) . ") 50%,transparent 50%);
--ct-hd-layer-size:" . $line_thickness . "px " . $line_thickness . "px;";
				break;

			case 'meshw':
				$variant_css .=
"--ct-hd-layer-pattern:linear-gradient(90deg,rgba(255,255,255," . $mask_opacity . ") 50%,transparent 50%),linear-gradient(rgba(255,255,255," . ($mask_opacity / 2) . ") 50%,transparent 50%);
--ct-hd-layer-size:" . $line_thickness . "px " . $line_thickness . "px;";
				break;
		}
	}



	/**
	 * Common page header CSS (Except site home)
	 */
	// For PC
	if ( isset( $dp_page_header_padding_top ) && !empty( $dp_page_header_padding_top ) ) {
		if ( isset( $header_bar_transparent ) && !empty( $header_bar_transparent ) ) {
			if ( isset( $header_bar_add_layer ) && !empty( $header_bar_add_layer ) ) {
				$variant_css .= "--page-header-space-top:calc(" . $dp_page_header_padding_top . "vh + 186px);";
			} else {
				$variant_css .= "--page-header-space-top:calc(" . $dp_page_header_padding_top . "vh + 166px);";
			}
		} else {
			$variant_css .= "--page-header-space-top:" . $dp_page_header_padding_top . "vh;";
		}
	}

	if ( isset( $dp_page_header_padding_bottom ) && !empty( $dp_page_header_padding_bottom ) ) {

		$variant_css .= "--page-header-space-btm:" . $dp_page_header_padding_bottom . "vh;";

		if ( isset( $page_header_bottom_edge ) && !empty( $page_header_bottom_edge ) ) {
			$variant_css .= "--page-header-space-btm-not-home:calc(" . $dp_page_header_padding_bottom . "vh + 4vw);";
		} else {
			$variant_css .= "--page-header-space-btm-not-home:calc(" . $dp_page_header_padding_bottom . "vh);";
		}
	}


	// For mobile
	if ( (isset($dp_page_header_padding_top_mb) && !empty($dp_page_header_padding_top_mb)) && (isset($dp_page_header_padding_bottom_mb) && !empty($dp_page_header_padding_bottom_mb)) ) {
		$variant_css .= '--page-header-space-top-mb:' . $dp_page_header_padding_top_mb . 'vh;';
		$variant_css .= '--page-header-space-btm-mb:' . $dp_page_header_padding_bottom_mb . 'vh;';
	}


	// Gradient effect
	if ( $page_header_bgcolor_overlay === 'primary_gradient' || $page_header_bgcolor_overlay === 'term_color_gradient' ) {

		$variant_css .= "--ct-hd-bg-gradient-no-bgimg:linear-gradient(135deg," . $primary_color . " 0%,rgba(" . $rgb_darken_primary_color[0] . "," . $rgb_darken_primary_color[1] . "," . $rgb_darken_primary_color[2] . ",1) 100%);";

	} else if ( $page_header_bgcolor_overlay === 'primary_secondary_gradient' ) {
		$variant_css .= "--ct-hd-bg-gradient-no-bgimg:linear-gradient(135deg," . $primary_color . " 0%," . $secondary_color . " 100%);";
	}

	if ( $page_header_bgimg_overlay === 'primary_gradient' ) {

		$variant_css .= "--ct-hd-bg-gradient-bgimg:linear-gradient(135deg," . $primary_color . " 0%,rgba(" . $rgb_darken_primary_color[0] . "," . $rgb_darken_primary_color[1] . "," . $rgb_darken_primary_color[2] . ",1) 100%);";

	} else if ( $page_header_bgimg_overlay === 'primary_secondary_gradient' ) {

		$variant_css .= "--ct-hd-bg-gradient-bgimg:linear-gradient(135deg," . $primary_color . " 0%,".$secondary_color." 100%);";

	} else if ( $page_header_bgimg_overlay === 'darken' || $page_header_bgimg_overlay === 'term_color' ) {

		$variant_css .= "--ct-hd-bg-opacity-bgimg:.52;--ct-hd-bg-color-bgimg:#000;";
	}


	// Blur effect
	if ((int)$page_header_bgimg_blur > 0) {
		$variant_css .= "--ct-hd-inner-bg-filter:url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='a' x='0' y='0' width='1' height='1' color-interpolation-filters='sRGB'%3E%3CfeGaussianBlur stdDeviation='" . $page_header_bgimg_blur . "' result='b'/%3E%3CfeMorphology operator='dilate' radius='" . $page_header_bgimg_blur . "'/%3E %3CfeMerge%3E%3CfeMergeNode/%3E%3CfeMergeNode in='b'/%3E%3C/feMerge%3E%3C/filter%3E %3C/svg%3E#a\");";
	}



	/**
	 * Loop article design
	 */
// 	$loop_article_css = 
// ".footer_bar::before{
// 	background-image:linear-gradient(135deg, ".$primary_color." 0%,".$secondary_color." 100%);
// }";


	// When the site background color is white...
	if ( $container_bg_color === '#ffffff' || $container_bg_color === '#fff' ) {
		$variant_css .= "--gen-container-bg-color:rgba(" . $rgb_darken_container_bg_color[0] ."," . $rgb_darken_container_bg_color[1] . ", " . $rgb_darken_container_bg_color[2] . ",1);";

		$variant_css .= "--lp-excerpt-gradient:linear-gradient(rgba(" . $rgb_darken_container_bg_color[0] ."," . $rgb_darken_container_bg_color[1] . ", " . $rgb_darken_container_bg_color[2] . ",0) 0%,rgba(" . $rgb_darken_container_bg_color[0] ."," . $rgb_darken_container_bg_color[1] . ", " . $rgb_darken_container_bg_color[2] . ",1) 100%);";
	} else {

		$variant_css .= "--gen-container-bg-color:rgba(" . $rgb_lighten_container_bg_color[0] ."," . $rgb_lighten_container_bg_color[1] . ", " . $rgb_lighten_container_bg_color[2] . ",1);";

		$variant_css .= "--lp-excerpt-gradient:linear-gradient(rgba(" . $rgb_lighten_container_bg_color[0] ."," . $rgb_lighten_container_bg_color[1] . ", " . $rgb_lighten_container_bg_color[2] . ",0) 0%,rgba(" . $rgb_lighten_container_bg_color[0] ."," . $rgb_lighten_container_bg_color[1] . ", " . $rgb_lighten_container_bg_color[2] . ",1) 100%);";
	}



	/**
	 * CSS for wow.js
	 */
	if ( !(bool)$options['disable_wow_js'] && !(bool)$options['disable_wow_js_mobile'] ) {
		// Both
		$wow_css = ".wow{visibility:hidden}";
	} else if ( !(bool)$options['disable_wow_js'] && (bool)$options['disable_wow_js_mobile'] ) {
		// Only PC
		$wow_css = "body:not(.mb-theme) .wow{visibility:hidden}";
	} else if ((bool)$options['disable_wow_js'] && !(bool)$options['disable_wow_js_mobile'] ) {
		// Only Mobile
		$wow_css = ".mb-theme .wow{visibility:hidden}";
	}



	/**
	 * Footer area CSS
	 */
	if ( isset($dp_footer_bg_img) && !empty($dp_footer_bg_img) && $dp_footer_bg_img !== 'none') {

		$variant_css .= "--footer-bg-img:url('" . $dp_footer_bg_img . "');";

	} else {

		$variant_css .= "--footer-bg-img:url('data:image/svg+xml;charset=utf8,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%221%22%20height%3D%221%22%3E%3Cpolygon%20fill%3D%22%23fff%22%20points%3D%220%200%200%201%201%201%201%200%200%200%22%2F%3E%3C%2Fsvg%3E');";
	}

// 	$footer_css .=
// ".footer_menu_ul.mb-theme .menu-item{
// 	border-color:rgba(".$rgb_footer_text_color[0].",".$rgb_footer_text_color[1].",".$rgb_footer_text_color[2].",.2);
// }
// .ftbar_btn, .ftbar_btn a{
// 	color:".$container_bg_color.";
// }";




	/**
	 * category colors
	 */
	$cats = get_categories();
	foreach($cats as $key => $cat){
		$cat_color = '';

		// Get term meta
		$term_meta = get_option( "ex_term_meta_" . $cat->term_id );

		if ( isset($term_meta['color'] ) ) {
			$cat_color = esc_attr( $term_meta['color'] );
		}

		if ( !empty($cat_color) ) {

			$term_color_css .=
".term-color" . $cat->term_id . "{
	--term-color:" . $cat_color . ";
}";
		}
	}

	// Tags
	$tags = get_tags();
	foreach($tags as $key => $tag){
		$tag_color = '';

		// Get term meta
		$term_meta = get_option( "ex_term_meta_" . $tag->term_id );

		if ( isset($term_meta['color'] ) ) {
			$tag_color = esc_attr($term_meta['color'] );
		}

		if ( !empty($tag_color) ) {
			$term_color_css .=
".term-color" . $tag->term_id . "{
	--term-color:" . $tag_color . ";
}";
		}
	}


	/**
	 * Head tag styling
	 */
	// Head tag font size
	if (isset($base_font_size_h1) && !empty($base_font_size_h1)) {
		if ( $base_font_size_h1 != $def_options['base_font_size_h1'] ) {
			$variant_css .= "--base-h1-size:" . $base_font_size_h1 . "%;";
		}
	}

	if (isset($base_font_size_h2) && !empty($base_font_size_h2)) {
		if ( $base_font_size_h2 != $def_options['base_font_size_h2'] ) {
			$variant_css .= "--base-h2-size:" . $base_font_size_h2 . "%;";
		}
	}

	if (isset($base_font_size_h3) && !empty($base_font_size_h3)) {
		if ( $base_font_size_h3 != $def_options['base_font_size_h3'] ) {
			$variant_css .= "--base-h3-size:" . $base_font_size_h3 . "%;";
		}
	}

	if (isset($base_font_size_h4) && !empty($base_font_size_h4)) {
		if ( $base_font_size_h4 != $def_options['base_font_size_h4'] ) {
			$variant_css .= "--base-h4-size:" . $base_font_size_h4 . "%;";
		}
	}

	if (isset($base_font_size_h5) && !empty($base_font_size_h5)) {
		if ( $base_font_size_h5 != $def_options['base_font_size_h5'] ) {
			$variant_css .= "--base-h5-size:" . $base_font_size_h5 . "%;";
		}
	}

	if (isset($base_font_size_h6) && !empty($base_font_size_h6)) {
		if ( $base_font_size_h6 != $def_options['base_font_size_h6'] ) {
			$variant_css .= "--base-h6-size:" . $base_font_size_h6 . "%;";
		}
	}


	// *************************************************
	// Typograpy CSS
	// *************************************************
	/**
	 * Alphanumeric font family
	 */
	if ( isset($alphanumeric_font_family) && $alphanumeric_font_family !== 'none' ) {
		$alphanumeric_font_css = "'" .str_replace( '+', ' ', $alphanumeric_font_family) . "',";
	}

	/**
	 * Font family
	 */
	switch ( $base_font_family ){
		case 'yugothic-all':
			$typography_css = "YuGothic,'Yu Gothic','Hiragino Sans','Hiragino Kaku Gothic ProN',Meiryo,sans-serif;";
			break;

		case 'serif-all':
		case 'yumincho-all':
			$font_face =
"@font-face {
	font-family:'Yu Mincho';
	src:local('Yu Mincho Demibold');
	font-weight:500;
}";
			$typography_css = "'HiraMinProN-W3','Hiragino Mincho ProN','YuMincho','Yu Mincho','HG明朝E',serif;";
			break;

		case 'm-plus-1p-all':
			$typography_css = "'M PLUS 1p','Hiragino Sans','Hiragino Kaku Gothic ProN',Meiryo,sans-serif;";
			break;

		case 'm-plus-rounded-1c-all':
			$typography_css = "'M PLUS Rounded 1c','Hiragino Sans','Hiragino Kaku Gothic ProN',Meiryo,sans-serif;";
			break;

		case 'm-plus-1-code-all':
			$typography_css = "'M PLUS 1 Code','Hiragino Sans','Hiragino Kaku Gothic ProN',Meiryo,sans-serif;";
			break;

		case 'sawarabi-gothic-all':
			$typography_css = "'Sawarabi Gothic','Hiragino Sans','Hiragino Kaku Gothic ProN',Meiryo,sans-serif;";
			break;

		case 'sawarabi-mincho-all':
			$typography_css = "'Sawarabi Mincho','HiraMinProN-W3','Hiragino Mincho ProN','HG明朝E',serif;";
			break;

		case 'kosugi-all':
			$typography_css = "'Kosugi','Hiragino Sans','Hiragino Kaku Gothic ProN',Meiryo,sans-serif;";
			break;

		case 'kosugi-maru-all':
			$typography_css = "'Kosugi Maru','Hiragino Sans','Hiragino Kaku Gothic ProN',Meiryo,sans-serif;";
			break;

		case 'hannari-all':
			$typography_css = "'Hannari','HiraMinProN-W3','Hiragino Mincho ProN','HG明朝E',serif;";
			break;

		case 'kokoro-all':
			$typography_css = "'Kokoro','HiraMinProN-W3','Hiragino Mincho ProN','HG明朝E',serif;";
			break;

		case 'kiwi-maru-all':
			$typography_css = "'Kiwi Maru','Hiragino Sans','Hiragino Kaku Gothic ProN',Meiryo,sans-serif;";
			break;

		case 'reggae-one-all':
			$typography_css = "'Reggae One','Hiragino Sans','Hiragino Kaku Gothic ProN',Meiryo,sans-serif;";
			break;

		case 'rocknroll-one-all':
			$typography_css = "'RocknRoll One','Hiragino Sans','Hiragino Kaku Gothic ProN',Meiryo,sans-serif;";
			break;

		case 'yusei-magic-all':
			$typography_css = "'Yusei Magic','Hiragino Sans','Hiragino Kaku Gothic ProN',Meiryo,sans-serif;";
			break;

		case 'hachi-maru-pop-all':
			$typography_css = "'Hachi Maru Pop','Hiragino Sans','Hiragino Kaku Gothic ProN',Meiryo,sans-serif;";
			break;

		case 'shippori-mincho-all':
			$typography_css = "'Shippori Mincho','HiraMinProN-W3','Hiragino Mincho ProN','HG明朝E',serif;";
			break;

		case 'shippori-mincho-b1-all':
			$typography_css = "'Shippori Mincho B1','HiraMinProN-W3','Hiragino Mincho ProN','HG明朝E',serif;";
			break;

		case 'shippori-antique-all':
			$typography_css = "'Shippori Antique','HiraMinProN-W3','Hiragino Mincho ProN','HG明朝E',serif;";
			break;

		case 'shippori-antique-b1-all':
			$typography_css = "'Shippori Antique B1','HiraMinProN-W3','Hiragino Mincho ProN','HG明朝E',serif;";
			break;

		case 'new-tegomin-all':
			$typography_css = "'New Tegomin','HiraMinProN-W3','Hiragino Mincho ProN','HG明朝E',serif;";
			break;

		case 'mochiy-pop-one-all':
			$typography_css = "'Mochiy Pop One','Hiragino Sans','Hiragino Kaku Gothic ProN',Meiryo,sans-serif;";
			break;

		case 'yuji-mai-all':
			$typography_css = "'Yuji Mai','HiraMinProN-W3','Hiragino Mincho ProN','HG明朝E',serif;";
			break;

		case 'yuji-boku-all':
			$typography_css = "'Yuji Boku','HiraMinProN-W3','Hiragino Mincho ProN','HG明朝E',serif;";
			break;

		case 'yuji-syuku-all':
			$typography_css = "'Yuji Syuku','HiraMinProN-W3','Hiragino Mincho ProN','HG明朝E',serif;";
			break;

		case 'zen-antique-soft-all':
			$typography_css = "'Zen Antique Soft','HiraMinProN-W3','Hiragino Mincho ProN','HG明朝E',serif;";
			break;

		case 'zen-kurenaido-all':
			$typography_css = "'Zen Kurenaido','Hiragino Sans','Hiragino Kaku Gothic ProN',Meiryo,sans-serif;";
			break;

		case 'zen-old-mincho-all':
			$typography_css = "'Zen Old Mincho','HiraMinProN-W3','Hiragino Mincho ProN','HG明朝E',serif;";
			break;

		case 'zen-kaku-gothic-new-all':
			$typography_css = "'Zen Kaku Gothic New','Hiragino Sans','Hiragino Kaku Gothic ProN',Meiryo,sans-serif;";
			break;

		case 'zen-maru-gothic-all':
			$typography_css = "'Zen Maru Gothic','Hiragino Sans','Hiragino Kaku Gothic ProN',Meiryo,sans-serif;";
			break;

		case 'kaisei-haruno-umi-all':
			$typography_css = "'Kaisei HarunoUmi','Hiragino Sans','Hiragino Kaku Gothic ProN',Meiryo,sans-serif;";
			break;

		case 'kaisei-decol-all':
			$typography_css = "'Kaisei Decol','Hiragino Sans','Hiragino Kaku Gothic ProN',Meiryo,sans-serif;";
			break;

		case 'kaisei-opti-all':
			$typography_css = "'Kaisei Opti','Hiragino Sans','Hiragino Kaku Gothic ProN',Meiryo,sans-serif;";
			break;

		case 'kaisei-tokumin-all':
			$typography_css = "'Kaisei Tokumin','Hiragino Sans','Hiragino Kaku Gothic ProN',Meiryo,sans-serif;";
			break;

		case 'klee-one-all':
			$typography_css = "'Klee One','Hiragino Sans','Hiragino Kaku Gothic ProN',Meiryo,sans-serif;";
			break;

		case 'yomogi-all':
			$typography_css = "'Yomogi','Hiragino Sans','Hiragino Kaku Gothic ProN',Meiryo,sans-serif;";
			break;

		case 'hina-mincho-all':
			$typography_css = "'Hina Mincho','Hiragino Sans','Hiragino Kaku Gothic ProN',Meiryo,sans-serif;";
			break;

		case 'notosans-all':
			$typography_css = "'Noto Sans JP','Hiragino Sans','Hiragino Kaku Gothic ProN',Meiryo,sans-serif;";
			break;

		case 'notoserif-all':
			$typography_css = "'Noto Serif JP','HiraMinProN-W3','Hiragino Mincho ProN','HG明朝E',serif;";
			break;
	}

	/**
	 * Custom font is for body or main title?
	 */
	if ( !empty($typography_css) ) {
		if ( isset($custom_font_only_title) && !empty($custom_font_only_title) ) {

			$variant_css .= '--major-title-font-family:' . $alphanumeric_font_css . $typography_css;
			$typography_css = '';

		} else {
			$typography_css = "body{font-family:" . $alphanumeric_font_css . $typography_css . "}";
		}
	} else {
		if ( !empty($alphanumeric_font_css) ) {
			$typography_css = "body{font-family:" . $alphanumeric_font_css . "'Hiragino Sans','Hiragino Kaku Gothic ProN',Meiryo,YuGothic,'Yu Gothic',sans-serif;}";
		}
	}

	/**
	 * Italic and bold for major titles
	 */
	if ( $title_font_bold ) {
		$variant_css .= '--major-title-font-weight:700;';
	}

	if ( $title_font_style_italic ) {
		$variant_css .= '--major-title-font-style:italic;';
	}


	// Root closure
	$variant_css .= '}';

	/**
	 * Whole custom CSS
	 */
	$result = <<<_EOD_
@charset "utf-8";
$variant_css
$wow_css
$typography_css
$term_color_css
$original_css
_EOD_;

	return $result;
}



/**
 * Export custom CSS file
 */
function dp_export_file($file_path, $str) {
	if ( !file_exists($file_path) ) {
		touch( $file_path );
		chmod( $file_path, 0666 );
	}

	$creds = request_filesystem_credentials( $file_path, '', false, false, null );

	if ( WP_Filesystem( $creds ) && is_writable($file_path) ) {
		if ( !defined('FS_CHMOD_FILE')) {
			define('FS_CHMOD_FILE', (0666 & ~ umask()));
		}
		global $wp_filesystem;
		if ( !$wp_filesystem->put_contents($file_path, $str, FS_CHMOD_FILE)) {
			$err_msg = $file_path.": ".__('The file may be in use by other program. Please identify the conflict process.','DigiPress');
			$e = new WP_Error();
			$e->add( 'error', $err_msg );
			set_transient( 'dp-admin-option-errors', $e->get_error_messages(), 10 );
			add_action( 'admin_notices', array('digipress_options', 'dp_show_admin_error_message') );
			return false;
  		}
	} else {
		//if only readinig
		$err_msg = $file_path.": ".__('The file is not rewritable. Please change the permission to 666 or 606.','DigiPress');
		$e = new WP_Error();
		$e->add( 'error', $err_msg );
		set_transient( 'dp-admin-option-errors', $e->get_error_messages(), 10 );
		add_action( 'admin_notices', array('digipress_options', 'dp_show_admin_error_message') );
		return false;
	}
	return true;
}


/**
 * Archiving custom CSS as gzip
 */
function dp_export_gzip($file_path, $str) {
	if ( !file_exists($file_path) ) {
		touch( $file_path );
		chmod( $file_path, 0666 );
	}

	//Rewrite CSS for custom design
	if (is_writable( $file_path )){
		//Open
		if( !$fp = gzopen($file_path.'.gz',  'w9') ){
			$err_msg = $file_path.".gz: ".__('The file can not be opened. Please identify the conflict process.','DigiPress');
			$e = new WP_Error();
			$e->add( 'error', $err_msg );
			set_transient( 'dp-admin-option-errors',
				$e->get_error_messages(), 10 );
			add_action( 'admin_notices', array('digipress_options', 'dp_show_admin_error_message') );
    		return false;
  		}
  		//Write
  		if( !gzwrite( $fp, $str )){
			$err_msg = $file_path.".gz: ".__('The file may be in use by other program. Please identify the conflict process.','DigiPress');
			$e = new WP_Error();
			$e->add( 'error', $err_msg );
			set_transient( 'dp-admin-option-errors',
				$e->get_error_messages(), 10 );
			add_action( 'admin_notices', array('digipress_options', 'dp_show_admin_error_message') );
			return false;
		}
		//Close file
		gzclose($fp);
	} else {
		//if only readinig
		$err_msg = $file_path.".gz: ".__('The file is not rewritable. Please change the permission to 666 or 606.','DigiPress');
		$e = new WP_Error();
		$e->add( 'error', $err_msg );
		set_transient( 'dp-admin-option-errors',
			$e->get_error_messages(), 10 );
		add_action( 'admin_notices', array('digipress_options', 'dp_show_admin_error_message') );
		return false;
	}
	return true;
}