<?php
/**
 * Add prev and next links to a numbered page link list
 */
function dp_link_pages_args_add_next_and_number( $args ) {

	if ( !is_singular() ) return;

	global $page, $numpages, $more, $pagenow;

	# exit early
	if ( $args['next_or_number'] !== 'next_and_number' ) {
		return $args;
	}

	$args['next_or_number'] = 'number'; # keep numbering for the main part
	# exit early
	if ( !$more ) {
		return $args;
	}

	# there is a next page
	if ( $page < $numpages && !empty( $args['nextpagelink'] ) ) {
		$nextpage_text = explode( "\n", $args['nextpagelink'] );
		$nextpage_text = is_array( $nextpage_text ) && isset( $nextpage_text[ $page - 1 ] ) ? $nextpage_text[ $page - 1 ] : sprintf( __( 'Read page %s', 'DigiPress' ), $page + 1 );
		$nextpage_text = '<span class="page-text __next">' . __( 'Next page' ) . '</span><span class="page-text __phrase">' . $nextpage_text . '</span>';

		$args['before'] .= '<div class="split-page-link __next">' . _wp_link_page( $page + 1 ) . $nextpage_text . '</a></div>';
	}

	# there is a previous page
	if ( $page - 1 && !empty( $args['previouspagelink'] ) ) {
		$args['before'] .= '<div class="split-page-link __prev">' . _wp_link_page( $page - 1 ) . '<span class="page-text">' . $args['previouspagelink'] . '</span></a></div>';
	}

	return $args;
}

add_filter( 'wp_link_pages_args', 'dp_link_pages_args_add_next_and_number' );