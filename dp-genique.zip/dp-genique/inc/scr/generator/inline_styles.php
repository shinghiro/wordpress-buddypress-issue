<?php
function dp_inline_styles() {
	global $post, $IS_MOBILE_DP;
	$inline_css = '';
	if ( is_singular() ){
		// Background image in single page
		if ( (bool)get_post_meta(get_the_ID(), 'dp_eyecatch_to_bg', true) ) {
			$bg_img = DP_Post_Thumbnail::get_post_thumbnail( array(
				'width' => 980,
				'height' => 980,
				'size' => $IS_MOBILE_DP ? 'large' : 'full',
				'if_img_tag' => false
			) );
			if ( !empty($bg_img) ) {
				$inline_css = '.dp-container.singular::before{background-image:url(\''.$bg_img.'\');background-size:cover;}';
			}
		}
	}
	if ( !empty($inline_css) ) {
		wp_register_style( 'dp-inline-styles', false, array()  );
		wp_enqueue_style( 'dp-inline-styles' );
		wp_add_inline_style( 'dp-inline-styles', $inline_css );
	}
}
add_action( 'wp_enqueue_scripts', 'dp_inline_styles' );