<?php
/**
 * Get author profile
 */
function dp_get_author_info( $args = array(
				'return_array' 	=> false,
				'user_id' 		=> null,
				'is_microdata' 	=> true,
				'avatar_size' 	=> 300 ) ) {

	global $post, $options, $IS_MOBILE_DP;

	extract( $args );

	// User ID
	$user_id 		= empty( $user_id ) ? get_the_author_meta('ID') : $user_id;
	if (empty( $user_id )) return;

	// Custom user data
	$user_data = get_userdata( $user_id );

	$prof_code = $author_roles = $author_sns_code = $authors_list_ref_url = $mi_name = $mi_photo = $mi_aff = $mi_role = $mi_url = $mi_scope = '';
	$open_new_tab_ref_url = false;

	// Microdata
	if ( $is_microdata ) {
		$mi_name 	= ' itemprop="name"';
		$mi_photo 	= ' itemprop="photo"';
		$mi_aff		= ' itemprop="affiliation"';
		$mi_role 	= ' itemprop="role"';
		$mi_url 	= ' itemprop="url"';
		$mi_scope 	= ' itemscope itemtype="http://data-vocabulary.org/Person"';
	}

	// avatar image
	$avatar_img = get_avatar( $user_id, $avatar_size, '', 'avatar', array( 'extra_attr' => $mi_photo ) );

	// Profile data
	$author_name 	= '<span' . $mi_name . ' class="author_name">' . get_the_author_meta( 'display_name', $user_id ) . '</span>';
	$profile_img 	= '<a href="'.get_author_posts_url( $user_id ) . '" rel="author" class="author_img">' . $avatar_img . '</a>';

	$author_org 	= get_the_author_meta( 'org', $user_id );
	$author_org 	= empty( $author_org) ? '' : '<span' . $mi_aff . ' class="author_org">' . $author_org . '</span>';

	$author_role 	= get_the_author_meta('title', $user_id );
	$author_role 	= empty( $author_role ) ? '' : '<span' . $mi_role . ' class="author_role">' . $author_role . '</span>';

	$author_roles 	= '<div class="author_roles">' . $author_org . $author_role . $author_name . '</div>';

	$author_site_name = get_the_author_meta( 'site_name', $user_id );
	$author_url 	= get_the_author_meta('user_url', $user_id );
	$author_site_name = empty( $author_site_name ) ? $author_url : $author_site_name;
	$author_url 	= empty( $author_url ) ? '' : '<span class="author_url icon-bookmark"><a href="' . $author_url . '"' . $mi_url . ' target="_blank">' . $author_site_name . '</a></span>';

	$author_desc 	= get_the_author_meta( 'description', $user_id );
	$author_desc 	= empty( $author_desc ) ? '' : '<div class="author_desc">' . str_replace( array("\r\n","\r","\n","\t","/^\s(?=\s)/" ), '<br />', $author_desc) . '</div>';

	$author_bg_img 	= get_the_author_meta( 'bg_img', $user_id );
	$author_bg_img 	= empty( $author_bg_img ) ? '' : ' style="background:url(' . $author_bg_img . ') center center;background-size:cover;"';

	$facebook_url 	= get_the_author_meta('facebook', $user_id );
	$facebook_url 	= empty( $facebook_url ) ? '' : '<a href="' . $facebook_url . '" target="_blank"><span class="icon-facebook"></span></a>';
	$twitter_url 	= get_the_author_meta('twitter', $user_id );
	$twitter_url 	= empty( $twitter_url ) ? '' : '<a href="' . $twitter_url . '" target="_blank"><span class="icon-twitter"></span></a>';
	$youtube_url 	= get_the_author_meta('youtube', $user_id );
	$youtube_url 	= empty( $youtube_url ) ? '' : '<a href="' . $youtube_url . '" target="_blank"><span class="icon-youtube"></span></a>';
	$flickr_url 	= get_the_author_meta('flickr', $user_id );
	$flickr_url 	= empty( $flickr_url ) ? '' : '<a href="' . $flickr_url . '" target="_blank"><span class="icon-flickr"></span></a>';
	$instagram_url 	= get_the_author_meta('instagram', $user_id );
	$instagram_url 	= empty( $instagram_url ) ? '' : '<a href="' . $instagram_url . '" target="_blank"><span class="icon-instagram"></span></a>';
	$pinterest_url 	= get_the_author_meta('pinterest', $user_id );
	$pinterest_url 	= empty( $pinterest_url ) ? '' : '<a href="' . $pinterest_url . '" target="_blank"><span class="icon-pinterest"></span></a>';

	if (!empty( $facebook_url ) || !empty( $twitter_url ) || !empty( $youtube_url ) || !empty( $flickr_url ) || !empty( $instagram_url ) || !empty( $pinterest_url )) {
		$author_sns_code = '<div class="author_sns"><span class="sns_follow">Follow :</span>' . $facebook_url . $twitter_url . $youtube_url . $flickr_url . $instagram_url . $pinterest_url . '</div>';
	}

	// Reference URL for authos list page
	if ( isset( $user_data->ref_url ) && !empty( $user_data->ref_url ) ) {
		$authors_list_ref_url = $user_data->ref_url;
	}
	// Open reference URL in new tab
	if ( isset( $user_data->open_new_tab_ref_url ) && !empty( $user_data->open_new_tab_ref_url ) ) {
		$open_new_tab_ref_url = true;
	}


	// Return value
	if ((bool)$return_array) {
		$prof_code = array(
			'author_name' 			=> $author_name,
			'author_org' 			=> $author_org,
			'author_role'			=> $author_role,
			'author_roles'			=> $author_roles,
			'author_posts_url' 		=> get_author_posts_url( $user_id ),
			'author_url'			=> $author_url,
			'author_desc'			=> $author_desc,
			'author_bg_img'			=> $author_bg_img,
			'author_sns_code'		=> $author_sns_code,
			'profile_img'			=> $profile_img,
			'avatar_img' 			=> $avatar_img,
			'authors_list_ref_url'	=> $authors_list_ref_url,
			'open_new_tab_ref_url'	=> $open_new_tab_ref_url
			);
	} else {
		$prof_code = '<section' . $mi_scope . ' class="archive-title-sec author"' . $author_bg_img . '>' . $profile_img . '<div class="author_meta">' . $author_roles . $author_desc . $author_url . $author_sns_code . '</div></section>';
	}
	return $prof_code;
}


/**
 * Get author's posts
 */
function dp_get_author_posts( $post_num = 4, $width = 250, $height = 154 ) {
	global $post, $options, $COLUMN_NUM, $IS_MOBILE_DP;
	if (post_password_required()) return;

	$thumb_code = '';
	$col_css  = '';
	$cats 		= '';
	$cats_code 	= '';
	$more_code 	= '';
	$date_code = '';
	$wow_title_css = $wow_posts_css = '';
	$direction = ' horizontal';
	$articles_code = '';
	$item_link_class = 'item-link';
	$thumb_link_class = 'thumb-link';

	$mb_suffix	= '';
	if ((bool)$IS_MOBILE_DP) {
		$mb_suffix = '_mobile';
	}
	// wow.js
	if (!(bool)$options['disable_wow_js' . $mb_suffix] ){
		$wow_title_css 	= ' wow fadeInDown';
		$wow_posts_css	= ' wow fadeInUp';
	}
	// Title
	$recent_title = $options['author_recent_articles_title'];
	if (!empty( $recent_title)) {
		$recent_title = '<h3 class="inside-title' . $wow_title_css . '"><span>' . $recent_title . '</span></h3>';
	}
	// Author ID
	$user_id = get_the_author_meta('ID');

	// Mobile or not
	if ( $IS_MOBILE_DP) {
		$post_num = 4;
		$direction .= ' mb';
	} else {
		$col_css = ' two-col';
		if ( $COLUMN_NUM === 1 || get_post_meta( get_the_ID(), 'disable_sidebar', true ) ) {
			$col_css	= ' one-col';
			$post_num 	= 5;
			// Narrow content width
			if ( (bool)get_post_meta( get_the_ID(), 'one_col_narrow', true ) ) {
				$col_css .= ' narrow';
				$post_num = 4;
			}
		}
	}

	// Thumb check
	$if_img_tag = false;
	$arg_thumb = array(
			"width" => $width,
			"height" => $height,
			"size" => "dp-related-thumb",
			"if_img_tag" => $if_img_tag
		);

	// Params
	$args = array(
				'author'		=> get_the_author_meta('ID'),
				'numberposts'	=> $post_num,
				'exclude'		=> $post->ID
				);

	// Get posts
	$articles =  get_posts( $args);

	// Display
	if ( $articles) {
		// Prefix
		$articles_code = '<div class="dp_related_posts clearfix' . $direction . $col_css . '">' . $recent_title . '<ul>';
		// Loop
		foreach ( $articles as $post ) : setup_postdata( $post );
			// Title
			$title = the_title( '', '', false );
			if (mb_strlen( $title, 'utf-8') > 52) $title = mb_substr( $title, 0, 51, 'utf-8' ) . '...';
			// Anchor
			$anchor_code = 'href="' . get_the_permalink() . '"';
			// Post options
			$dp_hide_date 	= get_post_meta( get_the_ID(), 'dp_hide_date', true );
			// Get eyecatch
			$thumb_code = DP_Post_Thumbnail::get_post_thumbnail( $arg_thumb );
			// *************
			// HTML
			// *************
			$articles_code .= '<li class="clearfix' . $wow_posts_css . '"><a ' . $anchor_code . ' class="' . $item_link_class . '">';
			// Thumbnail
			$thumb_code = DP_Post_Thumbnail::get_post_thumbnail( $arg_thumb );
			$thumb_code = '<div class="widget-post-thumb"><figure class="post-thumb"><img src="' . $thumb_code . '" alt="Thumbnail" width="120" height="80" class="thumb-img" /></figure></div>';

			// Date
			$articles_code .= $thumb_code . '<div class="excerpt_div has_thumb">';
			if ( !(bool)$dp_hide_date ) {
				if (isset( $options['date_eng_mode']) && (bool)$options['date_eng_mode']) {
					$articles_code .= '<div class="meta-date eng"><time datetime="' . get_the_date('c') . '"><span class="date_month_en_full">' . get_post_time('F') . '</span> <span class="date_day">' . get_post_time('j') . '</span>, <span class="date_year">' . get_post_time('Y') . '</span></time></div>';
				} else {
					$articles_code .= '<div class="meta-date"><time datetime="' . get_the_date('c') . '">' . get_the_date() . '</time></div>';
				}
			}
			// Category
			$cats = get_the_category();
			if ( $cats ) {
				$cats = $cats[0];
				$cat_color_class = " term-color" . $cats->cat_ID;
				// $cats_code = '<a href="' . get_category_link( $cats->cat_ID) . '" rel="tag" class="cat-link' . $cat_color_class . '"><span class="cat-name">' . $cats->cat_name . '</span></a>';
				$cats_code = '<span class="cat-link' . $cat_color_class . '"><span class="cat-name">' . $cats->cat_name . '</span></span>';
			}
			$articles_code .= '<div class="meta-cat">' . $cats_code . '</div>';
			// Title
			$articles_code .= '<h4 class="excerpt_title_wid">' . $title . '</h4></div>';
			// Close list
			$articles_code .= '</a></li>';

		endforeach; 
		wp_reset_postdata();

		// More link
		$more_code = '<div class="more-entry-link"><a href="' . get_author_posts_url( $user_id ) . '" rel="author"><span>' . get_the_author_meta( 'display_name' ) . __( '\'s articles', 'DigiPress' ) . '</span></a></div>';

		// Suffix
		$articles_code .= '</ul>' . $more_code.'</div>';
	}

	return $articles_code;
}