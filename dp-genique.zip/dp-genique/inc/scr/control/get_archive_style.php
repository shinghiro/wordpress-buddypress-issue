<?php
function dp_get_archive_style(){

	if ( is_admin() ) return;
	if ( is_singular() ) return;

	global $options, $ARCHIVE_STYLE;

	// Archive flag
	$top_or_archive 	= is_home() ? 'top' : 'archive';
	// Params to return
	$layout = $options[$top_or_archive . '_post_show_type'];

	$term_meta = $term_id = $sub_title = $video_id = $image = $image_width = $image_height = $color = $sub_terms_no_image = $sub_terms_hover_fx = '';
	$children = $sub_terms_layout = $sub_terms_crop_circle_image = false;

	// Archive type
	$archive_type = get_post_type_object(get_post_type());
	$archive_type = !is_null($archive_type) ? esc_html($archive_type->name) : '';
	if ($archive_type === 'news' || $archive_type == $options['news_cpt_slug_id'] ) {
		$archive_type = 'news';
		$layout = $archive_type;
	}


	// Get queried object array
	$term = get_queried_object();


	// Get the current term ID
	if ( isset($term->term_id) && !empty($term->term_id) ) {
		$term_id = $term->term_id;
	}


	// Check the category display style
	if ( is_search() ) {
		$layout = 'simple';
	}
	else if ( is_category() || is_tag() ) {

		// Get custom archive fields
		$term_meta = get_option('ex_term_meta_' . $term_id);

		if ( !empty($term_meta) ) {
			// Layout
			if ( isset($term_meta['layout']) && !empty($term_meta['layout']) ) {
				$layout = $term_meta['layout'];
			}

			// Get the featured image
			if ( isset($term_meta['img']) && !empty($term_meta['img']) ) {
				$image = esc_attr( $term_meta['img'] );
				$img_sizes = dp_get_image_size( $image, true );
				if ( is_array( $img_sizes ) ) {
					$image_width = $img_sizes[0];
					$image_height = $img_sizes[1];
				}
			}

			// Video ID
			if ( isset($term_meta['video_id']) && !empty($term_meta['video_id']) ) {
				$video_id = $term_meta['video_id'];
			}

			// Color
			if ( isset($term_meta['color']) && !empty($term_meta['color']) ) {
				$color = $term_meta['color'];
			}

			// Sub title
			if ( isset($term_meta['sub_title']) && !empty($term_meta['sub_title']) ) {
				$sub_title = $term_meta['sub_title'];
			}

			// Get the children object (if current term option is selected)
			if ( isset($term_meta['show_only_sub_terms']) && !empty($term_meta['show_only_sub_terms']) ) {

				$sub_terms_layout = isset($term_meta['sub_terms_layout']) && !empty($term_meta['sub_terms_layout']) ? $term_meta['sub_terms_layout'] : 'thumb big';
				$sub_terms_no_image = isset($term_meta['sub_terms_no_image']) && !empty($term_meta['sub_terms_no_image']) ? $term_meta['sub_terms_no_image'] : '';
				$sub_terms_hover_fx = isset($term_meta['sub_terms_hover_fx']) && !empty($term_meta['sub_terms_hover_fx']) ? $term_meta['sub_terms_hover_fx'] : '';
				$sub_terms_crop_circle_image = isset($term_meta['sub_terms_crop_circle_image']) && !empty($term_meta['sub_terms_crop_circle_image']) ? true : false;

				$empty_flag = isset($term_meta['sub_terms_exclude_empty']) && !empty($term_meta['sub_terms_exclude_empty']) ? true : false;

				$children = get_terms( $term->taxonomy, array(
					'parent'    => $term_id,
					'hide_empty' => $empty_flag
				) );

				if ( !$children ) $children = false;
			}
		}
	}

	$ARCHIVE_STYLE = array(
		'term_id'			=> $term_id,
		'top_or_archive' 	=> $top_or_archive,
		'archive_type'		=> $archive_type,
		'layout'			=> $layout,
		'color' 			=> $color,
		'sub_title' 		=> $sub_title,
		'image'				=> $image,
		'image_width'		=> $image_width,
		'image_height'		=> $image_height,
		'video_id'			=> $video_id,
		'children'			=> $children,
		'sub_terms_layout'	=> $sub_terms_layout,
		'sub_terms_no_image'=> $sub_terms_no_image,
		'sub_terms_hover_fx'=> $sub_terms_hover_fx,
		'sub_terms_crop_circle_image'=> $sub_terms_crop_circle_image,
	);
}