<?php
/**
 * Get the image width and height
 * @param $iamge_url : image URL
 * @return array(width, height) or false
 */
function dp_get_image_size( $image_url = null, $is_local = true ){
	if ( empty($image_url) ) return;

	if ( preg_match("/^\/\//", $image_url) ){
		$image_url = is_ssl() ? 'https:'.$image_url : 'http:'.$image_url;
	}


	/**
	 * Check the transient data and return the cache if cache is exists
	 */
	$hash = md5( $image_url );	// 32 strings
	if ( dp_is_enable_cache( array( 'target' => 'thumbnail_size' ) ) ){
		$cache = get_transient( 'dp_img_size_' . $hash );
		if ( $cache !== false ) {
			return $cache;
		}
	}


	$image_data = null;

	// Local path or URL
	if ( $is_local ) {
		// WP content dir local path
		$wp_content_dir = WP_CONTENT_DIR;
		// WP content dir URL
		$wp_content_url = content_url();

		// Replace to the local path
		$image_url_rep = str_replace( $wp_content_url, $wp_content_dir, $image_url );

		if ( $image_url_rep !== $image_url ) {
			// Get the dimensions
			$image_data = getimagesize( $image_url_rep );
			if ( isset( $image_data ) && is_array( $image_data ) ) {
				// ( width, height )
				$image_data = array( $image_data[0], $image_data[1] );
			}
		}
	}


	// When the image path is URL
	if ( $image_data === null ) {

		$image_data = wp_remote_get( $image_url );

		if ( !is_wp_error( $image_data ) && $image_data['response']['code'] === 200 ) {
			if ( function_exists('getimagesizefromstring') ) {
				$image_data = getimagesizefromstring($image_data['body']);
				if ( isset( $image_data ) && is_array( $image_data ) ) {
					// ( width, height )
					$image_data = array( $image_data[0], $image_data[1] );
				}
			} else {
				$image_data = imagecreatefromstring( $image_data['body'] );
				// ( width, height )
				$image_data = array( imagesx($image_data), imagesy($image_data) );
			}
		}
	}


	if ( $image_data !== null &&  is_array($image_data) ) {

		/**
		 * Save to cache
		 */
		if ( dp_is_enable_cache( array( 'target' => 'thumbnail_size' ) ) ){
			set_transient( 'dp_img_size_' . $hash, $image_data, 0 );
		}

		return $image_data;
	}


	return false;
}