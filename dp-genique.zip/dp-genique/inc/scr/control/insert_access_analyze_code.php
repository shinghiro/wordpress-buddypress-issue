<?php
/**
* Insert Javascript to the end of html
*/
function dp_inline_footer() {
	global $options;
	$trace_code = '';

	// Access Code
	if ( !empty($options['tracking_code']) ) {
		$trace_code = "<!-- Tracking Code -->" . $options['tracking_code'] ."<!-- /Tracking Code -->";
	}

	//Run only user logged in...
	if ( is_user_logged_in() ) {
		if (current_user_can('edit_others_posts') && $options['no_track_admin']) {
			$trace_code = "<!-- You are logged in as Administrator -->";
		}
	}
	$trace_code = str_replace(array("\r\n","\r","\n","\t"), '', $trace_code);
	echo $trace_code;
}
add_action('wp_footer', 'dp_inline_footer', 100);