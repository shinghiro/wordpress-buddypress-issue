<?php
function dp_get_elements_visibility(){

	if (is_admin()) return;

	global $options, $CURRENT_POST_TYPE, $ELEMENTS_SHOW;

	// set the def_params
	$ELEMENTS_SHOW = array(
		'breadcrumb' => true,
		'single_post_title' => true,
		'eyecatch_entry_top' => false,
		'eyecatch_header' => false,
		'header_bar_transparent' => false,
	);

	/**
	 * Transparent header bar
	 */
	if ( isset($options['header_bar_transparent']) && !empty($options['header_bar_transparent'])){

		$ELEMENTS_SHOW['header_bar_transparent'] = true;

		if ( is_front_page() ) {
			// Transparent mode is disabled in carousel, center mode, coverflow and cube slider.
			if ( ( $options['dp_header_content_type'] === 'slideshow' ||
					$options['dp_header_content_type'] === 'slideshow_selected_media' )
				&&
				( strpos($options['dp_slider_style'],'carousel') !== false ||
				  strpos($options['dp_slider_style'],'center') !== false ||
				  strpos($options['dp_slider_style'],'coverflow') !== false ) ) {

				$ELEMENTS_SHOW['header_bar_transparent'] = false;
			}

			if ( is_paged() || $options['dp_header_content_type'] === 'none' ){
				$ELEMENTS_SHOW['header_bar_transparent'] = false;
			}
		}
	}

	// Breadcrumb (common)
	if ( isset($options['hide_breadcrumb']) && !empty($options['hide_breadcrumb']) ){
		$ELEMENTS_SHOW['breadcrumb'] = false;
	} else {
		$ELEMENTS_SHOW['breadcrumb'] = true;
	}

	// Only single page
	if ( is_singular() ){

		$this_id = get_the_ID();

		// Breadcrumb
		if ( $ELEMENTS_SHOW['breadcrumb'] ){
			if ( !empty(get_post_meta($this_id, 'dp_disable_breadcrumb', true)) ){
				$ELEMENTS_SHOW['breadcrumb'] = false;
			}
		}

		if ( is_single() || is_page() || $CURRENT_POST_TYPE === $options['news_cpt_slug_id'] ) {
			// No title check
			if ( !empty(get_post_meta($this_id, 'dp_hide_title', true)) ){
				$ELEMENTS_SHOW['single_post_title'] = false;
			} else {
				$ELEMENTS_SHOW['single_post_title'] = true;
			}

			// Eyecatch first
			if ( (isset($options['show_eyecatch_first']) && !empty($options['show_eyecatch_first'])) || !empty(get_post_meta($this_id, 'dp_show_eyecatch_force', true)) ) {
				$ELEMENTS_SHOW['eyecatch_entry_top'] = true;
			} else {
				$ELEMENTS_SHOW['eyecatch_entry_top'] = false;
			}

			// Eyecatch on header
			if ( !empty(get_post_meta($this_id, 'dp_eyecatch_on_container', true)) ) {
				$ELEMENTS_SHOW['eyecatch_header'] = true;
			} else {
				$ELEMENTS_SHOW['eyecatch_header'] = false;
			}
		}
	}

	return $ELEMENTS_SHOW;
}