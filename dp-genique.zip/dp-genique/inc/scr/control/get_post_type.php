<?php
function dp_get_post_type(){
	if (is_admin()) return;
	global $options, $CURRENT_POST_TYPE;

	if ( is_singular() ){

		$CURRENT_POST_TYPE = get_post_type();

	} else if ( is_archive() || is_search() ) {

		if ( is_tax() ){
			$taxonomy = get_query_var( 'taxonomy' );
			$CURRENT_POST_TYPE = get_taxonomy( $taxonomy )->object_type[0];

		} else {
			// $CURRENT_POST_TYPE = get_query_var( 'post_type' );
			$CURRENT_POST_TYPE = get_post_type();
		}

	} else {
		$CURRENT_POST_TYPE = '';
	}

	return $CURRENT_POST_TYPE;
}