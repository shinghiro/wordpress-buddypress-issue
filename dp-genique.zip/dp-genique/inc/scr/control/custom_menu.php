<?php
/**
 * Extend Custom Menu.
 */
class dp_custom_menu_walker extends Walker_Nav_Menu {
	public function start_el(&$output, $item, $depth = 0, $args = array(), $id = 0) {
		global $wp_query, $options, $IS_MOBILE_DP;

		$class_names = $has_cap_class = $second_label = '';

		// $indent = ( $depth ) ? str_repeat( "\t", $depth ) : '';
		$classes = empty( $item->classes ) ? array() : (array) $item->classes;

		// Get custom fields
		$icon = get_post_meta( $item->ID, '_custom_menu_item_icon', true );
		$icon_position = get_post_meta( $item->ID, '_custom_menu_item_icon_position', true );

		if ( isset( $icon ) && ! empty( $icon ) ) {
			$icon = '<i class="' . $icon . '"></i>';
		} else {
			$icon = '';
		}

		if ( ! isset( $icon_position ) ) {
			$icon_position = 'left';
		}

		// Second label
		if ( !$IS_MOBILE_DP ) {
			$second_label = get_post_meta( $item->ID, '_custom_menu_item_second_label', true );
			if (  isset( $second_label ) && !empty( $second_label ) ) {
				$second_label = '<span class="menu-caption">' . $second_label . '</span>';
				$has_cap_class = ' has_cap';
			}
		}


		$class_names = join( ' ', apply_filters( 'nav_menu_css_class', array_filter( $classes ), $item ) );
		$class_names .= isset($args->item_class) && !empty($args->item_class) ? ' '.$args->item_class : '';
		if ( !$options['disable_pjax'] ) $class_names = str_replace( array(' current-menu-item', ' current-menu-parent'), '', $class_names );
		$class_names = ' class="'. esc_attr( $class_names ) . '"';
		$anchor_class = isset($args->anchor_class) && !empty($args->anchor_class) ? ' '.esc_attr($args->anchor_class) : '';

		$output .= '<li id="menu-item-'. $item->ID . '"' . $class_names . '>';

		$attributes = ! empty( $item->attr_title )	? ' title="'  . esc_attr( $item->attr_title ) . '"' : '';
		$attributes .= ! empty( $item->target )		? ' target="' . esc_attr( $item->target     ) . '"' : '';
		$attributes .= ! empty( $item->xfn )		? ' rel="'    . esc_attr( $item->xfn        ) . '"' : '';
		$attributes .= ! empty( $item->url )		? ' href="'   . esc_attr( $item->url        ) . '"' : '';

		$prepend	= '<span class="menu-title">';
		$append		= '</span>';

		// icon
		if ( !empty( $icon ) ) {
			if ( $icon_position == 'right' ) {
				$append = $icon . '</span>';
			} else {
				$prepend .= $icon;
			}
		}

		$append .= $second_label;


		// Only parent menu
		$before_only_parent = $after_only_parent = $before_only_parent_link = $after_only_parent_link = '';
		if ( $depth === 0 && !empty($args->before_only_parent) ) {
			$before_only_parent = $args->before_only_parent;
		}
		if ( $depth === 0 && !empty($args->after_only_parent) ) {
			$after_only_parent = $args->after_only_parent;
		}
		if ( $depth === 0 && !empty($args->before_only_parent_link) ) {
			$before_only_parent_link = $args->before_only_parent_link;
		}
		if ( $depth === 0 && !empty($args->after_only_parent_link) ) {
			$after_only_parent_link = $args->after_only_parent_link;
		}

		$item_output = $before_only_parent . $args->before;
		$item_output .= '<a' . $attributes . ' class="menu-link' . $has_cap_class . $anchor_class . '">' . $before_only_parent_link;
		$item_output .= $args->link_before . $prepend . apply_filters( 'the_title', $item->title, $item->ID ) . $append . $args->link_after;
		$item_output .= $after_only_parent_link . '</a>';
		$item_output .= $args->after . $after_only_parent;

		$output .= apply_filters( 'walker_nav_menu_start_el', $item_output, $item, $depth, $args );
	}
}


/**
 * Custom Mega Menu.
 */
class dp_custom_mega_menu_walker extends Walker_Nav_Menu {

	// private $has_sub_menu;
	static $is_mega_menu = false;
	static $sub_menu_items = array();


	public function start_lvl( &$output, $depth = 0, $args = null ) {

		// Default class.
		$classes = array( 'sub-menu' );

		$class_names = implode( ' ', apply_filters( 'nav_menu_submenu_css_class', $classes, $args, $depth ) );
		$class_names = $class_names ? ' class="' . esc_attr( $class_names ) . '"' : '';

		$output .= '<div class="sub-menu__wrapper';
		$output .= !empty( self::$sub_menu_items ) && is_array( self::$sub_menu_items ) ? ' menu-num__' . count( self::$sub_menu_items ) : '';
		$output .= self::$is_mega_menu ? ' is-mega-menu' . '">' : '">';
		$output .= "<ul$class_names>";

		// initialize
		self::$is_mega_menu = $depth == 0 && false;
		self::$sub_menu_items = array();
	}


	public function end_lvl( &$output, $depth = 0, $args = null ) {

		$output .= '</ul></div>';
	}


	public function start_el(&$output, $item, $depth = 0, $args = array(), $id = 0) {

		global $wp_query, $options, $IS_MOBILE_DP;


		$class_names = $description = $second_label = $ft_image = $mega_menu_content = '';

		$prepend_title	= '<span class="menu-title">';
		$append_title	= '</span>';

		$anchor_class = isset( $args->anchor_class ) && !empty( $args->anchor_class ) ? 'menu-link ' . esc_attr( $args->anchor_class ) : 'menu-link';

		$sub_menu_wrapper_class = 'sub-menu__wrapper';

		$sub_has_children = false;


		// $indent = ( $depth ) ? str_repeat( "\t", $depth ) : '';
		$classes = empty( $item->classes ) ? array() : (array) $item->classes;



		// Is mega menu?
		if ( !$IS_MOBILE_DP ){

			if ( $depth == 0 ) {

				// Only parent menu
				self::$is_mega_menu = get_post_meta( $item->ID, '_custom_menu_item_mega_menu', true ) || false;

				// Second label
				$second_label = get_post_meta( $item->ID, '_custom_menu_item_second_label', true );
				if (  isset( $second_label ) && !empty( $second_label ) ) {
					$second_label = '<span class="menu-caption">' . $second_label . '</span>';
					$anchor_class .= ' has_cap';
				}
			}
			else if ( $depth == 1 ) {

				self::$is_mega_menu = get_post_meta( $item->menu_item_parent, '_custom_menu_item_mega_menu', true ) || false;

				if ( self::$is_mega_menu ){

					// Has no sub menus
					if ( ! in_array( 'menu-item-has-children', $item->classes ) ) {

						// Menu is category
						if ( $item->object === 'category' || $item->object === 'post_tag' ){

							$mega_menu_content = DP_LISTING_POST_EACH_STYLES(array(
									'echo' 		=> false,
									'title'		=> '',
									'number'	=> 6,
									'orderby'	=> isset($options['global_nemu_cat_posts_order']) && !empty($options['global_nemu_cat_posts_order']) ? $options['global_nemu_cat_posts_order'] : 'date',
									// 'meta_key' => 'post_views_count',
									'cat_id'	=> $item->object === 'category' ? $item->object_id : '',
									'tag_id'	=> $item->object === 'post_tag' ? $item->object_id : '',
									'pub_date'	=> isset($options['global_nemu_cat_posts_meta_date']) && !empty($options['global_nemu_cat_posts_meta_date']) ? $options['global_nemu_cat_posts_meta_date'] : false,
									'author'	=> isset($options['global_nemu_cat_posts_meta_author']) && !empty($options['global_nemu_cat_posts_meta_author']) ? $options['global_nemu_cat_posts_meta_author'] : false,
									'show_cat'	=> isset($options['global_nemu_cat_posts_meta_cat']) && !empty($options['global_nemu_cat_posts_meta_cat']) ? $options['global_nemu_cat_posts_meta_cat'] : false,
									'comment'	=> false,
									'hatebu_num'=> false,
									'tweets_num'=> false,
									'likes_num'	=> false,
									'excerpt_length' => 0,
									'type'		=> 'recent',
									'layout'	=> 'mega-menu'
								)
							);

							$sub_menu_wrapper_class .= ' is-articles';

						}
						else {

							$item_image = $item_title = $item_description = '';

							// Get the featured image
							$item_image = get_post_meta( $item->ID, '_custom_menu_item_image', true );

							// Menu is post or page
							if ( $item->object === 'post' || $item->object === 'page' ){

								if ( !isset( $item_image ) || empty( $item_image ) ) {
									// Eyecatch
									$item_image = DP_Post_Thumbnail::get_post_thumbnail(array(
											'width' => 1260,
											'height' => 1260,
											'size' => 'large',
											'if_img_tag' => false,
											'post_id' => $item->object_id
										)
									);
								}

								$item_title = get_the_title( $item->object_id );

							} else {

								$item_title = $item->title;
							}

							// Wrap the image
							if ( isset( $item_image ) && !empty( $item_image ) ) {
								$item_image = '<figure class="ft-img-wrapper"><img src="' . $item_image . '" class="figure-img" role="presentation" /></figure>';
							} else {
								$item_image = '';
							}

							// Second label
							$item_label = get_post_meta( $item->ID, '_custom_menu_item_second_label', true );
							if (  isset( $item_label ) && !empty( $item_label ) ) {
								$item_label = '<div class="__caption">' . $item_label . '</div>';
							}

							// Menu description
							if ( !empty( $item->description ) ) {
								$item_description = '<div class="__desc" role="note">' . esc_attr( $item->description ) . '</div>';
							}

							$mega_menu_content = '<div class="mgm-content"><a href="' . $item->url . '" class="__link">' . $item_image . '<div class="__txt_area"><div class="__title" role="heading">' . $item_title . '</div>' . $item_label . $item_description . '</div></a></div>';
						}
					}

					// Wrap mega menu
					if ( !empty( $mega_menu_content ) ) {
						$mega_menu_content = '<div class="' . $sub_menu_wrapper_class . '">' . $mega_menu_content . '</div>';
					}


					// For counting child menu items
					self::$sub_menu_items = get_posts( array(
						'post_type' => 'nav_menu_item',
						'numberposts' => -1,
						// 'orderby' => 'menu_order',
						// 'order' => 'ASC',
						'meta_query' => array( array(
							'key' => '_menu_item_menu_item_parent',
							'value' => $item->ID ) )
					) );
				}
			}
			else if ( $depth == 2 ) {

				// Get the featured image
				$ft_image = get_post_meta( $item->ID, '_custom_menu_item_image', true );

				// has sub menu or not
				if ( ! in_array( 'menu-item-has-children', $item->classes ) ) {
					// Second label
					$second_label = get_post_meta( $item->ID, '_custom_menu_item_second_label', true );
					if (  isset( $second_label ) && !empty( $second_label ) ) {
						$second_label = '<span class="__caption">' . $second_label . '</span>';
						$anchor_class .= ' has_cap';
					}

					if ( isset( $ft_image ) && !empty( $ft_image ) ) {
						$prepend_title = '<figure class="ft-img-wrapper"><img src="' . $ft_image . '" class="figure-img" role="presentation" /></figure>' . $prepend_title;
						$anchor_class .= ' has_img';
					} else {
						// Menu description
						if ( !empty( $item->description ) ) {
							$description = '<div class="__desc" role="note">' . esc_attr( $item->description ) . '</div>';
						}
					}

					$ft_image = '';

				} else {

					if ( isset( $ft_image ) && !empty( $ft_image ) ) {
						$ft_image = '<figure class="ft-img-wrapper"><img src="' . $ft_image . '" class="figure-img" role="presentation" /></figure>';
					}

				}
			}
		}



		// Classes
		$class_names = join( ' ', apply_filters( 'nav_menu_css_class', array_filter( $classes ), $item ) );

		$class_names .= isset($args->item_class) && !empty($args->item_class) ? ' ' . $args->item_class : '';

		$class_names .= isset( self::$is_mega_menu ) && !empty( self::$is_mega_menu ) && $depth === 0 ? ' is-mega-menu' : '';

		if ( !$options['disable_pjax'] ) $class_names = str_replace( array(' current-menu-item', ' current-menu-parent'), '', $class_names );

		$class_names = ' class="'. esc_attr( $class_names ) . '"';



		/**
		 * Start menu list code
		 */
		$output .= '<li id="menu-item-'. $item->ID . '"' . $class_names . '>';
		$output .= $ft_image;

		$attributes = ! empty( $item->attr_title )	? ' title="'  . esc_attr( $item->attr_title ) . '"' : '';
		$attributes .= ! empty( $item->target )		? ' target="' . esc_attr( $item->target     ) . '"' : '';
		$attributes .= ! empty( $item->xfn )		? ' rel="'    . esc_attr( $item->xfn        ) . '"' : '';
		$attributes .= ! empty( $item->url )		? ' href="'   . esc_attr( $item->url        ) . '"' : '';


		/**
		 * Title icon
		 */
		$icon = get_post_meta( $item->ID, '_custom_menu_item_icon', true );
		$icon_position = get_post_meta( $item->ID, '_custom_menu_item_icon_position', true );

		if ( ! isset( $icon_position ) ) {
			$icon_position = 'left';
		}

		if ( isset( $icon ) && ! empty( $icon ) ) {

			$icon = '<i class="menu-icon ' . $icon . '"></i>';

			if ( $icon_position == 'right' ) {
				$append_title = $icon . '</span>';
			} else {
				$prepend_title .= $icon;
			}

		} else {
			$icon = '';
		}


		/**
		 * Only parent menu
		 */
		$before_only_parent = $after_only_parent = $before_only_parent_link = $after_only_parent_link = '';

		if ( $depth === 0 ){
			if ( !empty($args->before_only_parent) ) {
				$before_only_parent = $args->before_only_parent;
			}
			if ( !empty($args->after_only_parent) ) {
				$after_only_parent = $args->after_only_parent;
			}
			if ( !empty($args->before_only_parent_link) ) {
				$before_only_parent_link = $args->before_only_parent_link;
			}
			if ( !empty($args->after_only_parent_link) ) {
				$after_only_parent_link = $args->after_only_parent_link;
			}
		}

		$item_output = $before_only_parent . $args->before;
		$item_output .= '<a' . $attributes . ' class="' . $anchor_class . '">' . $before_only_parent_link;
		$item_output .= $args->link_before . $prepend_title . apply_filters( 'the_title', $item->title, $item->ID ) . $append_title . $args->link_after;
		$item_output .= $second_label;
		$item_output .= $description;
		$item_output .= $after_only_parent_link . '</a>';
		$item_output .= $args->after . $after_only_parent;
		$item_output .= $mega_menu_content;

		$output .= apply_filters( 'walker_nav_menu_start_el', $item_output, $item, $depth, $args );
	}
}


/**
 * Register custom menus.
 */
add_action( 'after_setup_theme', function(){
	register_nav_menus(
		array(
			'offcanvas_menu' => __('Offcanvas Menu','DigiPress'),
			'global_menu' => __('Gobal Menu','DigiPress'),
			'footer_menu' => __('Footer Menu','DigiPress'),
			'top_menu_mobile' => __('Global Menu (Mobile)','DigiPress'),
			'footer_menu_mobile' => __('Footer Menu (Mobile)','DigiPress')
		)
	);
} );