<?php
/**
 * Insert Ads in single post content
 */
define('DP_H_TAG_REG', '/<h[1-6].*?>/i');
function dp_get_h_tag_position_in_content( $the_content ){
	if ( preg_match( DP_H_TAG_REG, $the_content, $h_tags )) {
		return $h_tags[0];
	}
}
function dp_insert_widget_before_first_h_tag($the_content) {

	global $IS_MOBILE_DP;

	$middle_content = '';

	if ( is_singular() ){
		if ( !$IS_MOBILE_DP ) {
			ob_start();
			dynamic_sidebar('widget-post-middle');
			$middle_content = ob_get_contents();
			ob_end_clean();
		} else {
			ob_start();
			dynamic_sidebar('widget-post-middle-mb');
			$middle_content = ob_get_contents();
			ob_end_clean();
		}
	}
	$h_tag_position = dp_get_h_tag_position_in_content( $the_content );
	if ( $h_tag_position ) {
		$the_content = preg_replace(DP_H_TAG_REG, $middle_content . $h_tag_position, $the_content, 1);
	}
	return $the_content;
}
add_filter('the_content','dp_insert_widget_before_first_h_tag', 12);