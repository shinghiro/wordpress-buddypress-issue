<?php
/**
 * Delete current cache
 */

// Whether usable cache control
function dp_is_enable_cache( $args = '' ){
	$defaults = array(
		'target' => '',
	);
	$r = wp_parse_args( $args, $defaults );

	global $options;

	if ( isset($options['enable_transient_cache']) && !empty($options['enable_transient_cache']) && !is_customize_preview() ){

		switch ( $r['target'] ) {
			case 'banner_contents':	// Top page header banner
				if ( isset( $options['disable_cache__banner_contents'] ) && !empty( $options['disable_cache__banner_contents']) ) {
					return false;
				}

			case 'article_loop':
				if ( isset( $options['disable_cache__article_loop'] ) && !empty( $options['disable_cache__article_loop']) ) {
					return false;
				}

			case 'loop_post_meta':
				if ( isset( $options['disable_cache__loop_post_meta'] ) && !empty( $options['disable_cache__loop_post_meta']) ) {
					return false;
				}

			case 'single_post_meta':
				if ( isset( $options['disable_cache__single_post_meta'] ) && !empty( $options['disable_cache__single_post_meta']) ) {
					return false;
				}

			case 'related_posts':
				if ( isset( $options['disable_cache__related_posts'] ) && !empty( $options['disable_cache__related_posts']) ) {
					return false;
				}

			case 'post_thumbnail':
				if ( isset( $options['disable_cache__post_thumbnail'] ) && !empty( $options['disable_cache__post_thumbnail']) ) {
					return false;
				}

			case 'thumbnail_size':
				if ( isset( $options['disable_cache__thumbnail_size'] ) && !empty( $options['disable_cache__thumbnail_size']) ) {
					return false;
				}

			case 'json_ld':
				if ( isset( $options['disable_cache__json_ld'] ) && !empty( $options['disable_cache__json_ld']) ) {
					return false;
				}
		}

		return true;
	}

	return false;
}


// Delete single post meta cache
function dp_delete_transient_single_meta( $args = '' ) {
	$defaults = array(
		'post_id' => null,
		'is_all'  => false,
	);
	$r = wp_parse_args( $args, $defaults );

	global $wpdb;

	if ( $r['is_all'] ){
		$wpdb->query( "DELETE FROM `$wpdb->options` WHERE (`option_name` LIKE '%_transient_dp_single_meta_%') OR (`option_name` LIKE '%_transient_timeout_dp_single_meta_%')" );
		return;
	}

	if ( isset( $r['post_id'] ) && !empty( $r['post_id'] ) ){
		delete_transient( 'dp_single_meta_' . $r['post_id'] );
		delete_transient( 'dp_single_meta_amp_' . $r['post_id'] );
	}
}


// Delete single post meta cache
function dp_delete_transient_list_elements( $args = '' ) {
	$defaults = array(
		'post_id' => null,
		'is_all'  => false,
	);
	$r = wp_parse_args( $args, $defaults );

	global $wpdb;

	if ( $r['is_all'] ){
		$wpdb->query( "DELETE FROM `$wpdb->options` WHERE (`option_name` LIKE '%_transient_dp_list_elem_%') OR (`option_name` LIKE '%_transient_timeout_dp_list_elem_%')" );
		return;
	}

	if ( isset( $r['post_id'] ) && !empty( $r['post_id'] ) ){
		$wpdb->query( "DELETE FROM `$wpdb->options` WHERE (`option_name` LIKE '%_transient_dp_list_elem_" . $r['post_id'] . "%') OR (`option_name` LIKE '%_transient_timeout_dp_list_elem_" . $r['post_id'] . "%')" );
		$wpdb->query( "DELETE FROM `$wpdb->options` WHERE (`option_name` LIKE '%_transient_dp_list_elem_mb_" . $r['post_id'] . "%') OR (`option_name` LIKE '%_transient_timeout_dp_list_elem_mb_" . $r['post_id'] . "%')" );
		$wpdb->query( "DELETE FROM `$wpdb->options` WHERE (`option_name` LIKE '%_transient_dp_list_elem_amp_" . $r['post_id'] . "%') OR (`option_name` LIKE '%_transient_timeout_dp_list_elem_amp_" . $r['post_id'] . "%')" );
	}
}


// Delete eyecatch cache
function dp_delete_transient_eyecatch( $args = '' ) {
	$defaults = array(
		'post_id' => null,
		'is_all'  => false,
	);
	$r = wp_parse_args( $args, $defaults );

	global $wpdb;

	if ( $r['is_all'] ){
		$wpdb->query( "DELETE FROM `$wpdb->options` WHERE (`option_name` LIKE '%_transient_dp_eye_%') OR (`option_name` LIKE '%_transient_timeout_dp_eye_%')" );
		return;
	}

	if ( isset( $r['post_id'] ) && !empty( $r['post_id'] ) ){
		$wpdb->query( "DELETE FROM `$wpdb->options` WHERE (`option_name` LIKE '%_transient_dp_eye_" . $r['post_id'] . "%') OR (`option_name` LIKE '%_transient_timeout_dp_eye_" . $r['post_id'] . "%')" );
		$wpdb->query( "DELETE FROM `$wpdb->options` WHERE (`option_name` LIKE '%_transient_dp_eye_mb_" . $r['post_id'] . "%') OR (`option_name` LIKE '%_transient_timeout_dp_eye_mb_" . $r['post_id'] . "%')" );
		$wpdb->query( "DELETE FROM `$wpdb->options` WHERE (`option_name` LIKE '%_transient_dp_eye_amp_" . $r['post_id'] . "%') OR (`option_name` LIKE '%_transient_timeout_dp_eye_amp_" . $r['post_id'] . "%')" );
	}
}


// Delete article loop cache
function dp_delete_transient_article_loop( $args = '' ) {
	$defaults = array(
		'url' => '',
		'is_all'  => false,
	);
	$r = wp_parse_args( $args, $defaults );

	global $wpdb;

	if ( $r['is_all'] ){
		$wpdb->query( "DELETE FROM `$wpdb->options` WHERE (`option_name` LIKE '%_transient_dp_alp_%') OR (`option_name` LIKE '%_transient_timeout_dp_alp_%')" );
		return;
	}

	if ( isset( $r['url'] ) && !empty( $r['url'] ) ){
		$hash = md5( $r['url'] );

		delete_transient( 'dp_alp_' . $hash );
		delete_transient( 'dp_alp_mb_' . $hash );
		delete_transient( 'dp_alp_amp_' . $hash );
	}
}


// Delete related posts cache
function dp_delete_transient_related_posts( $args = '' ) {
	$defaults = array(
		'post_id' => null,
		'is_all'  => false,
	);
	$r = wp_parse_args( $args, $defaults );

	global $wpdb;

	if ( $r['is_all'] ){
		$wpdb->query( "DELETE FROM `$wpdb->options` WHERE (`option_name` LIKE '%_transient_dp_rel_posts_%') OR (`option_name` LIKE '%_transient_timeout_dp_rel_posts_%')" );
		return;
	}

	if ( isset( $r['post_id'] ) && !empty( $r['post_id'] ) ){
		delete_transient( 'dp_rel_posts_' . $r['post_id'] );
		delete_transient( 'dp_rel_posts_mb_' . $r['post_id'] );
		delete_transient( 'dp_rel_posts_amp_' . $r['post_id'] );
	}
}

// Delete image size cache
function dp_delete_transient_image_size( $args = '' ) {
	$defaults = array(
		'post_id' => null,
		'is_all'  => false,
	);
	$r = wp_parse_args( $args, $defaults );

	global $wpdb;

	if ( $r['is_all'] ){
		$wpdb->query( "DELETE FROM `$wpdb->options` WHERE (`option_name` LIKE '%_transient_dp_img_size_%') OR (`option_name` LIKE '%_transient_timeout_dp_img_size_%')" );
		return;
	}

	if ( isset( $r['post_id'] ) && !empty( $r['post_id'] ) ){
		$hash = md5( get_permalink( (int)$r['post_id'] ) );
		delete_transient( 'dp_img_size_' . $hash );
	}
}


// Delete json-ld cache
function dp_delete_transient_json_ld( $args = '' ) {
	$defaults = array(
		'url' => null,
		'post_id' => null,
		'is_all'  => false,
	);
	$r = wp_parse_args( $args, $defaults );

	global $wpdb;

	if ( $r['is_all'] ){
		$wpdb->query( "DELETE FROM `$wpdb->options` WHERE (`option_name` LIKE '%_transient_dp_jsonld_%') OR (`option_name` LIKE '%_transient_timeout_dp_jsonld_%')" );
		return;
	}

	if ( isset( $r['post_id'] ) && !empty( $r['post_id'] ) ){
		delete_transient( 'dp_jsonld_' . $r['post_id'] );
	}

	if ( isset( $r['url'] ) && !empty( $r['url'] ) ){
		$hash = md5( $r['url'] );

		delete_transient( 'dp_jsonld_' . $hash );
	}
}


// Delete related posts cache
function dp_delete_transient_widget( $args = '' ) {
	$defaults = array(
		'post_id' => null,
		'widget_id' => '',
		'is_all'  => false,
	);
	$r = wp_parse_args( $args, $defaults );

	global $wpdb;

	if ( $r['is_all'] ){
		$wpdb->query( "DELETE FROM `$wpdb->options` WHERE (`option_name` LIKE '%_transient_dp_wdt_%') OR (`option_name` LIKE '%_transient_timeout_dp_wdt_%')" );
		return;
	}

	if ( isset( $r['post_id'] ) && !empty( $r['post_id'] ) ){
		$wpdb->query( "DELETE FROM `$wpdb->options` WHERE (`option_name` LIKE '%_transient_dp_wdt_dp_recentposts%') OR (`option_name` LIKE '%_transient_timeout_dp_wdt_dp_recentposts%')" );
		$wpdb->query( "DELETE FROM `$wpdb->options` WHERE (`option_name` LIKE '%_transient_dp_wdt_dptabwidget%') OR (`option_name` LIKE '%_transient_timeout_dp_wdt_dptabwidget%')" );
		$wpdb->query( "DELETE FROM `$wpdb->options` WHERE (`option_name` LIKE '%_transient_dp_wdt_dprecentcustompostswidget%') OR (`option_name` LIKE '%_transient_timeout_dp_wdt_dprecentcustompostswidget%')" );
		$wpdb->query( "DELETE FROM `$wpdb->options` WHERE (`option_name` LIKE '%_transient_dp_wdt_dpmostviewedpostswidget%') OR (`option_name` LIKE '%_transient_timeout_dp_wdt_dpmostviewedpostswidget%')" );
		$wpdb->query( "DELETE FROM `$wpdb->options` WHERE (`option_name` LIKE '%_transient_dp_wdt_dprecentpostswidget%') OR (`option_name` LIKE '%_transient_timeout_dp_wdt_dprecentpostswidget%')" );
		$wpdb->query( "DELETE FROM `$wpdb->options` WHERE (`option_name` LIKE '%_transient_dp_wdt_dpmostcommentedpostswidget%') OR (`option_name` LIKE '%_transient_timeout_dp_wdt_dpmostcommentedpostswidget%')" );
	}

	if ( isset( $r['widget_id'] ) && !empty( $r['widget_id'] ) ){
		delete_transient( 'dp_wdt_' . $r['widget_id'] );
		delete_transient( 'dp_wdt_mb_' . $r['widget_id'] );
		delete_transient( 'dp_wdt_amp_' . $r['widget_id'] );
	}
}


// Delete header banner cache
function dp_delete_transient_banner_contents( $args = '' ) {
	$defaults = array(
		'widget_id' => '',
		'is_all'  => false,
	);
	$r = wp_parse_args( $args, $defaults );

	global $wpdb, $options;

	if ( $r['is_all'] ){
		$wpdb->query( "DELETE FROM `$wpdb->options` WHERE (`option_name` LIKE '%_transient_dp_banner_contents%') OR (`option_name` LIKE '%_transient_timeout_dp_banner_contents%')" );
		return;
	}

	if ( !empty( $r['widget_id'] ) ) {
		delete_transient( 'dp_banner_contents' );
		delete_transient( 'dp_banner_contents_mb' );
		return;
	}

	// PC
	if ( $options['dp_header_content_type'] === 'slideshow' ) {
		delete_transient( 'dp_banner_contents' );
	}

	// Mobile
	if ( $options['dp_header_content_type_mobile'] === 'slideshow' ) {
		delete_transient( 'dp_banner_contents_mb' );
		delete_transient( 'dp_banner_contents_amp' );
	}
}



/**
 * Delegate for delete all cache
 */
function dp_Delete_All_Cache() {
	dp_delete_transient_article_loop( array('is_all' => true) );
	dp_delete_transient_json_ld( array( 'is_all' => true ) );
	dp_delete_transient_single_meta( array('is_all' => true) );
	dp_delete_transient_list_elements( array('is_all' => true) );
	dp_delete_transient_eyecatch( array( 'is_all' => true ) );
	dp_delete_transient_image_size( array( 'is_all' => true ) );
	dp_delete_transient_related_posts( array('is_all' => true) );
	dp_delete_transient_widget( array('is_all' => true) );
	dp_delete_transient_banner_contents( array('is_all' => true) );
}



/**
 * Fires once a post has been saved.
 */
add_action( 'save_post', function( $post_id, $post, $update ){
	dp_delete_transient_article_loop( array('is_all' => true) );
	dp_delete_transient_json_ld( array( 'post_id' => $post_id ) );
	dp_delete_transient_single_meta( array( 'post_id' => $post_id ) );
	dp_delete_transient_list_elements( array( 'post_id' => $post_id ) );
	dp_delete_transient_eyecatch( array( 'post_id' => $post_id ) );
	dp_delete_transient_image_size( array( 'post_id' => $post_id ) );
	dp_delete_transient_related_posts( array( 'is_all' => true ) );
	dp_delete_transient_widget( array('post_id' => $post_id) );
	dp_delete_transient_banner_contents();
}, 10, 3 );

/**
 * Fires once an existing post has been updated.
 */
add_action( 'post_updated', function( $post_id, $post_after, $post_before ){
	dp_delete_transient_article_loop( array('is_all' => true) );
	dp_delete_transient_json_ld( array( 'post_id' => $post_id ) );
	dp_delete_transient_single_meta( array( 'post_id' => $post_id ) );
	dp_delete_transient_list_elements( array( 'post_id' => $post_id ) );
	dp_delete_transient_eyecatch( array( 'post_id' => $post_id ) );
	dp_delete_transient_image_size( array( 'post_id' => $post_id ) );
	dp_delete_transient_related_posts( array( 'is_all' => true ) );
	dp_delete_transient_widget( array('post_id' => $post_id) );
	dp_delete_transient_banner_contents();
}, 10, 3 );

/**
 * Fires immediately after a post is deleted from the database.
 */
add_action( 'deleted_post', function( $post_id ){
	dp_delete_transient_article_loop( array('is_all' => true) );
	dp_delete_transient_json_ld( array( 'post_id' => $post_id ) );
	dp_delete_transient_single_meta( array( 'post_id' => $post_id ) );
	dp_delete_transient_list_elements( array( 'post_id' => $post_id ) );
	dp_delete_transient_eyecatch( array( 'post_id' => $post_id ) );
	dp_delete_transient_image_size( array( 'post_id' => $post_id ) );
	dp_delete_transient_related_posts( array( 'is_all' => true ) );
	dp_delete_transient_widget( array('post_id' => $post_id) );
	dp_delete_transient_banner_contents();
});

/**
 * Fires after a post is sent to the trash.
 */
add_action( 'trashed_post', function( $post_id ){
	dp_delete_transient_article_loop( array('is_all' => true) );
	dp_delete_transient_related_posts( array( 'is_all' => true ) );
	dp_delete_transient_widget( array('post_id' => $post_id) );
	dp_delete_transient_banner_contents();
});

/**
 * Fires after a post is restored from the trash.
 */
add_action( 'untrashed_post', function( $post_id ){
	dp_delete_transient_article_loop( array('is_all' => true) );
	dp_delete_transient_related_posts( array( 'is_all' => true ) );
	dp_delete_transient_widget( array('post_id' => $post_id) );
	dp_delete_transient_banner_contents();
});

/**
 * Fires immediately after a widget has been marked for deletion.
 */
add_action( 'delete_widget', function( $widget_id, $sidebar_id, $id_base ){
	dp_delete_transient_widget( array('widget_id' => $widget_id) );
	// Delete banner cache
	if ( $sidebar_id === 'widget-on-top-banner' ) {
		dp_delete_transient_banner_contents( array( 'widget_id' => $widget_id ) );
	}
}, 10, 3 );

/**
 * Fires after a post is restored from the trash.
 */
add_filter( 'widget_update_callback', function( $instance, $new_instance, $old_instance, $current ){

	// Delete current widget cache
	dp_delete_transient_widget( array('widget_id' => $current->id) );

	// It also deletes the banner cache if the current widget is in the banner area.
	$target_widgets = wp_get_sidebars_widgets();
	$target_widgets = $target_widgets['widget-on-top-banner'];

	foreach ($target_widgets as $key => $widget_id) {
		if ( $current->id === $widget_id ) {
			dp_delete_transient_banner_contents( array( 'widget_id' => $widget_id ) );
		}
	}

	return $instance;
}, 10, 4 );

/**
 * Fires immediately after a comment is inserted into the database.
 */
add_action( 'comment_post', function( $comment_id, $comment_approved, $commentdata ){
	$post_id = $commentdata['comment_post_ID'];

	dp_delete_transient_single_meta( array( 'post_id' => $post_id ) );
	dp_delete_transient_list_elements( array( 'post_id' => $post_id ) );
}, 10, 3 );

/**
 * Fires immediately after edited term (category, tag)
 */
add_action( 'edit_term', function( $term_id ){
	dp_delete_transient_article_loop( array('is_all' => true) );
});

/**
 * Fires after updated theme
 */
add_action( 'upgrader_process_complete', function( $upgrader_object, $options ) {
	$current_theme = get_template();
	if ( $options['action'] === 'update' && $options['type'] === 'theme' ){
		dp_Delete_All_Cache();
	}
}, 10, 2 );