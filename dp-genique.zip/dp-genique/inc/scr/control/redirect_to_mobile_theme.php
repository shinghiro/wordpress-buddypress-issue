<?php
/**
* Use mobile theme when user agent is mobile.
*/
function dp_mobile_template_include( $template ) {
	global $options, $IS_MOBILE_DP;
	if (isset($options['disable_mobile_theme']) && !empty($options['disable_mobile_theme'])) return $template;

	// Mobile theme directory name
	if ( $IS_MOBILE_DP ) {
		$template_file = basename($template);
		$template_mb = str_replace( $template_file, DP_MOBILE_THEME_DIR.'/'.$template_file, $template );
		// If exist the mobile template, replace them.
		if ( file_exists( $template_mb ) )
			$template = $template_mb;
	}
	return $template;
}
add_filter( 'template_include', 'dp_mobile_template_include' );