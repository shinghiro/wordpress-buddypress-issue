<?php
// Pocket subscribers
function dp_get_pocket_subscribers(){
	global $post, $options;

	if ( !isset($options['share_count_cache']) || (bool)$options['share_count_cache'] ){
		$key = 'count_pk_' . get_the_ID();
		$count = get_transient( $key );
		if ( $count !== false ) return $count;
	}

	$count = 0;
	$query = rawurlencode( get_permalink() );
	$query = 'https://widgets.getpocket.com/api/saves?url=' . $query;
	$args = array( 'sslverify' => true );

	$count = wp_remote_get( $query, $args );

	if ( !is_wp_error($count) ) {
		$body = isset($count["body"]) ? $count["body"] : null;
		if ( $body ) {
			$json = json_decode( $body );
			$count = isset( $json->{'saves'} ) ? $json->{'saves'} : 0;

			// Save to cache
			if ( !isset($options['share_count_cache']) || (bool)$options['share_count_cache'] ){
				// Cache time
				$cache_time = ( isset($options['share_count_cache_time']) ) ? (int)$options['share_count_cache_time'] / 1000 : 60 * 60 * 24;
				set_transient( $key, $count, $cache_time );
			}
		}
	}
	return intval($count);
}

// Feedly subscribers
function dp_get_feedly_subscribers(){
	global $options;

	if ( !isset($options['share_count_cache']) || (bool)$options['share_count_cache'] ){
		$count = get_transient('feedly_subscribers');
		if ($count !== false) return $count;
	}

	$feed_url = rawurlencode( get_bloginfo( 'rss2_url' ) );
	$count = wp_remote_get( "https://cloud.feedly.com/v3/feeds/feed%2F".$feed_url );

	if (!is_wp_error( $count ) && $count["response"]["code"] === 200) {
		$count = json_decode( $count['body'] );
		if ( $count ) {
			$count = $count->subscribers;

			// Save to cache
			if ( !isset($options['share_count_cache']) || (bool)$options['share_count_cache'] ){
				// Cache time
				$cache_time = isset($options['share_count_cache_time']) ? (int)$options['share_count_cache_time'] / 1000 : 60 * 60 * 24;
				set_transient( 'feedly_subscribers', $count, $cache_time );
				$count = ($count ? $count : '-');
			}
		}
	}
	return intval($count);
}