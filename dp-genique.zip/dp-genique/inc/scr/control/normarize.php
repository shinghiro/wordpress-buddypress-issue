<?php
/**
* Disable self pinback
*/
function dp_no_self_ping( &$links ) {
	$home = home_url();
	foreach ( $links as $l => $link )
	if ( 0 === strpos( $link, $home ) )
		unset($links[$l]);
}
add_action( 'pre_ping', 'dp_no_self_ping' );
/* Enable excerpt for single page */
add_post_type_support( 'page', 'excerpt' );


/**
* Disable meta canonical
*/
remove_action('wp_head', 'adjacent_posts_rel_link_wp_head');
remove_action('wp_head', 'rel_canonical');


/**
* Add functions into outer html for theme.
*/
remove_action('wp_head', 'wp_generator');


/**
* Last Modified into HTTP Headers
*/
function dp_get_last_modified_date(){
	$date = array(
		get_the_modified_time("Y"),
		get_the_modified_time("m"),
		get_the_modified_time("d")
	);
	$time = array(
		get_the_modified_time("H"),
		get_the_modified_time("i"),
		get_the_modified_time("s"),
	);
	$time_str = implode("-", $date)."T".implode(":", $time);
	return date_i18n( "r", strtotime($time_str) );
}

function dp_http_header_set(){
	if (is_singular()){
		$mod_time = get_the_modified_time('U');
		$last_mod = gmdate("D, d M Y H:i:s T", $mod_time);
		$etag = md5($last_mod.get_permalink());
		header(sprintf("Last-Modified: %s", $last_mod));
		header(sprintf("Etag: %s", $etag));
	}
}
add_action( "wp", "dp_http_header_set", 1 );


/**
* Action hook on wp_head
*/
function dp_hook_wp_head(){
	global $options;

	// SNS
	if ( isset($options['disable_dns_prefetch']) && !empty($options['disable_dns_prefetch']) ) {
		remove_action('wp_head','wp_resource_hints', 2);
	} else {
		if ( !(isset($options['disable_sns_share_count']) && !empty($options['disable_sns_share_count'])) ){
			$prefetch = '<link rel="dns-prefetch" href="//connect.facebook.net" />
<link rel="dns-prefetch" href="//secure.gravatar.com" />
<link rel="dns-prefetch" href="//api.pinterest.com" />
<link rel="dns-prefetch" href="//jsoon.digitiminimi.com" />
<link rel="dns-prefetch" href="//b.hatena.ne.jp" />
<link rel="dns-prefetch" href="//platform.twitter.com" />';
			echo str_replace(array("\r\n","\r","\n","\t","/^\s(?=\s)/"), '', $prefetch);
		}
	}

	if (is_singular()){
		// Modified date
		printf( '<meta http-equiv="Last-Modified" content="%s" />', dp_get_last_modified_date() );
		// Ping URL
		if ( pings_open() ) {
			printf( '<link rel="pingback" href="%s" />', get_bloginfo( 'pingback_url' ) );
		}
	}
}
add_action( "wp_head", "dp_hook_wp_head", 1 );

/**
* Admin function
*/
/* Disable admin notice for editors */
if (!current_user_can('edit_users')) {
	function dp_wphidenag() {
		remove_action( 'admin_notices', 'update_nag');
	}
	add_action('admin_menu','dp_wphidenag');
}


/**
* Replace upload content url in SSL
*/
function dp_replace_ssl_content($content){
	if (is_ssl()){
		$upload_dir = wp_upload_dir();
		$upload_dir_url = $upload_dir['baseurl'];
		$upload_dir_ssl_url = str_replace('http:', 'https:', $upload_dir_url);
		$content = str_replace($upload_dir_url, $upload_dir_ssl_url, $content);
	}
	return $content;
}
add_filter('the_content', 'dp_replace_ssl_content');


/**
* After setup theme
*/
function dp_password_form() {
	$custom_phrase =
'<p class="need-pass-title label label-orange icon-lock">'.__('Protected','DigiPress').'</p>'.__('Please type the password to read this page.', 'DigiPress').'
<div id="protectedForm"><form action="' . esc_url(site_url()) . '/wp-login.php?action=postpass" method="post"><input name="post_password" type="password" size="24" /><input type="submit" name="Submit" value="' . esc_attr__("Submit") . '" />
</form></div>';

	return post_custom("CustomPasswordDesc").$custom_phrase;
}


/**
* Replace title tag
*/
function dp_replace_wp_title( $title ) {
	if ( ! class_exists('All_in_One_SEO_Pack') && ! function_exists( 'aioseo' ) && ! function_exists( 'YoastSEO' ) ) {
	    $title = dp_site_title( null, null, false );
	}
    return $title;
}
add_filter( 'pre_get_document_title', 'dp_replace_wp_title' );


/**
* Disable wp emoji
*/
function dp_disable_emoji() {
	global $options;
	if (!(bool)$options['disable_emoji'] ) return;
    remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
    remove_action( 'admin_print_scripts', 'print_emoji_detection_script' );
    remove_action( 'wp_print_styles', 'print_emoji_styles' );
    remove_filter( 'the_content_feed', 'wp_staticize_emoji' );
    remove_filter( 'comment_text_rss', 'wp_staticize_emoji' );
    remove_filter( 'wp_mail', 'wp_staticize_emoji_for_email' );
    add_filter( 'emoji_svg_url', '__return_false' );
}
add_action('init', 'dp_disable_emoji');


/**
* Disable oEmbed
*/
function dp_disable_oembed(){
	global $options;
	if(!$options['disable_oembed']) return;
	add_filter('embed_oembed_discover', '__return_false');
	remove_action('wp_head','rest_output_link_wp_head');
	remove_action('wp_head','wp_oembed_add_discovery_links');
	remove_action('wp_head','wp_oembed_add_host_js');
}
add_action('init', 'dp_disable_oembed');


/**
 * Disable gallery shortcode CSS
 */
add_filter( 'use_default_gallery_style', '__return_false' );


/**
* Remopve protection text and custome protected form
*/
function dp_remove_private($s) {
	return '%s';
}
add_filter('protected_title_format', 'dp_remove_private');


/**
* Disable hentry class
*/
function dp_remove_hentry( $classes ) {
	$classes = array_diff($classes, array('hentry'));
	return $classes;
}
add_filter('post_class', 'dp_remove_hentry');

/**
 * Remove unnecessary recent comment inline style
 */
function dp_remove_recent_comments_style() {
	global $wp_widget_factory;
	remove_action( 'wp_head', array( $wp_widget_factory->widgets['WP_Widget_Recent_Comments'], 'recent_comments_style' ) );
}
add_action( 'widgets_init', 'dp_remove_recent_comments_style', 1 );


/**
* Disable comment form at static page
*/
function dp_close_page_comment($open, $post_id) {
	$post = get_post($post_id);
	if ($post && $post->post_type == 'page') {
		return false;
	}
	return $open;
}
add_filter('comments_open', 'dp_close_page_comment', 10, 2);


/**
* Replace "more [...]" strings.
*/
//WordPress version as integer.
function dp_new_excerpt_more($more) {
	return '...';
}
//Replace "more" strings.
add_filter('excerpt_more', 'dp_new_excerpt_more');


/**
* Change excerpt length.
*/
function dp_new_excerpt_mblength($length) {
	return 220;
}
add_filter('excerpt_mblength', 'dp_new_excerpt_mblength');


/**
* Remove more "#" link string.
*/
function dp_custom_content_more_link( $output ) {
	$output = preg_replace('/#more-[\d]+/i', '', $output );
	return $output;
}
add_filter( 'the_content_more_link', 'dp_custom_content_more_link' );


/**
* Disable font-sizing in tag cloud
*/
function dp_theme_new_tag_cloud($args) {
	$my_args = array(
		'smallest'	=> 11,
		'largest'	=> 11,
		'unit'		=> 'px',
		'number' 	=> 45,
		'orderby'	=> 'count',
		'order' 	=> 'DESC'
		);
	$args = wp_parse_args( $args, $my_args );
	return $args;
}
add_filter('widget_tag_cloud_args', 'dp_theme_new_tag_cloud');


/**
 * remove style attribute in tag cloud
 */
function dp_remove_tagcloud_style( $return ) {
	$return = preg_replace('/\sstyle=".+?"/i', '', $return );
	return $return;
}
add_filter( 'wp_tag_cloud', 'dp_remove_tagcloud_style' );


/**
 * Remove type attribute from script tag
 */
add_action( 'template_redirect', function () {
	ob_start(function ($buffer) {
		$buffer = str_replace(array( '<script type="text/javascript"', "<script type='text/javascript'" ), '<script', $buffer);
		return $buffer;
	});
});

/**
 * Disable attachment page and redirect
 */
function dp_redirect_attachment_page() {

	if ( is_attachment() ) {
		global $post, $options;
		if ( !isset( $options['redirect_attachment_page'] ) || (bool)$options['redirect_attachment_page'] ) {
			if ( $post && $post->post_parent ) {
				wp_redirect( esc_url( get_permalink( $post->post_parent ) ), 301 );
				exit;
			} else {
				wp_redirect( esc_url( home_url( '/' ) ), 301 );
				exit;
			}
		}
	}
}
add_action( 'template_redirect', 'dp_redirect_attachment_page' );


/**
* Fix original "the_excerpt" function.
*/
remove_filter('the_excerpt', 'wpautop');
function dp_custom_excerpt( $excerpt ){
	if ( ! has_excerpt() ) {
		$excerpt = str_replace( array("\r\n", "\r", "\n"), ' ', strip_tags( strip_shortcodes( get_the_content() ) ) );
		$excerpt = preg_replace( '/\[.+?\]/m', '', $excerpt );
		$excerpt = wp_trim_words( $excerpt, 320 );
	}

	return $excerpt;
}
add_filter( 'get_the_excerpt', 'dp_custom_excerpt' );



/**
* Replace post slug when unexpected character.
*/
function dp_auto_post_slug( $slug, $post_ID, $post_status, $post_type ) {
	global $options;
	if (isset($options['disable_fix_post_slug']) && (bool)$options['disable_fix_post_slug']) return $slug;
	if ( preg_match( '/(%[0-9a-f]{2})+/', $slug ) ) {
		$slug = utf8_uri_encode( $post_type ) . '-' . $post_ID;
	}
	return $slug;
}
add_filter( 'wp_unique_post_slug', 'dp_auto_post_slug', 10, 4 );


/**
* Use search.php if the search word is not set.
*/
function dp_enable_empty_query( $search, $query ) {
	global $wpdb, $options;

	if ($query->is_main_query()) {
		// "q" is for Google Custom Search
		if ( (isset( $_REQUEST['s'] ) && empty( $_REQUEST['s'])) || (isset( $_REQUEST['q']) && isset( $options['gcs_id'] ) && !empty($options['gcs_id']) ) ) {
			$term = $_REQUEST['s'];
			$query->is_search = true;
			if ( $term === '' ) {
				$search = ' AND 0';
			} else {
				$search = " AND ( ( $wpdb->posts.post_title LIKE '%{$term}%' ) OR ( $wpdb->posts.post_content LIKE '%{$term}%' ) )";
			}
		}
	}
	return $search;
}
if (!is_admin()) {
	add_action( 'posts_search', 'dp_enable_empty_query', 10, 2);
}


/**
 * Converts pre tag contents to HTML entities
 */
function dp_pre_content_filter( $content ) {
	return preg_replace_callback(
		'|<pre(?!.*class="wp-block-.*").*>(.*)<\/pre>|isU',
		function( $matches ) {
			return str_replace( $matches[1], str_replace( array('[', ']', '&amp;lt;', '&amp;gt;', '&lt;br /&gt;'), array('&#91;', '&#93;', '&lt;', '&gt;', '<br />'), htmlentities( $matches[1] ) ), $matches[0] );
		}, $content );
}
add_filter( 'the_content', 'dp_pre_content_filter', 1 );



/**
* Add class into the next/previous anchor tag
*/
function dp_add_prev_posts_link_attr(){
	return 'class="page-numbers arw"';
}
add_filter('previous_posts_link_attributes', 'dp_add_prev_posts_link_attr');

function dp_add_next_posts_link_attr(){
	return 'class="page-numbers arw next"';
}
add_filter('next_posts_link_attributes', 'dp_add_next_posts_link_attr');



/**
* Detects animated GIF from given file pointer resource or filename.
*
* @param resource|string $file File pointer resource or filename
* @return bool
*/
function dp_is_animated_gif($file){
	$fp = null;
	if (is_string($file)) {
		$ct = stream_context_create(
			array(
				'ssl' => array(
					'verify_peer'      => false,
					'verify_peer_name' => false
				)
			)
		);
		$fp = fopen( $file, "rb", false, $ct );
	} else {
		$fp = $file;
		/* Make sure that we are at the beginning of the file */
		fseek($fp, 0);
	}
	if ( $fp === false ) {
		return false;
	} else {
		if ( fread( $fp, 3 ) !== "GIF" ) {
			fclose( $fp );
			return false;
		}
	}
	$frames = 0;
	while (!feof($fp) && $frames < 2) {
		if (fread($fp, 1) === "\x00") {
			/* Some of the animated GIFs do not contain graphic control extension (starts with 21 f9) */
			if (fread($fp, 1) === "\x21" || fread($fp, 2) === "\x21\xf9") {
				$frames++;
			}
		}
	}
	fclose($fp);
	return $frames > 1;
}
function dp_disable_upload_sizes( $sizes, $metadata ) {
	if (ini_get('allow_url_fopen')){
		$uploads = wp_upload_dir();
		$upload_path = $uploads['baseurl'];
		$relative_path = $metadata['file'];
		$file_url = $upload_path . '/' . $relative_path;

		if( dp_is_animated_gif( $file_url ) ) {
			$sizes = array();
		}
	}
	// Return sizes you want to create from image (None if image is gif.)
	return $sizes;
}
add_filter('intermediate_image_sizes_advanced', 'dp_disable_upload_sizes', 10, 2);


/**
 * Remove version param from all resource files
 */
function dp_remove_src_ver( $src ) {
	global $options;
	if ( isset($options['remove_resource_url_version_param']) && !empty($options['remove_resource_url_version_param']) ) {
		return remove_query_arg( 'ver', $src );
	} else {
		return $src;
	}
}
add_filter( 'script_loader_src', 'dp_remove_src_ver' );
add_filter( 'style_loader_src', 'dp_remove_src_ver' );

/**
 * For assyncro scripts
 */
function dp_async_scripts($url){
	if ( strpos( $url, '#asyncload') === false ) {
		return $url;
	} else if ( is_admin() ) {
		return str_replace( '#asyncload', '', $url );
	} else {
		return str_replace( '#asyncload', '', $url )."' async='async";
	}
}
add_filter('clean_url', 'dp_async_scripts', 11, 1 );


/**
 * Insert thumbnail tree in feed
 */
function dp_insert_thumbnail_data_to_feed(){
	global $post;

	if (!has_post_thumbnail($post->ID)) return;

	$thumbnail_ID = get_post_thumbnail_id( $post->ID );
	$thumbnail = wp_get_attachment_image_src( $thumbnail_ID, 'large' );
	$output = '<media:content xmlns:media="http://search.yahoo.com/mrss/" medium="image" type="image/jpeg" url="'. $thumbnail[0] .'" width="'. $thumbnail[1] .'" height="'. $thumbnail[2] .'" />';

	echo $output;
}
add_action('rss2_item', 'dp_insert_thumbnail_data_to_feed');


/**
 * Replace oEmbed style
 */
function dp_embed_styles(){
	wp_enqueue_style( 'wp-embed-template-org', DP_THEME_URI . '/inc/css/wp-embed-template.css' );
}
remove_action( 'embed_head', 'print_embed_styles' );
add_filter( 'embed_head', 'dp_embed_styles' );


/**
 * Disallow REST API access for security
 *
 * ## This filter has a bad issue in Block editor ##
 */
function dp_filter_rest_endpoints( $endpoints ) {

	if ( isset( $endpoints['/wp/v2/users'] ) ) {
		unset( $endpoints['/wp/v2/users'] );
	}
	if ( isset( $endpoints['/wp/v2/users/(?P[\d]+)'] ) ) {
		unset( $endpoints['/wp/v2/users/(?P[\d]+)'] );
	}

	return $endpoints;
}
// add_filter( 'rest_endpoints', 'dp_filter_rest_endpoints', 10, 1 );


/**
 * Remove the class including author ID from comment area
 */
function dp_remove_comment_author_class( $classes ) {
	foreach ( $classes as $key => $class ) {
		if ( strstr( $class, 'comment-author-' ) ) {
			unset( $classes[$key] );
		}
	}
	return $classes;
}
add_filter( 'comment_class', 'dp_remove_comment_author_class', 10, 1 );


/**
 * Disable Gutenberg Based Widget Screen
 */
function dp_disable_block_based_widget(){
	global $options;

	if ( isset($options['disable_block_based_widget']) && !empty($options['disable_block_based_widget']) ){
		return false;
	}

	return true;
}
add_filter( 'use_widgets_block_editor', 'dp_disable_block_based_widget' );


/**
 * Defer css and javascript
 */
if ( !is_admin() ) {
	function dp_replace_to_preload_style_tag( $tag ){
		$pattern = array(
			'dp-' . DP_THEME_KEY . '/css/parts/',
			'dp-' . DP_THEME_KEY . '/css/style.css',
			'dp-' . DP_THEME_KEY . '/mobile/css/parts/',
			'dp-' . DP_THEME_KEY . '/mobile/css/style.css',
			DP_THEME_KEY . '/css/visual-custom.css'
		);

		$pattern = array_map( function( $val ){
			return preg_quote( $val, '/' );
		}, $pattern );

		$pattern = '/' . implode( '|', $pattern ) . '/';

		$match = preg_match( $pattern, $tag );

		if ( !$match ) {
			$tag = preg_replace( "/rel=['|\"]stylesheet['|\"]/" , 'rel="preload" as="style" onload="this.onload=null;this.rel=\'stylesheet\'"', $tag );
		}

		return $tag;
	}
	add_filter( 'style_loader_tag', 'dp_replace_to_preload_style_tag' );

	// function dp_replace_to_defer_script_tag ( $tag ) {

	// 	$pattern = array(
	// 		'\sdefer',
	// 		'\sasync',
	// 		'main.min.js',
	// 		'swiper',
	// 		'fitvids',
	// 		'wow',
	// 		'scrollReveal',
	// 		'barba',
	// 		'imagesloaded',
	// 		'anime',
	// 		'jquery',
	// 	);

	// 	$pattern = array_map( function( $val ){
	// 		return preg_quote( $val, '/' );
	// 	}, $pattern );

	// 	$pattern = '/' . implode( '|', $pattern ) . '/';

	// 	$match = preg_match( $pattern, $tag );

	// 	if ( !$match ) {
	// 		return str_replace( "type='text/javascript'", 'defer', $tag );
	// 	}
	// 	return $tag;
	// }
	// add_filter( 'script_loader_tag', 'dp_replace_to_defer_script_tag' );
}

/**
 * Hide RSS icon on RSS widget
 */
add_filter( 'rss_widget_feed_link', '__return_false' );


/**
 * Custom codes after body opening tag.
 */ 
function dp_body_open_hook() {
	global $options, $IS_MOBILE_DP;

	$mb_suffix = $IS_MOBILE_DP ? '_mobile' : '';

	if ( isset( $options[ 'body_open_code' . $mb_suffix ] ) && !empty( $options[ 'body_open_code' . $mb_suffix ] ) ) {
		echo str_replace( array( "\r\n","\r","\n","\t","/^\s(?=\s)/" ), '', $options[ 'body_open_code' . $mb_suffix ] );
	}
}
add_action( 'wp_body_open', 'dp_body_open_hook' );