<?php
// ************************************************
// Count current column 
// 
// @return column number
// ************************************************
function get_column_num(){
	if (is_admin()) return;

	global $COLUMN_NUM, $SIDEBAR_FLOAT, $SIDEBAR2_FLOAT, $options;

	$post_type = get_post_type();
	$site_layout = $options['site_layout'];
	$num = 0;

	// Sidebar
	if ($site_layout === 'sb-content') {
		$SIDEBAR_FLOAT = 'left';
	} else if ($site_layout === 'content-sb'){
		$SIDEBAR_FLOAT = 'right';
	}

	// Column
	if ( $post_type === 'product' ) {
		$num = 1;
		$SIDEBAR_FLOAT = '';
		$SIDEBAR2_FLOAT = '';
	} else {
		if ( is_home() ) {
			if (is_paged()) {
				// Paged at top page
				if ( $site_layout === 'content' ) {
					$num = 1;
					$SIDEBAR_FLOAT = '';
					$SIDEBAR2_FLOAT = '';
				} else {
					if ($options['one_col_only_top']) {
						$num = 1;
						$SIDEBAR_FLOAT = '';
					} else {
						if ( $site_layout === 'sb-content-sb' || $site_layout === 'sb-sb-content' || $site_layout === 'content-sb-sb' ) {
							$num = 3;
						} else {
							$num = 2;
						}
					}
				}
			} else {
				// Top page
				if ( $site_layout === 'content' || $options['one_col_only_top'] ) {
					$num = 1;
					$SIDEBAR_FLOAT = '';
					$SIDEBAR2_FLOAT = '';
				} else {
					if ( $site_layout === 'sb-content-sb' || $site_layout === 'content-sb-sb' || $site_layout === 'sb-sb-content' ) {
						$num = 3;
					} else {
						$num = 2;
					}
				}
			}
		} else if (is_singular()) {
			if ( $site_layout === 'content' || get_post_meta(get_the_ID(), 'disable_sidebar', true) ) {
				$num = 1;
				$SIDEBAR_FLOAT = '';
				$SIDEBAR2_FLOAT = '';
			} else {
				if ( $site_layout === 'sb-content-sb' || $site_layout === 'content-sb-sb' || $site_layout === 'sb-sb-content' ) {
					$num = 3;
				} else {
					$num = 2;
				}
			}
		} else {
			if ( $site_layout === 'content' ) {
				$num = 1;
				$SIDEBAR_FLOAT = '';
				$SIDEBAR2_FLOAT = '';
			} else {
				// Get queried object array
				$q_obj = get_queried_object();

				if ( is_category() && !is_search() ) {

					// Get custom archive fields
					$meta = isset( $q_obj->cat_ID ) ? get_option('ex_term_meta_' . $q_obj->cat_ID) : null;

					// Layout
					if ( isset($meta['no_sidebar']) && !empty($meta['no_sidebar']) ) {
						$num = 1;
						$SIDEBAR_FLOAT = '';
						$SIDEBAR2_FLOAT = '';

					} else if ( isset($options['one_col_category']) && !empty($options['one_col_category']) ) {
						$arr_one_col_cat = explode(",", $options['one_col_category']);
						if ( is_category($arr_one_col_cat) ) {
							$num = 1;
							$SIDEBAR_FLOAT = '';
							$SIDEBAR2_FLOAT = '';
						} else {
							if ( $site_layout === 'sb-content-sb' || $site_layout === 'content-sb-sb' || $site_layout === 'sb-sb-content' ) {
								$num = 3;
							} else {
								$num = 2;
							}
						}
					} else {
						if ( $site_layout === 'sb-content-sb' || $site_layout === 'content-sb-sb' || $site_layout === 'sb-sb-content' ) {
							$num = 3;
						} else {
							$num = 2;
						}
					}

				} else if ( is_tag() ) {
					// Get custom archive fields
					$meta = isset( $q_obj->term_taxonomy_id ) ? get_option('ex_term_meta_' . $q_obj->term_taxonomy_id) : null;

					// Layout
					if ( isset($meta['no_sidebar']) && !empty($meta['no_sidebar']) ) {
						$num = 1;
						$SIDEBAR_FLOAT = '';
						$SIDEBAR2_FLOAT = '';
					} else {
						if ( $site_layout === 'sb-content-sb' || $site_layout === 'content-sb-sb' || $site_layout === 'sb-sb-content' ) {
							$num = 3;
						} else {
							$num = 2;
						}
					}

	 			} else {
					if ( $site_layout === 'sb-content-sb' || $site_layout === 'content-sb-sb' || $site_layout === 'sb-sb-content' ) {
						$num = 3;
					} else {
						$num = 2;
					}
				}
			}
		}
	}
	$COLUMN_NUM = $num;
	return $num;
}