<?php
/**
* Load css and js
*  -- disable WP default jquery, load Google API minimized script
*/
function dp_load_css_scripts() {
	if ( is_admin() ) return;

	global $options, $ARCHIVE_STYLE, $IS_MOBILE_DP;

	$mb_suffix = $IS_MOBILE_DP ? '_mobile' : '';
	$css_name = 'style.css';
	$css_pc = '/css/' . $css_name;
	$css_mb = '/' . DP_MOBILE_THEME_DIR . '/css/' . $css_name;
	$css_custom = '/css/visual-custom.css';
	$main_js = $IS_MOBILE_DP ? 'mb-main.min.js' : 'main.min.js';
	$arr_main_pri_js = array( 'jquery', 'easing', 'scrollReveal' );
	$arr_main_pri_css = array();

	$block_css = 'wp-blocks.css';
	$block_css = $IS_MOBILE_DP ?  DP_THEME_URI . '/' . DP_MOBILE_THEME_DIR . '/css/' . $block_css : DP_THEME_URI . '/css/' . $block_css;

	// Disable block library CSS
	if ( isset($options['disable_block_library_css']) && !empty($options['disable_block_library_css']) ) {
		wp_dequeue_style( 'wp-block-library' );
		wp_dequeue_style( 'wp-block-library-theme' );
	} else {
		// Additional preload CSS
		$arr_main_pri_css[] = 'dp-wp-block-library';
		// Enqueue block library CSS
		wp_enqueue_style( 'dp-wp-block-library', $block_css, array( 'wp-block-library' ), DP_OPTION_SPT_VERSION );
	}

	// Add some pre css
	$arr_main_pri_css = apply_filters( 'dp_add_theme_pre_css', $arr_main_pri_css );

	// version param
	$ver_param = DP_OPTION_SPT_VERSION;
	$main_css_ver_param = $IS_MOBILE_DP ? echo_filedate( DP_THEME_DIR . $css_mb ) : echo_filedate( DP_THEME_DIR . $css_pc );
	$custom_css_ver_param = echo_filedate( DP_UPLOAD_DIR . $css_custom );
	$main_js_ver_param = echo_filedate( DP_THEME_DIR . '/inc/js/' . $main_js );


	// wow.js
	if ( isset($options['disable_wow_js' . $mb_suffix]) && !$options['disable_wow_js' . $mb_suffix] ){
		wp_enqueue_style( 'wow', DP_THEME_URI . '/css/animate.css', array( 'digipress' ), $ver_param );
		wp_enqueue_script( 'wow', DP_THEME_URI . '/inc/js/wow.min.js', array(), $ver_param, true );
	}
	// Swiper
	if ( empty( $options['disable_pjax' . $mb_suffix] ) ){
		wp_enqueue_style( 'dp-swiper', DP_THEME_URI . '/css/swiper-bundle.css', null, $ver_param);
		wp_enqueue_script( 'dp-swiper', DP_THEME_URI . '/inc/js/swiper-bundle.min.js', null, false, true );
	}

	// Theme main CSS
	if ( $IS_MOBILE_DP ) {

		if ( !$options['disable_pjax' . $mb_suffix] ) {
			wp_enqueue_style( 'pjax-page-transition', DP_THEME_URI . '/' . DP_MOBILE_THEME_DIR . '/css/parts/pjax_page_transition.css', $arr_main_pri_css, $main_css_ver_param );

			$arr_main_pri_css[] = 'pjax-page-transition';
		}

		if ( is_home() || is_front_page() || !$options['disable_pjax' . $mb_suffix] ) {
			wp_enqueue_style( 'top-page-header-area', DP_THEME_URI . '/' . DP_MOBILE_THEME_DIR . '/css/parts/top_page_header_area.css', array(), $main_css_ver_param );
			$arr_main_pri_css[] = 'top-page-header-area';
		}
		if ( ( !is_home() && !is_front_page() ) || !$options['disable_pjax' . $mb_suffix] ) {
			wp_enqueue_style( 'breadcrumb', DP_THEME_URI . '/' . DP_MOBILE_THEME_DIR . '/css/parts/breadcrumb.css', array(), $main_css_ver_param );
			wp_enqueue_style( 'content-header-area', DP_THEME_URI . '/' . DP_MOBILE_THEME_DIR . '/css/parts/content_header_area.css', array(), $main_css_ver_param );

			$arr_main_pri_css[] = 'breadcrumb';
			$arr_main_pri_css[] = 'content-header-area';
		} else {
			if ( ( is_home() || is_front_page() ) && is_paged() ) {
				wp_enqueue_style( 'breadcrumb', DP_THEME_URI . '/' . DP_MOBILE_THEME_DIR . '/css/parts/breadcrumb.css', array(), $main_css_ver_param );

				$arr_main_pri_css[] = 'breadcrumb';
			}
		}

		if ( is_singular() || !$options['disable_pjax' . $mb_suffix] ) {
			wp_enqueue_style( 'author-profile', DP_THEME_URI . '/' . DP_MOBILE_THEME_DIR . '/css/parts/author_profile.css', array(), $main_css_ver_param );
			wp_enqueue_style( 'authors-list', DP_THEME_URI . '/' . DP_MOBILE_THEME_DIR . '/css/parts/authors_list.css', array(), $main_css_ver_param );
			wp_enqueue_style( 'single-article', DP_THEME_URI . '/' . DP_MOBILE_THEME_DIR . '/css/parts/single_article.css', array(), $main_css_ver_param );

			$arr_main_pri_css[] = 'author-profile';
			$arr_main_pri_css[] = 'authors-list';
			$arr_main_pri_css[] = 'single-article';
		}
		if ( is_404() || !$options['disable_pjax' . $mb_suffix] ) {
			wp_enqueue_style( '404', DP_THEME_URI . '/' . DP_MOBILE_THEME_DIR . '/css/parts/404.css', $arr_main_pri_css, $main_css_ver_param );
			$arr_main_pri_css[] = '404';
		}

		wp_enqueue_style( 'digipress', DP_THEME_URI . $css_mb, $arr_main_pri_css, $main_css_ver_param );

	} else {

		if ( !$options['disable_pjax'] ) {
			wp_enqueue_style( 'pjax-page-transition', DP_THEME_URI . '/css/parts/pjax_page_transition.css', array(), $main_css_ver_param );

			$arr_main_pri_css[] = 'pjax-page-transition';
		}

		if ( is_home() || is_front_page() || !$options['disable_pjax'] ) {
			wp_enqueue_style( 'top-page-header-area', DP_THEME_URI . '/css/parts/top_page_header_area.css', array(), $main_css_ver_param );

			$arr_main_pri_css[] = 'top-page-header-area';
		}

		if ( ( !is_home() && !is_front_page() ) || !$options['disable_pjax'] ) {
			wp_enqueue_style( 'breadcrumb', DP_THEME_URI . '/css/parts/breadcrumb.css', array(), $main_css_ver_param );
			wp_enqueue_style( 'content-header-area', DP_THEME_URI . '/css/parts/content_header_area.css', array(), $main_css_ver_param );

			$arr_main_pri_css[] = 'breadcrumb';
			$arr_main_pri_css[] = 'content-header-area';
		} else {

			if ( ( is_home() || is_front_page() ) && is_paged() ) {
				wp_enqueue_style( 'breadcrumb', DP_THEME_URI . '/css/parts/breadcrumb.css', array(), $main_css_ver_param );

				$arr_main_pri_css[] = 'breadcrumb';
			}
		}

		if ( is_singular() || !$options['disable_pjax'] ) {
			wp_enqueue_style( 'author-profile', DP_THEME_URI . '/css/parts/author_profile.css', array(), $main_css_ver_param );
			wp_enqueue_style( 'authors-list', DP_THEME_URI . '/css/parts/authors_list.css', array(), $main_css_ver_param );
			wp_enqueue_style( 'single-article', DP_THEME_URI . '/css/parts/single_article.css', array(), $main_css_ver_param );

			$arr_main_pri_css[] = 'author-profile';
			$arr_main_pri_css[] = 'authors-list';
			$arr_main_pri_css[] = 'single-article';
		}

		if ( is_404() || !$options['disable_pjax'] ) {
			wp_enqueue_style( '404', DP_THEME_URI . '/css/parts/404.css', $arr_main_pri_css, $main_css_ver_param );
			$arr_main_pri_css[] = '404';
		}

		wp_enqueue_style( 'digipress', DP_THEME_URI . $css_pc, $arr_main_pri_css, $main_css_ver_param );
	}

	// Custom CSS
	if ( file_exists( DP_UPLOAD_DIR . '/css/visual-custom.css' ) ) {
		wp_enqueue_style( 'dp-visual', DP_UPLOAD_URI . $css_custom, array( 'digipress' ), $custom_css_ver_param );
	} else {
		wp_enqueue_style( 'dp-visual', DP_THEME_URI . $css_custom, array( 'digipress' ), false );
	}

	// jQuery
	wp_deregister_script( 'jquery' );
	if ( $options['use_google_jquery'] ) {
		// Replace to Google API jQuery
		wp_register_script( 'jquery','https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js', false, NULL, true );
		wp_enqueue_script( 'jquery' );
	} else {
		wp_enqueue_script( 'jquery', includes_url( '/js/jquery/jquery.min.js' ), array(), NULL, true );
	}

	// jQuery easing
	wp_enqueue_script( 'easing', DP_THEME_URI . '/inc/js/jquery/jquery.easing.min.js', array( 'jquery' ) ,$ver_param, true );

	// fitVids
	wp_enqueue_script( 'fitvids', DP_THEME_URI . '/inc/js/jquery/jquery.fitvids.min.js', array( 'jquery' ) ,$ver_param, true );

	// scrollReveal js
	wp_enqueue_script( 'scrollReveal', DP_THEME_URI . '/inc/js/scrollReveal.min.js', array( 'jquery' ) ,$ver_param, true );

	// anime.js
	wp_enqueue_script( 'anime', DP_THEME_URI . '/inc/js/anime.min.js', array( 'jquery' ), $ver_param, true );

	// Share count
	if (!(isset($options['disable_sns_share_count']) && !empty($options['disable_sns_share_count']))){
		wp_enqueue_script( 'sns-share-count', DP_THEME_URI . '/inc/js/jquery/jquery.sharecount.min.js', array( 'jquery' ) ,$ver_param,true );
		$arr_main_pri_js[] = 'sns-share-count';
	}

	// PJAX barba (When pjax is enabled)
	if ( !( isset($options['disable_pjax' . $mb_suffix]) && !empty($options['disable_pjax' . $mb_suffix]) ) ) {
		// Main pjax module
		wp_enqueue_script( 'barba', DP_THEME_URI . '/inc/js/barba-custom.min.js', array( 'jquery' ), $ver_param, true );
		$arr_main_pri_js[] = 'barba';

		// Images loaded module
		wp_enqueue_script( 'imagesloaded', null, array( 'jquery' ), null, true );
		$arr_main_pri_js[] = 'imagesloaded';

		// isotope
		wp_enqueue_script( 'isotope', DP_THEME_URI . '/inc/js/jquery/jquery.isotope.min.js', array( 'jquery','imagesloaded' ) ,$ver_param,true );
		$arr_main_pri_js[] = 'isotope';

		// Air datepicker
		wp_enqueue_style( 'air-datepicker', DP_THEME_URI . '/css/datepicker.min.css', null, $ver_param );
		wp_enqueue_script( 'air-datepicker', DP_THEME_URI . '/inc/js/jquery/datepicker/jquery.datepicker.min.js', array( 'jquery' ), $ver_param, true );
	}

	// Rellax.js
	// wp_enqueue_script( 'rellax', DP_THEME_URI . '/inc/js/rellax.min.js', array() ,$ver_param, true );

	// Pallarax.js
	// wp_enqueue_script( 'dp_parallax_js', 'https://cdnjs.cloudflare.com/ajax/libs/parallax/3.1.0/parallax.min.js',  null, $ver_param, true );

	// Main theme js
	wp_enqueue_script( 'dp-main', DP_THEME_URI . '/inc/js/' . $main_js, $arr_main_pri_js, $main_js_ver_param, true );

	// for comment form
	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}
}
add_action( 'wp_enqueue_scripts', 'dp_load_css_scripts' );