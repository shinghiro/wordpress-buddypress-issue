<?php
/**
 * Check the current page is WooCommerce page.
 * @return [boolean]
 */
function is_woocommerce_dp(){

	if ( is_admin() ) return;

	global $IS_WOOCOMMERCE;

	if ( function_exists( 'is_woocommerce' ) && function_exists( 'is_cart' ) && function_exists( 'is_checkout' ) && function_exists( 'is_account_page' ) ) {
		if ( is_woocommerce() || is_cart() || is_checkout() || is_account_page() ) {
			$IS_WOOCOMMERCE = true;
		}
	}
}