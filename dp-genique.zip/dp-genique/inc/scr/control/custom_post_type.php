<?php
/**
 * Hook before WordPress loaded
 */
function dp_custom_post_type() {
    global $options;

    $id = !empty($options['news_cpt_slug_id']) ? $options['news_cpt_slug_id'] : 'news';
    $name = !empty($options['news_cpt_name']) ? $options['news_cpt_name'] : __('Information', 'DigiPress');
    $labels = array(
        'name' => $name,
        'add_new_item' => sprintf( __( 'Add a new %s', 'DigiPress' ), $name ),
        'not_found' => $name . __( ' is not found.', 'DigiPress' ),
        'new_item' => sprintf( __( 'New %s', 'DigiPress' ), $name ),
        'view_item' => sprintf( __( 'Show %s', 'DigiPress' ), $name )
    );
    $args = array(
        'labels' => $labels,
        'public' => true, //publicly_queriable, show_ui, show_in_nav_menus, exclude_from_search
        'publicly_queryable' => true,
        'show_ui' => true,
        'show_in_rest' => true,
        'exclude_from_search'   => false,
        'capability_type' => 'post',
        'rewrite' => true,
        'hierarchical' => false,
        'has_archive' => true,
        'menu_position' => 5, // 5 or 10 or 20
        'supports' => array(
            'title',
            'editor',
            'thumbnail',
            'author',
            'excerpt',
            'revisions',
            'custom-fields'
            )
    );
    register_post_type($id, $args);
}
// Original Custom Type
add_action('init', 'dp_custom_post_type');