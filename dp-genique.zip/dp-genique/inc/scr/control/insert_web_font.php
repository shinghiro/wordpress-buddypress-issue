<?php
/**
 * Insert custom web font into head
 */
function dp_insert_web_font_link(){
	global $options;

	if ( !isset($options['base_font_family']) && !isset($options['alphanumeric_font_family']) ) return;


	$base_font = $link_code = '';

	/**
	 * Base font
	 */
	switch ( $options['base_font_family'] ) {
		case 'm-plus-1p-all':
			$base_font = "https://fonts.googleapis.com/css2?family=M+PLUS+1p:wght@400;700";
			break;

		case 'm-plus-rounded-1c-all':
			$base_font = "https://fonts.googleapis.com/css2?family=M+PLUS+Rounded+1c:wght@400;700";
			break;

		case 'm-plus-1-code-all':
			$base_font = "https://fonts.googleapis.com/css2?family=M+PLUS+1+Code:wght@400;700";
			break;

		case 'sawarabi-gothic-all':
			$base_font = "https://fonts.googleapis.com/css2?family=Sawarabi+Gothic";
			break;

		case 'sawarabi-mincho-all':
			$base_font = "https://fonts.googleapis.com/css2?family=Sawarabi+Mincho";
			break;

		case 'kosugi-all':
			$base_font = "https://fonts.googleapis.com/css2?family=Kosugi";
			break;

		case 'kosugi-maru-all':
			$base_font = "https://fonts.googleapis.com/css2?family=Kosugi+Maru";
			break;

		case 'hannari-all':
			$base_font = 'https://fonts.googleapis.com/earlyaccess/hannari.css';
			break;

		case 'kokoro-all':
			$base_font = 'https://fonts.googleapis.com/earlyaccess/kokoro.css';
			break;

		case 'kiwi-maru-all':
			$base_font = 'https://fonts.googleapis.com/css2?family=Kiwi+Maru:wght@400;500';
			break;

		case 'reggae-one-all':
			$base_font = 'https://fonts.googleapis.com/css2?family=Reggae+One';
			break;

		case 'rocknroll-one-all':
			$base_font = 'https://fonts.googleapis.com/css2?family=RocknRoll+One';
			break;

		case 'yusei-magic-all':
			$base_font = 'https://fonts.googleapis.com/css2?family=Yusei+Magic';
			break;

		case 'hachi-maru-pop-all':
			$base_font = 'https://fonts.googleapis.com/css2?family=Hachi+Maru+Pop';
			break;

		case 'shippori-mincho-all':
			$base_font = 'https://fonts.googleapis.com/css2?family=Shippori+Mincho:wght@400;800';
			break;

		case 'shippori-mincho-b1-all':
			$base_font = 'https://fonts.googleapis.com/css2?family=Shippori+Mincho+B1:wght@400;800';
			break;

		case 'shippori-antique-all':
			$base_font = 'https://fonts.googleapis.com/css2?family=Shippori+Antique';
			break;

		case 'shippori-antique-b1-all':
			$base_font = 'https://fonts.googleapis.com/css2?family=Shippori+Antique+B1';
			break;

		case 'new-tegomin-all':
			$base_font = 'https://fonts.googleapis.com/css2?family=New+Tegomin';
			break;

		case 'mochiy-pop-one-all':
			$base_font = 'https://fonts.googleapis.com/css2?family=Mochiy+Pop+One';
			break;

		case 'yuji-mai-all':
			$base_font = 'https://fonts.googleapis.com/css2?family=Yuji+Mai';
			break;

		case 'yuji-boku-all':
			$base_font = 'https://fonts.googleapis.com/css2?family=Yuji+Boku';
			break;

		case 'yuji-syuku-all':
			$base_font = 'https://fonts.googleapis.com/css2?family=Yuji+Syuku';
			break;

		case 'zen-antique-soft-all':
			$base_font = 'https://fonts.googleapis.com/css2?family=Zen+Antique+Soft';
			break;

		case 'zen-kurenaido-all':
			$base_font = 'https://fonts.googleapis.com/css2?family=Zen+Kurenaido';
			break;

		case 'zen-old-mincho-all':
			$base_font = 'https://fonts.googleapis.com/css2?family=Zen+Old+Mincho:wght@400;900';
			break;

		case 'zen-kaku-gothic-new-all':
			$base_font = 'https://fonts.googleapis.com/css2?family=Zen+Kaku+Gothic+New:wght@400;900';
			break;

		case 'zen-maru-gothic-all':
			$base_font = 'https://fonts.googleapis.com/css2?family=Zen+Maru+Gothic:wght@400;900';
			break;

		case 'kaisei-haruno-umi-all':
			$base_font = 'https://fonts.googleapis.com/css2?family=Kaisei+HarunoUmi:wght@400;700';
			break;

		case 'kaisei-decol-all':
			$base_font = 'https://fonts.googleapis.com/css2?family=Kaisei+Decol:wght@400;700';
			break;

		case 'kaisei-opti-all':
			$base_font = 'https://fonts.googleapis.com/css2?family=Kaisei+Opti:wght@400;700';
			break;

		case 'kaisei-tokumin-all':
			$base_font = 'https://fonts.googleapis.com/css2?family=Kaisei+Tokumin:wght@400;800';
			break;

		case 'klee-one-all':
			$base_font = 'https://fonts.googleapis.com/css2?family=Klee+One';
			break;

		case 'yomogi-all':
			$base_font = 'https://fonts.googleapis.com/css2?family=Yomogi';
			break;

		case 'hina-mincho-all':
			$base_font = 'https://fonts.googleapis.com/css2?family=Hina+Mincho';
			break;

		case 'notosans-all':
			if ( $options['base_font_weight'] != 400 ) {
				$base_font = 'https://fonts.googleapis.com/css2?family=Noto+Sans+JP:wght@' . $options['base_font_weight'];
			} else {
				$base_font = 'https://fonts.googleapis.com/css2?family=Noto+Sans+JP';
			}
			break;

		case 'notoserif-all':
			$base_font = 'https://fonts.googleapis.com/css2?family=Noto+Serif+JP';
			break;
	}


	/**
	 * Alphanumeric font
	 */
	if ( !isset($options['alphanumeric_font_family']) || $options['alphanumeric_font_family'] === 'none' ) {

		if ( !empty($base_font) ) {
			$link_code = '<link href="' . $base_font;
		}

	} else {

		if ( empty($base_font) ) {
			$link_code = '<link href="https://fonts.googleapis.com/css2?family=' . $options['alphanumeric_font_family'];

		} else {
			if ( $options['base_font_family'] === 'hannari-all'|| $options['base_font_family'] === 'kokoro-all' ) {
				$base_font = '<link href="' . $base_font . '" rel="stylesheet" />';
				$link_code = $base_font . '<link href="https://fonts.googleapis.com/css2?family=' . $options['alphanumeric_font_family'];
			} else {
				$link_code = '<link href="' . $base_font . '&family=' . $options['alphanumeric_font_family'];
			}
		}

		// Only several style fonts
		if ( $options['alphanumeric_font_family'] !== 'Didact+Gothic' && $options['alphanumeric_font_family'] !== 'Reem+Kufi' ) {
			// Normalize the font weight
			if ( $options['alphanumeric_font_family'] === 'Josefin+Slab' ) {
				$link_code .= ':wght@600;700';
			} else if ( $options['alphanumeric_font_family'] === 'Quicksand' || $options['alphanumeric_font_family'] === 'Raleway' ) {
				$link_code .= ':wght@500';
			} else if ( $options['alphanumeric_font_family'] === 'Montserrat' ) {
				$link_code .= ':wght@300';
			} else if ( $options['alphanumeric_font_family'] === 'Libre+Baskerville' || $options['alphanumeric_font_family'] === 'Arvo' || $options['alphanumeric_font_family'] === 'Jost' || $options['alphanumeric_font_family'] === 'Sansita+Swashed' ) {
				$link_code .= ':wght@400;700';
			}
		}
	}

	 // Display
	 if ( !empty($link_code) ) {

	 	$link_code = '<link rel="preconnect" href="https://fonts.googleapis.com" /><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />' . $link_code;

	 	if ( $options['base_font_family'] === 'hannari-all' || $options['base_font_family'] === 'kokoro-all' ) {
	 		echo $link_code . '" rel="stylesheet" />';
	 	} else {
	 		echo $link_code . '&display=swap" rel="stylesheet" />';
	 	}
	 }
}
add_action( 'wp_head', 'dp_insert_web_font_link' );
add_action( 'dp_amp_head', 'dp_insert_web_font_link' );