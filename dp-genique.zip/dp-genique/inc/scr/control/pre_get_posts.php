<?php
/**
* Number of post at each archive.
*/
function dp_custom_pre_get_posts( $query ) {
	if (is_admin() || ! $query->is_main_query()) return;

	global $options, $IS_MOBILE_DP;

	// Suffix
	$suffix = $IS_MOBILE_DP ? '_mobile' : '';

	// Sort
	if ( isset($_GET['sort']) && !empty($_GET['sort']) ){
		switch ($_GET['sort']) {
			case 'modified':
				$query->set( 'orderby', 'modified' );
				break;
			case 'popular':
				$query->set( 'orderby', 'meta_value_num' );
				$query->set( 'meta_key', 'post_views_count' );
				break;
			case 'comments':
				$query->set( 'orderby', 'comment_count' );
				break;
			case 'title':
			case 'name':
				$query->set( 'orderby', $_GET['sort'] );
				$query->set( 'order', 'ASC' );
				break;
			default:
				$query->set( 'orderby', 'date' );
				break;
		}
	}

	// Show published posts only
	if ( $query->is_home() || $query->is_archive() || $query->is_post_type_archive() || $query->is_search() ){
		$query->query_vars['post_status'] = 'publish';
	}

	// Get posts
	if ( $query->is_home() ) {

		if ( $options['top_page_main_content'] === 'cat' ) {
			// Add nimus each category id
			if ($options['top_target_cat_exclude']) {
				$cat_ids = preg_replace('/(\d+)/', '-${1}', $options['top_target_cat_ids']);
			} else {
				$cat_ids = preg_replace('/(\d+)/', '${1}', $options['top_target_cat_ids']);
			}
			$query->set( 'cat', $cat_ids );
		} else if ($options['top_page_main_content'] === 'custom') {
			// Show specific custom post type
			$query->set( 'post_type', $options['specific_post_type_index'] );
		}

		if ( isset($options['number_posts_index'.$suffix]) && !empty($options['number_posts_index'.$suffix]) ) {
			$query->set( 'posts_per_page', $options['number_posts_index'.$suffix] );
		}


		// Sort
		if ( !isset($_GET['sort']) && isset( $options['top_post_orderby'] ) && !empty( $options['top_post_orderby'] ) ) {
			switch ( $options['top_post_orderby'] ) {
				case 'post_views_count':
					$query->set( 'orderby', 'meta_value_num' );
					$query->set( 'meta_key', $options['top_post_orderby'] );
					break;
				default:
					$query->set( 'orderby', $options['top_post_orderby'] );
					break;
			}
		}

		// Asc or Desc
		if ( !isset($_GET['sort']) && isset( $options['top_post_order'] ) && $options['top_post_order'] === 'ASC' ) {
			$query->set( 'order', $options['top_post_order'] );
		}

	}

	else if ( $query->is_search() ) {

		// Sanitize
		$s = isset( $_GET['s'] ) ? htmlspecialchars( $_GET['s'], ENT_QUOTES, 'UTF-8' ) : '';
		$s = mb_convert_kana( $s, 'asKV');
		$query->set( 's' , $s );

		// Exclude categories
		if ( !( isset($_GET['cat']) && !empty($_GET['cat']) ) ){
			if ( isset($_GET['exclude_cat']) && !empty($_GET['exclude_cat']) ){
				$query->set( 'cat', '-' . str_replace( ',', ',-', $_GET['exclude_cat'] ) );
			}
		}

		// Period
		if ( isset($_GET['range']) && !empty($_GET['range']) ){
			$range = explode( ' - ', urldecode($_GET['range']) );

			if ( isset($range) && is_array($range)) {
				if ( count($range) === 1 ) {
					$query->set( 'date_query', array(
						array(
							'inclusive' => true,
							'after' => $range[0]
						)
					) );
				} else if ( count($range) === 2 ) {
					$query->set( 'date_query', array(
						array(
							'compare' => 'BETWEEN',
							'inclusive' => true,
							'before' => $range[1],
							'after' => $range[0]
						)
					) );
				}
			}
		}

		// Post type
		if ( ! (isset($_GET['post_type']) && !empty($_GET['post_type']) && $_GET['post_type'] !== 'any') ){
			if ( isset($_GET['hidden_post_type']) && !empty($_GET['hidden_post_type']) && $_GET['hidden_post_type'] !== 'any' ) {
				$query->set( 'post_type', $_GET['hidden_post_type'] );
			}
		}

		// Tags
		if ( isset($_GET['tag']) && !empty($_GET['tag']) ){
			if (isset($_GET['and-or']) && !empty($_GET['and-or'])){
				if ($_GET['and-or'] === 'OR') {
					// OR
					$query->set( 'tag_slug__in', $_GET['tag'] );
				} else {
					// AND
					$query->set( 'tag_slug__and', $_GET['tag'] );
				}
			}
		}

		if ( isset($options['number_posts_search'.$suffix]) && !empty($options['number_posts_search'.$suffix]) ) {
			$query->set( 'posts_per_page', $options['number_posts_search'.$suffix] );
		}
	}

	else if ( $query->is_category() ) {

		$q_obj = get_queried_object();
		$meta = ( isset( $q_obj ) && ( isset( $q_obj->cat_ID ) && !empty( $q_obj->cat_ID ) ) ) ? get_option('ex_term_meta_' . $q_obj->cat_ID) : null;

		if ( !empty($meta) ) {
			// Sort
			if ( !(isset($_GET['sort']) && !empty($_GET['sort'])) ) {
				if ( isset($meta['orderby']) && !empty($meta['orderby']) ) {
					if ( $meta['orderby'] === 'post_views_count' ) {
						$query->set( 'orderby', 'meta_value_num' );
						$query->set( 'meta_key', $meta['orderby'] );
					} else {
						$query->set( 'orderby', $meta['orderby'] );

						if ( $meta['orderby'] == 'name' || $meta['orderby'] == 'title' ){
							$query->set( 'order', 'ASC' );
						}
					}
				}
			}

			// Number of posts
			if ( isset($meta['number_posts'.$suffix]) && !empty($meta['number_posts'.$suffix]) ) {
				$query->set( 'posts_per_page', $meta['number_posts'.$suffix] );
			} else {
				if ( isset($options['number_posts_category'.$suffix]) && !empty($options['number_posts_category'.$suffix]) ) {
					$query->set( 'posts_per_page', $options['number_posts_category'.$suffix] );
				}
			}
		} else {
			if ( isset($options['number_posts_category'.$suffix]) && !empty($options['number_posts_category'.$suffix]) ) {
				$query->set( 'posts_per_page', $options['number_posts_category'.$suffix] );
			}
		}
	}

	else if ( $query->is_tag() ) {

		$q_obj = get_queried_object();
		$meta = isset( $q_obj->term_taxonomy_id ) ? get_option('ex_term_meta_' . $q_obj->term_taxonomy_id) : null;

		if ( !empty($meta) ) {
			// Sort
			if ( !(isset($_GET['sort']) && !empty($_GET['sort'])) ) {
				if ( isset($meta['orderby']) && !empty($meta['orderby']) ) {
					if ( $meta['orderby'] === 'post_views_count' ) {
						$query->set( 'orderby', 'meta_value_num' );
						$query->set( 'meta_key', $meta['orderby'] );
					} else {
						$query->set( 'orderby', $meta['orderby'] );

						if ( $meta['orderby'] == 'name' || $meta['orderby'] == 'title' ){
							$query->set( 'order', 'ASC' );
						}
					}
				}
			}

			// Number of posts
			if ( isset($meta['number_posts'.$suffix]) && !empty($meta['number_posts'.$suffix]) ) {
				$query->set( 'posts_per_page', $meta['number_posts'.$suffix] );
			} else {
				if ( isset($options['number_posts_tag'.$suffix]) && !empty($options['number_posts_tag'.$suffix]) ) {
					$query->set( 'posts_per_page', $options['number_posts_tag'.$suffix] );
				}
			}
		} else {
			if ( isset($options['number_posts_tag'.$suffix]) && !empty($options['number_posts_tag'.$suffix]) ) {
				$query->set( 'posts_per_page', $options['number_posts_tag'.$suffix] );
			}
		}
	}

	else if ($query->is_date() && $options['number_posts_date'.$suffix] ) {
		$query->set( 'posts_per_page', $options['number_posts_date'.$suffix] );
	}

	else if ($query->is_author() && $options['number_posts_author'.$suffix] ) {
		$query->set( 'posts_per_page', $options['number_posts_author'.$suffix] );
	}
}

add_action( 'pre_get_posts', 'dp_custom_pre_get_posts' );