<?php
/**
 * Call theme support
 */
function dp_after_setup_theme() {
	global $options, $wp_version, $IS_WOOCOMMERCE;

	// Post thumbnail
	add_theme_support('post-thumbnails');
	// Custom menu
	add_theme_support('menus');
	// Feed links
	add_theme_support( 'automatic-feed-links' );
	// Auto title tag (WP4.1 over)
    if ( version_compare( $wp_version, '4.1', '>=' ) ) {
        add_theme_support('title-tag');
    }

	// Password form
	remove_filter( 'the_password_form', 'custom_password_form' );
	add_filter('the_password_form', 'dp_password_form');

	// Theme customizer
	add_theme_support('custom-background');
	add_theme_support('custom-header');

	// Post formats
	add_theme_support( 'post-formats', array(
		'aside',
		'gallery',
		'image',
		'link',
		'quote',
		'status',
		'video',
		'audio',
		'chat'
	) );

	// Enable support for HTML5 markup.
	add_theme_support( 'html5', array(
		'comment-list',
		'search-form',
		'comment-form',
		'gallery',
		'caption'
	) );
	// Indicate widget sidebars can use selective refresh in the Customizer.(WP4.7)
	add_theme_support('customize-selective-refresh-widgets');
	// Support woocommerce
	add_theme_support( 'woocommerce' );
	add_theme_support( 'wc-product-gallery-zoom' );
	add_theme_support( 'wc-product-gallery-lightbox' );
	add_theme_support( 'wc-product-gallery-slider' );
	add_filter( 'woocommerce_get_image_size_gallery_thumbnail', function( $size ) {
		return array(
		'width' => 300,
		'height' => 300,
		'crop' => 1,
		);
	} );

	add_theme_support( 'align-wide' );
	add_theme_support( 'editor-styles' );

}
add_action( 'after_setup_theme', 'dp_after_setup_theme' );