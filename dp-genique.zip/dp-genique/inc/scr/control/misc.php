<?php
/**
* Create Uinique ID
*/
function dp_rand($sha1 = false) {
	$str_rand = (bool)$sha1 ? sha1(uniqid(mt_rand())) : uniqid(mt_rand(100,500));
	return $str_rand;
}

/**
 * For url cache control
 */
function echo_filedate($filename) {
    if (file_exists($filename)) {
        return date_i18n('YmdHis', filemtime($filename));
    } else {
    	return date_i18n('Ymd');
    }
}

/**
 * HEX to RGB
 */
function dp_hex_to_rgb($color) {
	$color = preg_replace("/^#/", '', $color);
	if (mb_strlen($color) == 3) $color .= $color;
	$rgb = array();
	for($i = 0; $i < 6; $i+=2) {
		$hex = substr($color, $i, 2);
		$rgb[] = hexdec($hex);
	}
	return $rgb;
}

/**
 * Lightens/darkens a given colour (hex format), returning the altered colour in hex format.7
 * @param str $hex Colour as hexadecimal (with or without hash);
 * @percent float $percent Decimal ( 0.2 = lighten by 20%(), -0.4 = darken by 40%() )
 * @return str Lightened/Darkend colour as hexadecimal (with hash);
 */
function dp_color_luminance( $hex, $percent ) {

	// validate hex string
	$hex = preg_replace( '/[^0-9a-f]/i', '', $hex );
	$new_hex = '#';

	if ( strlen( $hex ) < 6 ) {
		$hex = $hex[0] + $hex[0] + $hex[1] + $hex[1] + $hex[2] + $hex[2];
	}

	// convert to decimal and change luminosity
	for ($i = 0; $i < 3; $i++) {
		$dec = hexdec( substr( $hex, $i*2, 2 ) );
		$dec = min( max( 0, $dec + $dec * $percent ), 255 );
		$new_hex .= str_pad( dechex( (int)$dec ) , 2, '0', STR_PAD_LEFT );
	}

	$rgb = dp_hex_to_rgb( $new_hex );

	if ( ! is_array($rgb) ) {
		$rgb = array(0, 0, 0);
	}

	return $rgb;
}

/* Function that Rounds To The Nearest Value.
   Needed for the pagenavi() function */ 
function dp_round_num($num, $to_nearest) {
	/*Round fractions down (http://php.net/manual/en/function.floor.php)*/
   return floor($num/$to_nearest)*$to_nearest;
}

/**
 * Published time diff
 */
function dp_published_diff(){
	$from 	= get_post_time('U',true); 	// Published datetime
	$to 	= time(); 				// Current time
	$diff 	= $to - $from; 			// Diff
	$code 	= '';
	if ( $diff < 0 ) {
		$code = human_time_diff( $from, $to ) . __(' ago','DigiPress');
	} elseif ( abs($diff) <= 86400 ) {
		// Posted in less than 24 hours
		// $code = '<span><time datetime="'.get_the_date('c').'">'.__('This article was posted in less than 24 hours.','DigiPress').'</time></span>';
		$code = human_time_diff( $from, $to ) . __(' ago','DigiPress');
	} else {
		$code = human_time_diff( $from, $to ) . __(' ago','DigiPress');
	}
	return $code;
}


/**
 * Retrieve the icon based on article format
 * @param  String $format article format type
 * @return String         theme icon
 */
function post_format_icon($format) {
	$titleIconClass = 'fmt-icon ';
	switch  ($format) {
		case 'aside':
			$titleIconClass .= 'icon-pencil';
			break;
		case 'gallery':
			$titleIconClass .= 'icon-pictures';
			break;
		case 'image':
			$titleIconClass .= 'icon-picture';
			break;
		case 'quote':
			$titleIconClass .= 'icon-quote-left';
			break;
		case 'status':
			$titleIconClass .= 'icon-comment';
			break;
		case 'video':
			$titleIconClass .= 'icon-video-play';
			break;
		case 'audio':
			$titleIconClass .= 'icon-music';
			break;
		case 'chat':
			$titleIconClass .= 'icon-comment';
			break;
		case 'link':
			$titleIconClass .= 'icon-link';
			break;
		default:
			$titleIconClass .= 'icon-dot-menu2';
			break;
	}

	return $titleIconClass;
}