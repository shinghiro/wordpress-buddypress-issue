<?php
/**
 * Original search form
 * @param  boolean $echo    show form or not
 * @param  array   $arr_arg form parameters
 * @return [type]           form code or null
 */
function dp_custom_search_form( $echo = true, $arr_arg = array(
		'form_id' => '',
		'param_cat' => false,	// Whether to show selectable categories
		'exclude_cat' => '',	// Excluded category ids
		'exclude_tag' => '',	// Excluded tag ids
		'exclude_type' => '',	// Excluded post type slugs
		'target_type' => '', 	// Target post type
		'param_tag' => false,	// Whether to show selectable tags
		'param_type' => false,	// Whether to show selectable all post types
		'param_range' => false,	// Whether to show date range calendar
		'param_word_area_title' => '',
		'param_cat_area_title' => '',
		'param_tag_area_title' => '',
		'param_type_area_title' => '',
		'param_range_area_title' => '',
		'preset_phrase' => '',	// Preset search words area title
		'preset_words' => '', // Preset search words (Commna needs to devide each word)
		'show_input_title' => true // Whether to show search word input form title
		) ) {

	global $IS_MOBILE_DP;

	extract($arr_arg);

	$form = $preset_form = $tag_and_or_form = $kw_title = $kw_submit_btn = $post_type_preset = $current_post_type = $current_cat = $current_range = '';
	$current_tags = $arr_exclude_type = array();
	$form_class = 'search-form';

	$form_class .= $IS_MOBILE_DP ? ' mb' : '';

	// Form ID
	$form_id = isset($form_id) && !empty($form_id) ?' id="' . $form_id . '"' : '';

	// Preset phrase
	if ( isset($preset_words) && !empty($preset_words) ) {
		// Post type
		if ( isset($target_type) && !empty($target_type) && $target_type !== 'any' ) {
			$post_type_preset = '&hidden_post_type=' . $target_type;
		}

		$preset_words = explode( ',', $preset_words );
		if ( is_array($preset_words) ){
			foreach ($preset_words as $word) {
				$word = trim($word);
				$form .= '<a href="' . home_url('/') . '?s=' . urlencode($word) . $post_type_preset . '" class="pword">' . $word . '</a>';
			}
			$form = '<div class="preset-words-area scrollable axis-x">' . $form . '</div>';
		}

		if ( isset($preset_phrase) && !empty($preset_phrase) ) {
			$form = '<h3 class="wd-block-title">' . htmlspecialchars_decode($preset_phrase) . '</h3>' . $form;
		}

		$form = '<div class="s-param preset">' . $form . '</div>';
	}

	// Custom Post type
	if ( isset($param_type) && !empty($param_type) ) {
		if ( is_search() ){
			if (isset($_GET['post_type']) && !empty($_GET['post_type'])){
				$current_post_type = $_GET['post_type'];
			}
		}

		$form .= '<div class="s-param post-type">';

		// Title
		if ( isset($param_type_area_title) && !empty($param_type_area_title) ) {
			$form .= '<h3 class="wd-block-title">' . $param_type_area_title . '</h3>';
		} else {
			$form .= '<h3 class="wd-block-title">' . __( 'Target contents', 'DigiPress' ) . '</h3>';
		}

		// Exclude
		if ( isset($exclude_type) && !empty($exclude_type) ) {
			$arr_exclude_type = explode( ',', $exclude_type );
		}

		$form .= '<select class="s-select" name="post_type">
<option value="any">' . __( 'All', 'DigiPress' ) . '</option>';

		if ( $current_post_type === 'post' ){
			$form .= '<option value="post" selected>' . __( 'Posts', 'DigiPress' ) . '</option>';
		} else {
			$form .= '<option value="post">' . __( 'Posts', 'DigiPress' ) . '</option>';
		}

		// Custom post types
		$types = get_post_types(
			array(
				'public'	=> true,
				'_builtin'	=> false
			), 'objects');
		foreach ($types as $key => $cpt ) {
			// Throw
			if ( is_array($arr_exclude_type) ) {
				if ( in_array( $cpt->name, $arr_exclude_type ) === true ) continue;
			}

			// Form
			if ( $current_post_type === $cpt->name ) {
				$form .= '<option value="'.$cpt->name.'" selected>'.esc_html($cpt->label).'</option>';
			} else {
				$form .= '<option value="'.$cpt->name.'">'.esc_html($cpt->label).'</option>';
			}
		}
		$form .= '</select></div>';
	}

	// Category
	if ( isset($param_cat) && !empty($param_cat) ) {
		// if search result page and check the url params
		if ( is_search() ){
			if (isset($_GET['cat']) && !empty($_GET['cat'])){
				$current_cat = $_GET['cat'];
			}
		}

		$form .='<div class="s-param cat">';

		if ( isset($exclude_cat) && !empty($exclude_cat) ) {
			$form .= '<input type="hidden" name="exclude_cat" value="' . $exclude_cat . '" />';
		} else {
			$exclude_cat = '';
		}

		// Title
		if ( isset($param_cat_area_title) && !empty($param_cat_area_title) ) {
			$form .= '<h3 class="wd-block-title">' . $param_cat_area_title . '</h3>';
		} else {
			$form .= '<h3 class="wd-block-title">' . __( 'Category', 'DigiPress' ) . '</h3>';
		}

		$form .= wp_dropdown_categories( array(
			'echo' => 0,
			'show_option_all' => __( 'All', 'DigiPress' ),
			'class' => 's-select',
			'hierarchical' => 1,
			'selected' => $current_cat,
			'exclude' => $exclude_cat
		) );

		$form .= '</div>';
	}

	// Tag
	if ( isset($param_tag) && !empty($param_tag) ) {
		$checkboxes = '';
		$chk_flg = false;

		$tag_and_or_form = '<label class="item-lbl"><input type="radio" name="and-or" value="AND" checked /> ' . __( 'Include all', 'DigiPress' ) . '</label><label class="item-lbl"><input type="radio" name="and-or" value="OR" /> ' . __( 'Include any', 'DigiPress' ) . '</label>';

		if ( is_search() ){
			if (isset($_GET['tag']) && !empty($_GET['tag'])){
				$current_tags = $_GET['tag'];
			}
			if (isset($_GET['and-or']) && !empty($_GET['and-or'])){
				if ($_GET['and-or'] === 'OR') {
					$tag_and_or_form = '<label class="item-lbl"><input type="radio" name="and-or" value="AND" /> ' . __( 'Include all', 'DigiPress' ) . '</label><label class="item-lbl"><input type="radio" name="and-or" value="OR" checked /> ' . __( 'Include any', 'DigiPress' ) . '</label>';
				}
			}
		}

		$form .= '<div class="s-param tags">';

		// Title
		if ( isset($param_tag_area_title) && !empty($param_tag_area_title) ) {
			$form .= '<h3 class="wd-block-title">' . $param_tag_area_title . '</h3>';
		} else {
			$form .= '<h3 class="wd-block-title">' . __( 'Tags', 'DigiPress' ) . '</h3>';
		}

		$form .= '<div class="inner-block scrollable axis-y">';

		// get tags
		if ( isset($exclude_tag) && !empty($exclude_tag) ) {
			$tags = get_tags( array('exclude' => $exclude_tag) );
		} else {
			$tags = get_tags();
		}

		// Export form
		foreach( $tags as $tag ) {
			foreach ($current_tags as $ctag) {
				if ( $tag->slug === $ctag ) {
					$checkboxes .= '<label class="item-lbl"><input type="checkbox" name="tag[]" value="' . $tag->slug . '" checked /> ' . $tag->name . '</label>';
					$chk_flg = true;
					break;
				}
			}
			if ( !$chk_flg ) {
				$checkboxes .= '<label class="item-lbl"><input type="checkbox" name="tag[]" value="' . $tag->slug . '" /> ' . $tag->name . '</label>';
			}
			$chk_flg = false;
		}
		$form .= $checkboxes . '</div>
<div class="inner-block">'.$tag_and_or_form.'</div>
</div>';
	}

	// Date
	if ( isset($param_range) && !empty($param_range) ) {
		wp_enqueue_style( 'air-datepicker', DP_THEME_URI.'/css/datepicker.min.css', null, DP_OPTION_SPT_VERSION );
		wp_enqueue_script( 'air-datepicker', DP_THEME_URI.'/inc/js/jquery/datepicker/jquery.datepicker.min.js', array('jquery'), DP_OPTION_SPT_VERSION, true);

		if ( is_search() ){
			if (isset($_GET['range']) && !empty($_GET['range'])){
				$current_range = urldecode($_GET['range']);
			}
		}

		// Calendar language
		$locale = get_locale() === 'ja' ? 'ja' : 'en';

		$form .= '<div class="s-param range">';

		// Title
		if ( isset($param_range_area_title) && !empty($param_range_area_title) ) {
			$form .= '<h3 class="wd-block-title">' . $param_range_area_title . '</h3>';
		} else {
			$form .= '<h3 class="wd-block-title">' . __( 'Range of date', 'DigiPress' ) . '</h3>';
		}

		$form .= '<div class="inner-block">
<input type="text" class="full-width datepicker-here" name="range" placeholder="'.__('Enter the search period', 'DigiPress').'" data-position="top left" data-language="'.$locale.'" data-range="true" data-multiple-dates-separator=" - " data-date-format="yyyy/m/d" data-clear-button="true" data-auto-close="true" value="'.$current_range.'" readonly />
</div>
</div>';
	}

	// Target post type (hidden)
	if ( isset($target_type) && !empty($target_type) && $target_type !== 'any' ) {
		$form .= '<input type="hidden" name="hidden_post_type" value="' . $target_type . '" />';
	}

	// Search parameter area
	if ( empty($form) ) {
		$form_class .= ' no-params';
		$kw_submit_btn = '<button type="submit" class="search-btn"><i class="icon-search"></i></button>';
	} else {
		$form_class .= ' with-params';

		if ( isset($show_input_title) && $show_input_title ){
			// Title
			if ( isset($param_word_area_title) && !empty($param_word_area_title) ) {
				$kw_title = '<h3 class="wd-block-title">' . $param_word_area_title . '</h3>';
			} else {
				$kw_title = '<h3 class="wd-block-title">' . __( 'Search words', 'DigiPress' ) . '</h3>';
			}
		}
		$form =
'<div class="params-area">' . $form . '</div>
<div class="submit-area"><button type="submit" class="search-btn"><i class="icon-search"></i><span>' . __( 'Search', 'DigiPress' ) . '</span></button></div>';
	}


	// Wrapping form
	$form =
'<form role="search" method="get" class="' . $form_class . '" action="' . esc_url( home_url( '/' ) ) . '"'.$form_id.'>' . $kw_title . '
<div class="words-area">
<label>
	<span class="screen-reader-text">' . __( 'Search', 'DigiPress' ) . '</span>
	<input type="search" class="search-field" placeholder="' . esc_attr( __('Enter keywords', 'DigiPress' ) ) . '" value="' . get_search_query() . '" name="s" title="' . esc_attr( __('Search', 'DigiPress') ) . '" required />
</label>' . $kw_submit_btn . '</div>' . $preset_form . $form . '</form>';

	$form = str_replace( array( "\r\n", "\r", "\n", "\t" ), '', $form);

	if ($echo) {
		echo $form;
	} else {
		return $form;
	}
}