<?php
/**
 * Infeed ads
 * @return string            infeed ads code
 */
function dp_get_infeed_ads($arr_params = array(
	'top_or_archive' => '',
	'suffix_mb' => '',
	'post_num' => '',
	'infeed_ads_order' => '',
	'infeed_ads_code' => '',
	'wrapper_before' => '<div class="loop-article infeed">',
	'wrapper_after' => '</div>')){

	extract($arr_params);

	if ( is_array( $infeed_ads_order ) ) {
		foreach ( $infeed_ads_order as $ads_num ) {
			if ( $ads_num == $post_num ) {
				return $wrapper_before.$infeed_ads_code.$wrapper_after;
			}
		}
	}
	else if ( $post_num == $infeed_ads_order ) {
		return $wrapper_before.$infeed_ads_code.$wrapper_after;
	}
}