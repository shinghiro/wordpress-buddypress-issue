<?php
function dp_get_related_posts() {

	if ( !is_singular() ) return;
	if ( post_password_required() ) return;

	global $post, $options, $ARCHIVE_STYLE, $COLUMN_NUM, $IS_MOBILE_DP;

	if ( get_post_meta( $post->ID, 'dp_hide_related_posts', true ) ) return;

	// Get queried object array
	$cats = get_the_category();
	if ( is_array( $cats ) && isset( $cats[0]->cat_ID ) ) {
		// Get custom archive fields
		$term_meta = get_option( 'ex_term_meta_' . $cats[0]->cat_ID );
		// Return when this post category is set to hide related posts
		if ( isset( $term_meta['hide_rel_posts'] ) && !empty( $term_meta['hide_rel_posts'] ) ) return;
	}


	$post_type 				= get_post_type() ?? '';
	$related_posts_style 	= $options['related_posts_style'] ?? 'horizontal';
	$related_posts_target 	= $options['related_posts_target'] ?? 'same_cat';


	/**
	 * Check the transient data and return the cache if cache is exists
	 */
	if ( dp_is_enable_cache( array( 'target' => 'related_posts' ) ) ){
		if ( $related_posts_target !== 'same_cat_rand' ) {
			$cache = false;
			if ( $IS_MOBILE_DP ){
				$cache = get_transient( 'dp_rel_posts_mb_' . $post->ID );
			} else {
				$cache = get_transient( 'dp_rel_posts_' . $post->ID );
			}
			if ( $cache !== false ) {
				echo $cache;
				return;
			}
		}
	}


	$code = $cats_code = $mb_suffix	= $mb_class	= '';
	$col_css	= ' two-col';

	// Main title
	$main_title = get_post_meta($post->ID, 'dp_related_posts_title', true);
	if (!(isset($main_title) && !empty($main_title))) {
		$main_title = !empty($options['related_posts_title']) ? $options['related_posts_title'] : __('YOU MIGHT ALSO LIKE','DigiPress');
	}


	if ((bool)$IS_MOBILE_DP) {

		$mb_suffix = '_mobile';
		$mb_class = ' mb';

	} else {
		// Column
		if ($COLUMN_NUM === 1 || get_post_meta(get_the_ID(), 'disable_sidebar', true)) {
			$col_css	= ' one-col';
			// Narrow content width
			if ( (bool)get_post_meta(get_the_ID(), 'one_col_narrow', true)) {
				$col_css .= ' narrow';
			}
		} else if ($COLUMN_NUM === 3) {
			$col_css	= ' three-col';
		}
	}


	// wow.js
	$wow_title_css 			= '';
	$wow_article_css 		= '';
	if ( !isset( $options['disable_wow_js'.$mb_suffix] ) || empty( $options['disable_wow_js'.$mb_suffix] ) ) {
		$wow_title_css		= ' wow fadeInDown';
		$wow_article_css 	= ' wow fadeInUp';
	}


	// Anchor selector
	$item_link_class = 'list-link';
	// $thumb_link_class = 'thumb-link';
	$cat_code = '';

	// *****************************
	// Main display
	// *****************************
	if ($post_type !== 'post' && $post_type !== 'page' && $post_type !== 'attachment' && $post_type !== 'revision') {
		// ***********************************
		// Probably Custom post type
		// ***********************************
		// Get title
		$customPostTypeObj 		= get_post_type_object( $post_type );
		$customPostTypeTitle 	= esc_html( $customPostTypeObj->labels->name );
		// More link
		$more_url 				= get_post_type_archive_link( $post_type );
		if ( !empty($more_url) ) {
			$more_url = '<div class="more-entry-link"><a href="'.$more_url.'"><span>'.__('See more', 'DigiPress').'</span></a></div>';
		}

		// Get posts
		$latest =  get_posts('numberposts='.$options['number_related_posts'].'&post_type='.$post_type.'&exclude='.$post->ID);


		// Start source
		$code = '<aside class="dp_related_posts news' . $col_css.$mb_class . '"><h3 class="inside-title' . $wow_title_css .'"><span>' . __('Other posts of ', 'DigiPress') . $customPostTypeTitle . '</span></h3><ul>';

		// Show posts of custom post type
		foreach( $latest as $post ) {
			setup_postdata($post);

			$code .= '<li class="' . $wow_article_css . '"><span class="meta-date">' . get_the_date() . '</span><a href="' . get_the_permalink() . '" class="rel-post-title list-link">' . get_the_title() . '</a></li>';
		}
		wp_reset_postdata();

		$code .= '</ul>' . $more_url . '</aside>';


	} elseif ( ( $post_type === 'post' ) && is_single() && isset( $options['show_related_posts'] ) && !empty( $options['show_related_posts'] ) ) {

		// ***********************************
		// Probably single post
		// ***********************************
		// Thumbnail size
		$width = 250;
		$height = 154;
		$if_img_tag = false;
		$arg_thumb = array( 'width' => $width, 'height' => $height, 'size' => 'dp-related-thumb', 'if_img_tag' => $if_img_tag );
		$title_length = 48;

		// Type
		if ( $related_posts_style === 'horizontal') {
			$type = ' horizontal';
		} else {
			$type = ' vertical';
			$title_length = 62;
		}


		// Start source
		$code = '<aside class="dp_related_posts clearfix' . $type . $col_css . $mb_class . '"><h3 class="inside-title' . $wow_title_css . '"><span>' . $main_title . '</span></h3><ul>';

		// Get related posts
		$number_posts = $options['number_related_posts'] ?? 8;
		// Target
		if ($related_posts_target == 'same_cat') {
			$cat = get_the_category();
			$cat = $cat[0];
			$args = array(
				'numberposts'	=> $number_posts,
				'category'		=> $cat->cat_ID,
				'exclude'		=> $post->ID
				);

		} else if ( $related_posts_target == 'same_cat_rand' ) {
			$cat = get_the_category();
			$cat = $cat[0];
			$args = array(
				'numberposts'	=> $number_posts,
				'category'		=> $cat->cat_ID,
				'exclude'		=> $post->ID,
				'orderby'		=> 'rand'
				);

		} else {
			$tagIDs		= array();
			$tags		= wp_get_post_tags( $post->ID );
			if ( is_array($tags) ){
				$tagcount 	= count($tags);
				for ($i = 0; $i < $tagcount; ++$i) {
					$tagIDs[$i] = $tags[$i]->term_id;
				}
			}
			$args = array(
				'tag__in'			=> $tagIDs,
				'post__not_in'		=> array( $post->ID ),
				'numberposts'		=> $number_posts,
				'exclude'			=> $post->ID,
				'ignore_sticky_posts'	=> 1
				);
		}

		// Query
		$my_query = get_posts($args);

		// Display
		if ( $my_query ) {
			foreach ( $my_query as $post ) {
				setup_postdata( $post );

				$thumb_url = $cats_code = '';
				// Title
				$title = the_title( '', '', false );
				$title = esc_attr($title);
				$anchor_code = 'href="' . get_the_permalink() . '" title="' . the_title_attribute( array( 'before' => '', 'after' => '', 'echo' => false ) ) . '"';


				// Source
				$code .= '<li class="' . $wow_article_css . '"><a ' . $anchor_code . ' class="' . $item_link_class . '">';

				if ( $related_posts_style === 'horizontal' ) {
					if ( mb_strlen( $title, 'utf-8' ) > $title_length ) $title = mb_substr( $title, 0, ( $title_length - 1 ), 'utf-8' ) . '...';
				}

				// Thumbnail
				$thumb_code = DP_Post_Thumbnail::get_post_thumbnail($arg_thumb);
				$code .= '<div class="widget-post-thumb"><figure class="post-thumb"><img src="' . $thumb_code . '" alt="Thumbnail" width="120" height="80" class="thumb-img" /></figure></div>';

				// Category
				if ( $options['related_posts_category'] ) {
					$cats = get_the_category();
					if ($cats) {
						$cats = $cats[0];
						$cat_color_class = " term-color".$cats->cat_ID;
						$cats_code = '<div class="meta-cat"><span class="cat-link ' . $cat_color_class . '"><span class="cat-name">' . $cats->cat_name . '</span></span></div>';
					}
				}

				// Source
				$code .= '<div class="excerpt_div has_thumb">' . $cats_code . '<h4 class="excerpt_title_wid">' . $title . '</h4></div></a></li>';
			}	// End of foreach
			wp_reset_postdata();

		} else {
			// Not found
			$code .= '<li>' . __('No related posts yet.', 'DigiPress') . '</li>';
		}

		// End
		$code .= '</ul></aside>';
	}	// End of "Main display"



	/**
	 * Save to cache
	 */
	if ( dp_is_enable_cache( array( 'target' => 'related_posts' ) ) ){
		if ( $related_posts_target !== 'same_cat_rand' ) {
			if ( $IS_MOBILE_DP ){
				set_transient( 'dp_rel_posts_mb_' . $post->ID, $code, 0 );
			} else {
				set_transient( 'dp_rel_posts_' . $post->ID, $code, 0 );
			}
		}
	}

	echo $code;
}