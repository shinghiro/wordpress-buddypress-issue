<?php
/**
* Show SNS buttons in post meta part.
* @return	string or array
*/
function dp_show_sns_buttons_original($echo = true) {
	global $options, $IS_MOBILE_DP;

	$html_code = $no_share_num_flag = $share_num_prefix = $share_num_suffix = $share_num = $code1 = $code2 = '';

	$url = urlencode(get_permalink());
	$title = urlencode(get_the_title().' | '.get_bloginfo('name'));
	$rss_url = urlencode(get_bloginfo('rss2_url'));

	if (isset($options['disable_sns_share_count']) && !empty($options['disable_sns_share_count'])){
		$no_share_num_flag = ' no-num';
	} else {
		$share_num_prefix = '<span class="share-num">';
		$share_num_suffix = '</span>';
	}

	// *** row1
	if ($options['show_sns_button_facebook']) {
		$code1 = '<div class="sitem bg-likes ct-fb"><a href="https://www.facebook.com/sharer/sharer.php?u='.$url.'&t='.$title.'" target="_blank" rel="nofollow"><i class="share-icon fb icon-facebook"></i>'.$share_num_prefix.$share_num_suffix.'</a><div class="sname">Facebook Likes</div></div>';
	}
	if ($options['show_sns_button_twitter']) {
		$code1 .= '<div class="sitem bg-tweets ct-tw"><a href="https://twitter.com/intent/tweet?original_referer='.$url.'&url='.$url.'&text='.$title.'" target="_blank" rel="nofollow"><i class="share-icon tw icon-twitter"></i>'.$share_num_prefix.$share_num_suffix.'</a><div class="sname">Tweets</div></div>';
	}
	if ($options['show_sns_button_hatena'] ) {
		$code1 .= '<div class="sitem bg-hatebu ct-hb"><a href="http://b.hatena.ne.jp/add?mode=confirm&url='.$url.'&title='.$title.'" target="_blank" rel="nofollow"><i class="share-icon hb icon-hatebu"></i>'.$share_num_prefix.$share_num_suffix.'</a><div class="sname">Hatena Bookmarks</div></div>';
	}
	if ($options['show_sns_button_pinterest']) {
		// Eyecatch ( for pinterest)
		$image_url = '';
		if (has_post_thumbnail(get_the_ID())) {
			$image_id = get_post_thumbnail_id(get_the_ID());
			$image_data = wp_get_attachment_image_src($image_id, array(800, 800), true); 
			$image_url = is_ssl() ? str_replace('http:', 'https:', $image_data[0]) : $image_data[0];
			$image_url = '&media='.urlencode($image_url);
		}
		$desc = urlencode(strip_tags(get_the_excerpt()));
		$code2 = '<div class="sitem bg-pinterest ct-pr"><a href="//www.pinterest.com/pin/create/button/?url='.$url.$image_url.'&description='.$desc.'" rel="nofollow" target="_blank"><i class="share-icon pr icon-pinterest"></i>'.$share_num_prefix.$share_num_suffix.'</a><div class="sname">Pinterest</div></div>';
	}

	// *** row2
	if ($options['show_sns_button_pocket']) {
		if ( !(isset($options['disable_sns_share_count']) && !empty($options['disable_sns_share_count'])) ){
			$share_num = dp_get_pocket_subscribers();
		} else {
			$share_num = '';
		}
		$code2 .= '<div class="sitem bg-pocket ct-pk"><a href="https://getpocket.com/edit?url='.$url.'" target="_blank"><i class="share-icon pk icon-pocket"></i>'.$share_num_prefix.$share_num.$share_num_suffix.'</a><div class="sname">Pocket</div></div>';
	}
	if ($options['show_sns_button_evernote']) {
		if ( !(isset($options['disable_sns_share_count']) && !empty($options['disable_sns_share_count'])) ){
			$share_num = '<i class="icon-attach"></i>';
		}
		$code2 .= '<div class="sitem bg-evernote"><a href="https://www.evernote.com/noteit.action?url='.$url.'&title='.$title.'" target="_blank"><i class="share-icon en icon-evernote"></i>'.$share_num_prefix.$share_num.$share_num_suffix.'</a><div class="sname">Evernote</div></div>';
	}
	if ($options['show_sns_button_feedly']) {
		if ( !(isset($options['disable_sns_share_count']) && !empty($options['disable_sns_share_count'])) ){
			$share_num = dp_get_feedly_subscribers();
		} else {
			$share_num = '';
		}
		$code2 .= '<div class="sitem bg-feedly"><a href="https://feedly.com/i/subscription/feed/'.$rss_url.'" target="_blank" rel="nofollow"><i class="share-icon fl icon-feedly"></i>'.$share_num_prefix.$share_num.$share_num_suffix.'</a><div class="sname">Feedly</div></div>';
	}
	if ($options['show_sns_button_line']) {
		if ( !(isset($options['disable_sns_share_count']) && !empty($options['disable_sns_share_count'])) ){
			$share_num = '<i class="icon-email"></i>';
		} else {
			$share_num = '';
		}

		if ( $IS_MOBILE_DP ) {
			$code2 .= '<div class="sitem bg-line"><a href="line://msg/text/' . $title . '%0D%0A' . $url . '"><i class="share-icon ln icon-line"></i>'.$share_num_prefix.$share_num.$share_num_suffix.'</a><div class="sname">Send to LINE</div></div>';
		} else {
			$code2 .= '<div class="sitem bg-line"><a href="https://lineit.line.me/share/ui?url='.$url.'" target="_blank"><i class="share-icon ln icon-line"></i>'.$share_num_prefix.$share_num.$share_num_suffix.'</a><div class="sname">Send to LINE</div></div>';
		}
	}

	if (!empty($code1) || !empty($code2)) {
		$html_code = '<div class="loop-share-num ct-shares'.$no_share_num_flag.'" data-url="'.get_permalink().'"><div class="stitle">Share / Subscribe</div>'.$code1.$code2.'</div>';
	}

	if ($echo) {
		echo $html_code;
	} else {
		return $html_code;
	}
}