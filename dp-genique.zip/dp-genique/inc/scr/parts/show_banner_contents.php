<?php
/**
* Echo slider Javascript
*
* @return strings
*/
function dp_make_slider_js($selector = 'hd_slider') {
	if ( !(is_home() && !is_paged()) ) return;
	global $options, $IS_MOBILE_DP;

	$js_code = '';
	$params = 'init:false,';
	$transition_start_evt = '';
	$slide_change_transition_start_evt = '';
	$video_play_pause_func = '';
	$suffix_class = '';
	$replpace_bgimg_pg = '';
	$thumbnav_js_code = '';

	if ($IS_MOBILE_DP) {
		$suffix_class = '_mobile';
	}
	$type = $options['dp_header_content_type' . $suffix_class];
	$slider_style = $options['dp_slider_style' . $suffix_class];
	$target = $options['dp_slider_post_or_page' . $suffix_class];

	if ($type !== 'slideshow' && $type !== 'slideshow_selected_media') return;

	// autoplay
	if ( empty($options['dp_slider_disable_autoplay' . $suffix_class]) ) {
		$params .= isset($options['dp_slider_show_time' . $suffix_class]) ? "autoplay:{delay:" . $options['dp_slider_show_time' . $suffix_class]."}," : "autoplay:true,";
	}

	// Slider params
	switch ( $slider_style ) {
		case 'fade':
			$params .= "effect:'fade',";
			break;

		case 'horizontal':
			$params .= "effect:'slide',";
			break;

		case 'vertical':
			$params .= "direction:'vertical',";
			break;

		case 'thumb':
			$thumbnav_js_code =
"let navSlOpt = {
	loop:true,
	loopAdditionalSlides:parseInt(hdSl.dataset.sliderNum,10),
	speed:" . $options['dp_slider_transition_time' . $suffix_class] . ",
	spaceBetween:1,
	slidesPerView:5,
	centeredSlides:true,
	touchRatio:0.2,
	slideToClickedSlide:true,
	direction:'horizontal',
	breakpoints:{
		1023:{
			direction:'vertical'
		}
	},
	on:{
		init:function(){
			let c=this;
			setTimeout(function(){
				c.el.classList.remove('loading');
			},400);
		},
		click:function(){
			dpMainSlider.autoplay.stop();
		}
	}
};
let dpNavSlider = new Swiper('#nav_slider',navSlOpt);

dpMainSlider.controller.control = dpNavSlider;
dpNavSlider.controller.control = dpMainSlider;";

			$params .=
"loopAdditionalSlides:parseInt(hdSl.dataset.sliderNum,10),
grabCursor: true,";
			break;

		case 'split':
			$params .=
"slidesPerView:2,
slidesPerGroup:2,
loopFillGroupWithBlank:true,
loopAdditionalSlides:parseInt(hdSl.dataset.sliderNum,10),";
			break;

		case 'carousel':
			$params .= "slidesPerView:";
			$params .= $options['dp_header_area_show_bgimg'] ? '4,' : '5,';
			$params .= "spaceBetween:1,";
			break;

		case 'center three':
			$params .=
"slidesPerView:1,
centeredSlides:true,
spaceBetween:1,
breakpoints:{
	768:{
		slidesPerView:2
	}
},";
			break;
		case 'center five':
			$params .=
"slidesPerView:1,
centeredSlides:true,
spaceBetween:1,
breakpoints:{
	768:{
		slidesPerView:2
	},
	1260:{
		slidesPerView:4
	}
},";
			break;
		case 'coverflow one':
			$params .=
"effect:'coverflow',
slidesPerView:1,
centeredSlides:true,";
			break;
		case 'coverflow three':
			$params .=
"effect:'coverflow',
slidesPerView:1,
centeredSlides:true,
breakpoints:{
	1024:{
		slidesPerView:2
	}
},";
			break;
		case 'coverflow five':
			$params .=
"effect:'coverflow',
slidesPerView:1,
centeredSlides:true,
breakpoints:{
	1024:{
		slidesPerView:2
	},
	1366:{
		slidesPerView:4
	}
},";
			break;

		case 'creative one':
			$params .=
"effect:'creative',
creativeEffect:{
	prev: {
		shadow:true,
		translate:[0,0,-600],
	},
	next: {
		translate:['100%',0,0],
	},
},";
			break;
		case 'creative two':
			$params .=
"effect:'creative',
creativeEffect:{
	prev: {
		shadow:true,
		translate:['-30%',0,-1],
	},
	next: {
		translate:['100%',0,0],
	},
},";
			break;
		case 'creative three':
			$params .=
"effect:'creative',
creativeEffect:{
	prev: {
		shadow:true,
		translate:['-125%',0,-800],
		rotate:[0,0,-90],
	},
	next: {
		shadow:true,
		translate:['125%',0,-800],
		rotate:[0,0,90],
	},
},";
			break;
		case 'creative four':
			$params .=
"effect:'creative',
creativeEffect:{
	prev: {
		shadow:true,
		origin:'left center',
		translate:['-5%',0,0],
		rotate:[0,100,0],
	},
	next: {
		origin:'right center',
		translate:['5%',0,0],
		rotate:[0,-100,0],
	},
},";
			break;
		case 'creative five':
			$params .=
"effect:'creative',
creativeEffect:{
	prev: {
		shadow:true,
		origin:'center top',
		translate:[0,'-28.5%',-800],
		rotate:[100,0,0],
	},
	next: {
		origin:'center bottom',
		translate:[0,'28.5%',-800],
		rotate:[-100,0,0],
	},
},";
			break;
		case 'creative six':
			$params .=
"effect:'creative',
creativeEffect:{
	prev: {
		shadow:true,
		translate:[0,0,-1800],
		rotate:[0,-180,0],
	},
	next: {
		shadow:true,
		translate:[0,0,-1800],
		rotate:[0,180,0],
	},
},";
			break;
	}


	// Parallax
	$params .= ( $slider_style !== 'carousel' || $slider_style !== 'split' ) ? 'parallax:true,' : '';

	// transition tile
	$params .= isset($options['dp_slider_transition_time' . $suffix_class]) ? 'speed:' . $options['dp_slider_transition_time' . $suffix_class] . ',' : '';

	// navigation button
	if ( $options['dp_slider_nav_button'] && !$IS_MOBILE_DP ) {
		$params .= "navigation:{nextEl:'.swiper-button-next',prevEl:'.swiper-button-prev'},";
	}
	// pagination
	if ( $options['dp_slider_control_button'] && !$IS_MOBILE_DP ) {
		$params .= "pagination:{el:'#dp-sl-pagination',clickable:true},";
	}

	// Show padding and background image
	if ( !$IS_MOBILE_DP ) {
		if ( $slider_style === 'horizontal' || $slider_style === 'vertical' || $slider_style === 'fade'|| $slider_style === 'center three' || $slider_style === 'center five' || $slider_style === 'carousel' ) {
			if ( isset($options['dp_header_area_show_bgimg']) && !empty($options['dp_header_area_show_bgimg']) ) {
				$replpace_bgimg_pg = "dp_slider_set_bgimg(this.slides[dpMainSlider.activeIndex]);";
			}
		}
	}
	

	// Resize player for init and resize event
	$init_on_resize_player = !$IS_MOBILE_DP ? 'dp_resize_embed_player(sl,sl.children[e.activeIndex]);' : '';
	$init_resize_resize_player = '';
	if (!$IS_MOBILE_DP){
		$init_resize_resize_player =
",resize:function(){
	if (rTimer!==false) {
		clearTimeout(rTimer);
	}
	rTimer=setTimeout(function(){
		dp_resize_embed_player(hdSl,hdSl.getElementsByClassName('swiper-slide-active')[0]);
	},tmIntvl);
}";
	};


	// Play or pause video
	if ( !$IS_MOBILE_DP && $slider_style !== 'thumb' ) {
		if ( ( $slider_style !== 'horizontal' && $slider_style !== 'vertical' ) || !$options['dp_slider_parallax_transition'] ) {
			// Disable auto play video
			$video_play_pause_func = 'dp_slider_play_pause_video(e.slides,e.realIndex);';
		}
	}


	/**
	 * Events
	 */
	// transition start event (Except on progress event)
	if ( !empty($video_play_pause_func) || !empty($replpace_bgimg_pg) ) {
		$transition_start_evt = "transitionStart:function(e){" . $video_play_pause_func . $replpace_bgimg_pg."},";
	}


	// Parameters
	$params .=
"on:{" . $transition_start_evt . $slide_change_transition_start_evt . "
	init:function(e){
		let sl=e.\$wrapperEl[0];
		e.el.classList.remove('loading');
		" . $init_on_resize_player . "
	}" . $init_resize_resize_player . ",
},";

	$params .= 'loop:true';
	$params = "hdSlOpt={" . $params."},";

	$js_code =
"<script id=\"main_slider_js\">
(function(){
	let hdSl=document.getElementById('" . $selector . "'),
		rTimer,
		tmIntvl=Math.floor(1000/60*10),
		isHdSlMove=false," . $params . "
		dpMainSlider=new Swiper('#" . $selector . "',hdSlOpt),
		dpRunMainSlider=function(){
			setTimeout(function(){
				dpMainSlider.init();
				" . $thumbnav_js_code . "
			},400);
		};
	dpRunMainSlider();
})();
</script>";

	return $js_code;
}

/**
 * [dp_slider_post_or_page description]
 * @param  array  $params [description]
 * @return [type]         [description]
 */
function dp_slider_post_or_page( $params ) {
	$params = wp_parse_args(
		(array)$params,
		array(
			'width'				=> 1680,
			'height'			=> 1200,
			'selector'			=> 'hd_slider',
			'navigation_class'	=> 'hd-slide-nav',
			'control_class'		=> 'hd-slide-control',
			'top_edge_class'	=> '',
		)
	);

	global $post, $options, $ELEMENTS_SHOW, $IS_MOBILE_DP;

	extract($params);

	$mb_class = '';
	$selector .= ' swiper loading hero-slider' . $top_edge_class;
	$nav_selector = 'nav_slider swiper loading';
	$slide_class = 'swiper-slide ';
	$slide_content_class = 'sl-content';
	$slide_content_title_class = 'title ';
	$slide_content_cap_class = 'caption ';
	$suffix_class = $IS_MOBILE_DP ? '_mobile' : '';
	$post_thumb_size = 'full';
	$data_plx_media = '';
	$data_plx_content = '';
	$data_plx_title = '';
	$data_plx_category = '';
	$data_plx_date = '';
	$pagination_code = '';
	$nav_button_code = '';
	$thumbnav_code = '';
	$image_code = '';
	$slider_code = '';
	$slide_sizes = array();

	$arr_http = array( 'http:','https:' );
	$target = $options['dp_slider_post_or_page' . $suffix_class];
	$orderby = $options['dp_slider_order' . $suffix_class];
	$slider_style = $options['dp_slider_style' . $suffix_class];
	$style_class = ' style-' . $slider_style;


	// Image size
	if ( false !== strpos( $slider_style, 'carousel' ) || $slider_style === 'coverflow five' ){
		$post_thumb_size = 'dp-archive-thumb';
	}

	$num = $options['dp_number_of_slideshow' . $suffix_class];

	if ( $IS_MOBILE_DP ) {
		$width 	= 818;
		$height = 680;
		$mb_class = ' mb';
	} else {
		if ( $options['dp_slider_control_button'] ){
			$pagination_code = '<div id="dp-sl-pagination" class="swiper-pagination' . $style_class . '"></div>';
		}
		if ( $options['dp_slider_nav_button'] ){
			$nav_button_code = '<div class="swiper-nav-button-wrapper"><div class="swiper-button-prev"></div><div class="swiper-button-next"></div></div>';
		}
	}

	// Parallax transition for media
	if ( $options['dp_slider_parallax_transition' . $suffix_class] ) {

		// if ( $slider_style === 'horizontal' || $slider_style === 'vertical' || $slider_style === 'thumb' ) {
		// 	$plx_class = ' plx_on ';
		// }

		// Slide media parallax
		if ( $slider_style === 'fade' ) {
			$data_plx_media = ' data-swiper-parallax-scale="1.24"';
		}

		else if ( $slider_style === 'horizontal' || $slider_style === 'thumb' ) {
			$data_plx_media = ' data-swiper-parallax-x="60%"';
		}

		else if ( false !== strpos($slider_style, 'center' ) ) {
			$data_plx_media = ' data-swiper-parallax-x="20%" data-swiper-parallax-scale="1.4"';
		}

		else if ( $slider_style === 'vertical' ) {
			$data_plx_media = ' data-swiper-parallax-y="50%"';
		}
	}

	// Above text parallax
	if ( $slider_style !== 'carousel' ) {

		$data_plx_content = ' data-swiper-parallax-opacity="0"';

		if ( $slider_style === 'vertical' ) {
			$data_plx_title = ' data-swiper-parallax-y="300%" ';
			$data_plx_category = ' data-swiper-parallax-y="220%"';
			$data_plx_date = ' data-swiper-parallax-y="160%"';
		}

		else if ( $slider_style === 'fade' ) {
			$data_plx_title = ' data-swiper-parallax-scale="0.8"';
			$data_plx_category = ' data-swiper-parallax-scale="0.8"';
			$data_plx_date = ' data-swiper-parallax-scale="1.2"';
		}

		else if ( $slider_style === 'split' ) {
			$data_plx_title = ' data-swiper-parallax-x="40%"';
			$data_plx_category = ' data-swiper-parallax-x="60%"';
			$data_plx_date = ' data-swiper-parallax-x="80%"';
		}

		else {
			$data_plx_title = ' data-swiper-parallax-x="20%"';
			$data_plx_category = ' data-swiper-parallax-x="40%"';
			$data_plx_date = ' data-swiper-parallax-x="60%"';
		}
	}

	// Show padding and bacground image
	if ( $slider_style === 'horizontal' || $slider_style === 'vertical' || $slider_style === 'fade'|| $slider_style === 'center three' || $slider_style === 'center five' || $slider_style === 'carousel' ) {
		if ( isset($options['dp_header_area_show_bgimg']) && !empty($options['dp_header_area_show_bgimg']) ) {
			$selector .= ' bgimg_layer';
			$style_class .= ' bgimg_layer';
		}
	}

	if ( $ELEMENTS_SHOW['header_bar_transparent'] ){
		$selector .= ' hd_bar_trpt';
		$nav_selector .= ' hd_bar_trpt';
	}

	// Query
	$posts = get_posts( array(
		'numberposts' => $num,
		'post_type'=> $target,
		'meta_key'=> 'is_slideshow',
		'meta_value' => array( "true", true ),
		'orderby'=> $orderby // or rand
		)
	);

	// Loop query posts
	foreach( $posts as $key => $post ) : setup_postdata($post);
		// Reset
		$slide_image 	= '';
		$image_code = '';
		$slide_sizes = array();
		$date_code = '';
		$cats 	= '';
		$cats_code = '';
		$p_id 	= get_the_ID();
		$post_url = get_permalink();
		$title 	= get_the_title();
		$title 	= ( mb_strlen( $title, 'utf-8' ) > 68 ) ? mb_substr( $title, 0, 68, 'utf-8' ) . '.. . ' : $title;


		// Category
		if ( !(bool)get_post_meta($p_id, 'dp_hide_cat', true) ) {
			$cats = get_the_category($post->ID);
			if ($cats) {
				$cats = $cats[0];
				$cats_code = '<div class="meta-cat"' . $data_plx_category . '><span class="cat-name">' . $cats->cat_name . '</span></div>';
			}
		}


		// Date
		if ( !(bool)get_post_meta($p_id, 'dp_hide_date', true) && ($target === 'post' && (isset($options['show_pubdate_on_meta_' . $target]) && $options['show_pubdate_on_meta_' . $target] !== 'hide' )) ) {

			$date_code 	= '<div class="date-wrap loop-date"' . $data_plx_date . '><span class="date_month">' . get_post_time( 'n' ) . '</span><span class="separator">.</span><span class="date_day">' . get_post_time( 'j' ) . '</span><span class="date_year">' . get_post_time( 'Y' ) . '</span></div>';
		}

		// Get post image
		$slide_image = get_post_meta($p_id, 'slideshow_image_url', true);
		$slide_image = str_replace($arr_http,'',$slide_image);

		if (empty($slide_image) ) {
			$slide_image = DP_Post_Thumbnail::get_post_thumbnail(array(
				'width' => $width,
				'height' => $height,
				"size" => $post_thumb_size,
				"if_img_tag" => false
				)
			);
		}

		// Wrapped
		$slider_code .= '<div class="' . $slide_class . $style_class . '"><a href="' . $post_url . '" class="slide-link"><figure class="sl-media sl-img" style="background-image:url(\'' . $slide_image . '\' );" data-slide-img="' . $slide_image . '"' . $data_plx_media . '></figure><div class="' . $slide_content_class . ' sl-meta style-' . $slider_style . '"><div class="sl-content__inner loop-flex"' . $data_plx_content . '>' . $date_code . '<p class="' . $slide_content_title_class . '"' . $data_plx_title . '>' . $title . '</p>' . $cats_code . '</div></div></a></div>';

		// Thumbnail slider
		$thumbnav_code .= $slider_style == 'thumb' ? '<div class="' . $slide_class . $style_class . '"><figure class="sl-media sl-img" style="background-image:url(\'' . $slide_image . '\' );"></figure></div>' : '';


	endforeach;
	wp_reset_postdata();


	// Main slider
	$slider_code = '<div id="hd_slider" class="' . $selector . $style_class . $mb_class . ' ' . $target . '" data-slider-num="'.count($posts) . '"><div class="swiper-wrapper">' . $slider_code . '</div>' . $nav_button_code . '</div>' . $pagination_code;

	// Thumbnail slider
	$thumbnav_code = $slider_style == 'thumb' ? '<div id="nav_slider" class="' . $nav_selector . '"><div class="swiper-wrapper">' . $thumbnav_code . '</div></div>' : '';


	return array(
		'slider_code' => $slider_code,
		'thumbnav_code' => $thumbnav_code
	);
}
/**
 * Image and video slider code
 */
function dp_slider_image_video( $params ) {
	$params = wp_parse_args(
		(array)$params,
		array(
			'selector'			=> 'hd_slider',
			'top_edge_class'	=> '',
			'is_one_title' 		=> false,
		)
	);


	global $def_options, $options, $ELEMENTS_SHOW, $IS_MOBILE_DP;
	extract($params);

	$selector .= ' swiper loading hero-slider' . $top_edge_class;
	$nav_selector = 'nav_slider swiper loading';
	$slide_class = 'swiper-slide ';
	$slide_content_class = 'sl-content';
	$slide_content_title_class = 'title';
	$slide_content_cap_class = 'caption';
	$slide_content_btn_class = 'btn_area';
	$suffix_class = $IS_MOBILE_DP ? '_mobile' : '';
	$mb_class = '';
	$slide_num = '';
	$slider_code = '';
	$thumbnav_code = '';
	$pagination_code = '';
	$nav_button_code = '';
	$data_plx_content = '';
	$data_plx_media = '';
	$data_plx_title = '';
	$data_plx_cap = '';
	$data_plx_btn = '';
	$slider_style = $options['dp_slider_style' . $suffix_class];
	$style_class = ' style-' . $slider_style;
	$slide_sizes = array();
	$arr_type = array(
		$options['dp_slider_background1'],
		$options['dp_slider_background2'],
		$options['dp_slider_background3'],
		$options['dp_slider_background4'],
		$options['dp_slider_background5'],
		$options['dp_slider_background6'],
		$options['dp_slider_background7'],
		$options['dp_slider_background8']
	);

	if ( !$IS_MOBILE_DP ) {
		// PC
		if ( $options['dp_slider_control_button'] ){
			$pagination_code = '<div id="dp-sl-pagination" class="swiper-pagination' . $style_class . '"></div>';
		}

		if ($options['dp_slider_nav_button']){
			$nav_button_code = '<div class="swiper-nav-button-wrapper"><div class="swiper-button-prev"></div><div class="swiper-button-next"></div></div>';
		}

	} else {
		// For mobile
		$arr_type = array(
			$options['dp_slider_image1' . $suffix_class] ? 'image' : 'none',
			$options['dp_slider_image2' . $suffix_class] ? 'image' : 'none',
			$options['dp_slider_image3' . $suffix_class] ? 'image' : 'none',
			$options['dp_slider_image4' . $suffix_class] ? 'image' : 'none',
			$options['dp_slider_image5' . $suffix_class] ? 'image' : 'none',
			$options['dp_slider_image6' . $suffix_class] ? 'image' : 'none',
			$options['dp_slider_image7' . $suffix_class] ? 'image' : 'none',
			$options['dp_slider_image8' . $suffix_class] ? 'image' : 'none'
		);
		$mb_class = ' mb';
	}


	if ( $ELEMENTS_SHOW['header_bar_transparent'] ){
		$selector .= ' hd_bar_trpt';
		$nav_selector .= ' hd_bar_trpt';
	}


	// Parallax transition for media
	if ( $options['dp_slider_parallax_transition' . $suffix_class] ) {

		// Slide media parallax
		if ( $slider_style === 'fade' ) {
			$data_plx_media = ' data-swiper-parallax-scale="1.24"';
		}

		else if ( $slider_style === 'horizontal' || $slider_style === 'thumb' ) {
			$data_plx_media = ' data-swiper-parallax-x="60%"';
		}

		else if ( false !== strpos($slider_style, 'center' ) ) {
			$data_plx_media = ' data-swiper-parallax-x="20%" data-swiper-parallax-scale="1.4"';
		}

		else if ( $slider_style === 'vertical' ) {
			$data_plx_media = ' data-swiper-parallax-y="50%"';
		}
	}

	// Above text parallax
	if ( $slider_style !== 'carousel' ) {

		$data_plx_content = ' data-swiper-parallax-opacity="0"';

		if ( $slider_style === 'vertical' ) {
			$data_plx_title = ' data-swiper-parallax-y="100%" ';
			$data_plx_cap = ' data-swiper-parallax-y="60%"';
			$data_plx_btn = ' data-swiper-parallax-y="120%"';
		}

		else if ( $slider_style === 'fade' ) {
			$data_plx_title = ' data-swiper-parallax-scale="0.8"';
			$data_plx_cap = ' data-swiper-parallax-scale="0.8"';
			$data_plx_btn = ' data-swiper-parallax-scale="1.2"';
		}

		else {
			if ( $options['header_text_vertically'] ) {
				$data_plx_title = ' data-swiper-parallax-x="140%"';
				$data_plx_cap = ' data-swiper-parallax-x="180%"';
				$data_plx_btn = ' data-swiper-parallax-x="220%"';
			} else {
				$data_plx_title = ' data-swiper-parallax-x="20%"';
				$data_plx_cap = ' data-swiper-parallax-x="40%"';
				$data_plx_btn = ' data-swiper-parallax-x="60%"';
			}
		}
	}


	// Show padding and bacground image
	if ( $slider_style === 'horizontal' || $slider_style === 'vertical' || $slider_style === 'fade'|| $slider_style === 'center three' || $slider_style === 'center five' || $slider_style === 'carousel' ) {
		if ( isset($options['dp_header_area_show_bgimg']) && !empty($options['dp_header_area_show_bgimg']) ) {
			$selector .= ' bgimg_layer';
		}
	}


	// Each slide
	foreach ($arr_type as $key => $type) {

		$slide_num = $key + 1;
		$title_caption = $title_pos_class = $video_start_time = $slide_link_mb = $slide_link_mb_suffix = $slide_content_style = '';
		$silide_sizes = array();

		if ( $type === 'none' ) continue;

		// Slide style
		// if ( isset( $options['dp_slider_button_color' . $slide_num . $suffix_class] ) && !empty( $options['dp_slider_button_color' . $slide_num . $suffix_class] ) ){
		// 	$slide_content_style .= ' style="--content-bg-color:' . $options['dp_slider_button_color' . $slide_num . $suffix_class] . ';"';
		// }


		if ( !$is_one_title ) {

			// Title
			if ( !empty($options['dp_slider_title' . $slide_num . $suffix_class]) ){

				$title_caption = '<p class="' . $slide_content_title_class . '" role="heading"' . $data_plx_title . '>' . $options['dp_slider_title' . $slide_num . $suffix_class] . '</p>';
			}

			// Caption
			if ( !empty($options['dp_slider_caption' . $slide_num . $suffix_class]) ){

				$title_caption .= '<div class="' . $slide_content_cap_class . '"' . $data_plx_cap . '>' . $options['dp_slider_caption' . $slide_num . $suffix_class] . '</div>';
			}

			// Text position
			if ( $style_class !== ' style-split' && $style_class !== ' style-carousel' && $style_class !== ' style-center five' && $style_class !== ' style-coverflow five' ){
				$title_pos_class = ' cpos-' . $options['dp_slider_title_pos' . $slide_num];
			}

			// Button
			if ( !$IS_MOBILE_DP ) {

				if ( !empty($options['dp_slider_button_text' . $slide_num . $suffix_class]) && !empty($options['dp_slider_button_url' . $slide_num . $suffix_class]) ) {

					$title_caption .= '<div class="' . $slide_content_btn_class . '"' . $data_plx_btn . '><a href="' . $options['dp_slider_button_url' . $slide_num . $suffix_class] . '" class="title_cap_btn num' . $slide_num . '">' . $options['dp_slider_button_text' . $slide_num . $suffix_class] . '</a></div>';
				}
			}

			// Combine
			if ( !empty($title_caption) ) {

				$title_caption = '<div class="' . $slide_content_class . ' slc-' . $slide_num . $title_pos_class . $suffix_class . '"' . $slide_content_style . '><div class="sl-content__inner"' . $data_plx_content . '>' . $title_caption . '</div></div>';
			}

			// Slide link
			if ( $IS_MOBILE_DP ){
				if (isset($options['dp_slider_url' . $slide_num . '_mobile']) && !empty($options['dp_slider_url' . $slide_num . '_mobile'])){
					$slide_link_mb = '<a href="' . $options['dp_slider_url' . $slide_num . '_mobile'] . '" class="slide-link">';
					$slide_link_mb_suffix = '</a>';
				}
			}
		}

		// Start with...
		$slider_code .= '<div class="' . $slide_class . $type . $style_class . '">' . $slide_link_mb;
		$thumbnav_code .= $slider_style == 'thumb' ? '<div class="' . $slide_class . $style_class . '">' : '';

		// Media
		switch ($type) {
			case 'video':	// Uploaded video
				if ( !empty($options['dp_slider_video' . $slide_num]) ) {
					$video_url = wp_get_attachment_url($options['dp_slider_video' . $slide_num]);
					$slider_code .= '<video class="sl-media ' . $type . '" loop muted preload="metadata"><source src="' . $video_url . '" type="video/mp4" /></video>';

					// Thumbnail navi
					if ( $slider_style == 'thumb' ) {
						// Get the video thumbnail
						$thumbnav_code .= '<video class="sl-media ' . $type . '" muted preload="metadata"><source src="' . $video_url . '" type="video/mp4" /></video>';
					}
				}
				break;

			case 'youtube':	// YouTube or Vimeo
				if ( !empty($options['dp_slider_youtube_vimeo_id' . $slide_num]) ) {

					if ( $slider_style == 'thumb' ) {

						// Thumbnail navi
						$slider_code .= '<figure class="sl-media sl-img" style="background-image:url(\'https://img.youtube.com/vi/' . $options['dp_slider_youtube_vimeo_id' . $slide_num] . '/maxresdefault.jpg\');" data-slide-img="\'https://img.youtube.com/vi/' . $options['dp_slider_youtube_vimeo_id' . $slide_num] . '/maxresdefault.jpg\'"' . $data_plx_media . '></figure>';

						// For thumbnail navigation
						$thumbnav_code .= '<figure class="sl-media sl-img" style="background-image:url(\'https://img.youtube.com/vi/' . $options['dp_slider_youtube_vimeo_id' . $slide_num] . '/0.jpg\');"></figure>';

					} else {
						$slider_code .= '<iframe class="sl-media ' . $type . '" width="980" height="520" src="https://www.youtube.com/embed/' . $options['dp_slider_youtube_vimeo_id' . $slide_num] . '?enablejsapi=1&controls=0&fs=0&iv_load_policy=3&rel=0&showinfo=0&loop=1&playlist=' . $options['dp_slider_youtube_vimeo_id' . $slide_num] . '&start=' . $options['dp_slider_video_start_time' . $slide_num] . '" allowfullscreen' . $data_plx_media . '></iframe>';
					}
				}
				break;

			case 'vimeo':

				if ( !empty($options['dp_slider_youtube_vimeo_id' . $slide_num]) ) {

					if ( $slider_style == 'thumb' ) {

						$json = wp_remote_get( 'https://vimeo.com/api/oembed.json?url=https://vimeo.com/' . $options['dp_slider_youtube_vimeo_id' . $slide_num] );

						if ( $json['response']['code'] === 200 ) {

							$json = json_decode( $json['body'], true );

							$large = str_replace( '_640', '', $json['thumbnail_url'] );

							// Thumbnail navi
							$slider_code .= '<figure class="sl-media sl-img" style="background-image:url(\'' . $large . '\');" data-slide-img="\'' . $large . '\'"' . $data_plx_media . '></figure>';

							// For thumbnail navigation
							$thumbnav_code .= '<figure class="sl-media sl-img" style="background-image:url(\'' . $json['thumbnail_url'] . '\' );"></figure>';
						}

					} else {

						if (isset($options['dp_slider_video_start_time' . $slide_num]) && (int)$options['dp_slider_video_start_time' . $slide_num] > 0){
							$video_start_time = ' data-video-start="' . $options['dp_slider_video_start_time' . $slide_num] . '"';
						}

						$slider_code .= '<iframe class="sl-media ' . $type . '" src="https://player.vimeo.com/video/' . $options['dp_slider_youtube_vimeo_id' . $slide_num] . '?loop=1&autoplay=0&byline=0&title=0&mute=0&playbar=0&color=666&portrait=0&background=1&speed=0&player_id=' . $options['dp_slider_youtube_vimeo_id' . $slide_num] . '" width="980" height="520" webkitallowfullscreen mozallowfullscreen allowfullscreen' . $video_start_time . $data_plx_media . ' id="sl-vimeo-' . $options['dp_slider_youtube_vimeo_id' . $slide_num] . '"></iframe>';
					}
				}
				break;

			default:	// Static image
				if ( !empty($options['dp_slider_image' . $slide_num . $suffix_class]) ) {
					// Normal
					$slider_code .= '<figure class="sl-media sl-img" style="background-image:url(\'' . $options['dp_slider_image' . $slide_num . $suffix_class] . '\' );" data-slide-img="' . $options['dp_slider_image' . $slide_num . $suffix_class] . '"' . $data_plx_media . '></figure>';

					// Thumbnail navi
					if ( $slider_style == 'thumb' ) {
						$thumbnav_code .= '<figure class="sl-media sl-img" style="background-image:url(\'' . $options['dp_slider_image' . $slide_num . $suffix_class] . '\' );"></figure>';
					}
				}
				break;
		}

		// End with...
		$slider_code .= $title_caption . $slide_link_mb_suffix . '</div>';
		$thumbnav_code .= $slider_style == 'thumb' ? '</div>' : '';
	}

	// Wrapped
	$slider_code = '<div id="hd_slider" class="' . $selector . $style_class . $mb_class . '" data-slider-num="' . $slide_num . '"><div class="swiper-wrapper">' . $slider_code . '</div>' . $nav_button_code . '</div>' . $pagination_code;

	// Thumbnail slider
	$thumbnav_code = $slider_style == 'thumb' ? '<div id="nav_slider" class="' . $nav_selector . '"><div class="swiper-wrapper">' . $thumbnav_code . '</div></div>' : '';

	return array(
		'slider_code' => $slider_code,
		'thumbnav_code' => $thumbnav_code
	);
}

/**
* Show the Banner Contents
*
* @return	none
*/
function dp_banner_contents() {

	if ( !( is_front_page() && !is_paged()) ) return;

	global $def_options, $options, $IS_MOBILE_DP, $ELEMENTS_SHOW, $CONTAINER_EDGE;

	$suffix_class = '';
	$slider_code = '';
	$banner_contents = '';
	$widget_code = '';
	$top_edge_class = '';
	$top_edge_svg = '';
	$bottom_edge_svg = '';
	$banner_header_class = 'banner_header';
	$banner_inner_class = 'header-banner-inner';
	$header_title_code 	= '';
	$banner_container_class = $banner_content_class = '';
	$bgimg_layer_flag = false;
	$is_one_title = false;
	$has_widget_class = ' no_widget';
	$mb_class = ' pc';

	// Wow fade-in params
	$title_fx = ' wow fadeIn';
	$caption_fx = ' wow fadeIn';
	$title_cap_fx_delay = ' data-wow-delay="1s"';
	$banner_wdgt_fx = ' wow fadeIn';
	$banner_wdgt_fx_delay = ' data-wow-delay="1.4s"';


	// For Mobile
	if ($IS_MOBILE_DP) {
		$suffix_class = '_mobile';
		$mb_class = ' mb';
	}

	//Get options
	$type = isset($options['dp_header_content_type' . $suffix_class]) && !empty($options['dp_header_content_type' . $suffix_class]) ? $options['dp_header_content_type' . $suffix_class] : $def_options['dp_header_content_type' . $suffix_class];


	if ( $type === 'none' ) return;


	/**
	 * Check the transient data and return the cache if cache is exists
	 */
	if ( !($type === 'slideshow' && $options['dp_slider_order' . $suffix_class] === 'rand' ) ) {
		if ( dp_is_enable_cache( array( 'target' => 'banner_contents' ) ) ){
			$cache = false;
			if ( $IS_MOBILE_DP ) {
				$cache = get_transient( 'dp_banner_contents_mb' );
			} else {
				$cache = get_transient( 'dp_banner_contents' );
			}

			if ( $cache !== false ) {
				// Reload swiper.js for slider
				if ( $type === 'slideshow' || $type === 'slideshow_selected_media' ){
					wp_enqueue_style( 'dp-swiper', DP_THEME_URI . '/css/swiper-bundle.css', null, DP_OPTION_SPT_VERSION );
					wp_enqueue_script( 'dp-swiper', DP_THEME_URI . '/inc/js/swiper-bundle.min.js', null, false, true );
				}

				echo $cache;
				return;
			}
		}
	}



	$slider_style = $options['dp_slider_style' . $suffix_class];
	$header_img = $options['dp_header_img' . $suffix_class];

	$target = isset($options['dp_slider_post_or_page' . $suffix_class]) && !empty($options['dp_slider_post_or_page' . $suffix_class]) ? $options['dp_slider_post_or_page' . $suffix_class] : $def_options['dp_slider_post_or_page' . $suffix_class];

	// Position
	$banner_content_class = isset($options['header_title_pos' . $suffix_class]) && !empty($options['header_title_pos' . $suffix_class]) ? 'pos-' . $options['header_title_pos' . $suffix_class] : '';

	// Vertical text flag
	$text_vertical_flag = isset($options['header_text_vertically' . $suffix_class]) && !empty($options['header_text_vertically' . $suffix_class]) ? true : false;
	if ( $type === 'slideshow_selected_media' && ( $slider_style === 'coverflow five' || $slider_style === 'center five' || $slider_style === 'carousel' ) ) {
		$text_vertical_flag = false;
	}


	if ( isset($options['header_img_text_animate' . $suffix_class]) && !empty($options['header_img_text_animate' . $suffix_class]) ) {

		// Wow fade in effect type
		$title_fx = ' wow fadeInDown';
		$caption_fx = ' wow fadeInUp';

		// Vertical or normal
		if ( $text_vertical_flag ) {
			$banner_header_class .= ' show-by-txtshadow';
			$title_cap_fx_delay = ' data-wow-delay="1.2s"';
		} else {
			$title_fx = ' ani-text gradually hd-title';
			$caption_fx = ' ani-text gradually hd-caption';
			$banner_wdgt_fx_delay = ' data-wow-delay="1.5s"';
		}
	}


	// Only slider
	if ($type === 'slideshow' || $type === 'slideshow_selected_media' ){
		$banner_container_class .= ' sl-style-' . $slider_style;
		wp_enqueue_style( 'dp-swiper',DP_THEME_URI . '/css/swiper-bundle.css',null,DP_OPTION_SPT_VERSION);
		wp_enqueue_script( 'dp-swiper',DP_THEME_URI . '/inc/js/swiper-bundle.min.js',null,false,true);

		// Parallax transition?
		if ( $options['dp_slider_parallax_transition' . $suffix_class] ) {
			if ( $slider_style === 'horizontal' || $slider_style === 'vertical' ) {
				$banner_container_class .= ' plx_on ';
			}
		}
	}

	// Has widget?
	if ( is_active_sidebar( 'widget-on-top-banner' ) && !$IS_MOBILE_DP ) {
		$has_widget_class = ' has_widget';
	}

	// Header margin and background layer image
	if ( !$IS_MOBILE_DP && $type === 'image'
		|| (
			($type === 'slideshow' || $type === 'slideshow_selected_media' )
			&& ( $slider_style === 'horizontal' || $slider_style === 'vertical' || $slider_style === 'fade'|| $slider_style === 'center three' || $slider_style === 'center five' || $slider_style === 'carousel' ) )
	) {
		if ( isset($options['dp_header_area_show_bgimg']) && !empty($options['dp_header_area_show_bgimg']) ) {
			$banner_container_class .= ' bgimg_layer';
			$bgimg_layer_flag = true;
		}
	}


	// Edge shape
	$top_shape_type = !$IS_MOBILE_DP && isset( $options[ 'dp_header_area_top_edge' . $suffix_class ] ) ? $options[ 'dp_header_area_top_edge' . $suffix_class ] : '';
	$bottom_shape_type = isset( $options[ 'dp_header_area_bottom_edge' . $suffix_class ] ) ? $options[ 'dp_header_area_bottom_edge' . $suffix_class ] : 'none';
	$header_area_edge_piled_layer = isset( $options[ 'dp_header_area_edge_piled_layer' . $suffix_class ] ) ? $options[ 'dp_header_area_edge_piled_layer' . $suffix_class ] : true;

	if ( $type === 'image' || ( $slider_style === 'fade' || $slider_style === 'horizontal' || $slider_style === 'vertical' || $slider_style === 'split' || $slider_style === 'center three' || $slider_style === 'center five' || $slider_style === 'thumb' || strpos( $slider_style, 'creative' ) !== false ) ) {

		// Top
		if ( $top_shape_type !== 'none' ){

			if ( $top_shape_type === 'wave1' || $top_shape_type === 'wave2' || $top_shape_type === 'curve1' || $top_shape_type === 'curve2' ) {

				$banner_container_class .= ' edge_shape_' . $top_shape_type . '_top';

				$edge_svg_class = 'svg_edge pos_top invert rev type-' . $type;

				if ( $header_area_edge_piled_layer ) {

					$edge_svg_class .= ' piled_layer';

					// When the shape is SVG...
					$top_edge_svg = '<svg class="' . $edge_svg_class . '"><use xlink:href="#svg_edge_' . $top_shape_type . '__layer1" /><use xlink:href="#svg_edge_' . $top_shape_type . '__layer2" /><use xlink:href="#svg_edge_' . $top_shape_type . '__layer3" /></svg>';

				} else {

					$top_edge_svg = '<svg class="' . $edge_svg_class . '"><use xlink:href="#svg_edge_' . $top_shape_type . '" /></svg>';

				}
			} else {

				// When the shape is clip-path
				$top_edge_class = ' edge_shape_' . $top_shape_type . '_top';
			}
		}

		// Bottom
		if ( $bottom_shape_type !== 'none' ){

			$banner_container_class .= ' edge_shape_' . $bottom_shape_type . '_btm';
			$CONTAINER_EDGE = ' edge_' . $bottom_shape_type;

			if ( $bottom_shape_type === 'wave1' || $bottom_shape_type === 'wave2' || $bottom_shape_type === 'curve1' || $bottom_shape_type === 'curve2' ) {

				$edge_svg_class = 'svg_edge pos_btm type-' . $type;

				if ( $header_area_edge_piled_layer ) {

					$edge_svg_class .= ' piled_layer';

					// When the shape is SVG...
					$bottom_edge_svg = '<svg class="' . $edge_svg_class . '"><use xlink:href="#svg_edge_' . $bottom_shape_type . '__layer1" /><use xlink:href="#svg_edge_' . $bottom_shape_type . '__layer2" /><use xlink:href="#svg_edge_' . $bottom_shape_type . '__layer3" /></svg>';

				} else {
					$bottom_edge_svg = '<svg class="' . $edge_svg_class . '"><use xlink:href="#svg_edge_' . $bottom_shape_type . '" /></svg>';
				}
			}
		}
	}



	// Top page header content
	switch ( $type ) {
		case 'image':	// Header image

			// One title only?
			if ( isset( $options['dp_slider_only_one_title' . $suffix_class] ) && !empty( $options['dp_slider_only_one_title' . $suffix_class] ) ) {
				$title_cap_fx_delay = ' data-wow-delay="0.5s"';
				$banner_wdgt_fx = ' wow fadeIn';
				$banner_wdgt_fx_delay = ' data-wow-delay="0.8s"';
				$is_one_title = true;
			}

			if (isset($options['dp_header_img' . $suffix_class]) && !empty($options['dp_header_img' . $suffix_class]) ) {
				$header_img = $options['dp_header_img' . $suffix_class];
			} else {
				$header_img = DP_THEME_URI . '/img/sample/header/header1.jpg';
			}

			if ( $bgimg_layer_flag ) {
				$banner_contents = '<figure class="header_media_wrapper figure_img bgimg_layer' . $top_edge_class . '"><img src="' . $header_img . '" alt="Background Image" class="static_img back" /><img src="' . $header_img . '" alt="Banner Image" class="static_img front" /></figure>';
			} else {
				$banner_contents = '<figure class="header_media_wrapper figure_img' . $top_edge_class . '" style="background-image:url( ' . $header_img . ' );"><img src="' . $header_img . '" alt="Banner Image" class="static_img" /></figure>';
			}

			$banner_container_class .= ' hd_img';

			break;

		case 'slideshow':	// Post / page slideshow
			$banner_container_class .= ' post-slider';
			$slider_code = dp_slider_post_or_page( array( 'top_edge_class' => $top_edge_class ) );
			$banner_contents = $slider_code['slider_code'] . $slider_code['thumbnav_code'];

			break;

		case 'slideshow_selected_media':
			// One title only?
			if ( $slider_style === 'fade' || $slider_style === 'horizontal' || $slider_style === 'vertical' || $slider_style === 'split' || $slider_style === 'coverflow one' || strpos( $slider_style, 'creative' ) !== false || ( $slider_style === 'coverflow three' && $IS_MOBILE_DP ) ) {
				if ( isset( $options['dp_slider_only_one_title' . $suffix_class] ) && !empty( $options['dp_slider_only_one_title' . $suffix_class] ) ) {
					$is_one_title = true;
				}
			}

			$banner_container_class .= ' media-slider';
			$slider_code = dp_slider_image_video( array(
				'top_edge_class' => $top_edge_class,
				'is_one_title' => $is_one_title
			) );
			$banner_contents = $slider_code['slider_code'] . $slider_code['thumbnav_code'];

			// Text vertically
			if ( $text_vertical_flag ) {
				$banner_inner_class .= ' is-text-vertical';
			}

			break;
	}


	// Title and caption
	if ( $type === 'image' || $is_one_title ) {

		// Text vertically
		if ( $text_vertical_flag ) {
			// Disable widget when the title is centered
			if ( !$IS_MOBILE_DP && $options['header_title_pos'] === 'center' ) {
				$has_widget_class = ' no_widget';
			}

			$banner_content_class .= ' is-text-vertical';
		}

		// Static title
		if ( !empty($options['header_img_title' . $suffix_class]) ) {
			$header_title_code = '<div id="banner_title"><h2 class="btitle' . $title_fx . '"' . $title_cap_fx_delay . '>'.htmlspecialchars_decode($options['header_img_title' . $suffix_class]) . '</h2></div>';
		}
		// title caption
		if ( !empty($options['header_img_caption' . $suffix_class]) ) {
			$header_title_code .= '<div id="banner_caption"><p class="bcaption' . $caption_fx . '"' . $title_cap_fx_delay . '>'.htmlspecialchars_decode($options['header_img_caption' . $suffix_class]) . '</p></div>';
		}
		if ( !empty($header_title_code) ) {
			$header_title_code = '<header id="banner_header" class="' . $banner_header_class . '">' . $header_title_code . '</header>';
		}

		// Widgets
		if ( $has_widget_class === ' has_widget' ) {
			ob_start();
			dynamic_sidebar( 'widget-on-top-banner' );
			if ( $options['header_title_pos' . $suffix_class] === 'right' ){
				$header_title_code = '<div class="widget-on-top-banner' . $banner_wdgt_fx . '"' . $banner_wdgt_fx_delay . ' data-selector=".widget-box">'.ob_get_contents() . '</div>' . $header_title_code;
			} else {
				$header_title_code .= '<div class="widget-on-top-banner' . $banner_wdgt_fx . '"' . $banner_wdgt_fx_delay . '>'.ob_get_contents() . '</div>';
			}
			ob_end_clean();
		}

		if ( !empty($options['dp_slider_control_button']) && !$IS_MOBILE_DP) {
			$banner_container_class .= ' show-nav-btns';
		}

		if ( $ELEMENTS_SHOW['header_bar_transparent'] ){
			$banner_content_class .= ' hd_bar_trpt';
		}

		// Title code
		$header_title_code = '<div id="header-banner-container" class="header-banner-container type-' . $type . $banner_container_class . '"><div class="header-banner-content ' . $banner_content_class . $has_widget_class . ' type-' . $type . '">' . $header_title_code . '</div></div>';
	}

	// Header banner inner class
	$banner_inner_class .= $banner_container_class . $has_widget_class . $mb_class;


	// Display
	if ( !empty($banner_contents) ) {
		$code = '<div id="header-banner-outer" class="header-banner-outer' . $banner_container_class . '"><div id="header-banner-inner" class="' . $banner_inner_class . '">' . $top_edge_svg . $banner_contents . $header_title_code . $bottom_edge_svg . '</div></div>';

		echo $code;


		/**
		 * Save to cache
		 */
		if ( !($type === 'slideshow' && $options['dp_slider_order' . $suffix_class] === 'rand' ) ) {
			if ( dp_is_enable_cache( array( 'target' => 'banner_contents' ) ) ){
				if ( $IS_MOBILE_DP ){
					set_transient( 'dp_banner_contents_mb', $code, 0 );
				} else {
					set_transient( 'dp_banner_contents', $code, 0 );
				}
			}
		}
	}
}