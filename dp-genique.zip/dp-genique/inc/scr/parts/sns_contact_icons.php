<?php
function dp_sns_contact_icons(
		$position = 'header',
		$ul_class = 'sns_contact_icons' ){

	global $options;

	$sns_code = $fb_url = $twitter_url = $instagram_url = $youtube_url = $contact_url = $rss_type = '';
	$sns_link_num = 0;

	if ( $position === 'footer' ) {
		$fb_url = isset($options['footer_sns_fb_url']) ? $options['footer_sns_fb_url'] : null;
		$twitter_url = isset($options['footer_sns_twitter_url']) ? $options['footer_sns_twitter_url'] : null;
		$instagram_url = isset($options['footer_sns_instagram_url']) ? $options['footer_sns_instagram_url'] : null;
		$youtube_url = isset($options['footer_sns_youtube_url']) ? $options['footer_sns_youtube_url'] : null;
		$contact_url = isset($options['footer_sns_contact_url']) ? $options['footer_sns_contact_url'] : null;
		$rss_type = isset($options['footer_sns_rss']) ? $options['footer_sns_rss'] : null;
	} else {
		$fb_url = isset($options['global_menu_fb_url']) ? $options['global_menu_fb_url'] : null;
		$twitter_url = isset($options['global_menu_twitter_url']) ? $options['global_menu_twitter_url'] : null;
		$instagram_url = isset($options['global_menu_instagram_url']) ? $options['global_menu_instagram_url'] : null;
		$youtube_url = isset($options['global_menu_youtube_url']) ? $options['global_menu_youtube_url'] : null;
		$contact_url = isset($options['global_menu_contact_url']) ? $options['global_menu_contact_url'] : null;
		$rss_type = isset($options['global_menu_rss']) ? $options['global_menu_rss'] : null;
	}

	/**
	 * SNS icon links
	 */
	if ( !empty( $fb_url ) ){
		$sns_code = '<li class="menu-item fb"><a href="' . $fb_url . '" target="_blank" class="menu-link sns_link"><i class="menu-title has_cap icon-facebook"></i><span>Facebook</span></a></li>';
		$sns_link_num++;
	}
	if ( !empty( $twitter_url ) ){
		$sns_code .= '<li class="menu-item tw"><a href="' . $twitter_url . '" target="_blank" class="menu-link sns_link"><i class="menu-title has_cap icon-twitter"></i><span>Twitter</span></a></li>';
		$sns_link_num++;
	}
	if ( !empty( $instagram_url ) ){
		$sns_code .= '<li class="menu-item instagram"><a href="' . $instagram_url . '" target="_blank" class="menu-link sns_link"><i class="menu-title has_cap icon-instagram"></i><span>Instagram</span></a></li>';
		$sns_link_num++;
	}
	if ( !empty( $youtube_url ) ){
		$sns_code .= '<li class="menu-item youtube"><a href="' . $youtube_url . '" target="_blank" class="menu-link sns_link"><i class="menu-title has_cap icon-youtube"></i><span>YouTube</span></a></li>';
		$sns_link_num++;
	}
	if ( !empty( $contact_url ) ){
		$sns_code .= '<li class="menu-item contact_url"><a href="' . $contact_url . '" class="menu-link sns_link"><i class="menu-title has_cap icon-mail"></i><span>Contact</span></a></li>';
		$sns_link_num++;
	}

	/**
	 * Feed icon
	 */
	switch ( $rss_type ) {
		case 'rss':
			$sns_code .= '<li class="menu-item rss feed"><a href="' . get_feed_link() . '" title="Subscribe Feed" target="_blank" class="menu-link sns_link"><i class="menu-title has_cap icon-rss"></i><span>RSS</span></a></li>';
			$sns_link_num++;
			break;
		case 'feedly':
			$sns_code .= '<li class="menu-item feedly feed"><a href="https://feedly.com/i/subscription/feed/' .urlencode(get_feed_link()) . '" target="_blank" title="Follow on feedly" class="menu-link sns_link"><i class="menu-title has_cap icon-feedly"></i><span>Feedly</span></a></li>';
			$sns_link_num++;
			break;
		default:
			break;
	}

	// Marge SNS and feed icons
	if ( $sns_link_num !== 0 ) {
		$sns_code = '<ul class="' . $ul_class . ' menu_num_' . $sns_link_num . '">' . $sns_code . '</ul>';
	}

	return $sns_code;
}