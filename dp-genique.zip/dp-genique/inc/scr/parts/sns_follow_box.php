<?php
/**
 * SNS Follow box
 */
function dp_sns_follow_box(){

	global $options, $def_options, $EXIST_FB_LIKE_BOX, $IS_MOBILE_DP;

	$post_type_name = get_post_type_object( get_post_type() );
	$post_type_name = isset( $post_type_name->name ) ? esc_html( $post_type_name->name ) : '';

	if (!is_single() || $post_type_name === $options['news_cpt_slug_id']) return;

	$fb_box = $tw_box = $fb_box_bg_img = $show_bg_class = '';

	$this_id = get_the_ID();

	// Custom field
	$cf_hide_follow_box = get_post_meta( $this_id, 'dp_hide_follow_box', true );
	if (isset($cf_hide_follow_box) && !empty($cf_hide_follow_box)) return;

	// Facebook follow box
	if ( isset($options['follow_box_facebook']) && !empty($options['follow_box_facebook']) ) {
		// Flag sets to true
		$EXIST_FB_LIKE_BOX = true;

		// eyecatch
		$arg_thumb = array(
			'width' => 1200,
			'height' => 800,
			"size" => "large",
			"if_img_tag" => true
		);
		$thumbnail = DP_Post_Thumbnail::get_post_thumbnail($arg_thumb);

		// background image filter ?
		if ( isset($options['follow_box_facebook_bg_image']) && !empty($options['follow_box_facebook_bg_image']) && !$IS_MOBILE_DP ){
			$fb_box_bg_img = '<figure class="flw_box_col bg_img">' . $thumbnail . '</figure>';
			$show_bg_class = ' show_bg_img';
		}

		// URL
		$url = home_url('/');
		if ( isset($options['follow_box_facebook_like_target']) ) {
			switch ($options['follow_box_facebook_like_target']) {
				case 'post':
					$url = get_permalink();
					break;
				case 'custom':
					if (isset($options['follow_box_facebook_like_url']) && !empty($options['follow_box_facebook_like_url']) ) {
						$url = $options['follow_box_facebook_like_url'];
					} else {
						$url = home_url('/');
					}
					break;
			}
		}

		// Follow phrase
		$phrase = '';
		if ( isset($options['follow_box_facebook_phrase']) && !empty($options['follow_box_facebook_phrase']) ) {
			$phrase = '<span class="phrase">' . $options['follow_box_facebook_phrase'] . '</span>';
		}

		// Box bg color
		$bgcolor = '';
		if ( isset($options['follow_box_facebook_overlay_color']) && !empty($options['follow_box_facebook_overlay_color']) ) {
			$bgcolor = $options['follow_box_facebook_overlay_color'];
		} else {
			$bgcolor = $def_options['follow_box_facebook_overlay_color'];
		}
		// Inline CSS
		$inline_css = '.flw_box.fb,.flw_box.fb .flw_box_col::after{background-color:'.$bgcolor.';}';
		// Insert inline style in head tag
		wp_register_style( 'dp_follow_box_fb', false );
		wp_enqueue_style( 'dp_follow_box_fb' );
		wp_add_inline_style( 'dp_follow_box_fb', $inline_css );


		// layout parameter
		$btn_layout = ' data-layout="button"';
		if ( isset($options['follow_box_facebook_count']) && !empty($options['follow_box_facebook_count']) ){
			$btn_layout = ' data-layout="button_count"';
		}

		// Like widget
		$widget = '<div class="fb-like" data-href="'.$url.'" data-size="large" data-action="like" data-show-faces="false"'.$btn_layout.'></div>';

		$fb_box = '<div class="flw_box fb' . $show_bg_class . '"><figure class="flw_box_col' . $show_bg_class .'">' . $thumbnail . '</figure><div class="flw_box_col">' . $phrase . $widget . '</div>' . $fb_box_bg_img . '</div>';
	}

	// Twitter follow box
	if ( isset($options['follow_box_twitter']) && !empty($options['follow_box_twitter']) ) {
		$twitter_user_id = '';
		if ( isset($options['twitter_user_id']) && !empty($options['twitter_user_id']) ) {
			$twitter_user_id = $options['twitter_user_id'];
		} else {
			if ( isset($options['twitter_card_user_id']) && !empty($options['twitter_card_user_id']) ) {
				$twitter_user_id = $options['twitter_card_user_id'];
			}
		}

		if (!empty($twitter_user_id)){
			$data_count = ' data-show-count="false"';
			if ( isset($options['follow_box_twitter_count']) && !empty($options['follow_box_twitter_count']) ) {
				$data_count = ' data-show-count="true"';
			}

			$tw_box = '<div class="flw_box tw"><span class="flw_label">' . sprintf(__('Follow <a href="https://twitter.com/%s" target="_blank" class="user_link">@%s</a> on Twitter', 'DigiPress'), $twitter_user_id, $twitter_user_id ) . '</span><a href="https://twitter.com/' . $twitter_user_id . '?ref_src=twsrc%5Etfw" class="twitter-follow-button" data-size="large" data-show-screen-name="false"' . $data_count . '>Follow @' . $twitter_user_id . '</a></div>';
		}
	}

	return $fb_box . $tw_box;
}
