<?php
/**
 * Generate Table of Contents
 * @param  $content post content
 */
function dp_table_of_contents($content) {
	global $options, $def_options, $DP_SINGLE_TOC, $IS_MOBILE_DP, $IS_AMP_DP;

	// Count h tag
	if ( preg_match_all( DP_H_TAG_REG, $content, $h_tags ) ) {
		if ( isset($options['toc_min_h_count']) ){
			if ( (int)$options['toc_min_h_count'] > count($h_tags[0]) ){
				return $content;
			}
		} else {
			if ( $def_options['toc_min_h_count'] > count($h_tags[0]) ){
				return $content;
			}
		}
	} else {
		return $content;
	}

	// Class
	$container_class = isset($options['toc_position']) ? ' pos-' . $options['toc_position'] : ' pos-' . $def_options['toc_position'];
	if ( !isset($options['toc_allow_user_toggle']) || !empty($options['toc_allow_user_toggle']) && $options['toc_position'] !== 'right_float' ) {
		$container_class .= ' allow-toggle';
	}

	// Top padding
	$data_padding= '';
	if ( $IS_MOBILE_DP ){
		if ( isset($options['toc_add_scroll_top_mobile']) && !empty($options['toc_add_scroll_top_mobile']) ) {
			$data_padding = ' data-margin="' . $options['toc_add_scroll_top_mobile'] . '"';
		}
	} else {
		if ( isset($options['toc_add_scroll_top']) && !empty($options['toc_add_scroll_top']) ) {
			$data_padding = ' data-margin="' . $options['toc_add_scroll_top'] . '"';
		}
	}

	// reset
	$DP_SINGLE_TOC = '<div class="dp_toc_container' . $container_class . '" role="navigation"' . $data_padding . '>';

	// Main title
	$main_title = '';
	if ( !isset($options['toc_show_main_title']) || !empty($options['toc_show_main_title']) ) {

		$main_title = isset($options['toc_main_title']) ? $options['toc_main_title'] : $def_options['toc_main_title'];

		if ( !isset($options['toc_allow_user_toggle']) || !empty($options['toc_allow_user_toggle']) && $options['toc_position'] !== 'right_float' && !$IS_AMP_DP ) {

			if ( isset($options['toc_close_default']) && !empty($options['toc_close_default']) ) {
				$DP_SINGLE_TOC .= '<p class="toc_title_block close-toc"><span class="toc_title icon-list">' . $main_title . '</span><span class="toc_toggle icon-up-open" role="button"></span></p>';
			} else {
				$DP_SINGLE_TOC .= '<p class="toc_title_block"><span class="toc_title icon-list">' . $main_title . '</span><span class="toc_toggle icon-up-open" role="button"></span></p>';
			}
		} else {
			$DP_SINGLE_TOC .= '<p class="toc_title_block"><span class="toc_title icon-list">' . $main_title . '</span></p>';
		}
	}

	/**
	 * Start TOC listing
	 */
	if ( !empty($main_title) ) {
		$DP_SINGLE_TOC .= '<ul class="dp_toc_ul has_title">';
	} else {
		$DP_SINGLE_TOC .= '<ul class="dp_toc_ul">';
	}

	// Regular expression
	$start_h = isset($options['toc_get_h_tag']) ? $options['toc_get_h_tag'] : '1';
	$regex = sprintf( '#<(h[%s-6])(.*?)>(.*?)</\1>#si', $start_h );

	$index = 1;

	// Insert the IDs and create the TOC.
	$arr_toc_list = array();
	$rep_content = preg_replace_callback(
		$regex,
		function ($matches) use (&$index, &$arr_toc_list, &$options, &$DP_SINGLE_TOC) {
			// Get the head tag
			$tag = $matches[1];

			// Title
			$title = trim( strip_tags($matches[3]) );

			// Check the ID
			$has_id = preg_match( '/id=(["\'])(.*?)(["\'])/si', $matches[2], $matched_ids );
			if ( $has_id ){
				// Has ID
				$id = $matched_ids[2];
			} else {
				// Doesn't have ID

				// convert accented characters to ASCII
				$target = sanitize_title( $title );
				// remove non alphanumeric chars
				$target = preg_replace( '/[^a-zA-Z0-9 \-_]*/', '', $target );
				// remove trailing - and _
				$target = rtrim( $target, '-_' );

				// New ID
				$id = $target . '-' . $index++;
			}
			// $id = $has_id ? $matched_ids[2] : $index++ . '-' . $target;

			// Excluded head
			if ( isset($options['toc_except_class']) && !empty($options['toc_except_class']) ) {

				$has_class = preg_match('/class=["\'](.+?)["\']/si', $matches[2], $matched_classes);

				if ( $has_class ) {
					// Get classes of the current head tag
					$matched_classes = explode( ' ', $matched_classes[1]);
					// Get ignore classes
					$ignore_classes = explode( ',', $options['toc_except_class']);

					if ( is_array($matched_classes) ) {
						foreach ( $matched_classes as $class ) {
							foreach ($ignore_classes as $ignore_class) {
								if ( $class === trim($ignore_class)) {
									return $matches[0];
								}
							}
						}
					}
				}
			}

			$arr_toc_list[] = array(
				// Heading depth => list tag
				'depth' => (int)substr( $tag, 1, 1),
				'tag' => "<a href=\"#$id\">$title</a>"
			);

			if ($has_id) {
				return $matches[0];
			}

			return sprintf("<%s%s id=\"%s\">%s</%s>", $tag, $matches[2], $id, $matches[3], $tag);
		}, $content );

	// preg_replace_callback is error...
	if ( $rep_content === NULL ) {
		$DP_SINGLE_TOC = '';
		return $content;
	} else {
		$content = $rep_content;
	}

	// Total list count
	$toc_num = count($arr_toc_list);

	// Wrapping by list tag
	$toc_list_code = '';
	$depth_level = 0;
	foreach ($arr_toc_list as $key => $list) {
		if ( $key > 0) {
			// After 2nd loop

			// How deep between previous and current
			$depth_level = $prev_depth - $list['depth'];

			if ( $depth_level === 0 ) {
				// Brother level
				$toc_list_code .= '</li><li>';

			} else if ( $depth_level < 0 ) {
				// Child level
				$toc_list_code .= '<ul><li>';

			} else {
				// Parent level
				for ( $i = 0; $i < $depth_level; $i++ ) {
					$toc_list_code .= '</li></ul>';
				}
				$toc_list_code .= '</li><li>';
			}

		} else {
			// Only first loop
			$toc_list_code .= '<li>';
		}

		// wrapped current anchor
		$toc_list_code .= $list['tag'];

		// Set as previous head tag level
		$prev_depth = $list['depth'];

		// Last
		if ( $toc_num === $key + 1 ) {
			if ( $depth_level < 0 ) {
				for ( $i = 0; $i < (-1 * $depth_level); $i++ ) {
					$toc_list_code .= '</li></ul>';
				}
			}
		}
	}

	// Closure
	if ( empty($toc_list_code) ) {
		$DP_SINGLE_TOC = '';
	} else {
		// Close
		$DP_SINGLE_TOC .= $toc_list_code . '</li></ul></div>';
	}

	return $content;
}
add_filter( 'the_content', 'dp_table_of_contents' );


// Use this to show TOC
function dp_get_the_table_of_contents(){
	global $DP_SINGLE_TOC;
	return $DP_SINGLE_TOC;
}

/**
 * Insert the TOC into the head of single page content
 */
function dp_insert_the_table_of_contents_to_post($content) {
	$post_type = get_post_type();

	if ( $post_type !== 'post' || is_home() ) return $content;

	global $options;

	// Theme option
	if ( !isset($options['toc_position']) || $options['toc_position'] === 'none' ) {
		return $content;
	}

	// Custom field
	$dp_hide_toc = get_post_meta(get_the_ID(), 'dp_hide_toc', true);
	if ( $dp_hide_toc ) {
		return $content;
	}

	// Show the TOC
	if ( $options['toc_position'] === 'top' || $options['toc_position'] === 'right_float' ) {
		// Top of the entry
		$content = dp_get_the_table_of_contents() . $content;

	} else if ( $options['toc_position'] === 'before_first_h' ) {
		// Get the first head tag position
		$h_tag_position = dp_get_h_tag_position_in_content( $content );
		// Insert before first head tag
		if ( $h_tag_position ) {
			$content = preg_replace( DP_H_TAG_REG, dp_get_the_table_of_contents() . $h_tag_position, $content, 1);
		}
	}

	return $content;
}
add_filter( 'the_content', 'dp_insert_the_table_of_contents_to_post', 12 );


// Add a TOC shortcode
add_shortcode( 'dp_toc', 'dp_get_the_table_of_contents' );