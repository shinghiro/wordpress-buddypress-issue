<?php
function dp_article_sort_form(){
	global $options;

	/**
	 * Sort element
	 */
	$sort_code = '';

	if ( ( is_home() && isset($options['sort_enable_top']) && !empty($options['sort_enable_top']) ) 
		|| ( is_search() && isset($options['sort_enable_search'] ) && !empty($options['sort_enable_search']) )
		|| ( is_category() && !is_search() && isset($options['sort_enable_cat'] ) && !empty($options['sort_enable_cat']) )
		|| ( is_tag() && isset($options['sort_enable_tag'] ) && !empty($options['sort_enable_tag']) )
		|| ( is_date() && isset($options['sort_enable_date'] ) && !empty($options['sort_enable_date']) )
		|| ( is_author() && isset($options['sort_enable_author'] ) && !empty($options['sort_enable_author']) )
	){

		$default_sort = '';
		$sort_type = isset($_GET['sort']) && !empty($_GET['sort']) ? $_GET['sort'] : NULL;
		$current_url = is_ssl() ? 'https://' : 'http://';
		$current_url .= $_SERVER["HTTP_HOST"] . $_SERVER["REQUEST_URI"];

		$sort_code =
		'<div class="sort-form-area"><span class="sort-form-title"><i class="icon-sort-desc"></i>' . __('Sorting', 'DigiPress') . '</span><form method="get" class="sort-form" action="' . $current_url . '" target="_top">';

		/**
		 * This is search results
		 */
		if ( isset($_GET['s']) && !empty($_GET['s']) ){
			$sort_code .= '<input type="hidden" name="s" value="' . $_GET['s'] . '" />';
		}

		$sort_code .= '<select name="sort" onchange="submit(this.form);">';

		if ( isset($options['sort_by_newest_label']) && !empty($options['sort_by_newest_label']) ) {
			$sort_code .='<option value="date">' . $options['sort_by_newest_label'] . '</option>';
		} else {
			$sort_code .='<option value="date">' . __('Sort by newest', 'DigiPress') . '</option>';
		}

		/**
		 * Category or tag
		 */
		if ( is_category() && !is_search() && !isset($sort_type) ) {
			/**
			 * Sorted by default
			 */
			$obj = get_queried_object();
			$meta = get_option('ex_term_meta_' . $obj->cat_ID);

			if ( isset($meta['orderby']) && !empty($meta['orderby']) ) {
				$default_sort = $meta['orderby'];
			}

		} else if ( is_tag() && !isset($sort_type) ){
			/**
			 * Sorted by default
			 */

			$obj = get_queried_object();
			$meta = get_option('ex_term_meta_' . $obj->term_taxonomy_id);

			if ( isset($meta['orderby']) && !empty($meta['orderby']) ) {
				$default_sort = $meta['orderby'];
			}
		}

		/**
		 * Sorted by form
		 */

		// Modified
		if ( !isset($options['sort_by_modified']) || !empty($options['sort_by_modified']) ) {
			if ( (isset($sort_type) && $sort_type === 'modified') || $default_sort === 'modified' ) {
				$sort_code .= '<option value="modified" selected>';
			} else {
				$sort_code .= '<option value="modified">';
			}
			if ( isset($options['sort_by_modified_label']) && !empty($options['sort_by_modified_label']) ) {
				$sort_code .= $options['sort_by_modified_label'] . '</option>';
			} else {
				$sort_code .= __('Sort by modified', 'DigiPress') . '</option>';
			}
		}

		// Popular
		if ( !isset($options['sort_by_popular']) || !empty($options['sort_by_popular']) ) {
			if ( (isset($sort_type) && $sort_type === 'popular') || $default_sort === 'post_views_count') {
				$sort_code .= '<option value="popular" selected>';
			} else {
				$sort_code .= '<option value="popular">';
			}
			if ( isset($options['sort_by_popular_label']) && !empty($options['sort_by_popular_label']) ) {
				$sort_code .= $options['sort_by_popular_label'] . '</option>';
			} else {
				$sort_code .= __('Sort by popularity', 'DigiPress') . '</option>';
			}
		}

		// Comments
		if ( !isset($options['sort_by_comments']) || !empty($options['sort_by_comments']) ) {
			if ( (isset($sort_type) && $sort_type === 'comments') || $default_sort === 'comment_count') {
				$sort_code .= '<option value="comments" selected>';
			} else {
				$sort_code .= '<option value="comments">';
			}
			if ( isset($options['sort_by_comments_label']) && !empty($options['sort_by_comments_label']) ) {
				$sort_code .= $options['sort_by_comments_label'] . '</option>';
			} else {
				$sort_code .= __('Sort by comment count', 'DigiPress') . '</option>';
			}
		}

		// Title
		if ( !isset($options['sort_by_title']) || !empty($options['sort_by_title']) ) {
			if ( (isset($sort_type) && $sort_type === 'title') || $default_sort === 'title') {
				$sort_code .= '<option value="title" selected>';
			} else {
				$sort_code .= '<option value="title">';
			}
			if ( isset($options['sort_by_title_label']) && !empty($options['sort_by_title_label']) ) {
				$sort_code .= $options['sort_by_title_label'] . '</option>';
			} else {
				$sort_code .= __('Sort by title', 'DigiPress') . '</option>';
			}
		}

		// Slug
		if ( !isset($options['sort_by_name']) || !empty($options['sort_by_name']) ) {
			if ( (isset($sort_type) && $sort_type === 'name') || $default_sort === 'name') {
				$sort_code .= '<option value="name" selected>';
			} else {
				$sort_code .= '<option value="name">';
			}
			if ( isset($options['sort_by_name_label']) && !empty($options['sort_by_name_label']) ) {
				$sort_code .= $options['sort_by_name_label'] . '</option>';
			} else {
				$sort_code .= __('Sort by slug', 'DigiPress') . '</option>';
			}
		}

		$sort_code .= '</select></form></div>';
	}

	return $sort_code;
}