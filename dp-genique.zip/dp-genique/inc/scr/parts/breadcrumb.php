<?php
/**
* Create site navigation strings.
*/
function dp_breadcrumb($echo = true,
						$divOption = array(
										"id" => "dp_breadcrumb_nav", 
										"class" => "dp_breadcrumb_nav")) {
	if ( is_front_page() && !is_paged() ) return;

	global $options, $post, $CURRENT_POST_TYPE, $ELEMENTS_SHOW, $IS_WOOCOMMERCE;

	if ( !$ELEMENTS_SHOW['breadcrumb'] ) return;

	if ( $IS_WOOCOMMERCE && function_exists( 'woocommerce_breadcrumb' ) ){
		woocommerce_breadcrumb(
			array(
				'delimiter' => '',
				'wrap_before' => '<nav id="' . $divOption['id'] . '" class="' . $divOption['class'] . '"><ul>',
				'wrap_after' => '</ul></nav>',
				'before' => '<li><span class="nav_title">',
				'after'=> '</span></li>'
			)
		);
		return;
	}

	// No title class
	if ( !$ELEMENTS_SHOW['single_post_title'] && !$ELEMENTS_SHOW['eyecatch_header'] ) {
		$divOption['class'] = $divOption['class'] . ' no_title';
	}

	$breadcrumb ='';
	$blank_flag = true;

	// Not home and admin page
	if ( !is_admin() ){
		$tagAttribute = '';
		$tagTitleStart = '<span class="nav_title">';
		$tagTitleEnd = '</span>';
		$tagTitleIcon = '';

		foreach($divOption as $attrName => $attrValue){
			$tagAttribute .= sprintf(' %s="%s"', $attrName, $attrValue);
		}
		$breadcrumb .= '<nav'. $tagAttribute .'>';
		$breadcrumb .= '<ul>';

		// Home
		$breadcrumb .= '<li><a href="'. home_url() .'/" class="nav_home nav_link">' . $tagTitleStart . 'HOME' . $tagTitleEnd .'</a></li>';

		if (is_home() && is_paged()) {							// Home paged
			$tagTitleStart = '<span class="nav_title">';
			$breadcrumb .= '<li>' . $tagTitleStart . 'Page ' . get_query_var('paged') . $tagTitleEnd . '</li>';

			$blank_flag = false;

		}
		else if (is_search()) {							// Search result
			$word = isset( $_REQUEST['q']) ? $_GET['q'] : get_search_query();
			$tagTitleIcon = '<i class="icon-search"></i>';

			// Paged
			if (is_paged()) {
				$breadcrumb .= '<li>' . $tagTitleStart . $tagTitleIcon . $word . ' ( ' . get_query_var('paged') . ' ) ' . $tagTitleEnd . '</li>';
			} else {
				$breadcrumb .= '<li>' . $tagTitleStart . $tagTitleIcon . $word . $tagTitleEnd . '</li>';
			}
			$blank_flag = false;

		}
		else if (is_archive()){
			// Category
			if (is_category()) {
				// $tagTitleIcon = '<i class=" icon-folder"></i>';

				$cat = get_queried_object();
				if($cat->parent != 0){
					$ancestors = array_reverse(get_ancestors( $cat->cat_ID, 'category' ));
					foreach($ancestors as $ancestor){
						$breadcrumb .= '<li><a href="'. get_category_link($ancestor) .'" class="nav_link">' . $tagTitleStart . $tagTitleIcon . get_cat_name($ancestor) . $tagTitleEnd . '</a></li>';
					}
					$blank_flag = false;
				}

				// Paged
				if (is_paged()) {
					$breadcrumb .= '<li>' . $tagTitleStart . $tagTitleIcon . $cat->name . ' ( ' . get_query_var('paged') . ' ) ' . $tagTitleEnd . '</li>';
					$blank_flag = false;

				} else {
					$breadcrumb .= '<li>' . $tagTitleStart . $tagTitleIcon . $cat->name . $tagTitleEnd . '</li>';

					$blank_flag = false;
				}
			}
			else if (is_date()){
				// Date Archive
				$tagTitleIcon = '<i class="icon-calendar"></i>';

				if (get_query_var('day') != 0){				// Archive of the day
					$breadcrumb .= '<li><a href="'. get_year_link(get_query_var('year')). '" class="nav_link">' . $tagTitleStart . $tagTitleIcon . get_query_var('year').$tagTitleEnd . '</a></li>';
					$breadcrumb .= '<li><a href="'. get_month_link(get_query_var('year'), get_query_var('monthnum')). '" class="nav_link">' . $tagTitleStart . '/ ' . get_query_var('monthnum') . $tagTitleEnd . '</a></li>';
					$breadcrumb .= '<li>' . $tagTitleStart . '/ ' . get_query_var('day'). $tagTitleEnd . '</li>';

					$blank_flag = false;

				}
				else if (get_query_var('monthnum') != 0){	// Archive of the month
					$breadcrumb .= '<li><a href="'. get_year_link(get_query_var('year')) .'" class="nav_link">' . $tagTitleStart . $tagTitleIcon . get_query_var('year') . $tagTitleEnd .'</a></li>';
					// Paged
					if (is_paged()) {
						$breadcrumb .= '<li>' . $tagTitleStart . '/ ' . get_query_var('monthnum').' ( ' . get_query_var('paged') . ' ) ' . $tagTitleEnd . '</li>';
					} else {
						$breadcrumb .= '<li>' . $tagTitleStart . '/ ' . get_query_var('monthnum'). $tagTitleEnd .'</li>';
					}

					$blank_flag = false;
				} else {									// Archive of the year
					// Paged
					if (is_paged()) {
						$breadcrumb .= '<li>' . $tagTitleStart . $tagTitleIcon . get_query_var('year') .' ( ' . get_query_var('paged') . ' ) ' . $tagTitleEnd . '</li>';
					} else {
						$breadcrumb .= '<li>' . $tagTitleStart . $tagTitleIcon . get_query_var('year') . $tagTitleEnd . '</li>';
					}

					$blank_flag = false;
				}
			}
			else if (is_author()){
				// Archive of author
				$tagTitleIcon = '<i class="icon-user"></i>';
				// Paged
				if (is_paged()) {
					$breadcrumb .= '<li>' . $tagTitleStart . $tagTitleIcon  . get_the_author_meta('display_name', get_query_var('author')) . ' ( ' . get_query_var('paged') . ' ) ' . $tagTitleEnd . '</li>';
				} else {
					$breadcrumb .= '<li>' . $tagTitleStart . $tagTitleIcon  . get_the_author_meta('display_name', get_query_var('author')) . $tagTitleEnd . '</li>';
				}

				$blank_flag = false;
			}
			else if (is_tag()){
				// Archive of tag
				// $tagTitleIcon = '<i class="icon-tag"></i>';

				// Paged
				if (is_paged()) {
					$breadcrumb .= '<li>' . $tagTitleStart . $tagTitleIcon . single_tag_title( '' , false ) . ' ( ' . get_query_var('paged') . ' ) ' . $tagTitleEnd . '</li>';
				} else {
					$breadcrumb .= '<li>' . $tagTitleStart . $tagTitleIcon . single_tag_title( '' , false ) . $tagTitleEnd . '</li>';
				}

				$blank_flag = false;
			}
			else if (is_post_type_archive()) {
				$customPostTypeObj = get_post_type_object(get_post_type());
				$customPostTypeTitle = esc_html($customPostTypeObj->labels->name);

				$breadcrumb .= '<li>' . $tagTitleStart . $tagTitleIcon . $customPostTypeTitle . $tagTitleEnd . '</li>';

				$blank_flag = false;
			} else {
				// Other

				// Paged
				if (is_paged()) {
					$breadcrumb .= '<li>' . $tagTitleStart . $tagTitleIcon . wp_title('', false) . ' ( ' . get_query_var('paged') . ' ) ' . $tagTitleEnd . '</li>';
				} else {
					$breadcrumb .= '<li>' . $tagTitleStart . $tagTitleIcon . wp_title('', false) . $tagTitleEnd . '</li>';
				}

				$blank_flag = false;
			}

		}
		else if ( is_singular()) {

			$customPostTypeObj = get_post_type_object(get_post_type());
			$customPostTypeTitle = esc_html($customPostTypeObj->labels->name);

			if (is_single()) {
				// Single post
				if ( $CURRENT_POST_TYPE === 'post' ) {
					// $tagTitleIcon = '<i class=" icon-folder"></i>';
					// Single post
					$categories = get_the_category($post->ID);
					$cat = $categories[0];

					if( $cat->parent != 0 ){
						// Has parent category
						$ancestors = array_reverse(get_ancestors( $cat->cat_ID, 'category' ));
						foreach($ancestors as $ancestor){
							$breadcrumb .= '<li><a href="'. get_category_link($ancestor).'" class="nav_link">' . $tagTitleStart . $tagTitleIcon . get_cat_name($ancestor) . $tagTitleEnd . '</a></li>';
						}
					}

					if ( count($categories) > 1 ) {
						$breadcrumb .= '<li><a href="'. get_category_link($cat->term_id) . '" class="nav_link">' . $tagTitleStart . $tagTitleIcon . $cat->cat_name . ', &#8230;' . $tagTitleEnd . '</a></li>';
					} else {
						$breadcrumb .= '<li><a href="'. get_category_link($cat->term_id) . '" class="nav_link">' . $tagTitleStart . $tagTitleIcon . $cat->cat_name . $tagTitleEnd . '</a></li>';
					}

				} else {
					// Maybe custom post type
					$breadcrumb .= '<li><a href="' . get_post_type_archive_link($post->post_type) . '" class="nav_link">' . $tagTitleStart . $tagTitleIcon . $customPostTypeTitle . $tagTitleEnd . '</a></li>';
				}

				$post_title =  the_title('', '', false) ? the_title('', '', false) : __('No Title', 'DigiPress');
				$post_title = strip_tags($post_title);
				$post_title = (mb_strlen($post_title, 'utf-8') > 58) ? mb_substr($post_title, 0, 58, 'utf-8') . '&#8230;' : $post_title;

				$breadcrumb .= '<li><a href="' . get_permalink() . '" class="nav_link">' . $tagTitleStart . $post_title . $tagTitleEnd . '</a></li>';

			}
			else if ( $CURRENT_POST_TYPE === 'page' ){
				// Page
				if($post->post_parent != 0 ){
					$ancestors = array_reverse(get_post_ancestors( $post->ID ));
					foreach($ancestors as $ancestor){
						$breadcrumb .= '<li><a href="'. get_permalink($ancestor).'" class="nav_link">' . $tagTitleStart . $tagTitleIcon . get_the_title($ancestor) . $tagTitleEnd . '</a></li>';
					}
					$post_title =  the_title('', '', false) ? the_title('', '', false) : __('No Title', 'DigiPress');
					$post_title = strip_tags($post_title);
					$post_title = (mb_strlen($post_title, 'utf-8') > 58) ? mb_substr($post_title, 0, 58, 'utf-8') . '&#8230;' : $post_title;

					$breadcrumb .= '<li><a href="' . get_permalink() . '" class="nav_link">' . $tagTitleStart . $tagTitleIcon . $post_title . $tagTitleEnd . '</a></li>';
				} else {
					$post_title =  the_title('', '', false) ? the_title('', '', false) : __('No Title', 'DigiPress');
					$post_title = strip_tags($post_title);
					$post_title = (mb_strlen($post_title, 'utf-8') > 58) ? mb_substr($post_title, 0, 58, 'utf-8') . '&#8230;' : $post_title;

					$breadcrumb .= '<li><a href="' . get_permalink() . '" class="nav_link">' . $tagTitleStart . $tagTitleIcon . $post_title . $tagTitleEnd . '</a></li>';
				}
			}
			else if (is_attachment()){						// Atttachment page
				$tagTitleIcon = '<i class="icon-attach"></i>';
				$breadcrumb .= '<li>' . $tagTitleStart . $tagTitleIcon . $post->post_title . $tagTitleEnd .'</li>';	
			}
			$blank_flag = false;

		}
		else if (is_404()){								// 404 Not Found
			$breadcrumb .= '<li>' . $tagTitleStart . $tagTitleIcon . 'Not found' . $tagTitleEnd . '</li>';

			$blank_flag = false;

		} else {											// Else
			$breadcrumb .= '<li>' . $tagTitleStart . $tagTitleIcon . wp_title('', false) . $tagTitleEnd . '</li>';

			$blank_flag = false;
		}

		$breadcrumb .= '</ul>';
		$breadcrumb .= '</nav>';
	}

	if (!$blank_flag) {
		if ($echo) {
			echo $breadcrumb;
		} else {
			return $breadcrumb;
		}
	}
}