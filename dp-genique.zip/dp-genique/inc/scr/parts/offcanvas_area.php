<?php
/**
 * Offcanvas menu area code
 * @return {[type]} [description]
 */
function dp_offcanvas_menu_area( $wow_class = '' ){
	global $options, $IS_MOBILE_DP;

	if ( $IS_MOBILE_DP ) return;

	$offcanvas_menu_flag = false;
	$offcanvas_menu_code = '';

	// From sns_contact_icons.php
	$sns_code = dp_sns_contact_icons( 'header' );

	if ( !empty($sns_code) ) {
		$sns_code = '<div id="hd_sns_links" class="hd_sns_links">' . $sns_code . '</div>';
	}

	/**
	 * Tel number
	 */
	if ( isset($options['global_menu_tel']) && !empty($options['global_menu_tel']) ) {
		$offcanvas_menu_flag = true;
		$offcanvas_menu_code .= '<div class="hd_tel"><a href="tel:'.$options['global_menu_tel'].'" class="icon-phone"><span>'.$options['global_menu_tel'].'</span></a></div>';
	}

	/**
	 * Search form window
	 */
	if ($options['global_menu_search_form'] !== 'none') {
		$offcanvas_menu_flag = true;
		$offcanvas_menu_code .= '<div id="hidden_search_window" class="hidden_search">';

		if ($options['global_menu_search_form'] === 'gcs') {
			// Google Custom Search
			$offcanvas_menu_code .= '<div id="dp_hd_gcs"><gcse:searchbox-only></gcse:searchbox-only></div>';
		} else {
			// Default search form

			// Preset keywords
			$preset_phrase = isset($options['global_menu_search_form_preset_kw_title']) && !empty($options['global_menu_search_form_preset_kw_title']) ? $options['global_menu_search_form_preset_kw_title'] : '';
			$preset_words = isset($options['global_menu_search_form_preset_kw']) && !empty($options['global_menu_search_form_preset_kw']) ? $options['global_menu_search_form_preset_kw'] : '';

			// Defined at /scr/search_form.php
			$offcanvas_menu_code .= dp_custom_search_form(false, array(
				'form_id' => 'hidden-searchform',
				'param_cat' => false,
				'param_tag' => false,
				'param_type' => false,
				'param_range' => false,
				'preset_phrase' => $preset_phrase,
				'preset_words' => $preset_words));

		}	// End of if ($options['global_menu_seach_form'] === 'gcs')

		$offcanvas_menu_code .= '</div>';
	}	// End if

	/**
	 * offcanvas_menu_ul
	 */
	if ( function_exists('wp_nav_menu') ) {
		if ( has_nav_menu('offcanvas_menu') ) {
			$offcanvas_menu_flag = true;

			$menu_num_class = 'offcanvas_menu_ul';
			$menu_num_class .= isset($options['disable_pjax']) && !empty($options['disable_pjax']) ? ' no_pjax' : ' use_pjax';

			$offcanvas_menu_code .= '<nav id="dp_hidden_menu" class="offcanvas_menu">';

			ob_start();
			wp_nav_menu(array(
				'theme_location'=> 'offcanvas_menu',
				'container'	=> 'ul',
				'menu_id'	=> 'offcanvas_menu_ul',
				'menu_class'=> $menu_num_class,
				'depth' => 1,
				'anchor_class' => 'delay_pjax',
				'fallback_cb' => '__return_false',
				'walker'	=> new dp_custom_menu_walker()
			));
			$offcanvas_menu_code .= ob_get_contents();
			ob_end_clean();

			$offcanvas_menu_code .= '</nav>';
		}
	}

	/**
	 * Offcanvas menu
	 */
	if ( $offcanvas_menu_flag ) {
		// Insert offcanvas panel element
		echo '<div id="offcanvas_overlay" class="offcanvas_overlay"></div><div id="offcanvas_menu_area" class="offcanvas_menu_area">' . $sns_code . $offcanvas_menu_code . '</div><div id="offcanvas_menu_trigger" class="offcanvas_menu_trigger' . $wow_class . '" role="button"><span class="trg_obj"><i></i></span></div>';
	}
}