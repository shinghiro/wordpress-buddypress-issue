<?php

function dp_show_child_terms($echo = true){

	global $options, $ARCHIVE_STYLE, $COLUMN_NUM;

	$children = $ARCHIVE_STYLE['children'];


	if ( ! $children || ! is_array($children) ) {
		return false;
	}

	$container_class = 'tmlist_container ' . $ARCHIVE_STYLE['sub_terms_layout'];

	if ( $COLUMN_NUM == 1 ) {
		$container_class .= ' one-col';
	} else {
		$container_class .= ' two-col';
	}

	// Mouseover effect class
	if ( !empty($ARCHIVE_STYLE['sub_terms_hover_fx']) ) {
		$container_class .= ' ' . $ARCHIVE_STYLE['sub_terms_hover_fx'];
	}

	// Crop image class
	if ( !empty($ARCHIVE_STYLE['sub_terms_crop_circle_image']) && $ARCHIVE_STYLE['sub_terms_layout'] !== 'simple_list' ) {
		$container_class .= ' circle-image';
	}



	$code = '';

	// Each term
	foreach ( $children as $term ) {

		// Get current term options
		$term_meta = get_option('ex_term_meta_' . $term->term_id);

		// Get current archive link
		$term_url = get_term_link($term->term_id);

		// Featured image
		$image = '';
		if ( $ARCHIVE_STYLE['sub_terms_layout'] !== 'simple_list' ) {
			if ( isset($term_meta['img']) && !empty($term_meta['img']) ) {
				// Use image URL
				$image = $term_meta['img'];
			} else {
				// NO IMAGE
				if ( !empty($ARCHIVE_STYLE['sub_terms_no_image']) ) {
					$image = $ARCHIVE_STYLE['sub_terms_no_image'];
				} else {
					$image = DP_THEME_URI . '/img/post_thumbnail/noimage.png';
				}
			}
			$image = '<figure class="tmlist_figure"><img src="' . esc_url($image) . '" class="tmlist_image" width="600" height="480" alt="Featured Image" /></figure>';
		}

		$code .= '<div class="tmlist_item"><a href="' . esc_url( $term_url ) .'" class="tmlist_link">' . $image . '<div class="tmlist_meta"><h4 class="tmlist_title">' . $term->name . '</h4></div></a></div>';
	}

	if ( !empty($code) ) {
		$code = '<div class="' . $container_class . '"><div class="tmlist_content">' . $code . '</div></div>';
	}

	// Result
	if ( $echo ) {
		echo $code;
	} else {
		return $code;
	}
}