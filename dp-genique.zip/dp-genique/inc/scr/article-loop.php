<?php
/**
 * Article loop in archive page only.
 * @param  object $posts global $posts
 * @return string        article loop code
 */
function dp_article_loop( $posts ){
	global $options;

	// Exceptions
	if ( is_home() && $options['top_page_main_content'] === 'none' ) return;
	if ( is_singular() ) return;
	if ( !isset( $posts ) || empty( $posts ) ) return;

	global $post, $COLUMN_NUM, $ARCHIVE_STYLE, $IS_MOBILE_DP;

	// Get archive style (/inc/scr/get_archive_style.php)
	// return {$top_or_archive, $archive_type, $layout}
	//params before extraction

	$loop_section_class = 'loop-section';
	$loop_section_style = '';
	$top_or_archive = '';

	extract( $ARCHIVE_STYLE );


	// Counter
	$i = 0;

	// Params
	$main_js = 'main.min.js';
	$html_code = '';
	$loop_code = '';
	$col_class = '';
	$excerpt_length = 120;
	$infeed_article_class = 'loop-article infeed no-cat';
	$cat_name = '';
	$grid_size = '';
	$isotope_grid_gutter = '';
	$more_url = '';
	$suffix_mb = '';
	$filter_form = '';
	$read_more_str = empty( $options[$top_or_archive . '_readmore_str'] ) ? 'Read More' : $options[$top_or_archive . '_readmore_str'];
	$loop_col_class = !empty( $options[$top_or_archive . '_loop_col'] ) ? ' lp-col' . $options[$top_or_archive . '_loop_col'] : '';


	$loop_section_class .= $layout == 'normal' || $layout == 'portfolio' ? ' nm-pf-common' : '';
	$loop_section_class .= $layout == 'portfolio' || $layout == 'magazine' ? ' pf-mz-common' : '';

	// Mobile
	if ( $IS_MOBILE_DP ){
		$suffix_mb = '_mobile';
		$main_js = 'mb-' . $main_js;
		$layout .= ' mobile';
		$col_class = '';
	}
	// PC
	else {
		// Column
		$col_class = ' two-col';

		if ( $COLUMN_NUM === 1 ) {
			$col_class = ' one-col';
		}
		else if ( $COLUMN_NUM === 3 ) {
			$col_class = ' three-col';
		}
	}



	/**
	* Check the transient data and return the cache if cache is exists
	*/
	$transient_suffix = md5( $_SERVER["HTTP_HOST"] . $_SERVER["REQUEST_URI"] );
	if ( dp_is_enable_cache( array( 'target' => 'article_loop' ) ) ){
		$cache = false;
		if ( $IS_MOBILE_DP ){
			$cache = get_transient( 'dp_alp_mb_' . $transient_suffix );
		} else {
			$cache = get_transient( 'dp_alp_' . $transient_suffix );
		}

		// Display
		if ( $cache !== false ) {
			// Reload swiper.js for thumbnail slider
			if ( strpos( $layout, 'slider' ) === false && $layout !== 'simple' ) {
				wp_enqueue_script( 'imagesloaded', null, array( 'jquery' ), null, true );
				wp_enqueue_script( 'isotope', DP_THEME_URI . '/inc/js/jquery/jquery.isotope.min.js', array( 'jquery','imagesloaded' ), DP_OPTION_SPT_VERSION, true );

				wp_enqueue_style( 'dp-swiper', DP_THEME_URI . '/css/swiper-bundle.css', null, DP_OPTION_SPT_VERSION );
				wp_enqueue_script( 'dp-swiper', DP_THEME_URI . '/inc/js/swiper-bundle.min.js', null, false, true );

				// Reload main js
				wp_deregister_script( 'dp-main' );
				wp_enqueue_script( 'dp-main', DP_THEME_URI . '/inc/js/' . $main_js, array( 'isotope', 'dp-swiper' ), echo_filedate(DP_THEME_DIR . '/inc/js/' . $main_js), true );
			}
			return $cache;
		}
	}



	// Sort form
	$sort_form = dp_article_sort_form();


	// Portfolio or magazine
	if ( ( strpos( $layout, 'portfolio' ) !== false) || ( strpos( $layout, 'magazine' ) !== false ) ) {
		// isotope
		if ( $options['disable_pjax' . $suffix_mb] ) {
			wp_enqueue_script( 'imagesloaded', null, array( 'jquery' ), null, true);
			wp_enqueue_script( 'isotope', DP_THEME_URI . '/inc/js/jquery/jquery.isotope.min.js', array( 'jquery','imagesloaded' ),DP_OPTION_SPT_VERSION,true);
			// Reload main js
			wp_deregister_script( 'dp-main' );
			wp_enqueue_script( 'dp-main', DP_THEME_URI . '/inc/js/' . $main_js, array( 'isotope' ), echo_filedate(DP_THEME_DIR . '/inc/js/' . $main_js),true);
		}

		// Filtering form UI for isotope
		if ( is_home() && ( isset( $options['enable_loop_article_filter'] ) && !empty( $options['enable_loop_article_filter'] ) ) ){
			$arg = array(
				'hierarchical' => 0,
				'exclude' => $options['exclude_cats_filter'] );
			$cats = get_categories( $arg );
			foreach( $cats as $key => $cat){
				$filter_form .= '<label class="flt-btn"><input type="checkbox" value=".cat-flt' . $cat->term_id . '" /><span>' . $cat->name . '</span></label>';
			}
			$filter_form = '<div class="loop-filter-form' . $col_class . '">' . $filter_form . '</div>';
		}

		// grid and gutter element
		$isotope_grid_gutter = '<div class="grid-sizer' . $col_class . $loop_col_class . '"></div><div class="gutter-sizer' . $col_class . $loop_col_class . '"></div>';
	}



	// wow.js
	$wow_title_css 	= $wow_article_css = '';
	if ( !(bool)$options['disable_wow_js' . $suffix_mb] ){
		$wow_title_css = ' wow fadeInDown';
		if ( empty( $filter_form ) ) {
			$wow_article_css 	= ' wow fadeInUp';
		}
	}

	// Excerpt length
	if ( isset( $options[$top_or_archive . '_article_excerpt_length'] ) && !empty( $options[$top_or_archive . '_article_excerpt_length'] ) ){
		if ( strpos( $layout, 'magazine' ) !== false ) {
			$excerpt_length = 68;
		} else {
			$excerpt_length = $options[$top_or_archive . '_article_excerpt_length'];
		}
	}

	// Overlay color
	$overlay_color = ' ' . $options[$top_or_archive . '_overlay_color'] . '-bg';

	// Params
	$args = array(
			'number' => $options['number_posts_index'],
			'pub_date'=> $options[$top_or_archive . '_archive_list_date'],
			'show_cat'=> $options[$top_or_archive . '_archive_list_cat'],
			'views'=> $options[$top_or_archive . '_archive_list_views'],
			'author'=> $options[$top_or_archive . '_archive_list_author'],
			'hatebu_num'=> $options['hatebu_number_after_title_' . $top_or_archive],
			'likes_num'=> $options['likes_number_after_title_' . $top_or_archive],
			'tweets_num'=> $options['tweets_number_after_title_' . $top_or_archive],
			'post_type'=> get_post_type(),
			'col_class' => $col_class,
			'loop_col_class' => $loop_col_class,
			'type'=> '',
			'more_text'=> '',
			'voted_icon' => '',
			'voted_count' => false,
			'if_img_tag' => false,
			'fix_thumb_h' => false,
			'layout'=> $layout,
			'excerpt_length' => $excerpt_length,
			'overlay_color'=> $overlay_color,
			'read_more_str' => $read_more_str,
			'wow_article_css'=> $wow_article_css
		);


	/**
	 * For infeed Ads
	 */
	// Load infeed ads
	require_once( DP_THEME_DIR . '/inc/scr/parts/infeed_ads.php' );
	// Settings for infeed ads
	$infeed_ads_flg = false;
	$infeed_ads_code = '';
	$infeed_ads_order = null;
	if ( !empty( $options[$top_or_archive . '_infeed_ads_code' . $suffix_mb] ) && !empty( $options[$top_or_archive . '_infeed_ads_order' . $suffix_mb] ) ) {
		$infeed_ads_flg = true;
		$infeed_ads_code = $options[$top_or_archive . '_infeed_ads_code' . $suffix_mb];
		$infeed_ads_order = explode(",", $options[$top_or_archive . '_infeed_ads_order' . $suffix_mb] );
	}


	/**
	 * Show post list
	 *
	 * Call the function written in "listing_post_styles.php"
	 */
	switch ( $layout ) {
		case 'normal':
		case 'normal mobile':

			$args['title_length'] = 180;

			// infeed ads class
			$infeed_article_class .= $args['wow_article_css'];

			foreach( $posts as $post_num => $post ) : setup_postdata( $post );

				if ( $infeed_ads_flg ) {
					$loop_code .= dp_get_infeed_ads(array(
						'top_or_archive' => $top_or_archive,
						'suffix_mb' => $suffix_mb,
						'post_num' => $post_num + 1,
						'infeed_ads_order' => $infeed_ads_order,
						'infeed_ads_code' => $infeed_ads_code,
						'wrapper_before' => '<div class="' . $infeed_article_class . '">',
						'wrapper_after' => '</div>'
						));
				}
				$args['comment'] = comments_open();
				$arr_post_ele = dp_post_list_get_elements( $args );
				$loop_code .= dp_show_post_list_for_archive_normal( $args, $arr_post_ele );

			endforeach;

			wp_reset_postdata();

			break;

		case 'portfolio':
		case 'portfolio mobile':

			if ( isset( $options[$top_or_archive . '_fix_article_height'] ) && !empty( $options[$top_or_archive . '_fix_article_height'] ) ){
				$loop_section_class .= ' fix_thumb_h';
			}

			$args['title_length'] = 120;
			$args['grid_size'] = $grid_size; // nothing

			// infeed ads class
			$infeed_article_class = $col_class . $loop_col_class . $wow_article_css;

			foreach( $posts as $post_num => $post ) : setup_postdata( $post );
				if ( $infeed_ads_flg ) {
					$loop_code .= dp_get_infeed_ads(array(
						'top_or_archive' => $top_or_archive,
						'suffix_mb' => $suffix_mb,
						'post_num' => $post_num + 1,
						'infeed_ads_order' => $infeed_ads_order,
						'infeed_ads_code' => $infeed_ads_code,
						'wrapper_before' => '<div class="' . $infeed_article_class . '">',
						'wrapper_after' => '</div>'
						));
				}

				$args['comment'] = comments_open();
				$arr_post_ele = dp_post_list_get_elements( $args );


				$loop_code .= dp_show_post_list_for_archive_portfolio1( $args, $arr_post_ele );

			endforeach;

			wp_reset_postdata();

			break;

		case 'magazine':
		case 'magazine mobile':

			$loop_section_class .= ' fix_thumb_h';

			// Chain classes
			$args['magazine_title_by_bold'] = !empty( $options[$top_or_archive . '_magazine_title_by_bold'] ) ? ' ' . $options[$top_or_archive . '_magazine_title_by_bold'] : '';
			$args['magazine_text_by_serif'] = !empty( $options[$top_or_archive . '_magazine_text_by_serif'] ) ? ' ' . $options[$top_or_archive . '_magazine_text_by_serif'] : '';
			$args['magazine_text_vertically'] = !empty( $options[$top_or_archive . '_magazine_text_vertically'] ) ? ' ' . $options[$top_or_archive . '_magazine_text_vertically'] : '';
			$args['magazine_cover_frame'] = !empty( $options[$top_or_archive . '_magazine_cover_frame'] ) ? ' ' . $options[$top_or_archive . '_magazine_cover_frame'] : '';
			$args['magazine_title_position'] = !empty( $options[$top_or_archive . '_magazine_title_position'] ) && empty( $options[$top_or_archive . '_magazine_text_vertically'] ) ? ' ' . $options[$top_or_archive . '_magazine_title_position'] : '';
			$args['magazine_title_tilt'] = !empty( $options[$top_or_archive . '_magazine_title_tilt'] ) ? ' ' . $options[$top_or_archive . '_magazine_title_tilt'] : '';
			$args['magazine_title_back'] = !empty( $options[$top_or_archive . '_magazine_title_back'] ) ? ' ' . $options[$top_or_archive . '_magazine_title_back'] : '';
			$args['magazine_title_back_border'] = !empty( $args['magazine_title_back'] ) && !empty( $options[$top_or_archive . '_magazine_title_back_border'] ) ? ' ' . $options[$top_or_archive . '_magazine_title_back_border'] : '';
			$args['magazine_date_design'] = !empty( $options[$top_or_archive . '_magazine_date_design'] ) ? ' ' . $options[$top_or_archive . '_magazine_date_design'] : ' date1';
			$args['magazine_accent_shape'] = !empty( $options[$top_or_archive . '_magazine_accent_shape'] ) ? ' ' . $options[$top_or_archive . '_magazine_accent_shape'] : '';

			// Common color, opacity styles
			$loop_section_style = !empty( $options[$top_or_archive . '_magazine_cover_frame_color'] ) && $options[$top_or_archive . '_magazine_cover_frame_color'] !== '#ffffff' ? '--mgz-frame-color:' . $options[$top_or_archive . '_magazine_cover_frame_color'] . ';' : '';
			$loop_section_style .= !empty( $options[$top_or_archive . '_magazine_title_color'] ) && $options[$top_or_archive . '_magazine_title_color'] !== '#ffffff' ? '--mgz-title-color:' . $options[$top_or_archive . '_magazine_title_color'] . ';' : '';
			$loop_section_style .=  !empty( $options[$top_or_archive . '_magazine_title_back'] ) && !empty( $options[$top_or_archive . '_magazine_title_back_color'] ) && $options[$top_or_archive . '_magazine_title_back_color'] !== '#000000' ? '--mgz-title-bg-color:' . $options[$top_or_archive . '_magazine_title_back_color'] . ';' : '';
			$loop_section_style .= !empty( $args['magazine_title_back'] ) && !empty( $options[$top_or_archive . '_magazine_title_back_color_opacity'] ) && $options[$top_or_archive . '_magazine_title_back_color_opacity'] !== 50 ? '--mgz-title-bg-opacity:' . ( $options[$top_or_archive . '_magazine_title_back_color_opacity'] / 100 ) . ';' : '';
			$loop_section_style .= !empty( $options[$top_or_archive . '_magazine_accent_shape_color'] ) ? '--acc-shape-color:' . $options[$top_or_archive . '_magazine_accent_shape_color'] . ';' : '';
			$loop_section_style .= !empty( $options[$top_or_archive . '_magazine_accent_shape_opacity'] ) && $options[$top_or_archive . '_magazine_accent_shape_opacity'] !== 30 ? '--acc-shape-opacity:' . ( $options[$top_or_archive . '_magazine_accent_shape_opacity'] / 100 ) . ';' : '';


			$args['title_length'] = 62;

			foreach( $posts as $post_num => $post ) : setup_postdata( $post );
				if ( $infeed_ads_flg ) {
					$loop_code .= dp_get_infeed_ads(array(
						'top_or_archive' => $top_or_archive,
						'suffix_mb' => $suffix_mb,
						'post_num' => $post_num + 1,
						'infeed_ads_order' => $infeed_ads_order,
						'infeed_ads_code' => $infeed_ads_code,
						'wrapper_before' => '<div class="' . $infeed_article_class . '">',
						'wrapper_after' => '</div>'
						));
				}

				$args['comment'] = comments_open();
				$arr_post_ele = dp_post_list_get_elements( $args );
				$loop_code .= dp_show_post_list_for_archive_magazine1( $args, $arr_post_ele );
			endforeach;
			wp_reset_postdata();

			break;

		case 'news':
		case 'news mobile':
			$args['title_length'] = 160;
			foreach( $posts as $post ) : setup_postdata( $post );
				$arr_post_ele = dp_post_list_get_elements( $args );
				$loop_code .= dp_show_post_list_for_archive_news( $args, $arr_post_ele );
			endforeach;
			wp_reset_postdata();

			break;

		case 'simple':
		case 'simple mobile':

			$layout .= ' news';

			$args['title_length'] = 160;
			$args['if_img_tag'] = true;
			foreach( $posts as $post ) : setup_postdata( $post );
				$arr_post_ele = dp_post_list_get_elements( $args );
				$loop_code .= dp_show_post_list_for_archive_simple( $args, $arr_post_ele );
			endforeach;
			wp_reset_postdata();
			break;
	}

	// Loop section styles
	$loop_section_style = !empty( $loop_section_style) ? ' style="' . $loop_section_style . '"' : '';


	// Loop section classes
	$loop_section_class .= ' lp-' . $top_or_archive . ' ' . $layout . $loop_col_class . $col_class;
	$loop_section_class .= isset( $options[$top_or_archive . '_article_round_corner'] ) && !empty( $options[$top_or_archive . '_article_round_corner'] ) ? ' item-rounded' : '' ;
	$loop_section_class .= isset( $options[$top_or_archive . '_article_box_shadow'] ) && !empty( $options[$top_or_archive . '_article_box_shadow'] ) ? ' item-boxshadow' : '' ;
	$loop_section_class .= isset( $options[$top_or_archive . '_article_alternately'] ) && !empty( $options[$top_or_archive . '_article_alternately'] ) ? ' item-alter' : '' ;


	/**
	 * Artcle list section source
	 */
	$html_code = '<section class="' . $loop_section_class . '"' . $loop_section_style .'>';

	/**
	 * Main title (Only Top page)
	 */
	if ( is_home() ) {
		if ( !is_paged() ) {
			if ( !empty( $options['top_posts_list_title'] ) ) {
				$html_code .= '<header class="loop-sec-header"><h1 class="inside-title' . $wow_title_css . '"><span>' . $options['top_posts_list_title'] . '</span></h1></header>';
			}
		} else {
			// Title (create_title_desc.php)
			$arr_title = dp_current_page_title();

			$html_code .= '<header class="loop-sec-header"><h1 class="inside-title' . $wow_title_css . '"><span>' . $arr_title['title'] . '</span></h1></header>';
		}
	}

	// Whole html code
	$html_code .= $sort_form . $filter_form . '<div class="loop-div">' . $isotope_grid_gutter . $loop_code . '</div></section>';



	/**
	 * Navigation
	 */
	$navigation_text_to_2page = (isset( $options['navigation_text_to_2page_' . $top_or_archive] ) && !empty( $options['navigation_text_to_2page_' . $top_or_archive] )) ? '<span>' . $options['navigation_text_to_2page_' . $top_or_archive] . '</span>' : '';
	$next_page_link = get_next_posts_link( $navigation_text_to_2page );
	$prev_page_link = get_previous_posts_link();

	if ( !empty( $next_page_link) ) {
		// 1st page
		if ( !is_paged() ) {
			if ( !empty( $navigation_text_to_2page) ) {
				$html_code .= '<nav class="navigation"><div class="nav_to_paged">' . $next_page_link . '</div></nav>';
			}
		} else {
			// Paged
			ob_start();
			dp_pagenavi( '<nav class="navigation">', '</nav>' );
			$html_code .= ob_get_contents();
			ob_end_clean();
		}
	} else {	// !empty( $next_page_link)
		// Last page
		if ( !empty( $prev_page_link) ) {
			ob_start();
			dp_pagenavi( '<nav class="navigation">', '</nav>' );
			$html_code .= ob_get_contents();
			ob_end_clean();
		}
	}



	/**
	 * Save to cache
	 */
	if ( dp_is_enable_cache( array( 'target' => 'article_loop' ) ) ){
		if ( $IS_MOBILE_DP ){
			set_transient( 'dp_alp_mb_' . $transient_suffix, $html_code, 0 );
		} else {
			set_transient( 'dp_alp_' . $transient_suffix, $html_code, 0 );
		}
	}


	// Result
	return $html_code;
}