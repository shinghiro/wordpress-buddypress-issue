<?php
/**
 * DigiPress functions and definitions
 *
 * @package DigiPress
 */

$dp_theme_upload_dir = wp_upload_dir();
$upload_url = is_ssl() ? str_replace( 'http:', 'https:', $dp_theme_upload_dir['baseurl'] ) : $dp_theme_upload_dir['baseurl'];
$theme_url = is_ssl() ? str_replace( 'http:', 'https:', get_template_directory_uri() ) : get_template_directory_uri();

//Version
define( 'DP_OPTION_SPT_VERSION', '1.0.2.8' );
//Base theme name
define( 'DP_THEME_NAME', 'Genique' );
//Base theme key
define( 'DP_THEME_KEY', 'genique' );
// Theme Slug
define ('DP_THEME_SLUG', 'dp_genique' );
//Theme ID
define( 'DP_THEME_ID', 'DigiPress' );
//Theme URI
define( 'DIGIPRESS_URI', 'https://digipress.info/' );
//Author URI
define( 'DP_AUTHOR_URI', 'https://www.digistate.co.jp/' );
//Theme Directory
define( 'DP_THEME_DIR', __DIR__ );
//Theme Directory
define( 'DP_THEME_URI', $theme_url );
//Theme Directory for mobile
define( 'DP_MOBILE_THEME_DIR', 'mobile' );
//Column Type(1, 2)
define( 'DP_COLUMN', '2' );
// Theme Type
define( 'DP_BUTTON_STYLE', 'flat6' );
//Original upload dir
define( 'DP_UPLOAD_DIR', $dp_theme_upload_dir['basedir'] . '/digipress/' . DP_THEME_KEY );
//Original upload path
define( 'DP_UPLOAD_URI', $upload_url . '/digipress/' . DP_THEME_KEY );
// Theme option name
define( 'DP_THEME_OPT_NAME', 'dp_theme_options' );

/**
* GLOBALS
*/
$FB_APP_ID = $COLUMN_NUM = $SIDEBAR_FLOAT = $SIDEBAR2_FLOAT = $CURRENT_POST_TYPE = $CONTAINER_EDGE = '';
$options = $ARCHIVE_STYLE = $SINGLE_META = $ELEMENTS_SHOW = array();
$EXIST_FB_LIKE_BOX = $IS_MOBILE_DP = $IS_WOOCOMMERCE = false;

/**
 * Load text domain
 */
add_action( 'after_setup_theme', 'dp_theme_after_setup_theme' );
function dp_theme_after_setup_theme() {
    load_theme_textdomain( 'DigiPress', get_template_directory() . '/languages' );
}

/**
* Admin only
*/
require_once( ABSPATH . 'wp-admin/includes/file.php' );
require_once( DP_THEME_DIR . '/inc/admin/def_options.php' );
if ( is_customize_preview() ){
	include_once(DP_THEME_DIR . '/inc/admin/theme_customizer.php' );
}
if ( is_admin() ) {
	require_once( DP_THEME_DIR . '/inc/admin/theme_options_class.php' );
	require_once( DP_THEME_DIR . '/inc/admin/permission_check.php' );
	require_once( DP_THEME_DIR . '/inc/admin/extended.php' );
	require_once( DP_THEME_DIR . '/inc/admin/error-tracking.php' );
	require_once( DP_THEME_DIR . '/inc/admin/admin-actions.php' );
	require_once( DP_THEME_DIR . '/inc/scr/generator/create_css.php' );
}

/**
* Load theme options/global
*/
function dp_get_option(){
	global $options, $def_options;
	$options = get_option(DP_THEME_OPT_NAME );
	if (empty($options)) {
		update_option( DP_THEME_OPT_NAME, $def_options );
		$options = $def_options;
	}
	return $options;
}
dp_get_option();

/**
 * Load theme updater functions.
 * Action is used so that child themes can easily disable.
 */
function dp_prefix_theme_updater() {
	require( DP_THEME_DIR . '/inc/scr/updater/theme-updater.php' );
}
add_action( 'after_setup_theme', 'dp_prefix_theme_updater' );

/**
* Include Function
*/
require_once( ABSPATH . '/wp-admin/includes/template.php' );

// Controllers
require_once( DP_THEME_DIR . '/inc/scr/control/control_cache.php' );
require_once( DP_THEME_DIR . '/inc/scr/control/count_sns.php' );
require_once( DP_THEME_DIR . '/inc/scr/control/custom_menu.php' );
require_once( DP_THEME_DIR . '/inc/scr/control/custom_post_type.php' );
require_once( DP_THEME_DIR . '/inc/scr/control/date_lang.php' );
require_once( DP_THEME_DIR . '/inc/scr/control/disable_auto_format.php' );
require_once( DP_THEME_DIR . '/inc/scr/control/frontend_enqueue.php' );
require_once( DP_THEME_DIR . '/inc/scr/control/get_archive_style.php' );
require_once( DP_THEME_DIR . '/inc/scr/control/is_woocommerce_dp.php' );
require_once( DP_THEME_DIR . '/inc/scr/control/get_column_num.php' );
require_once( DP_THEME_DIR . '/inc/scr/control/get_comments_popup_link.php' );
require_once( DP_THEME_DIR . '/inc/scr/control/get_elements_visibility.php' );
require_once( DP_THEME_DIR . '/inc/scr/control/get_image_size.php' );
require_once( DP_THEME_DIR . '/inc/scr/control/get_post_type.php' );
require_once( DP_THEME_DIR . '/inc/scr/control/insert_access_analyze_code.php' );
require_once( DP_THEME_DIR . '/inc/scr/control/insert_post_middle_widget.php' );
require_once( DP_THEME_DIR . '/inc/scr/control/insert_web_font.php' );
require_once( DP_THEME_DIR . '/inc/scr/control/is_mobile_dp.php' );
require_once( DP_THEME_DIR . '/inc/scr/control/misc.php' );
require_once( DP_THEME_DIR . '/inc/scr/control/normarize.php' );
require_once( DP_THEME_DIR . '/inc/scr/control/post_views.php' );
require_once( DP_THEME_DIR . '/inc/scr/control/pre_get_posts.php' );
require_once( DP_THEME_DIR . '/inc/scr/control/redirect_to_mobile_theme.php' );
require_once( DP_THEME_DIR . '/inc/scr/control/theme_support.php' );

// Generator
require_once( DP_THEME_DIR . '/inc/scr/generator/create_meta.php' );
require_once( DP_THEME_DIR . '/inc/scr/generator/create_title_desc.php' );
require_once( DP_THEME_DIR . '/inc/scr/generator/inline_styles.php' );
require_once( DP_THEME_DIR . '/inc/scr/generator/js_for_sns_objects.php' );
require_once( DP_THEME_DIR . '/inc/scr/generator/json_ld.php' );
require_once( DP_THEME_DIR . '/inc/scr/generator/listing_post_styles.php' );
require_once( DP_THEME_DIR . '/inc/scr/generator/meta_info_archive.php' );
require_once( DP_THEME_DIR . '/inc/scr/generator/meta_info_singular.php' );
require_once( DP_THEME_DIR . '/inc/scr/generator/shortcodes.php' );
require_once( DP_THEME_DIR . '/inc/scr/generator/show_ogp.php' );
require_once( DP_THEME_DIR . '/inc/scr/generator/split_page_links.php' );

// Partial parts
require_once( DP_THEME_DIR . '/inc/scr/parts/breadcrumb.php' );
require_once( DP_THEME_DIR . '/inc/scr/parts/offcanvas_area.php' );
require_once( DP_THEME_DIR . '/inc/scr/parts/pagination.php' );
require_once( DP_THEME_DIR . '/inc/scr/parts/post_thumbnail.php' );
require_once( DP_THEME_DIR . '/inc/scr/parts/related_posts.php' );
require_once( DP_THEME_DIR . '/inc/scr/parts/search_form.php' );
require_once( DP_THEME_DIR . '/inc/scr/parts/show_banner_contents.php' );
require_once( DP_THEME_DIR . '/inc/scr/parts/sns_contact_icons.php' );
require_once( DP_THEME_DIR . '/inc/scr/parts/sns_follow_box.php' );
require_once( DP_THEME_DIR . '/inc/scr/parts/sns_share_buttons.php' );
require_once( DP_THEME_DIR . '/inc/scr/parts/sort_form.php' );
require_once( DP_THEME_DIR . '/inc/scr/parts/toc.php' );

// Widgets
require_once( DP_THEME_DIR . '/inc/scr/widgets/footer_widgets.php' );
require_once( DP_THEME_DIR . '/inc/scr/widgets/widgets.php' );
require_once( DP_THEME_DIR . '/inc/scr/widgets/widget_categories.php' );
require_once( DP_THEME_DIR . '/inc/scr/widgets/widget_recent_comments.php' );
require_once( DP_THEME_DIR . '/inc/scr/widgets/widget_tag_cloud.php' );
require_once( DP_THEME_DIR . '/inc/scr/widgets/widget_for_archive.php' );
require_once( DP_THEME_DIR . '/inc/scr/widgets/widget_tabs.php' );



/**
* Set globals before the site is about to showing.
*/
add_action( 'after_setup_theme', 'is_mobile_dp', 11 );
add_action( 'wp', 'get_column_num' );
add_action( 'wp', 'dp_get_archive_style' );
add_action( 'wp', 'dp_get_post_type' );
add_action( 'wp', 'is_woocommerce_dp' );
add_action( 'wp', 'get_post_meta_for_single_page' );
add_action( 'wp', 'dp_get_elements_visibility', 11 );

//Add option menu into admin panel header and insert CSS and scripts to DigiPress panel.
add_action( 'admin_menu', array( 'digipress_options', 'add_menu' ) );
add_action( 'admin_menu', array( 'digipress_options', 'dp_export_all_settings' ) );
add_action( 'admin_menu', array( 'digipress_options', 'dp_import_all_settings' ) );
add_action( 'admin_menu', array( 'digipress_options', 'reset_theme_options' ) );
add_action( 'admin_menu', array( 'digipress_options', 'clear_all_cache' ) );

/**
 * Export CSS file when saved by theme customizer
 * Disable inserting inline CSS and uses export css file.
 */
add_action( 'customize_save_after', 'dp_css_create', 10, 1 );