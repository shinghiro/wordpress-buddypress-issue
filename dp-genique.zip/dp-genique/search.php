<?php 
/**
 * Header (main-wrap > container > content)
 */
get_header();
/**
 * show posts
 */
// Check the query
if (isset( $_REQUEST['q'] )) {
	// Google Custom Search?>
<gcse:searchresults-only></gcse:searchresults-only><?php
} else {
	if ( isset($_GET['s']) && empty($_GET['s']) ) { ?>
<div class="entry not-found"><div><?php _e( 'Please enter a search word.', 'DigiPress'); ?></div></div><?php
	} else {

		if ( have_posts() ) {
			require_once( DP_THEME_DIR . '/inc/scr/article-loop.php' );
			$loop_code = dp_article_loop( $posts );
			echo $loop_code;

			// Content bottom widget
			if (is_active_sidebar('widget-content-bottom')) {
				ob_start();
				dynamic_sidebar( 'widget-content-bottom' );
				$widget_content_btm_content = ob_get_contents();
				ob_end_clean();

				if ( !empty( $widget_content_btm_content ) ) {
					echo '<div class="widget-content bottom clearfix">' . $widget_content_btm_content . '</div>';
				}
			}
		} else {?>
<div class="entry not-found"><?php
			printf( __( 'Sorry, but nothing matched your search terms : %s.', 'DigiPress'), esc_html($_GET['s']) );?>
</div><?php
		}	// End of have_posts()
	}	// End of isset($_GET['s']) && empty($_GET['s'])
}	// End of isset( $_REQUEST['q'] )?>
</main><?php // end of .content
/**
 * Sidebar
 */
if ( $COLUMN_NUM === 2 ) get_sidebar();
/**
 * Footer
 */
get_footer();