<?php
if ( function_exists( 'wp_nav_menu' ) && has_nav_menu( 'global_menu' ) ) { ?>
<div class="hd_bar_content<?php echo $wow_menu_css; ?>"><?php

	/**
	 * Default menu
	 */
	function show_wp_global_menu_list() {?>
<ul id="global_menu_ul" class="global_menu_ul has_chaser_ul"><li class="menu-item"><a href="<?php echo home_url('/'); ?>" title="HOME" class="menu-link"><span class="menu-title"><i class="icon-home"></i><?php _e('HOME','DigiPress'); ?></span></a></li><li class="menu-item"><a href="<?php echo get_feed_link(); ?>" target="_blank" title="feed" class="menu-link"><span class="menu-title"><i class="icon-rss"></i>RSS</span></a></li></ul><?php
	} //End Function

?>
<nav id="global_menu_nav" class="global_menu_nav bar_item"><?php

	$menu_class = 'global_menu_ul has_chaser_ul';
	if (isset($options['disable_pjax']) && !empty($options['disable_pjax'])){
		$menu_class .= ' no_pjax';
	} else {
		$menu_class .= ' on_pjax';
	}

	// Show menu
	wp_nav_menu(array(
		'theme_location'=> 'global_menu',
		'container'	=> '',
		'menu_id'	=> 'global_menu_ul',
		'menu_class'=> $menu_class,
		'fallback_cb'=> 'show_wp_global_menu_list',
		'walker'	=> new dp_custom_mega_menu_walker()
	));?>
</nav>
</div><?php // End of .hd_bar_content
}	// End of has_nav_menu('global_menu_ul')