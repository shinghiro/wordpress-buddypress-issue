<?php 
/**
 * Header (main-wrap > container > content)
 */
get_header();
/**
 * show posts
 */
if ( $options['top_page_main_content'] === 'page' ) :
	// Display the specific static page
	$post_content = get_post( (int)$options['specific_page_id'] )->post_content;
	$post_content = apply_filters( 'the_content', $post_content );

	echo '<article id="page-' . $options['specific_page_id'] . '" class="single-article as-home"><div class="entry entry-content">' . $post_content . '</div></article>';
else :
	if ( have_posts() ) :
		require_once( DP_THEME_DIR . '/inc/scr/article-loop.php' );
		$loop_code = dp_article_loop( $posts );
		echo $loop_code;
	endif;	// End of have_posts()
endif;	// End of ($options['top_page_main_content'] === 'page')
/**
 * Content bottom widget
 */
if ( is_active_sidebar('widget-content-bottom') ) {
	ob_start();
	dynamic_sidebar( 'widget-content-bottom' );
	$widget_content_btm_content = ob_get_contents();
	ob_end_clean();

	if ( !empty( $widget_content_btm_content ) ) {
		echo '<div class="widget-content bottom clearfix">' . $widget_content_btm_content . '</div>';
	}
}?>
</main><?php // end of .content
/**
 * Sidebar
 */
if ( $COLUMN_NUM === 2 ) get_sidebar();
/**
 * Footer
 */
get_footer();