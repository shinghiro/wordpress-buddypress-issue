<?php
// Defined at /scr/search_form.php
dp_custom_search_form();