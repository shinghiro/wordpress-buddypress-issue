<?php 
/**
 * Header (main-wrap > container > content)
 */
get_header();

//For thumbnail size
$width = 1680;
$height = 1200;

// insert article class
$post_class = "single-article";

// Col class
$col_class = ' two-col';
if ( $COLUMN_NUM === 1 ) {
	$col_class = ' one-col';
}

// wow.js
$wow_title_css = $wow_prof_img_css = $wow_prof_css = $wow_prof_desc_css = $wow_eyecatch_css = '';
if ( !(bool)$options['disable_wow_js'] ){
	$wow_title_css = ' wow fadeInDown';
	$wow_prof_img_css = ' wow fadeInLeft';
	$wow_prof_css = ' wow fadeInRight';
	$wow_prof_desc_css =' wow fadeInDown';
	$wow_eyecatch_css = ' wow fadeInUp';
}

/**
 * show posts
 */
if ( have_posts() ) :
	$this_id = get_the_ID();

	// Variants
	$float_content = $first_row = $second_row = $meta_code_top = $meta_code_end = $author_code = '';

	// Count Post View
	if ( function_exists( 'dp_count_post_views' ) ) {
		dp_count_post_views( $this_id, true );
	}

	// Auto display eyecatch
	$show_eyecatch_first = $options['show_eyecatch_first'];
	// Show eyecatch on top
	$show_eyecatch_force = get_post_meta( $this_id, 'dp_show_eyecatch_force', true );
	// Show eyecatch upper the title
	$eyecatch_on_container = get_post_meta( $this_id, 'dp_eyecatch_on_container', true );
	// Hide author prof
	$hide_author_prof = get_post_meta( $this_id, 'dp_hide_author_prof', true );
	// Hide next prev
	$hide_next_prev = get_post_meta( $this_id, 'dp_hide_next_prev', true );
	// Slider image
	$sl_img1 = get_post_meta( $this_id, 'dp_archive_slider_img1', true );
	$sl_img2 = get_post_meta( $this_id, 'dp_archive_slider_img2', true );
	$sl_img3 = get_post_meta( $this_id, 'dp_archive_slider_img3', true );

	// Create meta data
	if ( !(bool)post_password_required() ) {
		/**
		 * float content
		 */
		// SNS buttons
		if ( !empty( $SINGLE_META['sns_btn'] ) ) {
			$float_content = '<div id="single_float_div" class="single_float_div"><input type="checkbox" role="button" id="share-tgl-chk" title="shares" /><label for="share-tgl-chk" aria-hidden="true" class="share-tgl" title="shares"><i class="icon-share"></i></label><div class="inner">' . $SINGLE_META['sns_btn'] . '</div></div>';
		}

		/**
		 * Meta No.1
		 */
		//*** filter hook
		if ( $CURRENT_POST_TYPE === 'post' ) {
			$filter_top_first = apply_filters( 'dp_single_meta_top_first', $this_id );
			$filter_top_end = apply_filters( 'dp_single_meta_top_end', $this_id );
			if ( !empty( $filter_top_first) && $filter_top_first != $this_id ) {
				$meta_code_top = $filter_top_first;
			}
			if ( !empty( $filter_top_end) && $filter_top_end != $this_id ) {
				$meta_code_top .= $filter_top_end;
			}
			if ( !empty( $meta_code_top) ){
				$meta_code_top = '<div class="single_post_meta">' . $meta_code_top . '</div>';
			}
		}
		/**
		 * Meta No.2
		 */
		// Reset params
		//*** filter hook
		if ( $CURRENT_POST_TYPE === 'post' ) {
			$filter_bottom_first = apply_filters( 'dp_single_meta_bottom_first', $this_id );
			if ( !empty( $filter_bottom_first) && $filter_bottom_first != $this_id ) {
				$first_row = $filter_bottom_first;
			}
		}

		// SNS follow box
		$first_row .= dp_sns_follow_box();

		// category + tags
		$first_row .= $SINGLE_META['cat_bottom_code'] . $SINGLE_META['tags'];
		// First row
		if ( !empty( $first_row) ) {
			$first_row = '<div class="first_row">' . $first_row . '</div>';
		}

		// Date
		if ( !empty( $SINGLE_META['date_bottom'] ) ) {
			$date_eng_flg = (bool)$options['date_eng_mode'] ? ' eng' : '';
			$second_row = '<div class="meta meta-date' . $date_eng_flg.'">' . $SINGLE_META['date_bottom'] . $SINGLE_META['last_update'].'</div>';
		}
		// Combine others
		$second_row .= $SINGLE_META['author_bottom_code'] . $SINGLE_META['comments'] . $SINGLE_META['post_comment'] . $SINGLE_META['views_bottom_code'] . $SINGLE_META['edit_link'];
		// First row
		if ( !empty( $second_row) ) {
			$second_row = '<div class="second_row">' . $second_row.'</div>';
		}

		//*** filter hook
		if ( $CURRENT_POST_TYPE === 'post' ) {
			$filter_bottom_end = apply_filters( 'dp_single_meta_bottom_end', $this_id );
			if ( !empty( $filter_bottom_end) && $filter_bottom_end != $this_id ) {
				$second_row .= $filter_bottom_end;
			}
		}
		// meta on bottom
		if ( !empty( $first_row) || !empty( $second_row) ) {
			$meta_code_end = '<footer class="single_post_meta bottom">' . $first_row.$second_row.'</footer>';
		}

		// **********************************
		// Get author codes (Call this function written in "get_author_info.php")
		// **********************************
		if (isset( $options['show_author_info'] ) && !empty( $options['show_author_info'] ) && !(bool)$hide_author_prof && $CURRENT_POST_TYPE === 'post') {
			// Import require functions
			require_once( DP_THEME_DIR . '/inc/scr/generator/get_author_info.php' );
			// Params
			$args = array('return_array'=> true,
						'is_microdata'	=> true,
						'avatar_size' 	=> 240);
			$author_info_title = isset( $options['author_info_title'] ) && !empty( $options['author_info_title'] ) ? '<h3 class="inside-title' . $wow_title_css . '"><span>' . $options['author_info_title'] . '</span></h3>' : '';

			$arr_author = dp_get_author_info( $args);
			$author_code = '<div itemscope itemtype="http://data-vocabulary.org/Person" class="author_info">' . $author_info_title . '<div class="author_col one ' . $wow_title_css . '">' . $arr_author['profile_img'] . '</div><div class="author_col two ' . $wow_prof_css . '">' . $arr_author['author_roles'].'</div><div class="author_col three' . $wow_prof_desc_css . '">' . $arr_author['author_desc'] . '</div><div class="' . $wow_eyecatch_css . '">' . $arr_author['author_url'] . $arr_author['author_sns_code'].'</div>' . dp_get_author_posts(6) . '</div>';

			$post_class .= ' has_profile';
		}
	}

	/**
	 * Article area start
	 */
	while ( have_posts() ) : the_post(); ?>
<article id="<?php echo $CURRENT_POST_TYPE.'-' . $this_id; ?>" <?php post_class( $post_class ); ?>><?php
		// header meta
		echo $meta_code_top;
		/**
		 * Single header widget
		 */
		if ( ( $CURRENT_POST_TYPE === 'post' ) && is_active_sidebar( 'widget-post-top' ) && !post_password_required() ) : ?>
<div class="widget-content single clearfix"><?php dynamic_sidebar( 'widget-post-top' ); ?></div><?php 
		endif;	// End of widget

		/**
		 * Main entry
		 */?>
<div class="entry entry-content"><?php

		/**
		 * Show eyecatch image
		 */
		global $page;
		$post_header_code = '';
		$flag_eyecatch_first = false;

		// Slideshow
		if ( ( $sl_img1 || $sl_img2 || $sl_img3) && !empty( $SINGLE_META['free_meta_code'] ) && $page === 1 ) {
			wp_enqueue_style( 'dp-swiper', DP_THEME_URI . '/css/swiper-bundle.css', null, DP_OPTION_SPT_VERSION );
			wp_enqueue_script( 'dp-swiper', DP_THEME_URI . '/inc/js/swiper-bundle.min.js', null, false, true );
			if ( $sl_img1) $sl_img1 = '<figure class="swiper-slide"><div class="sl-img"><img src="' . $sl_img1 . '" alt="Slide Image" class="figure-img" /></div></figure>';
			if ( $sl_img2) $sl_img2 = '<figure class="swiper-slide"><div class="sl-img"><img src="' . $sl_img2 . '" alt="Slide Image" class="figure-img" /></div></figure>';
			if ( $sl_img3) $sl_img3 = '<figure class="swiper-slide"><div class="sl-img"><img src="' . $sl_img3 . '" alt="Slide Image" class="figure-img" /></div></figure>';
			$post_header_code = '<div class="swiper aslider"><div class="swiper-wrapper">' . $sl_img1 . $sl_img2 . $sl_img3 . '</div><div class="swiper-button-prev"></div><div class="swiper-button-next"></div></div>';
			$flag_eyecatch_first = true;
		} else {
			if ( has_post_thumbnail() && $CURRENT_POST_TYPE === 'post' && $page === 1 ) {
				if ( $show_eyecatch_first ) {
				 	if ( !( $show_eyecatch_force && $eyecatch_on_container) ) {
				 		$flag_eyecatch_first = true;
					}
				} else {
					if ( $show_eyecatch_force && !$eyecatch_on_container ) {
						$flag_eyecatch_first = true;
					}
				}
			}
			if ( $flag_eyecatch_first || !empty( $SINGLE_META['free_meta_code'] ) ) {
				$image_id	= get_post_thumbnail_id();
				$image_data	= wp_get_attachment_image_src( $image_id, array( $width, $height), true );
				$image_url 	= is_ssl() ? str_replace('http:', 'https:', $image_data[0]) : $image_data[0];
				$img_tag	= '<img src="' . $image_url . '" class="wp-post-image aligncenter" alt="' . strip_tags(get_the_title() ) . '" width="' . $image_data[1] . '" height="' . $image_data[2] . '" />';

				 $post_header_code = '<figure class="eyecatch-under-title' . $wow_eyecatch_css . '">' . $img_tag . '</figure>';
			}
		}
		if ( !empty( $SINGLE_META['free_meta_code'] ) ) {
			echo '<div class="fmeta_area"><div class="fmeta_cell one">' . $post_header_code . '</div><div class="fmeta_cell two">' . $SINGLE_META['free_meta_code'] . '</div></div>';
		} else {
			echo $post_header_code;
		}

		/**
		 * Content
		 */
		the_content();

		/**
		 * Paged navigation
		 */
		wp_link_pages(array(
			'before' => '<nav class="navigation"><div class="dp-pagenavi">',
			'after' => '</div></nav>',
			'link_before' => '<span class="page-number">',
			'link_after' => '</span>',
			'next_or_number' => 'next_and_number',
			// 'separator' => ' ',
			// 'next_or_number' => 'next',
			// 'nextpagelink'	=> __( 'Next Page', 'DigiPress' ),
			'nextpagelink'	=> get_post_meta( $this_id, 'nextpage_text', true ),
			'previouspagelink'	=> '',
			'echo' => 1,
		) ); ?>
</div><?php 	// End of class="entry"

		/**
		 * Single footer widget
		 */
		if ( $CURRENT_POST_TYPE === 'post' && is_active_sidebar('widget-post-bottom') && !post_password_required() ) : ?>
<div class="widget-content single clearfix"><?php dynamic_sidebar( 'widget-post-bottom' ); ?></div><?php
		endif;
		/**
		 * Bottom meta
		 */
		echo $meta_code_end;
		/**
		 * Author profile
		 */
		echo $author_code;?>
</article><?php
		/**
		 * Related posts
		 */
		dp_get_related_posts();

		/**
		 * Prev / Next post navigation
		 */
		if ( !(isset( $options['hide_next_prev_post'] ) && !empty( $options['hide_next_prev_post'] ) ) && !$hide_next_prev) {
			$same_cat = isset( $options['same_cat_next_prev_post'] ) && !empty( $options['same_cat_next_prev_post'] ) ? true : false;
			$arr_ex_cats = isset( $options['exclude_cats_next_prev_post'] ) && !empty( $options['exclude_cats_next_prev_post'] ) ? explode(',', $options['exclude_cats_next_prev_post'] ) : '';
			$nav_url = $nav_title = $nav_img_url = '';
			// Next post title
			$next_post = get_next_post( $same_cat, $arr_ex_cats );
			// Previous post title
			$prev_post = get_previous_post( $same_cat, $arr_ex_cats );

			if ( $CURRENT_POST_TYPE === 'post' && ( $prev_post || $next_post) ) { ?>
<nav id="single-nav" class="single-nav <?php echo $col_class; ?>"><ul class="clearfix"><?php
				// Prev post
				if ( $prev_post) {
					if ( $CURRENT_POST_TYPE === 'post') {
						$nav_url = get_permalink( $prev_post->ID );
						$nav_title = get_the_title( $prev_post->ID );
						$arg_thumb = array('width' => 240, 'height' => 160, "size"=>"dp-related-thumb", "if_img_tag"=> false, "post_id" => $prev_post->ID);
						$nav_img_url = DP_Post_Thumbnail::get_post_thumbnail( $arg_thumb );
					}
					echo '<li class="is-left"><a href="' . $nav_url . '" class="navlink"><span class="nav-arrow icon-left-light" role="none"></span><figure><img src="' . $nav_img_url . '" class="post-img" alt="Previous" width="100" height="100" /></figure><div class="desc">' . strip_tags( $nav_title) . '</div></a></li>';
				}
				// Next post
				if ( $next_post) {
					if ( $CURRENT_POST_TYPE === 'post') {
						$nav_url = get_permalink( $next_post->ID );
						$nav_title = get_the_title( $next_post->ID );
						$arg_thumb = array('width' => 240, 'height' => 160, "size"=>"dp-related-thumb", "if_img_tag"=> false, "post_id" => $next_post->ID);
						$nav_img_url = DP_Post_Thumbnail::get_post_thumbnail( $arg_thumb );
					}
					echo '<li class="is-right"><a href="' . $nav_url . '" class="navlink"><span class="nav-arrow icon-right-light" role="none"></span><figure><img src="' . $nav_img_url . '"class="post-img" alt="Next" width="100" height="100" /></figure><div class="desc">' . strip_tags( $nav_title ) . '</div></a></li>';
				}?>
</ul></nav><?php 
			}	// End of ( $prev_post || $next_post)
		}	// End of !(isset( $options['hide_next_prev_post'] ) && !empty( $options['hide_next_prev_post'] ) )
		/**
		 * Comments
		 */
		comments_template();
	endwhile;	// End of (have_posts() )

	/**
	 * Content bottom widget
	 */
	if ( is_active_sidebar('widget-content-bottom') ) {
		ob_start();
		dynamic_sidebar( 'widget-content-bottom' );
		$widget_content_btm_content = ob_get_contents();
		ob_end_clean();

		if ( !empty( $widget_content_btm_content ) ) {
			echo '<div class="widget-content bottom clearfix">' . $widget_content_btm_content . '</div>';
		}
	}
	// Float content
	echo $float_content;
else :	// have_posts()
	// Not found...
	include_once(TEMPLATEPATH .'/not-found.php');
endif;	// End of have_posts()?>
</main><?php // end of .content
/**
 * Sidebar
 */
if ( $COLUMN_NUM === 2 ) get_sidebar();
/**
 * Footer
 */
get_footer();