window.console.log( '`widget-friends.js` is deprecated since 12.0.0, please use the BP Classic plugin to use BP Legacy Widgets.' );
